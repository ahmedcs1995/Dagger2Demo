package com.mobileapp.krank.Model.Enums

enum class SplashLinkReceived{
    LISTING_PAGE,
    PENDING_REQUEST,
    PEOPLE_YOU_MAY_KNOW,
    USER_PROFILE,
    COMPANY_PROFILE,
    DEFAULT_WEB_VIEW,
    ARTICLE,
    CHAT,
    GROUP_CHAT,
    APP_VIEW,
    WIZARD,
    DISCOVER,
}