package com.mobileapp.krank.Activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.InviteCompaniesResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InviteCompaniesAndCoWorker extends BaseActivity {

    TextView invitation_url_text_box;
    View send_invitation_btn;
    View email_btn;

    public static final String PAGE_NAME_INTENT_KEY ="page_name";
    public static final String IS_PRIVATE_CONNECTION_KEY ="private_connection_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_companies_and_co_worker);
        invitation_url_text_box = findViewById(R.id.invitation_url_text_box);
        send_invitation_btn = findViewById(R.id.send_invitation_btn);
        email_btn = findViewById(R.id.email_btn);

        setNormalPageToolbar(getIntentPageNameData());

        if (!preference.getString(Constants.INVITE_COMPANIES_URL).isEmpty()) {
            setTextInTextBox();
        }
        send_invitation_btn.setOnClickListener(view -> {
            if(isPrivateConnectionPage()){
                AppUtils.invitePrivateConnections(preference,this);
                return;
            }
            else if(isCoworkerScreen()){
                AppUtils.inviteCoWorkerInvite(preference,InviteCompaniesAndCoWorker.this);
                return;
            }
            AppUtils.inviteCompaniesAndCoWorkerInvite(preference,InviteCompaniesAndCoWorker.this);
        });

        email_btn.setOnClickListener(view -> sendInvitationThroughEmail());


    }


    private boolean isCoworkerScreen(){
        return getIntent().getStringExtra("page_name").equals("Add Co Workers");
    }

    private String getIntentPageNameData() {
        return getIntent().getStringExtra(PAGE_NAME_INTENT_KEY);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private boolean isPrivateConnectionPage(){
        return getIntent().getBooleanExtra(IS_PRIVATE_CONNECTION_KEY,false);
    }

    private void setTextInTextBox(){
        String url = preference.getString(Constants.INVITE_COMPANIES_URL);
        if(isPrivateConnectionPage()){
           url = url + "/p";
        }
        invitation_url_text_box.setText(url);
    }

    private void sendInvitationThroughEmail(){

        String subject = "Krank Invitation";
        String body;


        if(isPrivateConnectionPage()){
            body = Constants.PRIVATE_INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL) + "/p";
        }else if(isCoworkerScreen()){
            body = Constants.INVITE_CO_WORKER_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL);
        }
        else{
            body = Constants.INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL);
        }


        String mailto = "mailto:" +
                "?cc=" + "" +
                "&subject=" + Uri.encode(subject) +
                "&body=" + Uri.encode(body);

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse(mailto));

        try {
            startActivity(emailIntent);
        } catch (ActivityNotFoundException e) {
            //TODO: Handle case where no email app is available
        }
    }
}
