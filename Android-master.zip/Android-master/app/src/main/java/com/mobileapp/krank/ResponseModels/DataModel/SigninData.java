package com.mobileapp.krank.ResponseModels.DataModel;

/**
 * Created by arbaz on 5/23/2018.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SigninData {

    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("u_id")
    @Expose
    private String uId;
    @SerializedName("u_id_aes")
    @Expose
    private String uIdAes;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("user_profile_pic")
    @Expose
    private String userProfilePic;
    @SerializedName("user_cover_pic")
    @Expose
    private String userCoverPic;
    @SerializedName("job_title")
    @Expose
    private String jobTitle;
    @SerializedName("mobile_number")
    @Expose
    private String mobileNumber;
    @SerializedName("company_invitation")
    @Expose
    private String company_invitation;
    @SerializedName("is_operator")
    @Expose
    private String isOperator;
    @SerializedName("is_lineAdmin")
    @Expose
    private String isLineAdmin;
    @SerializedName("userStatus")
    @Expose
    private String userStatus;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("package_id")
    @Expose
    private String packageId;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("company_cover_pic")
    @Expose
    private String companyCoverPic;
    @SerializedName("companyStatus")
    @Expose
    private String companyStatus;
    @SerializedName("country_code")
    @Expose
    private String countryCode;
    @SerializedName("country_dial_code")
    @Expose
    private String countryDialCode;
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("city_id")
    @Expose
    private String cityId;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("user_total_connections")
    @Expose
    private String userTotalConnections;
    @SerializedName("user_total_networks")
    @Expose
    private String userTotalNetworks;
    @SerializedName("user_total_listings")
    @Expose
    private String userTotalListings;
    @SerializedName("user_total_company_listings")
    @Expose
    private String userTotalCompanyListings;
    @SerializedName("user_total_listing_limit")
    @Expose
    private String userTotalListingLimit;
    @SerializedName("email_address")
    @Expose
    private String email_address;
    @SerializedName("history_id")
    @Expose
    private int history_id;

    @SerializedName("verify_status")
    @Expose
    private String verify_status;

    @SerializedName("department_name")
    @Expose
    private String department_name;

    @SerializedName("invitedByUser")
    @Expose
    private String invitedByUser;

    @SerializedName("invitedByUserName")
    @Expose
    private String invitedByUserName;

    @SerializedName("total_contacts")
    @Expose
    private int total_contacts;

    @SerializedName("my_contacts")
    @Expose
    private int my_contacts;

    @SerializedName("last_sync_date")
    @Expose
    private String last_sync_date;

    @SerializedName("contact_popup_meta_key")
    @Expose
    private String contact_popup_meta_key;

    @SerializedName("user_slug")
    @Expose
    private String user_slug;







    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUId() {
        return uId;
    }

    public void setUId(String uId) {
        this.uId = uId;
    }

    public String getUIdAes() {
        return uIdAes;
    }

    public void setUIdAes(String uIdAes) {
        this.uIdAes = uIdAes;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public String getUserCoverPic() {
        return userCoverPic;
    }

    public void setUserCoverPic(String userCoverPic) {
        this.userCoverPic = userCoverPic;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getIsOperator() {
        return isOperator;
    }

    public void setIsOperator(String isOperator) {
        this.isOperator = isOperator;
    }

    public String getIsLineAdmin() {
        return isLineAdmin;
    }

    public void setIsLineAdmin(String isLineAdmin) {
        this.isLineAdmin = isLineAdmin;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getCompanyCoverPic() {
        return companyCoverPic;
    }

    public void setCompanyCoverPic(String companyCoverPic) {
        this.companyCoverPic = companyCoverPic;
    }

    public String getCompanyStatus() {
        return companyStatus;
    }

    public void setCompanyStatus(String companyStatus) {
        this.companyStatus = companyStatus;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryDialCode() {
        return countryDialCode;
    }

    public void setCountryDialCode(String countryDialCode) {
        this.countryDialCode = countryDialCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getUserTotalConnections() {
        return userTotalConnections;
    }

    public void setUserTotalConnections(String userTotalConnections) {
        this.userTotalConnections = userTotalConnections;
    }

    public String getUserTotalNetworks() {
        return userTotalNetworks;
    }

    public void setUserTotalNetworks(String userTotalNetworks) {
        this.userTotalNetworks = userTotalNetworks;
    }

    public String getUserTotalListings() {
        return userTotalListings;
    }

    public void setUserTotalListings(String userTotalListings) {
        this.userTotalListings = userTotalListings;
    }

    public String getUserTotalCompanyListings() {
        return userTotalCompanyListings;
    }

    public void setUserTotalCompanyListings(String userTotalCompanyListings) {
        this.userTotalCompanyListings = userTotalCompanyListings;
    }

    public String getUserTotalListingLimit() {
        return userTotalListingLimit;
    }

    public void setUserTotalListingLimit(String userTotalListingLimit) {
        this.userTotalListingLimit = userTotalListingLimit;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }

    public int getHistory_id() {
        return history_id;
    }

    public void setHistory_id(int history_id) {
        this.history_id = history_id;
    }

    public String getVerify_status() {
        return verify_status;
    }

    public void setVerify_status(String verify_status) {
        this.verify_status = verify_status;
    }

    public String getDepartment_name() {
        return department_name;
    }

    public void setDepartment_name(String department_name) {
        this.department_name = department_name;
    }

    public String getCompany_invitation() {
        return company_invitation;
    }

    public void setCompany_invitation(String company_invitation) {
        this.company_invitation = company_invitation;
    }

    public String getInvitedByUser() {
        return invitedByUser;
    }

    public void setInvitedByUser(String invitedByUser) {
        this.invitedByUser = invitedByUser;
    }

    public String getInvitedByUserName() {
        return invitedByUserName;
    }

    public void setInvitedByUserName(String invitedByUserName) {
        this.invitedByUserName = invitedByUserName;
    }

    public int getTotal_contacts() {
        return total_contacts;
    }

    public void setTotal_contacts(int total_contacts) {
        this.total_contacts = total_contacts;
    }

    public int getMy_contacts() {
        return my_contacts;
    }

    public void setMy_contacts(int my_contacts) {
        this.my_contacts = my_contacts;
    }

    public String getLast_sync_date() {
        return last_sync_date;
    }

    public void setLast_sync_date(String last_sync_date) {
        this.last_sync_date = last_sync_date;
    }

    public String getContact_popup_meta_key() {
        return contact_popup_meta_key;
    }

    public void setContact_popup_meta_key(String contact_popup_meta_key) {
        this.contact_popup_meta_key = contact_popup_meta_key;
    }

    public String getUser_slug() {
        return user_slug;
    }

    public void setUser_slug(String user_slug) {
        this.user_slug = user_slug;
    }
}