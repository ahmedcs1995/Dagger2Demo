package com.mobileapp.krank.ResponseModels.DataModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ListingDealerResponseDataModel {
    @SerializedName("dealer")
    @Expose
    private DealerDataListing dealer;
    @SerializedName("reps")
    @Expose
    private List<ListingDealerRepDataModel> reps = null;

    public DealerDataListing getDealer() {
        return dealer;
    }

    public void setDealer(DealerDataListing dealer) {
        this.dealer = dealer;
    }

    public List<ListingDealerRepDataModel> getReps() {
        return reps;
    }

    public void setReps(List<ListingDealerRepDataModel> reps) {
        this.reps = reps;
    }

}
