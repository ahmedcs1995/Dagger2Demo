package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse


import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Model.Enums.ConNetStatus
import com.mobileapp.krank.Utils.SaveInSharedPreference
import com.mobileapp.krank.Utils.ServiceManager
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.BaseViewHolder
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.ListItemViewHolder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * Created by Yaseen on 28/04/2018.
 */


class ListOfEmployeesAndConnectionsAdapter(internal var items: MutableList<GetNetworkEmployeeData>, internal var context: Context, internal var callBack: CallBackWithAdapterPosAndType?) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), CallBackWithPosTypeAndView {


    override fun act(position: Int, type: Int, view: View) {
        onConnectionButtonPressed(position, view)
    }




    //flag
    private var hideCoWorkerView: Boolean = false

    //phone book section
    var phoneBookViewText: String? = null


    private var preference = SaveInSharedPreference.getInstance(context)
    private var serviceManager = ServiceManager.getInstance()


    inner class ConnectContactsViewHolder(item: View) : BaseViewHolder(item) {

        var connect_textview: TextView = item.findViewById(R.id.connect_textview)

        init {
            status_btn_container.setOnClickListener {
                if (callBack == null || adapterPosition < 0) return@setOnClickListener
                callBack?.act(adapterPosition, SYNC_CONTACTS)
            }
        }

        fun onBind() {
            getStatusView(ConNetStatus.NOT_CONNECTED, context)
            if (phoneBookViewText != null) {
                connect_textview.text = phoneBookViewText
            }

        }
    }


    fun setFlag(hideCoWorkerView: Boolean) {
        this.hideCoWorkerView = hideCoWorkerView
    }

    fun removeListLoader() {
        for (i in items.indices.reversed()) {
            if (items[i].viewType == GetNetworkEmployeeData.LOADER_VIEW) {
                items.removeAt(i)
                notifyItemRemoved(i)
                notifyItemRangeChanged(i, items.size)
                break
            }
        }
    }

    private fun onConnectionButtonPressed(position: Int, view: View) {
        //connection and network request
        when (AppUtils.getConNetStatus(items[position].conStatus)) {
            ConNetStatus.REQUEST_PENDING -> {

            }
            ConNetStatus.CONNECTED -> {
                if (Integer.parseInt(items[position].id) != Constants.EMMA_COOPER_ID) {
                    removeConnection(view, items[position], position)
                }
            }
            ConNetStatus.INVITATION_RECEIVED -> {
                view.isEnabled = false
                acceptRequest(view, items[position], position)
            }
            ConNetStatus.NOT_CONNECTED -> {
                view.isEnabled = false
                sendConnectionRequest(view, items[position], position)
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var v: View
        return when (viewType) {
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.view_connections_in_my_network_item, parent, false)
                ListItemViewHolder(v, callBack, this@ListOfEmployeesAndConnectionsAdapter)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }
            3 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.connect_contacts_list_item, parent, false)
                ConnectContactsViewHolder(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }

        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (items[position].viewType) {
            GetNetworkEmployeeData.NORMAL_VIEW -> 1
            GetNetworkEmployeeData.INVITE_CONTACTS_VIEW -> 1
            GetNetworkEmployeeData.LOADER_VIEW -> 2
            GetNetworkEmployeeData.CONNECT_PHONE_BOOK_VIEW -> 3
            else -> 2
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]

        when {
            item.viewType == GetNetworkEmployeeData.NORMAL_VIEW -> (holder as ListItemViewHolder).onBind(item, hideCoWorkerView, false, context)
            item.viewType == GetNetworkEmployeeData.CONNECT_PHONE_BOOK_VIEW -> setConnectContactView(holder as ConnectContactsViewHolder)

        }

    }


    private fun setConnectContactView(holder: ConnectContactsViewHolder) {
        holder.onBind()
    }

    private fun acceptRequest(btn: View, item: GetNetworkEmployeeData, position: Int) {
        changeStatus(item, position, Constants.CONNECTED_TEXT)

        serviceManager.api.acceptConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), item.conId.toString()).enqueue(object : Callback<GeneralResponse> {
            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                btn.isEnabled = true
                onResponseFailure()
            }

            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                btn.isEnabled = true
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                    } else {
                        showToast(response.body().message)
                        changeStatus(item, position, Constants.INVITATION_RECEIVED)
                    }
                } else {
                    btn.isEnabled = true
                    onResponseFailure()
                    changeStatus(item, position, Constants.INVITATION_RECEIVED)
                }
            }
        })

    }


    private fun onResponseFailure() {
        try {
            Toast.makeText(context, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show()
        } catch (ex: Exception) {

        }

    }

    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun sendConnectionRequest(view: View, item: GetNetworkEmployeeData, position: Int) {
        changeStatus(item, position, Constants.REQUEST_PENDING)


        serviceManager.api.sentConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), item.id.toInt()).enqueue(object : Callback<SentConnectionRequestResponse> {
            override fun onFailure(call: Call<SentConnectionRequestResponse>, t: Throwable) {
                view.isEnabled = true
                onResponseFailure()
                changeStatus(item, position, Constants.CONNECTION_NOT_CONNECTED)
            }

            override fun onResponse(call: Call<SentConnectionRequestResponse>, response: Response<SentConnectionRequestResponse>) {
                view.isEnabled = true
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                    } else {
                        showToast(response.body().message)
                        changeStatus(item, position, Constants.CONNECTION_NOT_CONNECTED)
                    }
                } else {
                    onResponseFailure()
                    changeStatus(item, position, Constants.CONNECTION_NOT_CONNECTED)
                }
            }
        })

    }

    private fun changeStatus(item: GetNetworkEmployeeData, position: Int, status: String) {
        item.conStatus = status
        notifyItemChanged(position)
    }


    private fun removeConnection(view: View, item: GetNetworkEmployeeData, position: Int) {
        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, context) as NormalAppDialog)
                .setHeading("Are you sure you want to remove this connection?")
                .setDescription("You will also be removed from this user's connection list.")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener {
                    removeConnectionApi(view, item, position)
                }
        dialog.show()
    }

    private fun removeConnectionApi(btn: View, item: GetNetworkEmployeeData, position: Int) {

        changeStatus(item, position, Constants.CONNECTION_NOT_CONNECTED)

        serviceManager.api.removeConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), item.id.toInt()).enqueue(object : Callback<GeneralResponse> {
            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                btn.isEnabled = true
                onResponseFailure()
                changeStatus(item, position, Constants.CONNECTED_TEXT)
            }

            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                btn.isEnabled = true
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                    } else {
                        showToast(response.body().message)
                        changeStatus(item, position, Constants.CONNECTED_TEXT)
                    }
                } else {
                    onResponseFailure()
                    changeStatus(item, position, Constants.CONNECTED_TEXT)
                }
            }
        })

    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun updateListItem(index: Int, connectionStatus: String?) {
        if (connectionStatus == null) return
        items[index].conStatus = connectionStatus
        notifyItemChanged(index)
    }

}





