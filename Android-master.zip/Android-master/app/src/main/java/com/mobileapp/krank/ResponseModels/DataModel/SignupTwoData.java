package com.mobileapp.krank.ResponseModels.DataModel;

/**
 * Created by arbaz on 5/15/2018.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class SignupTwoData {


        @SerializedName("email_address")
        @Expose
        private String emailAddress;

        public String getEmailAddress() {
            return emailAddress;
        }

        public void setEmailAddress(String emailAddress) {
            this.emailAddress = emailAddress;
        }

}
