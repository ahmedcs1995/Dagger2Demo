package com.mobileapp.krank.Model.Enums;

public enum TypeOfDetailInListing {
    TOP_HEADER,
    HEADING,
    DETAIL_ITEM,
    SPECIFICATION_URL,
    VIDEO_VIEW,
    PARTS_ITEM,
    LOCATION,
    BOTTOM_BUTTONS,
    ERROR_VIEW
}
