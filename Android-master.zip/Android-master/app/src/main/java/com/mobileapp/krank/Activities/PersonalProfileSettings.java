package com.mobileapp.krank.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.CustomDropDown.CityListActivity;
import com.mobileapp.krank.Activities.CustomDropDown.CountryListActivity;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.DataModel.PublicProfileData;
import com.mobileapp.krank.ResponseModels.PublicProfileResponse;
import com.mobileapp.krank.ResponseModels.UpdateProfileRespose;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonalProfileSettings extends BaseActivity {

    // edit text
    private EditText first_name_edit_text, last_name_edit_text, email_edit_text, job_edit_text, department_edit_text, telephone_edit_text;

    //btn
    private View save_btn;
    //private TextView error;
    private TextView mobile_code_edit_text;
    private ImageView profile_image_view;
    private SweetAlertDialog showProgressAlert;

    //activity codes
    private static int COUNTRY_LIST_ACTIVITY_CODE = 100;
    private static int CITY_LIST_ACTIVITY_CODE = 200;
    //country city
    EditText city_text;
    EditText country_text;
    CountyListData selectedCountryData;
    CityListData selectedCityData;
    PublicProfileData myProfileData;

    //scroll
    ScrollView mScrollView;

    private static final String UPDATE_PROFILE_MSG = "Updating profile Please wait...";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_profile_settings);
        setNormalPageToolbar("Personal Profile Settings");

        //loader
        showProgressAlert = showAlert(SweetAlertDialog.PROGRESS_TYPE, false);

        //input fields
        first_name_edit_text = findViewById(R.id.first_name_edit_text);
        last_name_edit_text = findViewById(R.id.last_name_edit_text);
        email_edit_text = findViewById(R.id.email_edit_text);
        job_edit_text = findViewById(R.id.job_edit_text);
        department_edit_text = findViewById(R.id.department_edit_text);
        telephone_edit_text = findViewById(R.id.telephone_edit_text);
        mobile_code_edit_text = findViewById(R.id.mobile_code_edit_text);
        profile_image_view = findViewById(R.id.profile_image_view);
        //     error = findViewById(R.id.error_view);
        //country city
        country_text = findViewById(R.id.country_text);
        city_text = findViewById(R.id.city_text);

        //other views
        save_btn = findViewById(R.id.save_btn);
        mScrollView = findViewById(R.id.scroll_view);


        if (getIntent().getStringExtra("profile_data") != null) {
            myProfileData = getIntentData();

            updateUI();

        } else {
            getDataFromCache();
            updateUI();
            telephone_edit_text.requestFocus();
            // getDataFromServer();
        }


    }

    private void getDataFromCache() {
        myProfileData = new PublicProfileData();

        //country
        myProfileData.setCountryName(getPreferencesData(Constants.COUNTRY));
        myProfileData.setCountry_code(getPreferencesData(Constants.COUNTRY_CODE));
        myProfileData.setCountry_dial_code(getPreferencesData(Constants.COUNTRY_DIAL_CODE));

        //city
        myProfileData.setCityName(getPreferencesData(Constants.CITY));
        myProfileData.setCity_id(getPreferencesData(Constants.CITY_ID_KEY));

        myProfileData.setFirstName(getPreferencesData(Constants.FIRST_NAME));
        myProfileData.setLastName(getPreferencesData(Constants.LAST_NAME));
        myProfileData.setEmailAddress(getPreferencesData(Constants.USER_EMAIL));
        myProfileData.setJobTitle(getPreferencesData(Constants.JOB_TITLE));
        myProfileData.setDepartmentName(getPreferencesData(Constants.DEPARTMENT));

        //phone number
        myProfileData.setMobileNumber(getPreferencesData(Constants.MOBILE_NUMBER));
    }

    private String getPreferencesData(String key) {
        return preference.getString(key);
    }

    private void bindListeners() {
        save_btn.setOnClickListener(v -> updateProfile(0));

        country_text.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), CountryListActivity.class);
           /* if (selectedCountryData == null) {
                intent.putExtra("countryData", "null");
            } else {
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
            }*/
            if (selectedCountryData != null) {
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
            }
            startActivityForResult(intent, COUNTRY_LIST_ACTIVITY_CODE);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
        city_text.setOnClickListener(view -> {


            if (selectedCountryData != null) {
                Intent intent = new Intent(getApplicationContext(), CityListActivity.class);
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
                startActivityForResult(intent, CITY_LIST_ACTIVITY_CODE);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            } else {
                Toast.makeText(getApplicationContext(), "Please Select Country", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUI() {
        /*country data*/
        if (myProfileData.getCountryName() != null && myProfileData.getCountry_code() != null && myProfileData.getCountry_dial_code() != null) {
            selectedCountryData = new CountyListData(myProfileData.getCountry_code(), myProfileData.getCountryName(), myProfileData.getCountry_dial_code());

        }

        /*city data*/
        if (myProfileData.getCityName() != null && myProfileData.getCity_id() != null) {
            selectedCityData = new CityListData(myProfileData.getCityName(), myProfileData.getCity_id());

        }


        // country
        if (selectedCountryData != null) {
            country_text.setText("" + selectedCountryData.getName());
        }

        if (selectedCountryData != null) {
            mobile_code_edit_text.setText(selectedCountryData.getPhoneCode());
        }


        //city
        if (selectedCityData != null) {
            city_text.setText("" + selectedCityData.getCityName());
        }


        setDataOnTextField(first_name_edit_text, myProfileData.getFirstName());
        setDataOnTextField(last_name_edit_text, myProfileData.getLastName());
        setDataOnTextField(email_edit_text, myProfileData.getEmailAddress());
        setDataOnTextField(job_edit_text, myProfileData.getJobTitle());
        setDataOnTextField(department_edit_text, myProfileData.getDepartmentName());

        //mobile number
        if (myProfileData.getMobileNumber() != null && myProfileData.getMobileNumber().indexOf('-') != -1) {
            telephone_edit_text.setText("" + myProfileData.getMobileNumber().substring(myProfileData.getMobileNumber().indexOf('-') + 1, myProfileData.getMobileNumber().length()));
        }

        //user img
        Glide.with(getApplicationContext()).load(Constants.BASE_IMG_URL + preference.getString(Constants.PROFILE_PICTURE)).into(profile_image_view);

        bindListeners();

    }

    private void updateProfile(int force_verify) {

        try {
            final String department = department_edit_text.getText().toString();
            final String jobTitle = job_edit_text.getText().toString();
            final String phone = selectedCountryData.getPhoneCode() + "-" + telephone_edit_text.getText().toString();
            if (jobTitle.isEmpty()) {
                //  error.setText(Constants.ENTER_JOB_TITLE);
                showToast(Constants.ENTER_JOB_TITLE);
            } /*else if (department.isEmpty()) {
                error.setText(Constants.ENTER_DEPT);
                scrollToTop();
            }*/
            else if(selectedCountryData == null){
                showToast(Constants.SELECT_COUNTRY);
            }
            else if(selectedCityData == null){
                showToast(Constants.SELECT_CITY);
            }
            else if (telephone_edit_text.getText().toString().isEmpty()) {
                //error.setText(Constants.ENTER_MOBILE_NUM);
                showToast(Constants.ENTER_MOBILE_NUM);
            } else if (telephone_edit_text.getText().toString().length() < Constants.NUMBER_OF_CHARACTERS_OF_PH_NUM) {
                // error.setText(Constants.ENTER_VALID_MOBILE_NUM);
                showToast(Constants.ENTER_VALID_MOBILE_NUM);
            } else {
                updateProfileApi(phone, force_verify, jobTitle, department);
            }
        } catch (Exception e) {
            // error.setText("Please fill the fields with proper data");
            showProgressAlert.dismiss();

        }
    }

    private void updateProfileApi(String phone, int force_verify, String jobTitle, String department) {

        showProgressAlert.setContentText(UPDATE_PROFILE_MSG);
        showProgressAlert.show();
        getAPI().updateProfile(preference.getString(Constants.ACCESS_TOKEN), jobTitle, department, selectedCountryData.getCode(),
                selectedCityData.getCityId(), phone, force_verify).enqueue(new Callback<UpdateProfileRespose>() {
            @Override
            public void onResponse(Call<UpdateProfileRespose> call, Response<UpdateProfileRespose> response) {


                showProgressAlert.dismiss();

                if (response.isSuccessful()) {
                    UpdateProfileRespose updateProfileRespose = response.body();
                    if (updateProfileRespose.getStatus().equals("success")) {
                        onSuccess(department, jobTitle, phone);
                    } else if (updateProfileRespose.getStatus().equals("warning")) {
                        showWarningDialog(response.body().getTitle(), response.body().getMessage());
                    } else {
                        onError(updateProfileRespose);
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<UpdateProfileRespose> call, Throwable t) {
                showProgressAlert.dismiss();

            }
        });
    }

    private void showWarningDialog(String title, String description) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this)).setHeading(title).setDescription(description).setConfirmButtonListener(dialog1 -> {
            updateProfile(1);
        }).setCancelButtonListener(dialog12 -> dialog12.dismiss()).setCancelableDialog(false);
        dialog.show();
    }

    private void onError(UpdateProfileRespose updateProfileRespose) {

        showToast(updateProfileRespose.getMessage());
    }

    private void onSuccess(String department, String jobTitle, String phone) {
        showProgressAlert.dismiss();


        showToast("Profile update Successfully");
        //setting in local storage

        //mobile Number
        if (!isSamePhoneNumber()) {
            preference.setString(Constants.MOBILE_NUMBER, phone);
            preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, "no");

            CustomApplication app = (CustomApplication) getApplicationContext();
            app.isNumberChange = true;
        }
        // other cache
        preference.setString(Constants.DEPARTMENT, department);
        preference.setString(Constants.JOB_TITLE, jobTitle);

        //country
        preference.setString(Constants.COUNTRY, selectedCountryData.getName());
        preference.setString(Constants.COUNTRY_CODE, selectedCountryData.getCode());
        preference.setString(Constants.COUNTRY_DIAL_CODE, selectedCountryData.getPhoneCode());


        preference.setString(Constants.CITY, selectedCityData.getCityName());
        preference.setString(Constants.CITY_ID_KEY, selectedCityData.getCityId());

        //error.setText("");

        //runtime update
        updateLocally(jobTitle, department);

        Intent intent = new Intent();
        intent.putExtra("updated_data", "" + gson.toJson(myProfileData));
        setResult(RESULT_OK, intent);
        finish();
    }


    private boolean isSamePhoneNumber() {
        if (selectedCityData == null) return false;
        return ((selectedCountryData.getPhoneCode() + "-" + telephone_edit_text.getText().toString()).equals(preference.getString(Constants.MOBILE_NUMBER)));
    }

    private void updateLocally(String jobTitle, String department) {
        myProfileData.setJobTitle(jobTitle);
        myProfileData.setDepartmentName(department);

        myProfileData.setCountryName(selectedCountryData.getName());
        myProfileData.setCountry_dial_code(selectedCountryData.getPhoneCode());
        myProfileData.setCountry_code(selectedCountryData.getCode());


        myProfileData.setCityName(selectedCityData.getCityName());
        myProfileData.setCity_id(selectedCityData.getCityId());

        myProfileData.setMobileNumber(mobile_code_edit_text.getText().toString() + "-" + telephone_edit_text.getText().toString());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private void setDataOnTextField(EditText fieldName, String value) {
        if (value != null) {
            fieldName.setText("" + value);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COUNTRY_LIST_ACTIVITY_CODE) {
                selectedCountryData = gson.fromJson(data.getStringExtra("selectedCountry"), CountyListData.class);
                city_text.setText("");
                mobile_code_edit_text.setText(selectedCountryData.getPhoneCode());
                selectedCityData = null;
                country_text.setText("" + selectedCountryData.getName());
            } else if (requestCode == CITY_LIST_ACTIVITY_CODE) {
                selectedCityData = gson.fromJson(data.getStringExtra("cityData"), CityListData.class);
                city_text.setText("" + selectedCityData.getCityName());
            }

        }
    }

    private PublicProfileData getIntentData() {
        return gson.fromJson(getIntent().getStringExtra("profile_data"), PublicProfileData.class);
    }

}