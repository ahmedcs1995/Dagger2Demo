package com.mobileapp.krank.Repository.Chat.group;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.Dao.GroupChatConversationDao;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMessageModel;

import java.util.List;

public class GroupChatConversationRepository {
    private GroupChatConversationDao mGroupChatConversationMessageModelDao;

    AppExecutors executors;
    // private LiveData<List<GroupChatConversationMessageModel>> mAllGroupChatConversationMessageModel;

    // Note that in order to unit test the WordRepository, you have to remove the Application
    // dependency. This adds complexity and much more code, and this sample is not about testing.
    // See the BasicSample in the android-architecture-components repository at
    // https://github.com/googlesamples
    public GroupChatConversationRepository(Application application) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        mGroupChatConversationMessageModelDao = db.groupchatConversationDao();
        executors= AppExecutors.getInstance();
        //  mAllGroupChatConversationMessageModel = mGroupChatConversationMessageModelDao.getAllRecords();
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    public LiveData<List<GroupChatConversationMessageModel>> getmAllMsgs(String id) {
        return mGroupChatConversationMessageModelDao.getAllRecords(Integer.parseInt(id));
    }

    public GroupChatConversationDao getConversationDao(){
        return mGroupChatConversationMessageModelDao;
    }

    // You must call this on a non-UI thread or your app will crash.
    // Like this, Room ensures that you're not doing any long running operations on the main
    // thread, blocking the UI.
    public void insert (GroupChatConversationMessageModel msg) {

        executors.diskIO().execute(() -> {
            mGroupChatConversationMessageModelDao.insert(msg);
        });
    }
    public void delete (long mId) {

        executors.diskIO().execute(() -> {
            mGroupChatConversationMessageModelDao.deleteByMid(mId);
        });
    }


    public void NewMsgBulkInsert(final List<GroupChatConversationMessageModel> msgs) {

        executors.diskIO().execute(() -> {
            mGroupChatConversationMessageModelDao.bulkInsert(msgs);
        });

    }
    public void updateMsgByMid(String member_id,long mId,GroupChatConversationMessageModel data){
        executors.diskIO().execute(() -> {
            mGroupChatConversationMessageModelDao.updateMsgByMid(member_id,mId,data.getMsgId(),data.getMsgText(),data.getMsgUserId(),data.getMsgGroupId(),data.getMsgType(),data.getMsgAdded(),data.getMsgUpdated(),data.getId(),data.getProfilePic(),data.getFirstName(),data.getLastName(),data.getSentTime(),data.getSentByme(),data.getType(),data.getReply(),data.getSenderImg(),data.getSystem_message(),data.getMsgStatus());
        });
    }
    public void updateMsgStatusByMid(String convId,long mId,int status){
        executors.diskIO().execute(() -> {

            mGroupChatConversationMessageModelDao.updateStatusMsgByMid(convId,mId,status);
        });
    }
}



