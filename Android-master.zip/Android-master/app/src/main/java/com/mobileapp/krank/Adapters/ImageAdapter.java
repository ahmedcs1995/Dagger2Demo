package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.drawee.controller.ControllerListener;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.image.ImageInfo;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailImageModel;


import java.util.List;

public class ImageAdapter extends android.support.v4.view.PagerAdapter {


    List<ListingDetailImageModel> mCards;
    DeviceInfo deviceInfo;
    ListingDetail activity;
    AppUtils appUtils;
    public ImageAdapter(List<ListingDetailImageModel> cardItems, DeviceInfo deviceInfo, ListingDetail activity) {
        mCards = cardItems;
        this.deviceInfo = deviceInfo;
        this.activity=activity;
        appUtils = AppUtils.getInstance();
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        final View item = View.inflate(container.getContext(), R.layout.image_item, null);

        SimpleDraweeView img = item.findViewById(R.id.img);






        img.setImageURI(Uri.parse(mCards.get(position).getName()));
       // img.getLayoutParams().width = deviceInfo.getDeviceWidth();
       // img.getLayoutParams().height = (int) activity.appUtils.convertDpToPixel(300,activity);
      //  img.setAspectRatio((float)deviceInfo.getDeviceWidth()/405);

        item.setTag(position);

        container.addView(item);
        return item;
    }

    public void removeView(int index) {
        mCards.remove(index);
        notifyDataSetChanged();
    }

    private ControllerListener getControllerListener(SimpleDraweeView img){
        //getting the image size..
        return new BaseControllerListener(){
            @Override
            public void onFinalImageSet(String id, @Nullable Object imageInfo, @Nullable Animatable animatable) {
                updateSize( ((ImageInfo)imageInfo).getWidth(),((ImageInfo)imageInfo).getHeight(),img);
            }

            @Override
            public void onIntermediateImageSet(String id, @Nullable Object imageInfo) {
                updateSize( ((ImageInfo)imageInfo).getWidth(),((ImageInfo)imageInfo).getHeight(),img);
            }
        };
    }
    public void updateSize(int width, int height, SimpleDraweeView draweeView) {
        draweeView.setAspectRatio((float) width / height);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return mCards.size();
    }


    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }



}




