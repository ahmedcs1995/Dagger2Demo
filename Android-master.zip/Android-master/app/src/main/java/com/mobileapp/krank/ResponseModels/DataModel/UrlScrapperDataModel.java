package com.mobileapp.krank.ResponseModels.DataModel;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class UrlScrapperDataModel {
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("images")
    @Expose
    private List<UrlScrapperImgModel> UrlScrapperImgModels = null;
    @SerializedName("total_images")
    @Expose
    private int totalUrlScrapperImgModels;

    @SerializedName("url")
    @Expose
    private String url;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<UrlScrapperImgModel> getUrlScrapperImgModels() {
        return UrlScrapperImgModels;
    }

    public void setUrlScrapperImgModels(List<UrlScrapperImgModel> UrlScrapperImgModels) {
        this.UrlScrapperImgModels = UrlScrapperImgModels;
    }

    public int getTotalUrlScrapperImgModels() {
        return totalUrlScrapperImgModels;
    }

    public void setTotalUrlScrapperImgModels(int totalUrlScrapperImgModels) {
        this.totalUrlScrapperImgModels = totalUrlScrapperImgModels;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
