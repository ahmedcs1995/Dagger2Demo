package com.mobileapp.krank.ResponseModels.DataModel;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class GroupChatMessagesMemberDataModel {
    @SerializedName("member_id")
    @Expose
    private String memberId;

    @SerializedName("member_user_id")
    @Expose
    private String memberUserId;

    @SerializedName("member_group_id")
    @Expose
    private String memberGroupId;

    @SerializedName("member_added_by")
    @Expose
    private String memberAddedBy;

    @SerializedName("member_added")
    @Expose
    private String memberAdded;

    @SerializedName("member_updated")
    @Expose
    private String memberUpdated;

    @SerializedName("member_status")
    @Expose
    private String memberStatus;

    @SerializedName("member_is_read")
    @Expose
    private String memberIsRead;

    @SerializedName("member_notifications")
    @Expose
    private String memberNotifications;

    @SerializedName("member_leave_on")
    @Expose
    private String memberLeaveOn;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberUserId() {
        return memberUserId;
    }

    public void setMemberUserId(String memberUserId) {
        this.memberUserId = memberUserId;
    }

    public String getMemberGroupId() {
        return memberGroupId;
    }

    public void setMemberGroupId(String memberGroupId) {
        this.memberGroupId = memberGroupId;
    }

    public String getMemberAddedBy() {
        return memberAddedBy;
    }

    public void setMemberAddedBy(String memberAddedBy) {
        this.memberAddedBy = memberAddedBy;
    }

    public String getMemberAdded() {
        return memberAdded;
    }

    public void setMemberAdded(String memberAdded) {
        this.memberAdded = memberAdded;
    }

    public String getMemberUpdated() {
        return memberUpdated;
    }

    public void setMemberUpdated(String memberUpdated) {
        this.memberUpdated = memberUpdated;
    }

    public String getMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(String memberStatus) {
        this.memberStatus = memberStatus;
    }

    public String getMemberIsRead() {
        return memberIsRead;
    }

    public void setMemberIsRead(String memberIsRead) {
        this.memberIsRead = memberIsRead;
    }

    public String getMemberNotifications() {
        return memberNotifications;
    }

    public void setMemberNotifications(String memberNotifications) {
        this.memberNotifications = memberNotifications;
    }

    public String getMemberLeaveOn() {
        return memberLeaveOn;
    }

    public void setMemberLeaveOn(String memberLeaveOn) {
        this.memberLeaveOn = memberLeaveOn;
    }

}