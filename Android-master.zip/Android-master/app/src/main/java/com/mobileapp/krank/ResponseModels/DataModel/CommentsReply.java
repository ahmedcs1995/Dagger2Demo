package com.mobileapp.krank.ResponseModels.DataModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CommentsReply {

    @SerializedName("i")
    @Expose
    private String i;
    @SerializedName("reply")
    @Expose
    private String reply;
    @SerializedName("ca")
    @Expose
    private Integer ca;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("full_name")
    @Expose
    private String fullName;
    @SerializedName("pic")
    @Expose
    private String pic;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("total_likes")
    @Expose
    private String totalLikes;
    @SerializedName("is_like")
    @Expose
    private Integer isLike;

    @SerializedName("profile_pic")
    @Expose
    private String profile_pic;


    public String getI() {
        return i;
    }

    public void setI(String i) {
        this.i = i;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public Integer getCa() {
        return ca;
    }

    public void setCa(Integer ca) {
        this.ca = ca;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotalLikes() {
        return totalLikes;
    }

    public void setTotalLikes(String totalLikes) {
        this.totalLikes = totalLikes;
    }

    public Integer getIsLike() {
        return isLike;
    }

    public void setIsLike(Integer isLike) {
        this.isLike = isLike;
    }

    public String getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(String profile_pic) {
        this.profile_pic = profile_pic;
    }
}