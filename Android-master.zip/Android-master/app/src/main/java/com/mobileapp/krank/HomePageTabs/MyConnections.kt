package com.mobileapp.krank.HomePageTabs

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView

import com.google.gson.Gson
import com.mobileapp.krank.Activities.MainPage
import com.mobileapp.krank.Activities.MyConnectionCards
import com.mobileapp.krank.Adapters.ConnectionsAdapter
import com.mobileapp.krank.Activities.SortByNetwork
import com.mobileapp.krank.Base.BaseFragment
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Model.HomePageDataFlagContainer
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.ConnectionResponse

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import android.app.Activity.RESULT_OK
import android.text.Editable
import android.text.TextWatcher
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import com.github.clans.fab.FloatingActionMenu
import com.mobileapp.krank.Activities.CompanyProfileView
import com.mobileapp.krank.Scroll.HidingPageScrollListener
import com.mobileapp.krank.Functions.launchActivity
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.Utils.ServiceManager

/**
 * Created by Ahmed on 4/20/2018.
 */

class MyConnections : BaseFragment(), CallBackWithAdapterPosAndType {


    //for list items
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var mAdapter: ConnectionsAdapter
    internal lateinit var mListItems: MutableList<ConnectionsDataModel>
    internal lateinit var layoutManager: LinearLayoutManager

    //views
    internal lateinit var swipeRefreshLayout: SwipeRefreshLayout
    internal lateinit var no_item_found_view: TextView
    private lateinit var search_box: EditText
    internal lateinit var cross_icon: View
    internal lateinit var header: View


    internal lateinit var gson: Gson


    private var homePageDataFlagContainer: HomePageDataFlagContainer? = null

    private var activityRef: MainPage? = null

    internal lateinit var handler: Handler
    internal lateinit var runnable: Runnable

    //for pagination
    private var offset: Int = 0
    private var reminderCount: Int = 0

    //scroll flags
    internal var shouldScrollCall: Boolean = false

    //loader
    internal lateinit var loader: ProgressBar


    //typing events
    private lateinit var onTypingTimeout: Runnable

    //resume tab
    internal var isResume: Boolean = false

    lateinit var sort_fab: FloatingActionMenu

    internal lateinit var serviceManager: ServiceManager

    //api call
    private var call: Call<ConnectionResponse>? = null

    init {
        title = "My Connections"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val me = inflater.inflate(R.layout.my_connections_page, container, false)
        fragmentView = me


        init(savedInstanceState)



        runnable = Runnable { getMyConnectionData() }


        serviceManager = ServiceManager.getInstance()

        setUpTypingTimeoutRunnable()


        //views
        swipeRefreshLayout = findViewById(R.id.swipe_refresh) as SwipeRefreshLayout
        swipeRefreshLayout.setProgressViewOffset(false, 0, resources.getDimension(R.dimen.refresher_offset_end).toInt())
        no_item_found_view = findViewById(R.id.no_item_found_view) as TextView
        cross_icon = findViewById(R.id.cross_icon)
        header = findViewById(R.id.header)


        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT
        no_item_found_view.visibility = View.GONE
        loader = findViewById(R.id.loader) as ProgressBar

        //search box
        search_box = findViewById(R.id.search_box) as EditText
        search_box.hint = "Search Connections Here"

        //adapter
        setUpConnectionsAdapter()

        if (!homePageDataFlagContainer!!.isDataLoaded) {
            //get data from api
            getMyConnectionData()
        } else {
            hideLoader()
        }


        bindListeners()

        showViews()

        return me
    }

    private fun getDataAfterReset(resetClick: Boolean) {
        //update the data
        offset = 0
        shouldScrollCall = false

        mListItems.subList(1, mListItems.size).clear()

        if (!resetClick) swipeRefreshLayout.isRefreshing = true else mListItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))


        mAdapter.notifyDataSetChanged()


        getMyConnectionData()
    }


    private fun bindListeners() {
        //swipe refresh
        swipeRefreshLayout.setOnRefreshListener {
            //update data container
            homePageDataFlagContainer!!.isDataLoaded = true
            homePageDataFlagContainer!!.selectedId = null



            getDataAfterReset(false)
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(onTypingTimeout)

            }

            override fun afterTextChanged(editable: Editable) {
                if (isResume) {
                    isResume = false
                    return
                }
                onTextChange()
            }
        })

        cross_icon.setOnClickListener {
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")

            // getDataAfterReset(true)
        }

        this@MyConnections.sort_fab.setOnMenuButtonClickListener {
            gotoSortPage()
        }


    }

    fun gotoSortPage() {
        val intent = Intent(activity, SortByNetwork::class.java)
        intent.putExtra("show_reset_btn", true)
        intent.putExtra("selected_network_group", homePageDataFlagContainer!!.selectedId)
        startActivityForResult(intent, SORT_ACTIVITY_CODE)
        activity!!.overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun onTextChange() {
        handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())

    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {


            //scroll
            offset = 0
            shouldScrollCall = false

            //reset the data

            mListItems.subList(1, mListItems.size).clear()
            mListItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            mAdapter.notifyDataSetChanged()


            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }
            //api data
            getMyConnectionData()


        }
    }


    private fun init(savedInstanceState: Bundle?) {
        activityRef = activity as MainPage?
        if (activityRef != null) {
            mListItems = activityRef!!.connectionItems
            homePageDataFlagContainer = activityRef!!.connectionTabData
            handler = activityRef!!.handler
            preference = activityRef!!.preference
            gson = activityRef!!.gson
            sort_fab = activityRef!!.sort_fab
        }


        // get the save data
        if (savedInstanceState != null) {
            offset = savedInstanceState.getInt(OFFSET_KEY)
            shouldScrollCall = savedInstanceState.getBoolean(SCROLL_FLAG_KEY)
            reminderCount = savedInstanceState.getInt(CONNECTIONS_REMAINDER_KEY)

            isResume = true

        } else {
            offset = 0
            shouldScrollCall = false

            isResume = false
        }
    }

    private fun hideLoader() {
        loader.visibility = View.GONE
    }


    private fun setRecyclerViewScrollListener() {
        mRecyclerView.addOnScrollListener(object : HidingPageScrollListener() {


            override fun onScrolledToEnd() {
                onScrollEnd()
            }

            override fun onHide() {
                hideViews()
            }

            override fun onShow() {
                showViews()
            }



            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                mAdapter.closeLastOpenLayout()
            }

        })
    }

    private fun hideViews() {
        header.animate().translationY((-(header.height + resources.getDimension(R.dimen.search_bar_padding)))).interpolator = AccelerateInterpolator(2F)
        sort_fab.animate().translationY(sort_fab.height + resources.getDimension(R.dimen.main_page_fab_margin)).setInterpolator(AccelerateInterpolator(2F)).start()
    }

    private fun showViews() {
        header.animate().translationY(0F).interpolator = DecelerateInterpolator(2F)
        sort_fab.animate().translationY(0F).setInterpolator(DecelerateInterpolator(2F)).start()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        //saving the data
        outState.putInt(OFFSET_KEY, offset)
        outState.putBoolean(SCROLL_FLAG_KEY, shouldScrollCall)
        outState.putInt(CONNECTIONS_REMAINDER_KEY, reminderCount)
    }


    private fun onScrollEnd() {

        if (shouldScrollCall) {
            shouldScrollCall = false
            offset += Constants.PAGE_LIMIT

           // mListItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
          //  mAdapter.notifyItemInserted(mListItems.size)


            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())
        }
    }

    private fun setUpConnectionsAdapter() {
        mRecyclerView = findViewById(R.id.my_connections_recycler_view) as RecyclerView

        mAdapter = ConnectionsAdapter(mListItems, context, this@MyConnections)
        layoutManager = LinearLayoutManager(activity)
        mRecyclerView.layoutManager = layoutManager
        mRecyclerView.adapter = mAdapter

        setRecyclerViewScrollListener()

        if (homePageDataFlagContainer!!.isDataLoaded) {
            checkForData()
        }

    }

    private fun getMyConnectionData() {
        call = serviceManager.api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, if (homePageDataFlagContainer!!.selectedId == null) "" else homePageDataFlagContainer!!.selectedId, search_box.text.toString(), Constants.PAGE_LIMIT)
        if (call == null) return
        call?.enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                        reminderCount = response.body().data.reminderCount

                        homePageDataFlagContainer!!.isDataLoaded = true


                        hideLoader()

                        removeLoader()


                        val oldSize = mListItems.size

                        mListItems.addAll(response.body().data.connectionsData)

                        if (response.body().data.connectionsData.size >= Constants.PAGE_LIMIT) {
                            mListItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }

                        mAdapter.notifyItemRangeInserted(oldSize, mListItems.size)

                        checkForData()
                    }
                }
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                homePageDataFlagContainer!!.isDataLoaded = true
                swipeRefreshLayout.isRefreshing = false
                loader.visibility = View.GONE
            }
        })
    }

    private fun changePrivateConnectionStatus(position: Int,status : String){
        mListItems[position].con_type = status
        mAdapter.notifyItemChanged(position)
    }

    private fun markAsPrivateConnection(userId: String?,position: Int) {
        serviceManager.api.privateConnection(preference.getString(Constants.ACCESS_TOKEN), userId).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>?, response: Response<GeneralResponse>?) {
                if (response == null) return

                if (response.isSuccessful) {
                    if (response.body().status != Constants.SUCCESS_STATUS) {
                        changePrivateConnectionStatus(position, ConnectionsDataModel.NORMAL_CONNECTION)
                    }
                    activityRef?.showToast(response.body().message)
                } else {
                    activityRef?.onResponseFailure()
                    changePrivateConnectionStatus(position, ConnectionsDataModel.NORMAL_CONNECTION)
                }
            }

            override fun onFailure(call: Call<GeneralResponse>?, t: Throwable?) {
                activityRef?.onResponseFailure()
            }

        })
    }

    private fun removeLoader() {
        for (i in mListItems.indices.reversed()) {
            if (mListItems[i].type == Constants.LOADER_VIEW) {
                mListItems.removeAt(i)
                mAdapter.notifyItemRemoved(i)
                break
            }
        }
    }

    private fun checkForData() {
        if (mListItems.size <= 1) {
            no_item_found_view.visibility = View.VISIBLE
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }


    fun upDateConnectionsData() {
        try {
            swipeRefreshLayout.isRefreshing = true
            mListItems.subList(1, mListItems.size).clear()
            mAdapter.notifyDataSetChanged()
            getMyConnectionData()
        } catch (ex: Exception) {

        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == SORT_ACTIVITY_CODE) {
                if (data!!.getBooleanExtra("reset_click", false)) {
                    homePageDataFlagContainer!!.selectedId = null
                } else {
                    homePageDataFlagContainer!!.selectedId = data.getStringExtra("companyId")
                }

                mListItems.subList(1, mListItems.size).clear()

                mAdapter.notifyDataSetChanged()

                offset = 0
                swipeRefreshLayout.isRefreshing = true

                shouldScrollCall = false

                getMyConnectionData()

            } else if (requestCode == CARDS_ACTIVITY_CODE) {
                if (data!!.getBooleanExtra("isDataDeleted", false)) {

                    val app = activity!!.applicationContext as CustomApplication
                    mListItems.subList(1, mListItems.size).clear()
                    mListItems.addAll(app.connectionItems)
                    mAdapter.notifyDataSetChanged()

                    checkForData()
                }
            }
        }
    }

    companion object {

        //activity code
        private const val SORT_ACTIVITY_CODE = 10
        const val CARDS_ACTIVITY_CODE = 500

        //type
        const val TYPE_HEADER = 2

        //save instance keys
        private const val OFFSET_KEY = "connection_offset"
        private const val SCROLL_FLAG_KEY = "connection_flag"
        private const val CONNECTIONS_REMAINDER_KEY = "connections_remainder_count"
    }

    override fun act(position: Int, type: Int) {
        if (type == ConnectionsAdapter.COMPANY_IMG_CLICK) {
            if (mListItems[position].companyData == null) return
            context?.launchActivity<CompanyProfileView> {
                putExtra(CompanyProfileView.INTENT_COMPANY_ID,  mListItems[position].companyData.companyId)
            }
            return
        } else if (type == ConnectionsAdapter.MARK_AS_PRIVATE_CLICK) {
            if(mListItems[position].companyData == null) return

            mListItems[position].con_type = ConnectionsDataModel.PRIVATE_CONNECTION
            mAdapter.notifyItemChanged(position)
            markAsPrivateConnection(mListItems[position].companyData.userId,position)
            return
        }

        if (mListItems[position].companyData == null) return

        if (mListItems.size <= 1) return

        mAdapter.closeLastOpenLayout()

        val intent = Intent(activity, MyConnectionCards::class.java)
        intent.putExtra(Constants.INTENT_KEY, mListItems[position].companyData.userId)

        val app = activity!!.applicationContext as CustomApplication
        app.connectionItems = mListItems.subList(1, mListItems.size)

        intent.putExtra("currentItem", position - 1)
        intent.putExtra("offset", offset)
        intent.putExtra("reminderCount", reminderCount)
        intent.putExtra("keyword", search_box.text.toString())
        startActivityForResult(intent, CARDS_ACTIVITY_CODE)
        activity!!.overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }
}