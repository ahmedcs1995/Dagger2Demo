package com.mobileapp.krank.Repository.Chat.group;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.Handler;

import com.google.gson.Gson;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChat;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.Dao.GroupChatListDao;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;
import com.mobileapp.krank.ResponseModels.GroupChatConversationResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GroupChatListRepository {
    private GroupChatListDao mGroupChatConversationGroupModelDao;
    private LiveData<List<GroupChatConversationGroupModel>> mAllGroupChatConversationGroupModel;

    AppExecutors appExecutors;

    // Note that in order to unit test the WordRepository, you have to remove the Application
    // dependency. This adds complexity and much more code, and this sample is not about testing.
    // See the BasicSample in the android-architecture-components repository at
    // https://github.com/googlesamples

    private static int SECONDS_TO_REFRESH = 3000;

    Handler handler;
    Runnable runnable;
    SaveInSharedPreference preference;
    ServiceManager serviceManager;
    Gson gson;


    List<GroupChatConversationGroupModel> tempMsgs;
    List<GroupChatConversationGroupModel> serverMsgs;
    List<GroupChatConversationGroupModel> newMsgs;
    List<GroupChatConversationGroupModel> oldMsgs;
    boolean idFound;
    private boolean isDbEmpty;

    public GroupChatListRepository(Application application) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        mGroupChatConversationGroupModelDao = db.groupchatConversationListDao();
        mAllGroupChatConversationGroupModel = mGroupChatConversationGroupModelDao.getAllChatList();


        tempMsgs = new ArrayList<>();
        serverMsgs = new ArrayList<>();
        newMsgs = new ArrayList<>();
        oldMsgs = new ArrayList<>();

        appExecutors = AppExecutors.getInstance();
        handler = new Handler();
        runnable = () -> getChatConversationList(null);
        serviceManager = ServiceManager.getInstance();
        gson = CustomGson.getInstance();
        preference = new SaveInSharedPreference(application.getApplicationContext());
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    public LiveData<List<GroupChatConversationGroupModel>> getmAllGroupChatConversationGroupModel() {
        return mAllGroupChatConversationGroupModel;
    }

    // You must call this on a non-UI thread or your app will crash.
    // Like this, Room ensures that you're not doing any long running operations on the main
    // thread, blocking the UI.
    public void insert(GroupChatConversationGroupModel msg) {
        //new insertAsyncTask(mGroupChatConversationGroupModelDao).execute(msg);
        appExecutors.diskIO().execute(() -> {
            mGroupChatConversationGroupModelDao.insert(msg);
        });
    }

    public void stopTask() {
        handler.removeCallbacks(runnable);
    }

    public void startTask(CustomCallBack customCallBack) {
        // Log.e("start_task","yes");
        getChatConversationList(customCallBack);
    }

    public void bulkInsert(List<GroupChatConversationGroupModel> list) {
        //  new bulkInsertAsyncTask(mGroupChatConversationGroupModelDao).execute(list);
        appExecutors.diskIO().execute(() -> {
            mGroupChatConversationGroupModelDao.bulkInsert(list);
        });
    }

    public void bulkUpdate(List<GroupChatConversationGroupModel> list) {
        appExecutors.diskIO().execute(() -> {
            mGroupChatConversationGroupModelDao.bulkUpdate(list);
        });

    }

    private void getChatConversationList(CustomCallBack customCallBack) {
        // Log.e("start_task","getChatConversationList");


        serviceManager.getAPI().groupConversationList(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<GroupChatConversationResponse>() {
            @Override
            public void onResponse(Call<GroupChatConversationResponse> call, Response<GroupChatConversationResponse> response) {

                try{
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            if (getmAllGroupChatConversationGroupModel() != null && getmAllGroupChatConversationGroupModel().getValue() != null) {
                                tempMsgs.clear();
                                newMsgs.clear();
                                serverMsgs.clear();
                                oldMsgs.clear();

                                if (getmAllGroupChatConversationGroupModel().getValue().size() <= 0) {
                                    isDbEmpty = true;
                                } else {
                                    isDbEmpty = false;
                                }

                                if (isDbEmpty) {
                                    // insert data
                                    appExecutors.diskIO().execute(() -> {
                                        getDao().bulkInsert(response.body().getData().getGroups());
                                    });
                                } else {
                                    //update data
                                    tempMsgs = getmAllGroupChatConversationGroupModel().getValue();
                                    serverMsgs.clear();
                                    serverMsgs.addAll(response.body().getData().getGroups());
                                    for (int i = 0; i < serverMsgs.size(); i++) {
                                        idFound = false;
                                        for (int j = 0; j < tempMsgs.size(); j++) {
                                            if (serverMsgs.get(i).getMemberId() == tempMsgs.get(j).getMemberId()) {
                                                idFound = true;
                                            }
                                        }
                                        if (!idFound) {
                                            newMsgs.add(serverMsgs.get(i));
                                        } else {
                                            oldMsgs.add(serverMsgs.get(i));
                                        }
                                    }
                                    try {
                                        appExecutors.diskIO().execute(() -> {
                                            getDao().bulkUpdate(oldMsgs);
                                            getDao().bulkInsert(newMsgs);
                                        });
                                    } catch (Exception e) {

                                    }


                                }
                                if (customCallBack != null) {
                                    customCallBack.act();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex){

                }
                //  Log.e("call","group =>" + gson.toJson(call.request()));
                //   Log.e("response","group => " + gson.toJson(response.body()));

                if (!GroupChat.EXIT) {
                    pull();
                }
            }

            @Override
            public void onFailure(Call<GroupChatConversationResponse> call, Throwable t) {
                if (customCallBack != null) {
                    customCallBack.act();
                }
                if (!GroupChat.EXIT) {
                    pull();
                }
            }
        });
    }

    private void pull() {
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }

    public GroupChatListDao getDao() {
        return mGroupChatConversationGroupModelDao;
    }
}


