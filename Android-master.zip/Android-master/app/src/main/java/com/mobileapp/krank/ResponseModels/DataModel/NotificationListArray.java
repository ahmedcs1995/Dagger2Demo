package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.Model.Enums.TypeOfNotification;

public class NotificationListArray {


    TypeOfNotification typeOfNotification;

    public NotificationListArray(TypeOfNotification typeOfNotification) {
        this.typeOfNotification = typeOfNotification;
    }


    public TypeOfNotification getTypeOfNotification() {
        return typeOfNotification;
    }

    public void setTypeOfNotification(TypeOfNotification typeOfNotification) {
        this.typeOfNotification = typeOfNotification;
    }

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("sender_id")
    @Expose
    private String senderId;
    @SerializedName("recipient_id")
    @Expose
    private String recipientId;
    @SerializedName("activity")
    @Expose
    private String activity;
    @SerializedName("notify_type")
    @Expose
    private String notifyType;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("is_read")
    @Expose
    private String isRead;
    @SerializedName("track_id")
    @Expose
    private String trackId;
    @SerializedName("is_admin")
    @Expose
    private String isAdmin;
    @SerializedName("c_id")
    @Expose
    private String cId;
    @SerializedName("nid")
    @Expose
    private String nid;
    @SerializedName("isShare")
    @Expose
    private String isShare;
    @SerializedName("track_title")
    @Expose
    private String trackTitle;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("online")
    @Expose
    private String online;
    @SerializedName("url")
    @Expose
    private String url;
    @SerializedName("company_url")
    @Expose
    private String companyUrl;
    @SerializedName("post_url")
    @Expose
    private String postUrl;
    @SerializedName("desc")
    @Expose
    private String desc;
    @SerializedName("notify_page_desc")
    @Expose
    private String notifyPageDesc;
    @SerializedName("redirect_url")
    @Expose
    private String redirectUrl;

    @SerializedName("listing_id")
    @Expose
    private String listing_id;

    @SerializedName("member_id")
    @Expose
    private String member_id;

    @SerializedName("conStatus")
    @Expose
    private String conStatus;

    @SerializedName("discover_flag")
    @Expose
    private boolean discover_flag;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getNotifyType() {
        return notifyType;
    }

    public void setNotifyType(String notifyType) {
        this.notifyType = notifyType;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public String getTrackId() {
        return trackId;
    }

    public void setTrackId(String trackId) {
        this.trackId = trackId;
    }

    public String getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(String isAdmin) {
        this.isAdmin = isAdmin;
    }

    public String getCId() {
        return cId;
    }

    public void setCId(String cId) {
        this.cId = cId;
    }

    public String getNid() {
        return nid;
    }

    public void setNid(String nid) {
        this.nid = nid;
    }

    public String getIsShare() {
        return isShare;
    }

    public void setIsShare(String isShare) {
        this.isShare = isShare;
    }

    public String getTrackTitle() {
        return trackTitle;
    }

    public void setTrackTitle(String trackTitle) {
        this.trackTitle = trackTitle;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getNotifyPageDesc() {
        return notifyPageDesc;
    }

    public void setNotifyPageDesc(String notifyPageDesc) {
        this.notifyPageDesc = notifyPageDesc;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getListing_id() {
        return listing_id;
    }

    public void setListing_id(String listing_id) {
        this.listing_id = listing_id;
    }

    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public boolean showRemoveDealerView(){
        if(getActivity() == null || getNotifyType() == null) return false;
        return getActivity().equals("accepted") && getNotifyType().equals("dealer");
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public ConNetStatus getConnectionStatus(){
       return AppUtils.getConNetStatus(conStatus);
    }

    public boolean isDiscover_flag() {
        return discover_flag;
    }

    public void setDiscover_flag(boolean discover_flag) {
        this.discover_flag = discover_flag;
    }


}
