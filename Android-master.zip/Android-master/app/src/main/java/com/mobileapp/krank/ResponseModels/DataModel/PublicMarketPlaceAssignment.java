package com.mobileapp.krank.ResponseModels.DataModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PublicMarketPlaceAssignment {
    @SerializedName("online")
    @Expose
    private String online;
    @SerializedName("firstName")
    @Expose
    private String firstName;
    @SerializedName("lastName")
    @Expose
    private String lastName;
    @SerializedName("companyName")
    @Expose
    private String companyName;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("companyId")
    @Expose
    private String companyId;
    @SerializedName("profilePic")
    @Expose
    private String profilePic;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("connectionStatus")
    @Expose
    private String connectionStatus;

    private boolean isItemSelected;

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(String connectionStatus) {
        this.connectionStatus = connectionStatus;
    }

    public boolean getIsItemSelected() {
        return isItemSelected;
    }

    public void setIsItemSelected(boolean isItemSelected) {
        this.isItemSelected = isItemSelected;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof PublicMarketPlaceAssignment)) {
            return false;
        }
        PublicMarketPlaceAssignment obj = (PublicMarketPlaceAssignment) o;

       return id.equals(obj.id);

    }

    public boolean isLoggedInUser(String user_id){
        return id.equals(user_id);
    }
}
