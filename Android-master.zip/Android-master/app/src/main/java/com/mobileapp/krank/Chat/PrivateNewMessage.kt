package com.mobileapp.krank.Chat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mobileapp.krank.Adapters.AppGeneralAdapter

import com.mobileapp.krank.Utils.AnimationUtils
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.ConnectionResponse
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.UserViewHolderCheckBox
import kotlinx.android.synthetic.main.activity_private_new_message.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.shimmer_loader_layout.*
import kotlinx.android.synthetic.main.toolbar_with_search.*

import java.util.ArrayList

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PrivateNewMessage : BaseActivity() {
    private lateinit var peopleRecyclerAdapter: AppGeneralAdapter<ConnectionsDataModel>
    internal lateinit var listItems: MutableList<ConnectionsDataModel>
    // var selected_index: Int = 0

    private lateinit var personalChatItems: MutableList<ChatConversationListDataModel>
    internal lateinit var conv_id: String

    //list call back
    private lateinit var listCallBack: CallBackWithAdapterPosition

    private var previousSelectedItem: ConnectionsDataModel? = null
    private var selectedItem: ConnectionsDataModel? = null


    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //pagination
    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false

    //typing events
    private var onTypingTimeout: Runnable? = null

    //api
    private var call: Call<ConnectionResponse>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_private_new_message)


        setNormalPageToolbar( intent.getStringExtra("page_title"))

        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT

        setUpTypingTimeoutRunnable()


        setUpRunnable()

        personalChatItems = ArrayList()

        // selected_index = -1


        if (intent.getStringExtra("type") == "visiting_card") {
            add_contacts.visibility = View.GONE
        }


        if(applicationRef.recentChat != null){
            personalChatItems.addAll(applicationRef.recentChat)
        }


        /*if (intent.getStringExtra("chat_data") != null) {
            personalChatItems.addAll(Arrays.asList(*gson.fromJson(intent.getStringExtra("chat_data"), Array<ChatConversationListDataModel>::class.java)))
        }*/

        setUpCallBack()

        //views
        shimmer_view_container.startShimmer()
        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT
        no_item_found_view.visibility = View.GONE

        setUpAdapter()

        getData()

        bindListeners()
    }
    private fun removeShimmerLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }

    private fun checkForData() {
        if (listItems.size <= 0) no_item_found_view.visibility = View.VISIBLE else no_item_found_view.visibility = View.GONE
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {
            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            listItems.clear()
            listItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            peopleRecyclerAdapter.notifyDataSetChanged()


            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }

            //api data
            getData()
        }
    }

    private fun setUpRunnable() {
        runnable = Runnable {
            getData()
        }
    }

    private fun bindListeners() {

        done_btn.setOnClickListener(View.OnClickListener {


            //set null
            applicationRef.recentChat = null

            if (selectedItem != null) {
                if (intent.getStringExtra("type") == "visiting_card") {
                    val intent = Intent()
                    intent.putExtra("selected_data", appUtils.convertToJson(selectedItem))
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                    return@OnClickListener
                }

                val intent = Intent(applicationContext, PrivateChatConversationActivity::class.java)
                intent.putExtra("selected_data", appUtils.convertToJson(selectedItem))
                intent.putExtra("recipient_name", selectedItem!!.companyData.firstName + " " + selectedItem!!.companyData.lastName)
                intent.putExtra("user_two_id", selectedItem!!.companyData.userId)
                if (checkForStartConversation()) {
                    intent.putExtra("start_conversation", false)
                    intent.putExtra("conv_id", conv_id)
                } else {
                    intent.putExtra("start_conversation", true)
                    intent.putExtra("connection_id", selectedItem!!.companyData.userId)
                }
                startActivity(intent)
                finish()
            }
        })

        search_btn.setOnClickListener {
            showKeyboard(search_box)
            AnimationUtils.circleReveal(search_container, 1, true, true, this@PrivateNewMessage)
        }


        back_btn_search.setOnClickListener {
            AnimationUtils.circleReveal(search_container, 1, true, false, this@PrivateNewMessage)
            hideFocusKeyboard()
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

        })

    }

    private fun setUpCallBack() {
        listCallBack = CallBackWithAdapterPosition {
            if (previousSelectedItem == null) {
                listItems[it].isItemCheck = true
                peopleRecyclerAdapter.notifyDataSetChanged()
                previousSelectedItem = listItems[it]
                selectedItem = listItems[it]
                chip_name.visibility = View.VISIBLE
                chip_name.text = "" + listItems[it].companyData.firstName + " " + listItems[it].companyData.lastName
                return@CallBackWithAdapterPosition
            }
            previousSelectedItem?.isItemCheck = false
            listItems[it].isItemCheck = true
            peopleRecyclerAdapter.notifyDataSetChanged()
            previousSelectedItem = listItems[it]
            selectedItem = listItems[it]
            chip_name.text = "" + listItems[it].companyData.firstName + " " + listItems[it].companyData.lastName
        }
    }

    private fun setUpAdapter() {
        listItems = ArrayList()

        peopleRecyclerAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(listItems) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                if (viewHolder is UserViewHolderCheckBox) {
                    viewHolder.onBindConnections(item, appUtils)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when (i) {
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                }
            }

            override fun getItemViewType(position: Int): Int {
                return listItems[position].type
            }

        }

        contacts_recycler.layoutManager = LinearLayoutManager(this@PrivateNewMessage)
        contacts_recycler.adapter = peopleRecyclerAdapter

        addOnScrollEndListener()

    }

    private fun addOnScrollEndListener() {
        contacts_recycler.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun getData() {

        call = api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", search_box.text.toString(), Constants.PAGE_LIMIT)
        if (call == null) return
        call?.enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {
                removeShimmerLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }
            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                removeShimmerLoader()
                onResponseFailure()
            }
        })
    }

    private fun removeLoader() {
        for (i in listItems.indices.reversed()) {
            if (listItems[i].type == Constants.LOADER_VIEW) {
                peopleRecyclerAdapter.removeAt(i)
                break
            }
        }
    }

    private fun onSuccess(response: Response<ConnectionResponse>) {

        val tempList = response.body().data.connectionsData

        removeLoader()

        /*for pagination*/
        if (tempList.size >= Constants.PAGE_LIMIT) {
            tempList.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /*for pagination*/


        /*for already selected*/
        if (selectedItem != null && selectedItem!!.companyData != null) {
            for (i in tempList.indices) {
                if (tempList[i].companyData != null && tempList[i].companyData.userId == selectedItem!!.companyData.userId) {
                    tempList[i].isItemCheck = true
                }
            }
        }
        /*for already selected*/

        peopleRecyclerAdapter.addAll(tempList)

        checkForData()

    }


    private fun checkForStartConversation(): Boolean {
        if (selectedItem == null) return true
        for (j in personalChatItems.indices) {
            if (personalChatItems[j].second_user.id == selectedItem!!.companyData.userId) {
                conv_id = "" + personalChatItems[j].id
                return true
            }
        }
        return false
    }

    override fun onBackPressed() {
        val intent = Intent()
        setResult(Activity.RESULT_OK, intent)
        finish()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

}
