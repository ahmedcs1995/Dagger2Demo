package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Functions.Constants;

@Entity(tableName = "personal_chat_conversation_list_table")
public class ChatConversationListDataModel {
    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    @NonNull
    @PrimaryKey
    private int id;
    @SerializedName("update_date")
    @Expose
    @ColumnInfo(name = "update_date")
    private String updateDate;

    //user_one current login user
    @SerializedName("user_one")
    @Expose
    @ColumnInfo(name = "user_one")
    private String userOne;

    @SerializedName("user1_designation")
    @Expose
    @ColumnInfo(name = "user1_designation")
    private String user1_designation;
    @SerializedName("user1Name")
    @Expose
    
    @ColumnInfo(name = "user1Name")
    private String user1Name;
    @SerializedName("user1Img")
    @Expose
    
    @ColumnInfo(name = "user1Img")
    private String user1Img;
    @SerializedName("user1Online")
    @Expose
    
    @ColumnInfo(name = "user1Online")
    private String user1Online;
    @SerializedName("user2Online")
    @Expose
    
    @ColumnInfo(name = "user2Online")
    private String user2Online;

    @SerializedName("user_two")
    @Expose
    //user_two... jis se chat chal rhe hai..
    @ColumnInfo(name = "user_two")
    private String userTwo;
    @SerializedName("user2_designation")
    @Expose
    @ColumnInfo(name = "user2_designation")
    private String user2_designation;
    @SerializedName("user2Img")
    @Expose
    
    @ColumnInfo(name = "user2Img")
    private String user2Img;
    @SerializedName("user2Name")
    @Expose
    
    @ColumnInfo(name = "user2Name")
    private String user2Name;
    @SerializedName("msgTime")
    @Expose
    
    @ColumnInfo(name = "msgTime")
    private String msgTime;
    @SerializedName("recipient")
    @Expose
    
    @ColumnInfo(name = "recipient")
    private String recipient;
    @SerializedName("recipientImg")
    @Expose
    
    @ColumnInfo(name = "recipientImg")
    private String recipientImg;
    @SerializedName("recipientId")
    @Expose
    
    @ColumnInfo(name = "recipientId")
    private String recipientId;
    @SerializedName("recipientOnline")
    @Expose
    
    @ColumnInfo(name = "recipientOnline")
    private String recipientOnline;

    @SerializedName("convoPreview")
    @Expose
    @ColumnInfo(name = "convoPreview")
    private String convoPreview;

    @SerializedName("senderId")
    @Expose
    
    @ColumnInfo(name = "senderId")
    private String senderId;
    @SerializedName("senderName")
    @Expose
    
    @ColumnInfo(name = "senderName")
    private String senderName;
    @SerializedName("senderImg")
    @Expose
    
    @ColumnInfo(name = "senderImg")
    private String senderImg;
    @SerializedName("type")
    @Expose
    
    @ColumnInfo(name = "type")
    private String type;
    @SerializedName("sentTime")
    @Expose
    
    @ColumnInfo(name = "sentTime")
    private String sentTime;
    @SerializedName("isRead")
    @Expose
    
    @ColumnInfo(name = "isRead")
    private String isRead;

    @SerializedName("user1_company_name")
    @Expose
    
    @ColumnInfo(name = "user1_company_name")
    private String user1_company_name;

    @SerializedName("user2_company_name")
    @Expose
    
    @ColumnInfo(name = "user2_company_name")
    private String user2_company_name;

    @SerializedName("conversation_unread")
    @Expose
    
    @ColumnInfo(name = "conversation_unread")
    private String conversation_unread;

    @SerializedName("conversation_count")
    @Expose
    @ColumnInfo(name = "conversation_count")
    private String conversation_count;




    @ColumnInfo(name = "from_local_db")
    private String from_local_db;


    @SerializedName("second_user")
    @Expose
    @Embedded
    private SecondUserChatDataModel second_user;




    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUserOne() {
        return userOne;
    }

    public void setUserOne(String userOne) {
        this.userOne = userOne;
    }

    public String getUser1Name() {
        return user1Name;
    }

    public void setUser1Name(String user1Name) {
        this.user1Name = user1Name;
    }

    public String getUser1Img() {
        return user1Img;
    }

    public void setUser1Img(String user1Img) {
        this.user1Img = user1Img;
    }

    public String getUser1Online() {
        return user1Online;
    }

    public void setUser1Online(String user1Online) {
        this.user1Online = user1Online;
    }

    public String getUser2Online() {
        return user2Online;
    }

    public void setUser2Online(String user2Online) {
        this.user2Online = user2Online;
    }

    public String getUserTwo() {
        return userTwo;
    }

    public void setUserTwo(String userTwo) {
        this.userTwo = userTwo;
    }

    public String getUser2Img() {
        return user2Img;
    }

    public void setUser2Img(String user2Img) {
        this.user2Img = user2Img;
    }

    public String getUser2Name() {
        return user2Name;
    }

    public void setUser2Name(String user2Name) {
        this.user2Name = user2Name;
    }

    public String getMsgTime() {
        return msgTime;
    }

    public void setMsgTime(String msgTime) {
        this.msgTime = msgTime;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getRecipientImg() {
        return recipientImg;
    }

    public void setRecipientImg(String recipientImg) {
        this.recipientImg = recipientImg;
    }

    public String getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getRecipientOnline() {
        return recipientOnline;
    }

    public void setRecipientOnline(String recipientOnline) {
        this.recipientOnline = recipientOnline;
    }

    public String getConvoPreview() {
        return convoPreview;
    }

    public void setConvoPreview(String convoPreview) {
        this.convoPreview = convoPreview;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getSenderImg() {
        return senderImg;
    }

    public void setSenderImg(String senderImg) {
        this.senderImg = senderImg;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSentTime() {
        return sentTime;
    }

    public void setSentTime(String sentTime) {
        this.sentTime = sentTime;
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public String getConversation_unread() {
        return conversation_unread;
    }

    public void setConversation_unread(String conversation_unread) {
        this.conversation_unread = conversation_unread;
    }

    public String getConversation_count() {
        return conversation_count;
    }

    public void setConversation_count(String conversation_count) {
        this.conversation_count = conversation_count;
    }

    public String getUser1_designation() {
        return user1_designation;
    }

    public void setUser1_designation(String user1_designation) {
        this.user1_designation = user1_designation;
    }

    public String getUser2_designation() {
        return user2_designation;
    }

    public void setUser2_designation(String user2_designation) {
        this.user2_designation = user2_designation;
    }

    public String getUser1_company_name() {
        return user1_company_name;
    }

    public void setUser1_company_name(String user1_company_name) {
        this.user1_company_name = user1_company_name;
    }

    public String getUser2_company_name() {
        return user2_company_name;
    }

    public void setUser2_company_name(String user2_company_name) {
        this.user2_company_name = user2_company_name;
    }
    @Ignore
    public ChatConversationListDataModel(@NonNull int id, String userOne) {
        this.id = id;
        this.userOne = userOne;
    }

    public ChatConversationListDataModel(){

    }
    @Ignore
    public ChatConversationListDataModel(@NonNull int id,String convoPreview,String senderId,String msgTime,String isRead,String type,String conversation_unread,String recipient,String recipientImg,String from_local_db,String userOne,String userTwo){
        this.id = id;
        this.convoPreview=convoPreview;
        this.senderId=senderId;
        this.msgTime=msgTime;
        this.isRead=isRead;
        this.type=type;
        this.conversation_unread=conversation_unread;
        this.recipient=recipient;
        this.recipientImg=recipientImg;
        this.from_local_db=from_local_db;
        this.userOne=userOne;
        this.userTwo=userTwo;
    }

    public String getFrom_local_db() {
        return from_local_db;
    }

    public void setFrom_local_db(String from_local_db) {
        this.from_local_db = from_local_db;
    }

    public SecondUserChatDataModel getSecond_user() {
        return second_user;
    }

    public void setSecond_user(SecondUserChatDataModel second_user) {
        this.second_user = second_user;
    }


}
