package com.mobileapp.krank.HomePageTabs

import android.content.Intent
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar

import com.google.gson.Gson
import com.mobileapp.krank.Activities.MainPage
import com.mobileapp.krank.Activities.SelectNetworkFromDealerGroup
import com.mobileapp.krank.Adapters.DealersAdapter
import com.mobileapp.krank.Base.BaseFragment
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.CustomGson
import com.mobileapp.krank.Model.HomePageDataFlagContainer
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData
import com.mobileapp.krank.ResponseModels.NetworkDealersResponse
import com.mobileapp.krank.Utils.ServiceManager



import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import android.app.Activity.RESULT_OK
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import com.github.clans.fab.FloatingActionButton
import com.github.clans.fab.FloatingActionMenu
import com.mobileapp.krank.Scroll.HidingPageScrollListener

/**
 * Created by Ahmed on 4/20/2018.
 */

class MyDealers : BaseFragment() {

    //for list items
    private lateinit var myDealersRecyclerView: RecyclerView
    private lateinit var myDealersRecyclerAdapter: RecyclerView.Adapter<*>
    internal lateinit var myDealersItems: MutableList<NetworkDealersData>


    internal lateinit var dealersFirstTimeScreen: View

    //invite dealer Btns
    private lateinit var add_dealer_to_your_network: Button
    private lateinit var addDealerFromExistingNetwork: Button

    internal lateinit var layout_for_hide_and_show: View
    //refresh
    internal lateinit var swipeRefreshLayout: SwipeRefreshLayout

    internal lateinit var appUtils: AppUtils

    //main page views
    internal lateinit var mViewPager: ViewPager

    internal lateinit var gson: Gson

    //flags
    internal lateinit var dataFlagContainer: HomePageDataFlagContainer


    //loader
    internal lateinit var loader: ProgressBar

    //fab
    private lateinit var network_fab_container: FloatingActionButton
    private lateinit var existing_dealer_fab_container: FloatingActionButton
    private lateinit var fab: FloatingActionMenu

    internal lateinit var serviceManager: ServiceManager

    init {
        title = "My Dealers"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val me = inflater.inflate(R.layout.my_dealers_page, container, false)
        fragmentView = me

        init()

        //utils
        appUtils = AppUtils.getInstance()
        gson = CustomGson.getInstance()
        serviceManager = ServiceManager.getInstance()


        //views
        swipeRefreshLayout = findViewById(R.id.swipe_refresh) as SwipeRefreshLayout
        //myDealersItems = new ArrayList<>();
        dealersFirstTimeScreen = findViewById(R.id.dealer_first_time_screen)
        add_dealer_to_your_network = findViewById(R.id.add_dealer_to_your_network) as Button
        layout_for_hide_and_show = findViewById(R.id.layout_for_hide_and_show)
        addDealerFromExistingNetwork = findViewById(R.id.add_dealer_from_existing_network) as Button
        loader = findViewById(R.id.loader) as ProgressBar

        //listeners
        add_dealer_to_your_network.setOnClickListener { addDealerToYourNetworkPress() }

        addDealerFromExistingNetwork.setOnClickListener { addDealerPress() }

        swipeRefreshLayout.setOnRefreshListener {
            dataFlagContainer.isDataLoaded = false
            swipeRefreshLayout.isRefreshing = true
            myDealersItems.clear()
            myDealersRecyclerAdapter.notifyDataSetChanged()
            getDealerData()
        }

        //dealer invite btn
        setTextOnButton()

        //adapter
        setUpDealersAdapter()


        Log.e("Loading data", "=======> " + dataFlagContainer.isDataLoaded)
        //get the data from API
        if (!dataFlagContainer.isDataLoaded) {
            getDealerData()
        } else {
            //decide which view to display
            loader.visibility = View.GONE
            showView()

        }

        bindListeners()

        showViews()

        return me


    }

    private fun init() {
        val mainPage = activity as MainPage?
        myDealersItems = mainPage!!.myDealersItems
        dataFlagContainer = mainPage.dealerTabData


        preference = mainPage.preference

        //fab
        this.fab = mainPage.fab
        this.network_fab_container = mainPage.network_fab_container
        this.existing_dealer_fab_container = mainPage.existing_dealer_fab_container


        this.mViewPager = mainPage.mViewPager

    }


    private fun setTextOnButton() {
        addDealerFromExistingNetwork.text = "+ " + resources.getString(R.string.dealer_from_existing_network)
        add_dealer_to_your_network.text = "+ " + resources.getString(R.string.dealer_add_network)
    }

    private fun setUpDealersAdapter() {
        myDealersRecyclerView = findViewById(R.id.my_dealers_recycler_view) as RecyclerView

        myDealersRecyclerAdapter = DealersAdapter(myDealersItems, this)
        myDealersRecyclerView.layoutManager = LinearLayoutManager(activity)
        myDealersRecyclerView.adapter = myDealersRecyclerAdapter

        setRecyclerViewScrollListener()

    }


    private fun bindListeners() {
        existing_dealer_fab_container.setOnClickListener {
            if (existing_dealer_fab_container.alpha != 0f) {
                addDealerPress()
            }
        }

        network_fab_container.setOnClickListener { view ->
            if (network_fab_container.alpha != 0f) {
                addDealerToYourNetworkPress()
            }
        }
    }


    private fun setRecyclerViewScrollListener() {
        myDealersRecyclerView.addOnScrollListener(object : HidingPageScrollListener(){
            override fun onScrolledToEnd() {

            }

            override fun onHide() {
                hideViews()
            }

            override fun onShow() {
                showViews()
            }

        })
    }

    private fun hideViews(){
        fab.close(true)
        fab.animate().translationY(fab.height +resources.getDimension(R.dimen.main_page_fab_margin)).setInterpolator(AccelerateInterpolator(2F)).start()

    }

    private fun showViews(){
        fab.animate().translationY(0F).setInterpolator(DecelerateInterpolator(2F)).start()
    }

    private fun getDealerData() {
        serviceManager.api.getNetworkDealers(preference.getString(Constants.ACCESS_TOKEN)).enqueue(object : Callback<NetworkDealersResponse> {
            override fun onResponse(call: Call<NetworkDealersResponse>, response: Response<NetworkDealersResponse>) {
                if (response.isSuccessful) {

                    dataFlagContainer.isDataLoaded = true


                    loader.visibility = View.GONE

                    val networkListResponse = response.body()
                    myDealersItems.addAll(networkListResponse.data.dealer_list)

                    showView()

                    myDealersRecyclerAdapter.notifyDataSetChanged()


                }
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<NetworkDealersResponse>, t: Throwable) {
                // Toast.makeText(getContext(),Constants.ERROR_MSG_TOAST,Toast.LENGTH_SHORT).show();


                loader.visibility = View.GONE

                dataFlagContainer.isDataLoaded = true


                swipeRefreshLayout.isRefreshing = false
                if (myDealersItems.size <= 0) {
                    dealersFirstTimeScreen.visibility = View.VISIBLE
                    layout_for_hide_and_show.visibility = View.GONE
                }

            }
        })
    }

    private fun showView() {
        /*show hide adapter and first time view*/
        if (myDealersItems.size <= 0) {
            dealersFirstTimeScreen.visibility = View.VISIBLE
            layout_for_hide_and_show.visibility = View.GONE
        } else {
            dealersFirstTimeScreen.visibility = View.GONE
            layout_for_hide_and_show.visibility = View.VISIBLE

        }
        /*show hide adapter and first time view*/


        /*show dealer fab*/
        if (mViewPager.currentItem == 3 && myDealersItems.size > 0) {
            fab.showMenuButton(true)
        } else {
            fab.hideMenuButton(true)
        }
        /*show dealer fab*/
    }

    fun addDealerPress() {
        val intent = Intent(context, SelectNetworkFromDealerGroup::class.java)
        startActivity(intent)
        activity!!.overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }


    private fun sendInvitationUrl() {
        AppUtils.dealerInvite(preference, context)
    }

    fun addDealerToYourNetworkPress() {
        if (preference.getString(Constants.INVITE_COMPANIES_URL).isEmpty()) {
            return
        }
        sendInvitationUrl()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == CARDS_ACTIVITY_CODE) {
                if (data!!.getBooleanExtra("isDataDeleted", false)) {
                    val app = activity!!.applicationContext as CustomApplication
                    myDealersItems.clear()
                    myDealersItems.addAll(app.dealerItems)
                    showView()
                    myDealersRecyclerAdapter.notifyDataSetChanged()
                }
            }
        }

    }

    companion object {


        //activity code
        const val CARDS_ACTIVITY_CODE = 500
    }
}