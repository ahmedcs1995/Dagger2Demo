package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerGroupDataModel;

import java.util.ArrayList;

public class DealerGroupChipAdapter extends RecyclerView.Adapter<DealerGroupChipAdapter.ViewHolder>  {
    public ArrayList<DealerGroupDataModel> items = new ArrayList<>();
    public ArrayList<DealerGroupDataModel> tempItems = new ArrayList<>();
    Context context;
    TextView label;
    View container;
    CustomCallBack customCallBack;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View cancelBtn;
        TextView name;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            cancelBtn=itemView.findViewById(R.id.cancel_btn);
            name=itemView.findViewById(R.id.name);
        }
    }

    public DealerGroupChipAdapter(ArrayList<DealerGroupDataModel> items, Context context,TextView label,View container) {
        this.items = items;
        this.context = context;
        this.label = label;
        this.container = container;
    }

    public DealerGroupChipAdapter(ArrayList<DealerGroupDataModel> items,ArrayList<DealerGroupDataModel> tempItems, Context context,TextView label,View container) {
        this.items = items;
        this.tempItems = tempItems;
        this.context = context;
        this.label = label;
        this.container = container;
    }

    public DealerGroupChipAdapter(ArrayList<DealerGroupDataModel> items,ArrayList<DealerGroupDataModel> tempItems, Context context,TextView label,View container,CustomCallBack customCallBack) {
        this.items = items;
        this.tempItems = tempItems;
        this.context = context;
        this.label = label;
        this.container = container;
        this.customCallBack=customCallBack;
    }



    @Override
    public DealerGroupChipAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chip_view_item, parent, false);
        return new DealerGroupChipAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final DealerGroupChipAdapter.ViewHolder holder, final int position) {
        final DealerGroupDataModel item = items.get(position);

        holder.name.setText("" + item.getGroupName());


        holder.cancelBtn.setOnClickListener(view -> {
            removeAt(position);
            tempItems.remove(position);
            checkContainerVisibility();

            if(customCallBack!=null){
                customCallBack.act();
            }
        });
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,items.size());
    }

    private void checkContainerVisibility(){
        if(items.size() <=0){
            container.setVisibility(View.GONE);
            return;
        }
        label.setText("You have selected " + items.size() + " dealer group");
        container.setVisibility(View.VISIBLE);
    }


    @Override
    public int getItemCount() {
        return items.size();
    }


}

