package com.mobileapp.krank.ResponseModels.DataModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChatImageUploadDataModel {
    @SerializedName("errors")
    @Expose
    private List<Object> errors = null;
    @SerializedName("success")
    @Expose
    private List<ChatImageUploadSuccessModel> success = null;

    public List<Object> getErrors() {
        return errors;
    }

    public void setErrors(List<Object> errors) {
        this.errors = errors;
    }

    public List<ChatImageUploadSuccessModel> getSuccess() {
        return success;
    }

    public void setSuccess(List<ChatImageUploadSuccessModel> success) {
        this.success = success;
    }

}
