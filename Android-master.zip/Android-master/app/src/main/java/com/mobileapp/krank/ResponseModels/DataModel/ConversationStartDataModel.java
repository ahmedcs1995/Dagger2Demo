package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ConversationStartDataModel {
    @SerializedName("message")
    @Expose
    private ConversationDetail convo_msg;

    @SerializedName("conversation_id")
    @Expose
    private String conversation_id;

    public ConversationDetail getConvo_msg() {
        return convo_msg;
    }

    public void setConvo_msg(ConversationDetail convo_msg) {
        this.convo_msg = convo_msg;
    }

    public String getConversation_id() {
        return conversation_id;
    }

    public void setConversation_id(String conversation_id) {
        this.conversation_id = conversation_id;
    }
}
