package com.mobileapp.krank.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Html;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by ahmed on 2/23/2017.
 */

public class CustomFaView extends android.support.v7.widget.AppCompatTextView {
    public CustomFaView(Context context) {
        super(context);
        this.setCustomFont(context);
    }

    public CustomFaView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setCustomFont(context);
    }

    public CustomFaView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.setCustomFont(context);
    }

    public void setCustomFont(Context context){
        String fontName = "fontawesome-webfont.ttf";
        Typeface face1= Typeface.createFromAsset(context.getAssets(), "fonts/"+fontName);
        setTypeface(face1);
    }

}
