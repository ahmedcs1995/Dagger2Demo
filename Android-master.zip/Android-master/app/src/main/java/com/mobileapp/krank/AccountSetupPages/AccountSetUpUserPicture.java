package com.mobileapp.krank.AccountSetupPages;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.yalantis.ucrop.UCrop;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Ahmed on 3/30/2018.
 */

public class AccountSetUpUserPicture extends BaseFragment {
    View imgSelect;
    CircleImageView imgOFUser;
    View camera_placeholder;
    TextView profilePicText;
    TextView text_view_name;
    private SaveInSharedPreference preference;


    CustomImagePicker imagePicker;
    public AccountSetUpUserPicture() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_two, container, false);
        setFragmentView(me);


        init();


        initViews();

        imgSelect.setOnClickListener(view -> {
            imagePicker.pickImage(AccountSetUpUserPicture.this);
        });

        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));


        setProfilePictureOfUser();

        return me;
    }

    private void init() {


        AccountSetupPage accountSetupPage = ((AccountSetupPage)getActivity());
        preference = accountSetupPage.preference;


        imagePicker = new CustomImagePicker();


    }


    private void initViews() {
        imgSelect = findViewById(R.id.img_select);
        camera_placeholder = findViewById(R.id.camera_placeholder);
        profilePicText = (TextView) findViewById(R.id.profile_pic_text);
        imgOFUser = (CircleImageView) findViewById(R.id.img_user);
        text_view_name = (TextView) findViewById(R.id.text_view_name);

    }

    private void setProfilePictureOfUser() {

        if (preference.getString(Constants.PROFILE_PICTURE).isEmpty()) {
            return;
        }
        Glide.with(getContext()).load(preference.getString(Constants.PROFILE_PICTURE)).into(imgOFUser);
        camera_placeholder.setVisibility(View.GONE);
        profilePicText.setText(Constants.USER_IMG_UPLOAD_MESSAGE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (resultCode == RESULT_OK) {
            if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);
                ApiUtils.uploadImage(resultUri, Constants.USER_PROFILE_IMG, preference, getContext());
                preference.setString(Constants.TEMP_USER_PROFILE_PICTURE,resultUri.toString());
                setImage(resultUri);
            } else {
                Bitmap bitmap = imagePicker.handleImagePick(requestCode,getActivity(),  intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(getContext(), bitmap), Uri.fromFile(new File(getActivity().getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, getContext(), Constants.USER_PROFILE_IMG);
                    uCrop.start(getContext(), AccountSetUpUserPicture.this);
                }
            }
        }
    }

    private void setImage(Uri uri) {
        ((AccountSetupPage)getActivity()).hideSkipNowView();
        Constants.USER_IMG = true;
        Glide.with(this).load(uri).into(imgOFUser);
        camera_placeholder.setVisibility(View.GONE);
        profilePicText.setText(Constants.USER_IMG_UPLOAD_MESSAGE);
    }
}
