package com.mobileapp.krank.AccountSetupPages;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.yalantis.ucrop.UCrop;

import java.io.File;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Yaseen on 09/04/2018.
 */

public class AccountSetUpUserCoverPicture extends BaseFragment implements AccountSetupPage.PictureChangeListener {

    //views
    ImageView coverImg;
    ImageView imgPlaceHolder;
    ImageView temp_profile_picture;
    View imgSelect;
    TextView coverPicText;
    TextView text_view_name;


    CustomImagePicker imagePicker;
    private SaveInSharedPreference preference;
    public AccountSetUpUserCoverPicture() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_three, container, false);
        setFragmentView(me);

        init();
        initViews();
        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));


        coverImg.setVisibility(View.GONE);
        imgSelect.setOnClickListener(view -> {
            imagePicker.pickImage(AccountSetUpUserCoverPicture.this);
        });

        update();
        setCoverPictureOfUser();
        return me;
    }

    private void initViews(){
        coverImg = (ImageView) findViewById(R.id.cover_img);
        imgPlaceHolder = (ImageView) findViewById(R.id.img_place_holder);
        temp_profile_picture = (ImageView) findViewById(R.id.temp_profile_picture);
        text_view_name = (TextView) findViewById(R.id.text_view_name);
        coverPicText = (TextView) findViewById(R.id.cover_pic_text);
        imgSelect = findViewById(R.id.img_select);


    }

    private void init(){

        //activity
        AccountSetupPage accountSetupPage = (AccountSetupPage)getActivity();
        preference = accountSetupPage.preference;


        //listener
        accountSetupPage.setmUserPicChangeListener(this);

        imagePicker = new CustomImagePicker();
    }
    @Override
    public void onPictureChange() {
        update();
    }


    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if(resultCode == RESULT_OK){
            if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);
                ApiUtils.uploadImage(resultUri, Constants.USER_COVER_IMG, preference, getContext());
                setImage(resultUri);
            }
            else{
               // Bitmap bitmap = ImagePicker.getImageFromResult(getActivity(), requestCode, resultCode, intent);
                Bitmap bitmap = imagePicker.handleImagePick(requestCode,getActivity(),  intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(getContext(), bitmap), Uri.fromFile(new File(getActivity().getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, getContext(), Constants.USER_COVER_IMG);
                    uCrop.start(getContext(), AccountSetUpUserCoverPicture.this);
                }
            }
        }
    }


    private void setImage(Uri uri) {
        Constants.COVER_IMG = true;
        ((AccountSetupPage)getActivity()).hideSkipNowView();
        imgPlaceHolder.setVisibility(View.GONE);
        Glide.with(this).load(uri).into(coverImg);
        coverPicText.setText(Constants.USER_COVER_IMG_UPLOAD_MESSAGE);
    }
    private void setCoverPictureOfUser(){

        if(preference.getString(Constants.COVER_PICTURE).isEmpty()){
            return;
        }

        coverImg.setVisibility(View.VISIBLE);
        imgPlaceHolder.setVisibility(View.GONE);
        Glide.with(getContext()).load(preference.getString(Constants.COVER_PICTURE)).into(coverImg);
        coverPicText.setText(Constants.USER_COVER_IMG_UPLOAD_MESSAGE);
    }

    public void  update() {
        if (!(preference.getString(Constants.TEMP_USER_PROFILE_PICTURE).isEmpty())) {
            Glide.with(getActivity()).load(Uri.parse(preference.getString(Constants.TEMP_USER_PROFILE_PICTURE))).apply(((AccountSetupPage)getActivity()).appUtils.getRequestOptions(getContext())).into(temp_profile_picture);
        }

        else if (!(preference.getString(Constants.PROFILE_PICTURE).isEmpty())) {
            Glide.with(getActivity()).load(Constants.BASE_IMG_URL + preference.getString(Constants.PROFILE_PICTURE)).apply(((AccountSetupPage)getActivity()).appUtils.getRequestOptions(getContext())).into(temp_profile_picture);
        } else {
            Glide.with(getActivity()).load(Constants.BASE_IMG_URL + "target-avatar.jpg").into(temp_profile_picture);
        }
    }


}