package com.mobileapp.krank.AccountSetupPages;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Adapters.CompanyInterestListAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomViews.CustomViewPager.SwipeableViewPager;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CompanyInterestListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInterestListData;
import com.mobileapp.krank.ResponseModels.UpdateInterestCompanyResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Field;

/**
 * Created by Yaseen on 18/04/2018.
 */


public class MarketPlaceInterestPage extends BaseFragment implements AccountSetupPage.ProceedButtonListener {

    //views
    TextView text_view_name;
    TextView error_view;


    //list
    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerAdapter;
    List<CompanyInterestListData> items;


    private static final String API_FLAG_KEY = "api_flag_2";

    //activity ref
    AccountSetupPage activityRef;

    public MarketPlaceInterestPage() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_eight, container, false);
        setFragmentView(me);


        init();

        text_view_name = me.findViewById(R.id.text_view_name);
        error_view = me.findViewById(R.id.error_view);


        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));


        setUpAdapter();

        if (shouldCallApi(savedInstanceState)) {
            getData();
        } else {
            //get data
            if (activityRef != null) {
                items.addAll(activityRef.getMarketPlaceInterest());
                recyclerAdapter.notifyDataSetChanged();
            }
        }


        return me;
    }

    private boolean shouldCallApi(Bundle savedInstanceState) {
        return !(savedInstanceState != null && savedInstanceState.getInt(API_FLAG_KEY, 0) == 1);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(API_FLAG_KEY, 1);

    }

    private void init() {
        activityRef = (AccountSetupPage) getActivity();

        activityRef.setmMarketPlaceInterestProceedListener(this::onProceed);
        preference = activityRef.preference;
    }

    private void setUpAdapter() {
        recyclerView = (RecyclerView) findViewById(R.id.checkBox_recycler);
        items = new ArrayList<>();


        recyclerAdapter = new CompanyInterestListAdapter(items, getActivity());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerAdapter);


    }

    private void getData() {
        ((AccountSetupPage) getActivity()).getAPI().getCompanyInterestList(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<CompanyInterestListResponse>() {
            @Override
            public void onResponse(Call<CompanyInterestListResponse> call, Response<CompanyInterestListResponse> response) {


                if (response.body().getStatus().equals("success")) {


                    items.addAll(response.body().getData());

                    if (activityRef != null) {
                        activityRef.setMarketPlaceInterest(items);
                    }

                    recyclerAdapter.notifyDataSetChanged();


                }

            }

            @Override
            public void onFailure(Call<CompanyInterestListResponse> call, Throwable t) {

            }
        });
    }


    /*
     * Update Data
     */
    public void update() {

        final ArrayList<String> marketplace_categories = new ArrayList<>();

        //adding
        for (CompanyInterestListData item : items) {
            if (item.getIsSelected()) {
                marketplace_categories.add(item.getCategoryId());
            }
        }

        //validation
       /* if (marketplace_categories.size() <= 0) {
            error_view.setText("Please select an option");
            return;
        }*/

        //proceed

        activityRef.getListener().onNextPage();


        error_view.setText("");

        UpdateInterestPostModel params = new UpdateInterestPostModel(marketplace_categories);


        activityRef.getAPI().updateCompanyInterest(preference.getString(Constants.ACCESS_TOKEN),params).enqueue(new Callback<UpdateInterestCompanyResponse>() {
            @Override
            public void onResponse(Call<UpdateInterestCompanyResponse> call, Response<UpdateInterestCompanyResponse> response) {

                try {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();

                        } else {
                            Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (Exception ex) {

                }


            }

            @Override
            public void onFailure(Call<UpdateInterestCompanyResponse> call, Throwable t) {

            }
        });
    }


    @Override
    public void onProceed(SwipeableViewPager mViewPager, ImageView nextBtn) {
        update();
    }

    public class UpdateInterestPostModel{
        @SerializedName("marketplace_categories")
        private ArrayList<String> marketplace_categories;

        public ArrayList<String> getMarketplace_categories() {
            return marketplace_categories;
        }

        public void setMarketplace_categories(ArrayList<String> marketplace_categories) {
            this.marketplace_categories = marketplace_categories;
        }

        public UpdateInterestPostModel(ArrayList<String> marketplace_categories) {
            this.marketplace_categories = marketplace_categories;
        }
    }
}