package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Adapters.PagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Model.FilterMarketPlaceModel;
import com.mobileapp.krank.Model.ListingSearchModel;
import com.mobileapp.krank.MyListingTabs.MyListingRent;
import com.mobileapp.krank.MyListingTabs.MyListingSale;
import com.mobileapp.krank.R;

import java.util.ArrayList;

public class MyListingPage extends BaseActivity {


    private Typeface mTypefaceBold;
    private Typeface mTypefaceNormal;
    private ViewPager mViewPager;
    private TabLayout mCustomTabLayout;
    private static int TAB_TEXT_SIZE = 15;

    View filterBtn;
    View searchBtn;

    private static int SEARCH_PAGE_CODE = 20;
    private static int FILTER_PAGE_CODE = 30;
    private static int SORT_PAGE_CODE = 40;
    MyListingSale sale;
    MyListingRent rent;


    ListingSearchModel listingSearchModelForSale;
    ListingSearchModel listingSearchModelForRent;

    FilterMarketPlaceModel filterMarketPlaceModelForSale;
    FilterMarketPlaceModel filterMarketPlaceModelForRent;




    private static String LISTING_TYPE ;
    private static final String SALE_LISTING = "sale_listing" ;
    private static final String RENT_LISTING = "rent_listing" ;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_listing_page);

        mTypefaceBold = Typeface.createFromAsset(this.getAssets(), "fonts/HELR65W.ttf");
        mTypefaceNormal = Typeface.createFromAsset(this.getAssets(), "fonts/HELR45W.ttf");


        sale = new MyListingSale();
       // sale.setListingCode(1);
        rent = new MyListingRent();
        //rent.setListingCode(2);

        setNormalPageToolbar("My Listings");

        listingSearchModelForSale = new ListingSearchModel("Keyword", "");
        listingSearchModelForRent = new ListingSearchModel("Keyword", "");


        filterMarketPlaceModelForSale = new FilterMarketPlaceModel("0", "0", "0", -1, -1, -1, "", "", "");
        filterMarketPlaceModelForRent = new FilterMarketPlaceModel("0", "0", "0", -1, -1, -1, "", "", "");


        filterBtn = findViewById(R.id.filter_btn);
        searchBtn = findViewById(R.id.search_btn);




        filterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mViewPager.getCurrentItem() == 0) {
                    LISTING_TYPE = SALE_LISTING;
                    Intent intent = new Intent(MyListingPage.this, FilterMarketPlace.class);
                    intent.putExtra("filtered_data", appUtils.convertToJson(filterMarketPlaceModelForSale));
                    startActivityForResult(intent, FILTER_PAGE_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                }
                else{
                    LISTING_TYPE=RENT_LISTING;
                    Intent intent = new Intent(MyListingPage.this, FilterMarketPlace.class);
                    intent.putExtra("filtered_data", appUtils.convertToJson(filterMarketPlaceModelForRent));
                    startActivityForResult(intent, FILTER_PAGE_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                }

            }
        });
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mViewPager.getCurrentItem() == 0) {
                    LISTING_TYPE = SALE_LISTING;
                    Intent intent = new Intent(MyListingPage.this, SearchMarketPlace.class);
                    intent.putExtra("search_data", appUtils.convertToJson(listingSearchModelForSale));
                    startActivityForResult(intent, SEARCH_PAGE_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                }
                else{
                    LISTING_TYPE=RENT_LISTING;
                    Intent intent = new Intent(MyListingPage.this, SearchMarketPlace.class);
                    intent.putExtra("search_data", appUtils.convertToJson(listingSearchModelForRent));
                    startActivityForResult(intent, SEARCH_PAGE_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                }

            }
        });
        setViewPagerAndTabLayout();
        mViewPager.setCurrentItem(getIntent().getIntExtra("currentItem",0));


    }

    private void setViewPagerAndTabLayout() {
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mCustomTabLayout = findViewById(R.id.sliding_tabs);
        ArrayList<BaseFragment> pages = new ArrayList<>();

        pages.add(sale);
        pages.add(rent);
        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));

        mCustomTabLayout.setupWithViewPager(mViewPager);

        mViewPager.setOffscreenPageLimit(pages.size());
        setInitialTabLayoutConfig();


        mCustomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());

                TextView text = (TextView) tab.getCustomView();


                text.setTypeface(mTypefaceBold);
                text.setTextColor(getResources().getColor(R.color.AppDarkGray));
                text.setTextSize(TAB_TEXT_SIZE);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TextView text = (TextView) tab.getCustomView();

                text.setTypeface(mTypefaceNormal);
                text.setTextColor(getResources().getColor(R.color.drawerGray));
                text.setTextSize(TAB_TEXT_SIZE);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });
    }

    private void setInitialTabLayoutConfig() {
        for (int i = 0; i < mCustomTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mCustomTabLayout.getTabAt(i);
            if (tab != null) {
                TextView tabTextView = new TextView(this);
                tab.setCustomView(tabTextView);

                tabTextView.getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
                tabTextView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;

                tabTextView.setTextColor(getResources().getColor(R.color.drawerGray));
                tabTextView.setTypeface(mTypefaceNormal);
                tabTextView.setTextSize(TAB_TEXT_SIZE);

                tabTextView.setText(tab.getText());

                // First tab is the selected tab, so if i==0 then set BOLD typeface
                if (i == 0) {
                    tabTextView.setTypeface(mTypefaceBold);
                    tabTextView.setTextColor(getResources().getColor(R.color.AppDarkGray));
                }

            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SEARCH_PAGE_CODE) {
                if(LISTING_TYPE.equals(SALE_LISTING)){
                    listingSearchModelForSale = gson.fromJson(data.getStringExtra("search_data"), ListingSearchModel.class);
                    String sale_search_type;
                    if (listingSearchModelForSale.getSearchType().equals("Keyword")) {
                        sale_search_type = "any";
                    } else {
                        sale_search_type = "exact";
                    }
                    sale.performSearchFilterization(listingSearchModelForSale.getSearchKeyword(), sale_search_type);
                }
                else{
                    listingSearchModelForRent = gson.fromJson(data.getStringExtra("search_data"), ListingSearchModel.class);
                    String sale_search_type;
                    if (listingSearchModelForRent.getSearchType().equals("Keyword")) {
                        sale_search_type = "any";
                    } else {
                        sale_search_type = "exact";
                    }
                    rent.performSearchFilterization(listingSearchModelForRent.getSearchKeyword(), sale_search_type);
                }

            } else if (requestCode == FILTER_PAGE_CODE) {
                if(LISTING_TYPE.equals(SALE_LISTING)){
                    filterMarketPlaceModelForSale = gson.fromJson(data.getStringExtra("filtered_data"), FilterMarketPlaceModel.class);
                    String category_id = filterMarketPlaceModelForSale.getCategoryId();
                    String subCategoryId = (filterMarketPlaceModelForSale.getSubCategoryId().equals("-1")) ? "0" : filterMarketPlaceModelForSale.getSubCategoryId();
                    String type_id = (filterMarketPlaceModelForSale.getType().equals("-1")) ? "0" : filterMarketPlaceModelForSale.getType();
                    sale.performCategoryFilterization(category_id, subCategoryId, type_id);
                }
                else{
                    filterMarketPlaceModelForRent = gson.fromJson(data.getStringExtra("filtered_data"), FilterMarketPlaceModel.class);
                    String category_id = filterMarketPlaceModelForRent.getCategoryId();
                    String subCategoryId = (filterMarketPlaceModelForRent.getSubCategoryId().equals("-1")) ? "0" : filterMarketPlaceModelForRent.getSubCategoryId();
                    String type_id = (filterMarketPlaceModelForRent.getType().equals("-1")) ? "0" : filterMarketPlaceModelForRent.getType();
                    rent.performCategoryFilterization(category_id, subCategoryId, type_id);
                }

            }
        }
    }
}

