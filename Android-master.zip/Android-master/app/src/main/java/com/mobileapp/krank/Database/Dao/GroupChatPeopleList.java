package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;


import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;

import java.util.List;
@Dao
public interface GroupChatPeopleList {
    @Query("Select * from group_chat_members_list_table where groupId=:groupId")
    LiveData<List<GroupChatMembersDataModel>> getPeopleList(String groupId);

    @Insert
    long insert(GroupChatMembersDataModel conversationDetail);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<GroupChatMembersDataModel> conversationDetails);

    @Query("Delete from group_chat_members_list_table where groupIdUserId=:grpUserId")
    void deletePeople(String grpUserId);

    @Query("Delete from group_chat_members_list_table")
    void deleteAll();
}
