package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.RequestRecievedItem;
import com.mobileapp.krank.Model.Enums.TypeOfRequest;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Yaseen on 28/04/2018.
 */


public class RequestAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<RequestRecievedItem> items;
    Context context;

    String requestType;
    private static String ACCEPT_REQUEST = "accept_request";
    private static String REJECT_REQUEST = "reject_request";
    private static String CANCEL_REQUEST = "cancel_request";
    ServiceManager serviceManager;
    SaveInSharedPreference preference;

    public int connectionRequestLeft;
    public int networkRequestLeft;
    public int dealerRequestLeft;

    AppUtils appUtils;


    public class HeaderListItem extends RecyclerView.ViewHolder {
        TextView header_title;

        public HeaderListItem(View itemView) {
            super(itemView);
            header_title = itemView.findViewById(R.id.header_title);

        }
    }

    public class NoRequestFoundItem extends RecyclerView.ViewHolder {
        TextView no_request_found_text;

        public NoRequestFoundItem(View itemView) {
            super(itemView);
            no_request_found_text = itemView.findViewById(R.id.no_request_found_text);

        }
    }

    public class RequestListItem extends RecyclerView.ViewHolder {
        View item;
        SimpleDraweeView profile_image_view;
        TextView employee_name_text_view;
        TextView company_name_text_view;
        TextView enquiry_text;
        View accept_btn;
        View reject_btn;
        View accept_reject_btn_container;
        View cancel_request_btn;

        public RequestListItem(View itemView) {
            super(itemView);
            profile_image_view = itemView.findViewById(R.id.profile_image_view);
            employee_name_text_view = itemView.findViewById(R.id.employee_name_text_view);
            company_name_text_view = itemView.findViewById(R.id.company_name_text_view);
            accept_btn = itemView.findViewById(R.id.accept_btn);
            reject_btn = itemView.findViewById(R.id.reject_btn);
            accept_reject_btn_container = itemView.findViewById(R.id.accept_reject_btn_container);
            cancel_request_btn = itemView.findViewById(R.id.cancel_request_btn);
            enquiry_text = itemView.findViewById(R.id.enquiry_text);

            profile_image_view.setOnClickListener(view -> {
                appUtils.gotoUserProfile(context,items.get(getAdapterPosition()).getUserId(),preference);
            });
            employee_name_text_view.setOnClickListener(view -> {
                appUtils.gotoUserProfile(context,items.get(getAdapterPosition()).getUserId(),preference);
            });
            company_name_text_view.setOnClickListener(view -> {
                appUtils.gotoCompanyProfile(context,items.get(getAdapterPosition()).getCompanyId(),preference);
            });

            accept_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());

                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                }
            });
            reject_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());

                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                }
            });
            cancel_request_btn.setOnClickListener(view -> {

                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());


                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                }
            });

        }
    }

    public class RequestListItemCompanyView extends RecyclerView.ViewHolder {
        View item;
        SimpleDraweeView network_profile_image_view;
        View accept_reject_btn_container;
        View accept_btn;
        View reject_btn;
        View cancel_request_btn;
        TextView employee_name_text_view;


        TextView company_name_text_view;
        TextView enquiry_text;

        public RequestListItemCompanyView(View itemView) {
            super(itemView);
            network_profile_image_view = itemView.findViewById(R.id.network_profile_image_view);
            accept_reject_btn_container = itemView.findViewById(R.id.accept_reject_btn_container);
            accept_btn = itemView.findViewById(R.id.accept_btn);
            reject_btn = itemView.findViewById(R.id.reject_btn);
            cancel_request_btn = itemView.findViewById(R.id.cancel_request_btn);
            employee_name_text_view = itemView.findViewById(R.id.employee_name_text_view);
            company_name_text_view = itemView.findViewById(R.id.company_name_text_view);

            enquiry_text = itemView.findViewById(R.id.enquiry_text);

           /* profile_image_view.setOnClickListener(view -> {
                appUtils.gotoUserProfile(context,items.get(getAdapterPosition()).getUserId(),preference);
            });*/
            employee_name_text_view.setOnClickListener(view -> {
                appUtils.gotoCompanyProfile(context,items.get(getAdapterPosition()).getCompanyId(),preference);
            });
            company_name_text_view.setOnClickListener(view -> {
                appUtils.gotoCompanyProfile(context,items.get(getAdapterPosition()).getCompanyId(),preference);
            });
            network_profile_image_view.setOnClickListener(view -> {
                appUtils.gotoCompanyProfile(context,items.get(getAdapterPosition()).getCompanyId(),preference);
            });



            accept_btn.setOnClickListener(view -> {

                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());


                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), ACCEPT_REQUEST, item.getConId());
                        break;
                }
            });
            reject_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());

                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), REJECT_REQUEST, item.getConId());
                        break;
                }
            });
            cancel_request_btn.setOnClickListener(view -> {

                if(getAdapterPosition() < 0) return;
                RequestRecievedItem item = items.get(getAdapterPosition());


                switch (item.getTypeOfRequest()) {
                    case CONNECTION_REQUEST_LIST_ITEM:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                    case NETWORK_REQUEST_LIST_ITEM:
                        handleNetworkRequestAccept(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                    case DEALER_REQUEST_LIST_ITEM:
                        handleDealerRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, item.getConId());
                        break;
                }
            });

        }
    }

    public class BlankUserViewHolder extends RecyclerView.ViewHolder {
        View item;
        TextView enquiry_text;
        View cancel_request_btn;
        public BlankUserViewHolder(View itemView) {
            super(itemView);
            enquiry_text = itemView.findViewById(R.id.enquiry_text);
            cancel_request_btn = itemView.findViewById(R.id.cancel_request_btn);

            cancel_request_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0) return;
                switch (items.get(getAdapterPosition()).getTypeOfRequest()) {
                    case CONNECTION_BLANK_VIEW:
                        handleConnectionRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, items.get(getAdapterPosition()).getConId());
                        break;
                    case NETWORK_BLANK_VIEW:
                        handleNetworkRequestAccept(getAdapterPosition(), CANCEL_REQUEST, items.get(getAdapterPosition()).getConId());
                        break;
                    case DEALER_BLANK_VIEW:
                        handleDealerRequestAcceptReject(getAdapterPosition(), CANCEL_REQUEST, items.get(getAdapterPosition()).getConId());
                        break;
                }
            });
        }
    }

    public RequestAdapter(List<RequestRecievedItem> items, Context context, String requestType, int connectionRequestLeft, int networkRequestLeft, int dealerRequestLeft) {
        this.items = items;
        this.context = context;
        this.requestType = requestType;
        serviceManager =  ServiceManager.getInstance();
        preference = new SaveInSharedPreference(context);
        this.connectionRequestLeft = connectionRequestLeft;
        this.networkRequestLeft = networkRequestLeft;
        this.dealerRequestLeft = dealerRequestLeft;
        appUtils = AppUtils.getInstance();
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public int getItemViewType(int position) {

        switch (items.get(position).getTypeOfRequest()) {
            case CONNECTION_REQUEST_HEADER:
            case NETWORK_REQUEST_HEADER:
            case DEALER_REQUEST_HEADER:
                return 1;
            case DEALER_REQUEST_LIST_ITEM:
            case NETWORK_REQUEST_LIST_ITEM:
                return 4;
            case CONNECTION_REQUEST_LIST_ITEM:
                return 2;
            case NO_DEALER_REQUEST:
            case NO_NETWORK_REQUEST:
            case NO_CONNECTION_REQUEST:
                return 3;
            case DEALER_BLANK_VIEW:
            case NETWORK_BLANK_VIEW:
            case CONNECTION_BLANK_VIEW:
                return 5;
            default:
                return -1;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      /*  View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_recieved_item, parent, false);
        return new MarketPlaceViewHolder(v);*/
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_header_item, parent, false);
                return new HeaderListItem(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_list_item, parent, false);
                return new RequestListItem(view);
            case 3:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.no_request_found_item, parent, false);
                return new NoRequestFoundItem(view);
            case 4:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_list_item_company, parent, false);
                return new RequestListItemCompanyView(view);
            case 5:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.blank_user_view, parent, false);
                return new BlankUserViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_header_item, parent, false);
                return new HeaderListItem(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final RequestRecievedItem item = items.get(position);

        switch (item.getTypeOfRequest()) {
            case CONNECTION_REQUEST_HEADER:
                //connectionViewHolder(holder);
                setHeaderTitle(holder, "Connection Requests");
                break;
            case NETWORK_REQUEST_HEADER:
                // networkViewHolder(holder);
                setHeaderTitle(holder, "Network Request");

                break;
            case DEALER_REQUEST_HEADER:
                setHeaderTitle(holder, "Dealer Request");
                //   dealerViewHolder(holder);
                break;
            case CONNECTION_REQUEST_LIST_ITEM:
                listItem(holder, item, position);
                //   dealerViewHolder(holder);
                break;
            case DEALER_REQUEST_LIST_ITEM:
                companyListItem(holder, item, position);
                //   dealerViewHolder(holder);
                break;
            case NETWORK_REQUEST_LIST_ITEM:
                companyListItem(holder, item, position);
                //   dealerViewHolder(holder);
                break;
            case NO_CONNECTION_REQUEST:
                noRequestFoundText(holder, "No connection requests for you to manage");
                break;
            case NO_NETWORK_REQUEST:
                noRequestFoundText(holder, "No network request for you to manage");
                break;
            case NO_DEALER_REQUEST:
                noRequestFoundText(holder, "No dealer request for you to manage");
                break;
            case DEALER_BLANK_VIEW:
            case NETWORK_BLANK_VIEW:
            case CONNECTION_BLANK_VIEW:
                setBlankView(holder,item);
                break;

        }
    }

    private void setBlankView(RecyclerView.ViewHolder holder,RequestRecievedItem item){
        BlankUserViewHolder viewHolder =(BlankUserViewHolder)holder;

        viewHolder.enquiry_text.setText(item.getEnquiryMessageBuilder());
        viewHolder.enquiry_text.setMovementMethod(LinkMovementMethod.getInstance());


    }
    private void setHeaderTitle(RecyclerView.ViewHolder holder, String title) {
        final HeaderListItem viewHolder = (HeaderListItem) holder;
        viewHolder.header_title.setText(title);
    }

    private void noRequestFoundText(RecyclerView.ViewHolder holder, String msg) {
        final NoRequestFoundItem viewHolder = (NoRequestFoundItem) holder;
        viewHolder.no_request_found_text.setText(msg);
    }

    private void listItem(RecyclerView.ViewHolder holder, final RequestRecievedItem item, final int position) {
        final RequestListItem viewHolder = (RequestListItem) holder;

     //   Glide.with(context).load(item.getProfilePic()).into(viewHolder.profile_image_view);
        viewHolder.employee_name_text_view.setText("" + item.getFirstName() + " " + item.getLastName());
        viewHolder.company_name_text_view.setText("" + AppUtils.getCompanyAndDesignation(item.getCompanyName(), item.getDesignation()));


        viewHolder.profile_image_view.setImageURI(Uri.parse(item.getProfilePic()));

        if(item.getEnquiryMessageBuilder()!=null){
            viewHolder.enquiry_text.setVisibility(View.VISIBLE);
            viewHolder.enquiry_text.setText(item.getEnquiryMessageBuilder());
            viewHolder.enquiry_text.setMovementMethod(LinkMovementMethod.getInstance());
        }else{
            viewHolder.enquiry_text.setVisibility(View.GONE);
        }

        if (requestType.equals("request_sent")) {
            viewHolder.cancel_request_btn.setVisibility(View.VISIBLE);
            viewHolder.accept_reject_btn_container.setVisibility(View.GONE);
        } else {
            viewHolder.cancel_request_btn.setVisibility(View.GONE);
            viewHolder.accept_reject_btn_container.setVisibility(View.VISIBLE);
        }

       // appUtils.gotoUserProfile(context,item.getUserId(),preference);


    }

    private String getCountryAndCity(String city,String country){
        if(country == null && city == null){
            return null;
        }
        if(city == null){
            return country;
        }else if(country == null){
            return city;
        }else{
            return city + "," + country;
        }

    }
    private void companyListItem(RecyclerView.ViewHolder holder, final RequestRecievedItem item, final int position) {
        final RequestListItemCompanyView viewHolder = (RequestListItemCompanyView) holder;

       // Glide.with(context).load(item.getCompanyPic()).into(viewHolder.network_profile_image_view);
        viewHolder.network_profile_image_view.setImageURI(Uri.parse(item.getCompanyPic()));

        viewHolder.employee_name_text_view.setText("" + item.getCompanyName());
        String countryCity = getCountryAndCity(item.getCity(),item.getCountry());
        if(countryCity !=null){
            viewHolder.company_name_text_view.setText(countryCity);
        }else{
            viewHolder.company_name_text_view.setVisibility(View.GONE);
        }



        if(item.getEnquiryMessageBuilder()!=null){
            viewHolder.enquiry_text.setVisibility(View.VISIBLE);
            viewHolder.enquiry_text.setText(item.getEnquiryMessageBuilder());
            viewHolder.enquiry_text.setMovementMethod(LinkMovementMethod.getInstance());
        }else{
            viewHolder.enquiry_text.setVisibility(View.GONE);
        }

        if (requestType.equals("request_sent")) {
            viewHolder.cancel_request_btn.setVisibility(View.VISIBLE);
            viewHolder.accept_reject_btn_container.setVisibility(View.GONE);
        } else {
            viewHolder.cancel_request_btn.setVisibility(View.GONE);
            viewHolder.accept_reject_btn_container.setVisibility(View.VISIBLE);
        }


       // viewHolder.profile_image_view.setOnClickListener();
        //appUtils.gotoCompanyProfile(context,item.getCompanyId(),preference);



    }

    private void changeElement(RequestRecievedItem noRequestItem, int index) {

        items.add(index, noRequestItem);

        notifyItemRangeChanged(index, items.size());

    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }

    private void handleNetworkRequestAccept(final int position, String type, String connectionId) {
        if (networkRequestLeft > 0) {
            networkRequestLeft--;

            if (type.equals(ACCEPT_REQUEST)) {
                acceptNetworkRequest(connectionId);
            } else if (type.equals(REJECT_REQUEST)) {
                rejectNetworkRequest(connectionId);
            } else {
                cancelNetworkRequest(connectionId);
            }
            if (networkRequestLeft == 0) {
                items.remove(position);
                changeElement(new RequestRecievedItem(TypeOfRequest.NO_NETWORK_REQUEST), position);
            } else {
                removeAt(position);
            }
        }
    }

    private void handleConnectionRequestAcceptReject(final int position, String type, String connectionId) {
        if (connectionRequestLeft > 0) {
            connectionRequestLeft--;
            /*sending request*/
            if (type.equals(ACCEPT_REQUEST)) {
                acceptConnectionRequest(connectionId);
            } else if (type.equals(REJECT_REQUEST)) {
                rejectConnectionRequest(connectionId);
            } else {
                cancelConnectionRequest(connectionId);
            }
            /*removing items*/
            if (connectionRequestLeft == 0) {
                items.remove(position);
                changeElement(new RequestRecievedItem(TypeOfRequest.NO_CONNECTION_REQUEST), position);
            } else {
                removeAt(position);
            }
        }
    }

    private void handleDealerRequestAcceptReject(final int position, String type, String connectionId) {
        if (dealerRequestLeft > 0) {
            dealerRequestLeft--;

            /*sending request*/
            if (type.equals(ACCEPT_REQUEST)) {
                acceptRejectDealerRequest(connectionId, "accept");
            } else if (type.equals(REJECT_REQUEST)) {
                acceptRejectDealerRequest(connectionId, "reject");
            } else {
                cancelDealerRequest(connectionId);
            }
            /*removing items*/
            if (dealerRequestLeft == 0) {
                items.remove(position);
                changeElement(new RequestRecievedItem(TypeOfRequest.NO_DEALER_REQUEST), position);
            } else {
                removeAt(position);
            }

        }

    }


    private void acceptConnectionRequest(String connectionId) {
        serviceManager.getAPI().acceptConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void rejectConnectionRequest(String connectionId) {
        serviceManager.getAPI().rejectConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void cancelConnectionRequest(String connectionId) {
        serviceManager.getAPI().cancelConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void acceptRejectDealerRequest(String connectionId, String requestType) {
        serviceManager.getAPI().acceptRejectDealerRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId, requestType).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }


    private void cancelDealerRequest(String connectionId) {
        serviceManager.getAPI().cancelDealerRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void acceptNetworkRequest(String connectionId) {
        serviceManager.getAPI().acceptNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void rejectNetworkRequest(String connectionId) {
        serviceManager.getAPI().rejectNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

    private void cancelNetworkRequest(String connectionId) {
        serviceManager.getAPI().cancelNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }

}





