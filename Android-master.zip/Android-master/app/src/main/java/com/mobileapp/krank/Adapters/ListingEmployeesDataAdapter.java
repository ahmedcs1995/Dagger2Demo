package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Activities.AssignRepresentativeForMyListing;
import com.mobileapp.krank.CallBacks.AddRemoveListener;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ViewHolders.CommonViewHolder.ConnectionsListItemViewHolder;

import java.util.List;

public class ListingEmployeesDataAdapter extends RecyclerView.Adapter<ConnectionsListItemViewHolder> implements CallBackWithAdapterPosition {
    private List<GetNetworkEmployeeData> items;
    Context context;
    AppUtils appUtils;
    private AddRemoveListener addRemoveListener;

    @Override
    public void act(int position) {
        if(!(items.get(position).isItemSelected())){
            addRemoveListener.add(items.get(position),AssignRepresentativeForMyListing.MAIN_LIST);
        }else{
            addRemoveListener.remove(items.get(position),AssignRepresentativeForMyListing.MAIN_LIST);
        }
        items.get(position).setItemSelected(!items.get(position).isItemSelected());
        notifyItemChanged(position);
    }


    public ListingEmployeesDataAdapter(List<GetNetworkEmployeeData> items, Context context,AddRemoveListener addRemoveListener ) {
        this.items = items;
        this.context = context;
        this.addRemoveListener = addRemoveListener;
        appUtils = AppUtils.getInstance();
    }


    @Override
    public ConnectionsListItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_by_connection_dealer_item, parent, false);
        return new ConnectionsListItemViewHolder(v,this);
    }

    @Override
    public void onBindViewHolder(final ConnectionsListItemViewHolder holder, int position) {
        final GetNetworkEmployeeData item = items.get(position);

        holder.people_name.setText("" + item.getFirstName() + " " + item.getLastName());
        holder.company_name_text_view.setText("" + AppUtils.getCompanyAndDesignation(item.getCompanyName(),item.getDesignation()));
      //  Glide.with(context).load(item.getProfilePic()).into(holder.profile_image_view);

        holder.profile_image_view.setImageURI("" + item.getProfilePic());


        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}






