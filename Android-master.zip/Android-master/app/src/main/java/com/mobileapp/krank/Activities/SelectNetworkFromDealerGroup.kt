package com.mobileapp.krank.Activities

import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import cn.pedant.SweetAlert.SweetAlertDialog
import com.mobileapp.krank.Adapters.AppGeneralAdapter

import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.NetworkListResponse
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.Utils.AnimationUtils
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.NetworkViewHolderCheckBox
import kotlinx.android.synthetic.main.activity_select_network_from_dealer_group.*
import kotlinx.android.synthetic.main.app_progress_bar.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.toolbar_with_search.*

import java.util.ArrayList

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SelectNetworkFromDealerGroup : BaseActivity() {


    private lateinit var mNetworkDealersAdapter: AppGeneralAdapter<NetworkList>
    private lateinit var mNetworkDealers: MutableList<NetworkList>
    internal lateinit var layoutManager: LinearLayoutManager



    private lateinit var callBack : CallBackWithAdapterPosition

    //scroll
    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false

    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //typing events
    private var onTypingTimeout: Runnable? = null

    //alert dialog
    internal lateinit var progressDialog: SweetAlertDialog



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_network_from_dealer_group)

        no_item_found_view.text = Constants.NO_NETWORK_DEALERS_FOUND


        progressDialog = showAlert("Loading...", SweetAlertDialog.PROGRESS_TYPE,false)


        runnable = Runnable {
            getNetworkDealers()
        }
        setUpTypingTimeoutRunnable()




        setNormalPageToolbar("Select Network for Dealers")

        setUpCallBack()


        setUpAdapter()

        bindListeners()

        getNetworkDealers()
    }

    private fun bindListeners(){
        send_dealer_request.setOnClickListener {
            sendDealerRequest()
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

            override fun afterTextChanged(editable: Editable) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }
        })
        search_btn.setOnClickListener {
            //open the search box
            AnimationUtils.circleReveal(search_container, 1, true, true, this@SelectNetworkFromDealerGroup)
            showKeyboard(search_box)
        }


        back_btn_search.setOnClickListener {
            //close the search box
            AnimationUtils.circleReveal(search_container, 1, true, false, this@SelectNetworkFromDealerGroup)


            hideFocusKeyboard()

            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")
        }
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {


            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            mNetworkDealers.clear()
            mNetworkDealers.add(NetworkList(Constants.LOADER_VIEW))
            mNetworkDealersAdapter.notifyDataSetChanged()


            //api data
            getNetworkDealers()

        }
    }

    private fun setUpCallBack(){
        callBack = CallBackWithAdapterPosition {
            when(mNetworkDealers[it].dealerStatus.toLowerCase().trim()){
                "not a dealer" -> {
                    mNetworkDealers[it].isItemCheck = ! mNetworkDealers[it].isItemCheck
                    mNetworkDealersAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun sendDealerRequest(){

        var company_ids = getNetworksForDealerRequest()

        if(company_ids.size <=0){
            showToast("No network selected.")
            return
        }

        progressDialog.show()

        api.addNetworkDealers(preference.getString(Constants.ACCESS_TOKEN), company_ids)
                .enqueue(object : Callback<GeneralResponse> {
                    override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                        if (response.isSuccessful) {
                            if (response.body().status == Constants.SUCCESS_STATUS) {
                               showToast(response.body().message)
                                progressDialog.dismiss()
                                onBackPressed()
                            } else {
                                progressDialog.dismiss()
                                showToast(response.body().message)
                            }
                        } else {
                            onResponseFailure()
                            progressDialog.dismiss()
                        }
                    }

                    override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                        onResponseFailure()
                        progressDialog.dismiss()
                    }
                })
    }

    private fun getNetworksForDealerRequest(): ArrayList<String> {
        var company_ids = ArrayList<String>()

        for (item in mNetworkDealers) {
            if (item.isItemCheck) {
                company_ids.add(item.companyId)
            }
        }
        return company_ids
    }


    private fun setUpAdapter() {
        mNetworkDealers = ArrayList()
        layoutManager = LinearLayoutManager(this)

        mNetworkDealersAdapter = object : AppGeneralAdapter<NetworkList>(mNetworkDealers){
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: NetworkList, position: Int) {
                if(item.type == Constants.ITEM_VIEW){
                    (viewHolder as NetworkViewHolderCheckBox).onBind(item)
                }

            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {

                var v : View
                return when (i){
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.network_sort_item, parent, false)
                        NetworkViewHolderCheckBox(v,callBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.network_sort_item, parent, false)
                        NetworkViewHolderCheckBox(v,callBack)
                    }
                }


            }

            override fun getItemViewType(position: Int): Int {
                return mNetworkDealers[position].type
            }

        }

        network_dealer_recycler_view.layoutManager = layoutManager
        network_dealer_recycler_view.adapter = mNetworkDealersAdapter

        addOnScrollEndListener()
    }

    private fun addOnScrollEndListener() {
        network_dealer_recycler_view.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }


    private fun removeLoader() {
        for (i in mNetworkDealers.indices.reversed()) {
            if (mNetworkDealers[i].type == Constants.LOADER_VIEW) {
                mNetworkDealers.removeAt(i)
                mNetworkDealersAdapter.notifyItemRemoved(i)
                break
            }
        }
    }

    private fun getNetworkDealers() {


        api.getNetworkByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", search_box.text.toString(),Constants.PAGE_LIMIT).enqueue(object : Callback<NetworkListResponse> {
            override fun onResponse(call: Call<NetworkListResponse>, response: Response<NetworkListResponse>) {

                hideLoader()

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    }else{
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }

            }

            override fun onFailure(call: Call<NetworkListResponse>, t: Throwable) {
                hideLoader()
                onResponseFailure()
            }
        })

    }


    private fun onSuccess(response: Response<NetworkListResponse>){

      //  mNetworkDealers.addAll(response.body().data.networkList)
      //  mNetworkDealersAdapter.notifyDataSetChanged()

        removeLoader()
        val oldSize = mNetworkDealers.size

        mNetworkDealers.addAll(getFilterdList(response.body().data.networkList))

      //  for pagination
        if (response.body().data.networkList.size >= Constants.PAGE_LIMIT) {
            mNetworkDealers.add(NetworkList(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
       // for pagination


        mNetworkDealersAdapter.notifyItemRangeInserted(oldSize,mNetworkDealers.size)


        checkForData()

    }

    private fun checkForData(){
        if (mNetworkDealers.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
        }else{
            no_item_found_view.visibility = View.GONE
        }
    }

    private fun hideLoader() {
        loader.visibility = View.GONE
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    private fun getFilterdList(inputData: List<NetworkList>): MutableList<NetworkList> {
        val items = ArrayList<NetworkList>()

        for (i in inputData.indices) {
            if (inputData[i].companyId == preference.getString(Constants.MY_COMPANY_ID) || inputData[i].companyId == Constants.KRANK_ID.toString()) {
                continue
            }
            items.add(inputData[i])
        }
        return items
    }

}
