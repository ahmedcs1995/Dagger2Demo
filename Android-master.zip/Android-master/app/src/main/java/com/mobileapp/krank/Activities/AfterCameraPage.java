package com.mobileapp.krank.Activities;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.UploadImageResponse;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AfterCameraPage extends BaseActivity {

    ImageView img;
    final int PIC_CROP = 2;
    CropImageView cropImageView;
    Button saveBtn, upload_btn;
    private String mediaPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_camera_page);
        cropImageView = findViewById(R.id.cropImageView);
        saveBtn = findViewById(R.id.save_btn);
        upload_btn = findViewById(R.id.upload_btn);

        Log.e("into the ", "OnCreate After Cam");
        String imgType = getIntent().getExtras().getString(Constants.IMAGE_TYPE);

        switch (imgType) {
            case "UserImg":
                setUserImgVisualization();
                break;
            case "UserCoverImg":
                setUserCoverImgVisualization();
                break;
            case "CompanyImg":
                setCompanyImgVisualization();
                break;
            case "CompanyCoverImg":
                setCompanyCoverImgVisualization();
                break;
            case "UserProfileView":
                setMainActivityVisualization();
                break;

        }
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cropAndUpload();
            }
        });
        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cropAndUpload();
            }
        });
    }

    public void cropAndUpload() {
        Bitmap cropped = cropImageView.getCroppedImage();
        String imgType = getIntent().getExtras().getString(Constants.IMAGE_TYPE);
        Uri tempUri = getImageUri(getApplicationContext(), cropped);
        mediaPath = (getPath(tempUri));

        switch (imgType) {
            case "UserImg":
              //  Constants.USER_IMG = cropped;
                uploadImage("user-profile");
                break;
            case "UserCoverImg":
             //   Constants.COVER_IMG = cropped;
                uploadImage("user-cover");
                break;
            case "CompanyImg":
              //  Constants.COMPANY_IMG = cropped;
                uploadImage("company-profile");
                break;
            case "CompanyCoverImg":
              //  Constants.COMPANY_COVER_IMG = cropped;
                uploadImage("company-cover");
                break;

        }


      //  finish();
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public void uploadImage(final String userType) {
        File file = new File(mediaPath);


        RequestBody requestBodyid = RequestBody.create(MediaType.parse("image/jpeg"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("upload_file", file.getName(), requestBodyid);

        getAPI().uploadProfileImage(preference.getString(Constants.ACCESS_TOKEN), userType, body).enqueue(new Callback<UploadImageResponse>() {
            @Override
            public void onResponse(Call<UploadImageResponse> call, Response<UploadImageResponse> response) {
                if (response.isSuccessful()) {


                    if (response.body().getStatus().equals("success")) {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        if (userType.equals("user-profile")) {
                            preference.setString(Constants.TEMP_USER_PROFILE_PICTURE, response.body().getData().getFileName());
                            preference.setString(Constants.PROFILE_PICTURE,response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());

                        }
                        if (userType.equals("user-cover")) {
                            preference.setString(Constants.COVER_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());

                        }
                        if (userType.equals("company-profile")) {
                            preference.setString(Constants.COMPANY_PROFILE_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                        }
                        if (userType.equals("CompanyCoverImg")) {
                            preference.setString(Constants.COMPANY_COVER_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                        }
                        Intent intent = new Intent();
                        setResult(RESULT_OK, intent);
                        finish();
                    }

                } else {
                    int statusCode = response.code();
                    Log.e("getappcont", "posts loaded from API " + statusCode);

                    // handle request errors depending on status code
                }
            }

            @Override
            public void onFailure(Call<UploadImageResponse> call, Throwable t) {
                Log.e("getappcont", "error loading from API");
                Log.e("getappcont", t.getLocalizedMessage());

            }
        });
    }
//
//    private String getRealPathFromURI(String contentURI) {
//        Uri contentUri = Uri.parse(contentURI);
//        Cursor cursor = getContentResolver().query(contentUri, null, null, null, null);
//        if (cursor == null) {
//            return contentUri.getPath();
//        } else {
//            cursor.moveToFirst();
//            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
//            return cursor.getString(index);
//        }
//    }

    public String getPath(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getApplicationContext().getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String s = cursor.getString(column_index);
        cursor.close();
        return s;
    }

//    public String compressImage(String imageUri) {
//
//        String filePath = getRealPathFromURI(imageUri);
//        Bitmap scaledBitmap = null;
//
//        BitmapFactory.Options options = new BitmapFactory.Options();
//
////      by setting this field as true, the actual bitmap pixels are not loaded in the memory. Just the bounds are loaded. If
////      you try the use the bitmap here, you will get null.
//        options.inJustDecodeBounds = true;
//        Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
//
//        int actualHeight = options.outHeight;
//        int actualWidth = options.outWidth;
//
////      max Height and width values of the compressed image is taken as 816x612
//
//        float maxHeight = 1920.0f;
//        float maxWidth = 1080.0f;
//        float imgRatio = actualWidth / actualHeight;
//        float maxRatio = maxWidth / maxHeight;
//
////      width and height values are set maintaining the aspect ratio of the image
//
//        if (actualHeight > maxHeight || actualWidth > maxWidth) {
//            if (imgRatio < maxRatio) {
//                imgRatio = maxHeight / actualHeight;
//                actualWidth = (int) (imgRatio * actualWidth);
//                actualHeight = (int) maxHeight;
//            } else if (imgRatio > maxRatio) {
//                imgRatio = maxWidth / actualWidth;
//                actualHeight = (int) (imgRatio * actualHeight);
//                actualWidth = (int) maxWidth;
//            } else {
//                actualHeight = (int) maxHeight;
//                actualWidth = (int) maxWidth;
//
//            }
//        }
//
////      setting inSampleSize value allows to load a scaled down version of the original image
//
//        options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);
//
////      inJustDecodeBounds set to false to load the actual bitmap
//        options.inJustDecodeBounds = false;
//
////      this options allow android to claim the bitmap memory if it runs low on memory
//        options.inPurgeable = true;
//        options.inInputShareable = true;
//        options.inTempStorage = new byte[16 * 1024];
//
//        try {
////          load the bitmap from its path
//            bmp = BitmapFactory.decodeFile(filePath, options);
//        } catch (OutOfMemoryError exception) {
//            exception.printStackTrace();
//
//        }
//        try {
//            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
//        } catch (OutOfMemoryError exception) {
//            exception.printStackTrace();
//        }
//
//        float ratioX = actualWidth / (float) options.outWidth;
//        float ratioY = actualHeight / (float) options.outHeight;
//        float middleX = actualWidth / 2.0f;
//        float middleY = actualHeight / 2.0f;
//
//        Matrix scaleMatrix = new Matrix();
//        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
//
//        Canvas canvas = new Canvas(scaledBitmap);
//        canvas.setMatrix(scaleMatrix);
//        canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
//
////      check the rotation of the image and display it properly
//        ExifInterface exif;
//        try {
//            exif = new ExifInterface(filePath);
//
//            int orientation = exif.getAttributeInt(
//                    ExifInterface.TAG_ORIENTATION, 0);
//            Log.d("EXIF", "Exif: " + orientation);
//            Matrix matrix = new Matrix();
//            if (orientation == 6) {
//                matrix.postRotate(90);
//                Log.d("EXIF", "Exif: " + orientation);
//            } else if (orientation == 3) {
//                matrix.postRotate(180);
//                Log.d("EXIF", "Exif: " + orientation);
//            } else if (orientation == 8) {
//                matrix.postRotate(270);
//                Log.d("EXIF", "Exif: " + orientation);
//            }
//            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
//                    scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
//                    true);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        FileOutputStream out = null;
//        String filename = getFilename();
//        try {
//            out = new FileOutputStream(filename);
//
////          write the compressed bitmap at the destination specified by filename.
//            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 30, out);
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//
//        return filename;
//
//    }

//    public String getFilename() {
//        File file = new File(Environment.getExternalStorageDirectory().getPath(), "MyFolder/Images");
//        if (!file.exists()) {
//            file.mkdirs();
//        }
//        String uriSting = (file.getAbsolutePath() + "/" + System.currentTimeMillis() + ".jpg");
//        return uriSting;
//
//    }

//    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
//        final int height = options.outHeight;
//        final int width = options.outWidth;
//        int inSampleSize = 1;
//
//        if (height > reqHeight || width > reqWidth) {
//            final int heightRatio = Math.round((float) height / (float) reqHeight);
//            final int widthRatio = Math.round((float) width / (float) reqWidth);
//            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
//        }
//        final float totalPixels = width * height;
//        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
//        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
//            inSampleSize++;
//        }
//
//        return inSampleSize;
//    }

    private void setUserImgVisualization() {
   //     Bitmap bitmap = Constants.USER_IMG_TO_SEND;
      //  cropImageView.setImageBitmap(bitmap);
        cropImageView.setCropShape(CropImageView.CropShape.OVAL);
        cropImageView.setMaxCropResultSize(400, 400);
        cropImageView.setMinCropResultSize(250, 250);
        cropImageView.setAutoZoomEnabled(true);
    }

    private void setMainActivityVisualization() {
        //  byte[] byteArray = getIntent().getByteArrayExtra("image");
        // Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        Bitmap bitmap = null;
        try {

            Uri uri = Uri.parse(getIntent().getStringExtra("image"));
            bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);

            cropImageView.setImageBitmap(bitmap);
            cropImageView.setCropShape(CropImageView.CropShape.OVAL);
            cropImageView.setMaxCropResultSize(400, 400);
            cropImageView.setMinCropResultSize(250, 250);
            cropImageView.setAutoZoomEnabled(true);
        } catch (IOException ex) {

        }
//        Bitmap bitmap = Constants.USER_IMG_TO_SEND;


    }

    private void setCompanyImgVisualization() {
        //Bitmap bitmap = Constants.COMPANY_IMG_TO_SEND;
        ///cropImageView.setImageBitmap(bitmap);
        cropImageView.setCropShape(CropImageView.CropShape.OVAL);
        cropImageView.setMaxCropResultSize(400, 400);
        cropImageView.setMinCropResultSize(250, 250);
        cropImageView.setAutoZoomEnabled(false);
    }

    private void setCompanyCoverImgVisualization() {
        //Bitmap bitmap = Constants.COMPANY_COVER_IMG_TO_SEND;
     //   cropImageView.setImageBitmap(bitmap);
        cropImageView.setCropShape(CropImageView.CropShape.RECTANGLE);
        cropImageView.setAspectRatio(16, 11);
    }

    private void setUserCoverImgVisualization() {
       // Bitmap bitmap = Constants.COVER_IMG_TO_SEND;
     //   cropImageView.setImageBitmap(bitmap);
        cropImageView.setCropShape(CropImageView.CropShape.RECTANGLE);
        cropImageView.setAspectRatio(16, 11);
        // cropImageView.setMaxCropResultSize(400,200);
        //  cropImageView.setMinCropResultSize(400,200);

    }

}
