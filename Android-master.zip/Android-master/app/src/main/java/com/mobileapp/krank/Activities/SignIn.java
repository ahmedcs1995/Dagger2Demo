package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.SigninResponse;
import com.mobileapp.krank.Utils.ApiUtils;


import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SignIn extends BaseActivity {


    TextView forgetPass;
    private TextView errorView;

    Button signInBtn;

    //input fields
    EditText email_edit_text, pass_edit_text;

    //invite text
    TextView info_text;

    private SweetAlertDialog showProgressAlert;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        //views
        forgetPass = findViewById(R.id.forget_pass);
        signInBtn = findViewById(R.id.sign_in_btn);

        email_edit_text = findViewById(R.id.email_edit_text);
        pass_edit_text = findViewById(R.id.pass_edit_text);

        errorView = findViewById(R.id.error_view);
        info_text = findViewById(R.id.info_text);


        /*invitation text*/
        setInviteText(info_text);
        /*invitation text*/


        showProgressAlert = showAlert(Constants.SIGN_IN_LOADING, SweetAlertDialog.PROGRESS_TYPE, false);

        setScreenHeader("Sign In");

        setImageIntermsOfDeviceResolution();


        setKrankLogoForUserProfiling();

        //enable bottom links
        gotoLinkPage();


        forgetPass.setOnClickListener(view -> {
            Intent intent = new Intent(SignIn.this, ForgetPassword.class);
            startActivity(intent);
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });

        signInBtn.setOnClickListener(view -> signInBtnListener());
    }

    private void signInBtnListener() {

        String email = email_edit_text.getText().toString().trim();
        String pass = pass_edit_text.getText().toString().trim();


        if (email.isEmpty()) {
            errorView.setText(Constants.ENTER_EMAIL_TEXT);
            return;
        } else if (!(AppUtils.validateEmail(email))) {
            errorView.setText(Constants.ENTER_VALID_EMAIL_TEXT);
            return;
        } else if (pass.isEmpty()) {
            errorView.setText(Constants.ENTER_PASSWORD_TEXT);
            return;
        }
        showProgressAlert.show();


        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }
                    final String token = task.getResult().getToken();
                    signIn(email, pass, token);

                });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    public void signIn(String email, String pass, String android_id) {
        getAPI().signin(email, pass, android_id,AppUtils.getDeviceVersion(),AppUtils.getModel(), AppUtils.getManufacturer(), AppUtils.getDeviceId(this)).enqueue(new Callback<SigninResponse>() {
            @Override
            public void onResponse(Call<SigninResponse> call, Response<SigninResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {


                        SigninResponse signinResponse = response.body();

                        //set data in cache
                        setUserDataInSharedPreferences(signinResponse);


                        CustomApplication app = (CustomApplication) getApplicationContext();

                        proceedAfterUserSuccessFullLogin(AppUtils.getDeviceName(),() -> {

                            showProgressAlert.dismiss();
                            //if listing then goto listing detail other wise goto dashboard
                            startActivity(getIntentToRedirectNextPage(SignIn.this, app.listingUrl, app.pageToRedirect));
                            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                            finishAffinity();
                            //  proceed();
                        });

                    } else {
                        if (errorView != null) {
                            errorView.setText(response.body().getMessage());
                        }
                        showProgressAlert.dismiss();
                    }
                } else {
                    onResponseFailure();
                    showProgressAlert.dismiss();

                    // handle request errors depending on status code
                }
            }

            @Override
            public void onFailure(Call<SigninResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                onResponseFailure();
            }
        });
    }

    private void proceed() {
        Intent intent = new Intent(SignIn.this, MainPage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        finishAffinity();
    }

}
