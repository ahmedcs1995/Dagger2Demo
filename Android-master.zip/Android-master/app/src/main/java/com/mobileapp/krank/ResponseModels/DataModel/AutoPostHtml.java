package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.TypeConverters;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Functions.StringListTypeConverter;


public class AutoPostHtml implements Parcelable  {


    @SerializedName("my_company_id")
    @Expose
    @ColumnInfo(name = "my_company_id")
    private String my_company_id;

    @SerializedName("my_company_name")
    @Expose
    @ColumnInfo(name = "my_company_name")
    private String myCompanyName;

    @SerializedName("my_company_logo")
    @Expose
    @ColumnInfo(name = "my_company_logo")
    private String myCompanyLogo;

    @SerializedName("connect_company_name")
    @Expose
    @ColumnInfo(name = "connect_company_name")
    private String connectCompanyName;

    @SerializedName("connect_company_logo")
    @Expose
    @ColumnInfo(name = "connect_company_logo")
    private String connectCompanyLogo;


    @SerializedName("connect_company_id")
    @Expose
    @ColumnInfo(name = "connect_company_id")
    private String connect_company_id;

    @SerializedName("dealer_post_type")
    @Expose
    @ColumnInfo(name = "dealer_post_type")
    private int dealer_post_type;

    @SerializedName("description")
    @Expose
    @ColumnInfo(name = "auto_post_description")
    @TypeConverters(StringListTypeConverter.class)
    private List<String> description;

    @SerializedName("post_logo")
    @Expose
    @ColumnInfo(name = "post_logo")
    private String postLogo;

    @SerializedName("heading")
    @Expose
    @ColumnInfo(name = "auto_post_heading")
    private String heading;

    @SerializedName("list")
    @Expose
    @ColumnInfo(name = "auto_post_list")
    @TypeConverters(StringListTypeConverter.class)
    private List<String> list;

    @SerializedName("pera")
    @Expose
    @Embedded
    private AutoPostPera pera;


    protected AutoPostHtml(Parcel in) {
        my_company_id = in.readString();
        myCompanyName = in.readString();
        myCompanyLogo = in.readString();
        connectCompanyName = in.readString();
        connectCompanyLogo = in.readString();
        description = in.createStringArrayList();
        postLogo = in.readString();
        dealer_post_type = in.readInt();
        connect_company_id = in.readString();
        heading = in.readString();
        list = in.createStringArrayList();
        pera = in.readParcelable(AutoPostPera.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(my_company_id);
        dest.writeString(myCompanyName);
        dest.writeString(myCompanyLogo);
        dest.writeString(connectCompanyName);
        dest.writeString(connectCompanyLogo);
        dest.writeStringList(description);
        dest.writeString(postLogo);
        dest.writeInt(dealer_post_type);
        dest.writeString(connect_company_id);
        dest.writeString(heading);
        dest.writeStringList(list);
        dest.writeParcelable(pera, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AutoPostHtml> CREATOR = new Creator<AutoPostHtml>() {
        @Override
        public AutoPostHtml createFromParcel(Parcel in) {
            return new AutoPostHtml(in);
        }

        @Override
        public AutoPostHtml[] newArray(int size) {
            return new AutoPostHtml[size];
        }
    };

    public String getMyCompanyName() {
        return myCompanyName;
    }

    public void setMyCompanyName(String myCompanyName) {
        this.myCompanyName = myCompanyName;
    }

    public String getMyCompanyLogo() {
        return myCompanyLogo;
    }

    public void setMyCompanyLogo(String myCompanyLogo) {
        this.myCompanyLogo = myCompanyLogo;
    }

    public String getConnectCompanyName() {
        return connectCompanyName;
    }

    public void setConnectCompanyName(String connectCompanyName) {
        this.connectCompanyName = connectCompanyName;
    }

    public String getConnectCompanyLogo() {
        return connectCompanyLogo;
    }

    public void setConnectCompanyLogo(String connectCompanyLogo) {
        this.connectCompanyLogo = connectCompanyLogo;
    }

    public List<String> getDescription() {
        return description;
    }

    public void setDescription(List<String> description) {
        this.description = description;
    }

    public String getPostLogo() {
        return postLogo;
    }

    public void setPostLogo(String postLogo) {
        this.postLogo = postLogo;
    }

    public String getConnect_company_id() {
        return connect_company_id;
    }

    public void setConnect_company_id(String connect_company_id) {
        this.connect_company_id = connect_company_id;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public AutoPostPera getPera() {
        return pera;
    }

    public void setPera(AutoPostPera pera) {
        this.pera = pera;
    }

    public AutoPostHtml() {
    }

    public String getMy_company_id() {
        return my_company_id;
    }

    public void setMy_company_id(String my_company_id) {
        this.my_company_id = my_company_id;
    }

    public int getDealer_post_type() {
        return dealer_post_type;
    }

    public void setDealer_post_type(int dealer_post_type) {
        this.dealer_post_type = dealer_post_type;
    }
}
