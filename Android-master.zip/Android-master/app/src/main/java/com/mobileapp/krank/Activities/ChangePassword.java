package com.mobileapp.krank.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePassword extends BaseActivity {

    private Button setPasswordBtn;
    private EditText password_edit_text, confirm_password_edit_text,old_password_edit_text;
    private TextView error_view;
    private SweetAlertDialog showProgressAlert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        setNormalPageToolbar("Change Password");
        setImageIntermsOfDeviceResolution();
        setKrankLogoForUserProfiling();
        setPasswordBtn = (Button) findViewById(R.id.setPasswordBtn);
        error_view =  findViewById(R.id.error_view);

        password_edit_text = findViewById(R.id.password_edit_text);
        confirm_password_edit_text = findViewById(R.id.confirm_password_edit_text);
        old_password_edit_text = findViewById(R.id.old_password_edit_text);

        showProgressAlert = showAlert("Loading ...", SweetAlertDialog.PROGRESS_TYPE, false);


        setPasswordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean error = false;
                String pass = password_edit_text.getText().toString();
                String cPass = confirm_password_edit_text.getText().toString();
                String old_pass = old_password_edit_text.getText().toString();

                if(old_password_edit_text.getText().toString().length() <= 0 ){
                    error = true;
                    error_view.setText("Please enter old password");
                }
                else if(password_edit_text.getText().toString().length() <= 0 ){
                    error = true;
                    error_view.setText("Please enter new password");
                }
                else if(confirm_password_edit_text.getText().toString().length() <= 0 ){
                    error = true;
                    error_view.setText("Please enter confirm new password");
                }
                else  if(!(cPass.equals(pass))){
                    error = true;
                    error_view.setText("Passwords do not match");
                }
                Log.e("cPass",cPass);
                Log.e("pass",pass);

                if(!error){
                    showProgressAlert.show();
                    changePassword(old_pass,pass,cPass);
                }
            }
        });
    }
    private void changePassword(String oldPass,String newPass,String passCon){
        getAPI().updatePassword(preference.getString(Constants.ACCESS_TOKEN),oldPass,newPass,passCon).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if(response.isSuccessful()){
                    if(response.body().getStatus().equals("success")){
                        Toast.makeText(getApplicationContext(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else{
                        error_view.setText("" + response.body().getMessage());
                    }
                }
                showProgressAlert.dismiss();
               // Toast.makeText(getApplicationContext(),Constants.ERROR_MSG_TOAST,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                Toast.makeText(getApplicationContext(),Constants.ERROR_MSG_TOAST,Toast.LENGTH_SHORT).show();

            }
        });
    }
}
