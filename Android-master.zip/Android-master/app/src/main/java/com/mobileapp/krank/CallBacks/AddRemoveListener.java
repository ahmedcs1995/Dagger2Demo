package com.mobileapp.krank.CallBacks;

import com.mobileapp.krank.Activities.AssignRepresentativeForMyListing;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
public interface AddRemoveListener{
    void add(GetNetworkEmployeeData item,@AssignRepresentativeForMyListing.OperationsDef int type);
    void remove(GetNetworkEmployeeData item,@AssignRepresentativeForMyListing.OperationsDef int operation);
}