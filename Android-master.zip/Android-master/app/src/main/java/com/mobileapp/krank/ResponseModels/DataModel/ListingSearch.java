package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ListingSearch {
    @SerializedName("user_slug")
    @Expose
    private String userSlug;
    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("list_slug")
    @Expose
    private String listSlug;
    @SerializedName("companyName")
    @Expose
    private String companyName;
    @SerializedName("companyId")
    @Expose
    private String companyId;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("lid")
    @Expose
    private String lid;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("listing")
    @Expose
    private String listing;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("listing_name")
    @Expose
    private String listingName;
    @SerializedName("category")
    @Expose
    private String category;
    @SerializedName("sub_category")
    @Expose
    private String subCategory;
    @SerializedName("cat_type")
    @Expose
    private String catType;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("manufacturer")
    @Expose
    private String manufacturer;
    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("equipment_number")
    @Expose
    private String equipmentNumber;
    @SerializedName("s_no")
    @Expose
    private String sNo;
    @SerializedName("lengths")
    @Expose
    private String lengths;
    @SerializedName("cylinders")
    @Expose
    private String cylinders;
    @SerializedName("capacity")
    @Expose
    private String capacity;
    @SerializedName("drive")
    @Expose
    private String drive;
    @SerializedName("min_amp")
    @Expose
    private String minAmp;
    @SerializedName("max_amp")
    @Expose
    private String maxAmp;
    @SerializedName("year_of_manf")
    @Expose
    private String yearOfManf;
    @SerializedName("power_fuel")
    @Expose
    private String powerFuel;
    @SerializedName("power")
    @Expose
    private String power;
    @SerializedName("transmission")
    @Expose
    private String transmission;
    @SerializedName("max_lifting")
    @Expose
    private String maxLifting;
    @SerializedName("flow_rate")
    @Expose
    private String flowRate;
    @SerializedName("condition")
    @Expose
    private String condition;
    @SerializedName("weight")
    @Expose
    private String weight;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("modified_date")
    @Expose
    private Object modifiedDate;
    @SerializedName("available")
    @Expose
    private Object available;
    @SerializedName("available_distance")
    @Expose
    private String availableDistance;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("price_privacy")
    @Expose
    private String pricePrivacy;
    @SerializedName("listing_privacy")
    @Expose
    private String listingPrivacy;
    @SerializedName("latlng")
    @Expose
    private String latlng;
    @SerializedName("max_lifting_unit")
    @Expose
    private String maxLiftingUnit;
    @SerializedName("flow_rate_unit")
    @Expose
    private String flowRateUnit;
    @SerializedName("energy")
    @Expose
    private String energy;
    @SerializedName("registration_number")
    @Expose
    private String registrationNumber;
    @SerializedName("number_of_seats")
    @Expose
    private String numberOfSeats;
    @SerializedName("listing_flight_rules")
    @Expose
    private String listingFlightRules;
    @SerializedName("total_time")
    @Expose
    private String totalTime;
    @SerializedName("av_condition")
    @Expose
    private String avCondition;
    @SerializedName("zip")
    @Expose
    private String zip;
    @SerializedName("hash")
    @Expose
    private String hash;
    @SerializedName("price_per_day")
    @Expose
    private String pricePerDay;
    @SerializedName("views")
    @Expose
    private String views;
    @SerializedName("ref_num")
    @Expose
    private String refNum;
    @SerializedName("inventory_id")
    @Expose
    private String inventoryId;
    @SerializedName("show_in_marketplace")
    @Expose
    private String showInMarketplace;
    @SerializedName("is_deleted")
    @Expose
    private String isDeleted;
    @SerializedName("watermark")
    @Expose
    private String watermark;
    @SerializedName("wm_type")
    @Expose
    private String wmType;
    @SerializedName("wm_position")
    @Expose
    private String wmPosition;
    @SerializedName("wm_image")
    @Expose
    private String wmImage;
    @SerializedName("wm_text")
    @Expose
    private String wmText;
    @SerializedName("wm_image_type")
    @Expose
    private String wmImageType;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("u_profile_pic")
    @Expose
    private String uProfilePic;
    @SerializedName("IMAGE_NAME")
    @Expose
    private String iMAGENAME;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("user_profile_pic")
    @Expose
    private String userProfilePic;
    @SerializedName("user_url")
    @Expose
    private String userUrl;
    @SerializedName("company_url")
    @Expose
    private String companyUrl;
    @SerializedName("inMyNetwork")
    @Expose
    private Integer inMyNetwork;




    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getListSlug() {
        return listSlug;
    }

    public void setListSlug(String listSlug) {
        this.listSlug = listSlug;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLid() {
        return lid;
    }

    public void setLid(String lid) {
        this.lid = lid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getListing() {
        return listing;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getListingName() {
        return listingName;
    }

    public void setListingName(String listingName) {
        this.listingName = listingName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getCatType() {
        return catType;
    }

    public void setCatType(String catType) {
        this.catType = catType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getEquipmentNumber() {
        return equipmentNumber;
    }

    public void setEquipmentNumber(String equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }

    public String getSNo() {
        return sNo;
    }

    public void setSNo(String sNo) {
        this.sNo = sNo;
    }

    public String getLengths() {
        return lengths;
    }

    public void setLengths(String lengths) {
        this.lengths = lengths;
    }

    public String getCylinders() {
        return cylinders;
    }

    public void setCylinders(String cylinders) {
        this.cylinders = cylinders;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public String getDrive() {
        return drive;
    }

    public void setDrive(String drive) {
        this.drive = drive;
    }

    public String getMinAmp() {
        return minAmp;
    }

    public void setMinAmp(String minAmp) {
        this.minAmp = minAmp;
    }

    public String getMaxAmp() {
        return maxAmp;
    }

    public void setMaxAmp(String maxAmp) {
        this.maxAmp = maxAmp;
    }

    public String getYearOfManf() {
        return yearOfManf;
    }

    public void setYearOfManf(String yearOfManf) {
        this.yearOfManf = yearOfManf;
    }

    public String getPowerFuel() {
        return powerFuel;
    }

    public void setPowerFuel(String powerFuel) {
        this.powerFuel = powerFuel;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getMaxLifting() {
        return maxLifting;
    }

    public void setMaxLifting(String maxLifting) {
        this.maxLifting = maxLifting;
    }

    public String getFlowRate() {
        return flowRate;
    }

    public void setFlowRate(String flowRate) {
        this.flowRate = flowRate;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Object getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Object modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Object getAvailable() {
        return available;
    }

    public void setAvailable(Object available) {
        this.available = available;
    }

    public String getAvailableDistance() {
        return availableDistance;
    }

    public void setAvailableDistance(String availableDistance) {
        this.availableDistance = availableDistance;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPricePrivacy() {
        return pricePrivacy;
    }

    public void setPricePrivacy(String pricePrivacy) {
        this.pricePrivacy = pricePrivacy;
    }

    public String getListingPrivacy() {
        return listingPrivacy;
    }

    public void setListingPrivacy(String listingPrivacy) {
        this.listingPrivacy = listingPrivacy;
    }

    public String getLatlng() {
        return latlng;
    }

    public void setLatlng(String latlng) {
        this.latlng = latlng;
    }

    public String getMaxLiftingUnit() {
        return maxLiftingUnit;
    }

    public void setMaxLiftingUnit(String maxLiftingUnit) {
        this.maxLiftingUnit = maxLiftingUnit;
    }

    public String getFlowRateUnit() {
        return flowRateUnit;
    }

    public void setFlowRateUnit(String flowRateUnit) {
        this.flowRateUnit = flowRateUnit;
    }

    public String getEnergy() {
        return energy;
    }

    public void setEnergy(String energy) {
        this.energy = energy;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(String numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public String getListingFlightRules() {
        return listingFlightRules;
    }

    public void setListingFlightRules(String listingFlightRules) {
        this.listingFlightRules = listingFlightRules;
    }

    public String getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(String totalTime) {
        this.totalTime = totalTime;
    }

    public String getAvCondition() {
        return avCondition;
    }

    public void setAvCondition(String avCondition) {
        this.avCondition = avCondition;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(String pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getViews() {
        return views;
    }

    public void setViews(String views) {
        this.views = views;
    }

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getShowInMarketplace() {
        return showInMarketplace;
    }

    public void setShowInMarketplace(String showInMarketplace) {
        this.showInMarketplace = showInMarketplace;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getWatermark() {
        return watermark;
    }

    public void setWatermark(String watermark) {
        this.watermark = watermark;
    }

    public String getWmType() {
        return wmType;
    }

    public void setWmType(String wmType) {
        this.wmType = wmType;
    }

    public String getWmPosition() {
        return wmPosition;
    }

    public void setWmPosition(String wmPosition) {
        this.wmPosition = wmPosition;
    }

    public String getWmImage() {
        return wmImage;
    }

    public void setWmImage(String wmImage) {
        this.wmImage = wmImage;
    }

    public String getWmText() {
        return wmText;
    }

    public void setWmText(String wmText) {
        this.wmText = wmText;
    }

    public String getWmImageType() {
        return wmImageType;
    }

    public void setWmImageType(String wmImageType) {
        this.wmImageType = wmImageType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getUProfilePic() {
        return uProfilePic;
    }

    public void setUProfilePic(String uProfilePic) {
        this.uProfilePic = uProfilePic;
    }

    public String getIMAGENAME() {
        return iMAGENAME;
    }

    public void setIMAGENAME(String iMAGENAME) {
        this.iMAGENAME = iMAGENAME;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public String getUserUrl() {
        return userUrl;
    }

    public void setUserUrl(String userUrl) {
        this.userUrl = userUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public Integer getInMyNetwork() {
        return inMyNetwork;
    }

    public void setInMyNetwork(Integer inMyNetwork) {
        this.inMyNetwork = inMyNetwork;
    }

}

