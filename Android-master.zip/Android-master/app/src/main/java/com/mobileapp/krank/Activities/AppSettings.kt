package com.mobileapp.krank.Activities

import android.Manifest
import android.app.*
import android.arch.lifecycle.Observer
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CustomViews.SwitchButton
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Model.SettingDataModel
import com.mobileapp.krank.R
import com.mobileapp.krank.Repository.ContactsImportRepository
import com.mobileapp.krank.SynchronizationFromServer.SyncUtils
import com.mobileapp.krank.ViewHolders.SettingsViewHolders.SettingsHeader
import com.mobileapp.krank.ViewHolders.SettingsViewHolders.SettingsImportExportItemViewHolder
import com.mobileapp.krank.ViewHolders.SettingsViewHolders.SettingsItemViewHolder
import kotlinx.android.synthetic.main.activity_app_settings.*
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Button
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService
import com.mobileapp.krank.Functions.*
import com.mobileapp.krank.Model.Enums.NetworkState
import com.mobileapp.krank.ResponseModels.GeneralResponse
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class AppSettings : BaseActivity() {

    interface AppSettingsCallBack {
        fun <T : View> onTogglePressed(state: Boolean, check_box: T, position: Int, type: Int)
        fun <T : View> onButtonPressed(view: T, position: Int, type: Int)
    }


    companion object {
        const val TOGGLE_INDEX = 1
        const val DELETE_BUTTON_INDEX = 2

        //activity code
        const val FILE_CHOOSER_INTENT = 1000
        const val READ_EXTERNAL_STORAGE_PERMISSION = 600

    }

    private lateinit var mAdapter: AppGeneralAdapter<SettingDataModel>
    private lateinit var listItems: MutableList<SettingDataModel>
    private lateinit var callBack: AppSettingsCallBack



    private lateinit var contactsFetch: ContactsFetcher
    private lateinit var mRepository: ContactsImportRepository




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_settings)

        setNormalPageToolbar( "Contact Settings")

        contactsFetch = applicationRef.contactsFetcher

        mRepository = ContactsImportRepository(applicationContext as Application)



        initCallBack()

        initList()

        initAdapter()

        bindObserverForContactsSync()
    }

    private fun bindObserverForContactsSync(){
        mRepository.getNetworkState().observe(this, Observer {
            if(it == null) return@Observer
            if(it.status != NetworkState.Status.RUNNING){
                /**
                 * Update list item for
                 *
                 * For contacts Count only
                 * */
                listItems[TOGGLE_INDEX].state = applicationRef.getmMyContactsCount() > 0
                listItems[DELETE_BUTTON_INDEX].isButtonEnable = applicationRef.getmTotalContactsCount() > 0
                mAdapter.notifyDataSetChanged()

            }
        })
    }

    private fun initAdapter() {
        mAdapter = object : AppGeneralAdapter<SettingDataModel>(listItems) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: SettingDataModel, position: Int) {
                when (viewHolder) {
                    is SettingsItemViewHolder -> viewHolder.onBind(item, position == listItems.size - 1)
                    is SettingsHeader -> viewHolder.onBind(item,this@AppSettings)
                    is SettingsImportExportItemViewHolder -> viewHolder.onBind(item, position == listItems.size - 1)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when (i) {
                    SettingDataModel.HEADER -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.settings_header_item, parent, false)
                        SettingsHeader(v)
                    }
                    SettingDataModel.ITEM_TOGGLE -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.settings_list_item, parent, false)
                        SettingsItemViewHolder(v, callBack)
                    }
                    SettingDataModel.ITEM_DELETE_BUTTON -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.settings_list_item, parent, false)
                        SettingsItemViewHolder(v, callBack)
                    }
                    SettingDataModel.ITEM_IMPORT_EXPORT -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.import_export_setting_list_item, parent, false)
                        SettingsImportExportItemViewHolder(v, callBack)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.settings_list_item, parent, false)
                        SettingsItemViewHolder(v, callBack)
                    }
                }
            }

            override fun getItemViewType(position: Int): Int {
                return listItems[position].type
            }
        }

        settings_recycler.layoutManager = LinearLayoutManager(this@AppSettings)
        settings_recycler.adapter = mAdapter

    }

    private fun openFileChooser() {

        val permission = Manifest.permission.READ_EXTERNAL_STORAGE
        if (!AppUtils.isPermissionAllowed(this, permission)) {
            //request for permission
            AppUtils.requestPermissions(READ_EXTERNAL_STORAGE_PERMISSION, this, arrayOf(permission))
            return
        }
        openFileIntent()
    }

    private fun openFileIntent() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*"
        startActivityForResult(intent, FILE_CHOOSER_INTENT)
    }

    private fun initCallBack() {
        callBack = object : AppSettingsCallBack {
            override fun <T : View> onButtonPressed(view: T, position: Int, type: Int) {


                if (type == SettingDataModel.ITEM_DELETE_BUTTON) {

                    /**
                     * Delete All Button
                     * */
                    if (listItems[position].isButtonEnable) {
                        showUnSyncDialog(position = position, syncFlag = Constants.UNSYNC_ALL)
                    } else {
                        Toast.makeText(this@AppSettings, "Contacts has been already deleted", Toast.LENGTH_SHORT).show()
                    }
                } else if (type == SettingDataModel.IMPORT_BUTTON) {

                    openFileChooser()


                } else if (type == SettingDataModel.EXPORT_BUTTON) {
                    this@AppSettings.launchActivity<ImportExportConnectionsPrivacy> {
                        putExtra(ImportExportConnectionsPrivacy.PAGE_NAME,ImportExportConnectionsPrivacy.EXPORT_CONNECTION)
                    }
                } else {

                }
            }

            override fun <T : View> onTogglePressed(state: Boolean, check_box: T, position: Int, type: Int) {


                /**
                 * Contacts Sync UnSYnc
                 * */
                if (type == SettingDataModel.ITEM_TOGGLE) {

                    /**
                     *
                     * */
                    if (!listItems[position].isButtonEnable) {
                        listItems[position].state = false
                        mAdapter.notifyItemChanged(position)
                        showToast("Sim is required for import the contacts")
                        return
                    }




                    if (state) {
                        //sync here
                        syncContacts()
                        return
                    }
                    showUnSyncDialog(check_box as SwitchButton, position, Constants.UNSYNC)
                    //unsync here
                    return
                }

            }

        }
    }

    private fun syncContacts() {
        if (!isReadContactsPermissionAllowed) {
            requestContactsPermission()
            return
        }
        startSyncAdapter()
    }

    private fun showUnSyncDialog(checkBox: SwitchButton? = null, position: Int, syncFlag: Int) {
        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this@AppSettings) as NormalAppDialog)
                .setHeading("Disconnect Contacts?")
                .setDescription("Syncing your contacts helps you discover people you may know. We'll no longer sync contacts with our system when you disconnect")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setCancelableDialog(false)
                .setConfirmButtonListener {
                    unSyncMobileContacts(syncFlag, position, checkBox)
                    it.dismiss()
                }
                .setCancelButtonListener {
                    checkBox?.isChecked = true
                    listItems[position].state = true
                    mAdapter.notifyItemChanged(position)
                    it.dismiss()
                }
        dialog.show()

    }

    private fun startSyncAdapter() {

        listItems[TOGGLE_INDEX].state = true
        listItems[DELETE_BUTTON_INDEX].isButtonEnable = true


        if (preference.getBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE)) {
            //   SyncUtils.requestSync(true)

            syncContactsToServer()
        } else {
            SyncUtils.createSyncAccount(this@AppSettings, true) {
                preference.setBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE, true)
            }
        }

        preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, true)

    }

    private fun syncContactsToServer() {
        val contacts = contactsFetch.getContactsList(preference)
        val deleteContactList = contactsFetch.getDeleteContactList(preference)

        mRepository.sendContactsToServer(contacts, deleteContactList)
    }

    private fun unSyncMobileContacts(syncFlag: Int, position: Int, checkBox: SwitchButton? = null) {


        SyncUtils.disableSync()
        mRepository.unSyncToServer(checkBox, syncFlag)

        /**
         * Un Sync All
         * */
        if (syncFlag == Constants.UNSYNC_ALL) {
            listItems[TOGGLE_INDEX].state = false
            listItems[position].isButtonEnable = false

            mAdapter.notifyDataSetChanged()

            //application class
            applicationRef.setmMyContactsCount(0)
            applicationRef.setmTotalContactsCount(0)
        } else {

            /**
             * Toggle un sync
             * */


            checkBox?.isEnabled = false
            applicationRef.setmTotalContactsCount(applicationRef.getmTotalContactsCount() - applicationRef.getmMyContactsCount())
            applicationRef.setmMyContactsCount(0)

            listItems[position].state = false

            listItems[DELETE_BUTTON_INDEX].isButtonEnable = applicationRef.getmTotalContactsCount() > 0

            mAdapter.notifyDataSetChanged()

        }

        return


    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CONTACTS_PERMISSION && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSyncAdapter()
            } else {
                listItems[TOGGLE_INDEX].state = false
                mAdapter.notifyItemChanged(TOGGLE_INDEX)
            }
        } else if (requestCode == READ_EXTERNAL_STORAGE_PERMISSION && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openFileIntent()
            }
        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == FILE_CHOOSER_INTENT) {
                if (data == null) return
                try {
                    if (DocumentsContract.isDocumentUri(this@AppSettings, data.data)) {
                       // val path = data.data.path.split(':')
                     //   val filePath = path[1]

                        val fileName = AppUtils.getFileName(data.data,this)

                        val path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path

                        val filePath = "$path/$fileName"

                        //var file = File("/storage/emulated/0/Download/DemoAccount14-Jun-2019.krank")

                        var file = File(filePath)
                        if (file.extension.toLowerCase() == "krank") {
                            //api call
                            this@AppSettings.launchActivity<ImportExportConnectionsPrivacy> {
                                putExtra(ImportExportConnectionsPrivacy.PAGE_NAME,ImportExportConnectionsPrivacy.IMPORT_CONNECTION)
                                putExtra(ImportExportConnectionsPrivacy.FILE_PATH,filePath)
                            }
                            return
                        }
                    }
                    showToast("Please choose correct file")
                } catch (ex: java.lang.Exception) {
                    showToast("Please choose correct file")
                }
            }
        }
    }


    private fun initList() {
        listItems = ArrayList()

        listItems.add(SettingDataModel(title = "Phone Contacts", type = SettingDataModel.HEADER,icon =R.drawable.ic_local_phone))

        listItems.add(SettingDataModel(title = "Sync Phone Contacts", description = resources.getString(R.string.unsync_contacts_des), type = SettingDataModel.ITEM_TOGGLE, state = preference.getBoolean(Constants.CONTACTS_SYNC_ENABLED), isButtonEnable = AppUtils.isSimAvailable(this@AppSettings)))

        listItems.add(SettingDataModel(title = "Stop Syncing & Delete Phone Contacts", description = resources.getString(R.string.delete_all_contacts_des), type = SettingDataModel.ITEM_DELETE_BUTTON, isButtonEnable = applicationRef.getmTotalContactsCount() > 0))


        /**
         * Krank Contacts
         * */
        listItems.add(SettingDataModel(title = "Krank Contacts", type = SettingDataModel.HEADER,icon = R.drawable.ic_ic_address_book))
        listItems.add(SettingDataModel(title = "Import/Export Connections", description = resources.getString(R.string.export_connections_heading), type = SettingDataModel.ITEM_IMPORT_EXPORT))
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }






}


