package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NetworkGroupListData {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("networks")
    @Expose
    private String networks;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("group_name")
    @Expose
    private String groupName;
    @SerializedName("company_data")
    @Expose
    private List<CompanyDatum> companyData = null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNetworks() {
        return networks;
    }

    public void setNetworks(String networks) {
        this.networks = networks;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<CompanyDatum> getCompanyData() {
        return companyData;
    }

    public void setCompanyData(List<CompanyDatum> companyData) {
        this.companyData = companyData;
    }
    public class CompanyDatum {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("profile_pic")
        @Expose
        private String profilePic;
        @SerializedName("company_name")
        @Expose
        private String companyName;
        @SerializedName("cnt")
        @Expose
        private String cnt;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getProfilePic() {
            return profilePic;
        }

        public void setProfilePic(String profilePic) {
            this.profilePic = profilePic;
        }

        public String getCompanyName() {
            return companyName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public String getCnt() {
            return cnt;
        }

        public void setCnt(String cnt) {
            this.cnt = cnt;
        }

    }

}