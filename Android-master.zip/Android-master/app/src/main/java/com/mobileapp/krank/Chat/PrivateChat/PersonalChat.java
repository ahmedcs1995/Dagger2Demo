package com.mobileapp.krank.Chat.PrivateChat;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.mobileapp.krank.Adapters.PersonalChatAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.ChatMainPage;
import com.mobileapp.krank.Chat.GroupChatPakage.NewGroupMessage;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.ChatSearchPeopleListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ViewModels.PersonalChatListViewModel;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Yaseen on 30/04/2018.
 */


public class PersonalChat extends BaseFragment {

    private RecyclerView ChatRecyclerView;
    private RecyclerView.Adapter chatRecyclerAdapter;
    List<ChatConversationListDataModel> personalChatItems;
    FloatingActionMenu mainFab;
    FloatingActionButton msgFab;
    FloatingActionButton groupFab;

    private ShimmerFrameLayout mShimmerViewContainer;
    EditText searchedit_text;

    boolean isFirstTimeInit;
    boolean onResumeFirstTimeCall;
    AppUtils appUtils;
    private PersonalChatListViewModel personalChatListViewModel;
    public static boolean EXIT = false;

    CustomCallBack customCallBack;

    TextView no_item_found_view;
    View shimmer_layout_container;

    SendList sendList;
    public PersonalChat() {
        setTitle("Chats");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.personal_chat, container, false);
        setFragmentView(me);


        setCallBack();


        init();

        initViews();

        //fab bind listeners
        bindListeners();

        setUpChatAdapter();

        // observe changes
        observerMsgs();

        customCallBack = () -> {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            shimmer_layout_container.setVisibility(View.GONE);
            ChatRecyclerView.setVisibility(View.VISIBLE);

        };

        /*searchedit_text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                groupChatConvo.clear();
                chatRecyclerAdapter.notifyDataSetChanged();
                mShimmerViewContainer.startShimmer();
                mShimmerViewContainer.setVisibility(View.VISIBLE);
                if(searchedit_text.getText().toString().length() <=0){
                    Log.e("calling if","yess ->" + + groupChatConvo.size());
                    getChatConversationList();
                    return;
                }
                Log.e("calling if","after return ->" + groupChatConvo.size());
                getSearchPeopleList(searchedit_text.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });*/


        return me;
    }

    private void addOnSendListener(List<ChatConversationListDataModel> conversationList){
        sendList.act(conversationList);
    }
    private void observerMsgs(){
        personalChatListViewModel.getAllConversaionList().observe(this, conversationList -> {
            Log.e("into the", "Personal Chat observer => " + appUtils.convertToJson(conversationList));
            try{
                /* groupChatConvo.clear();
            groupChatConvo.addAll(conversationList);
            chatRecyclerAdapter.notifyDataSetChanged();*/

                //for data passing to fragment two
                addOnSendListener(conversationList);


                if (isFirstTimeInit) {
                    if(conversationList.size() <=0){
                        no_item_found_view.setVisibility(View.VISIBLE);
                        return;
                    }
                    personalChatItems.clear();
                    personalChatItems.addAll(conversationList);
                    chatRecyclerAdapter.notifyDataSetChanged();
                    isFirstTimeInit = false;
                    return;
                } else if (!isFirstTimeInit && personalChatItems.size() > 0) {
                    int i = 0;
                    while (i < personalChatItems.size()) {

                        if(!(compareServerAndDbValues(personalChatItems.get(i).getMsgTime(),conversationList.get(i).getMsgTime())) || !(compareServerAndDbValues(personalChatItems.get(i).getConversation_unread(),conversationList.get(i).getConversation_unread()))){
                            personalChatItems.set(i, conversationList.get(i));
                            chatRecyclerAdapter.notifyItemChanged(i);
                        }

                    /*if (!(personalChatItems.get(i).getMsgTime().equals(conversationList.get(i).getMsgTime())) || !(personalChatItems.get(i).getConversation_unread().equals(conversationList.get(i).getConversation_unread()))) {
                        personalChatItems.set(i, conversationList.get(i));
                        chatRecyclerAdapter.notifyItemChanged(i);
                    }*/
                        i++;
                    }
                    if (i < conversationList.size()) {
                        personalChatItems.addAll(conversationList.subList(i, conversationList.size()));
                        chatRecyclerAdapter.notifyItemRangeInserted(i, conversationList.size());
                    }
                }
            }
            catch (Exception ex){

            }

        });
    }

    private boolean compareServerAndDbValues(String value1, String value2){
        if(value2 !=null){
            return value1.equals(value2);
        }
        return false;
    }

    private void init(){
        isFirstTimeInit = true;
        onResumeFirstTimeCall = true;
        appUtils = AppUtils.getInstance();
        personalChatListViewModel = ViewModelProviders.of(PersonalChat.this).get(PersonalChatListViewModel.class);

    }

    private void initViews(){
        mainFab = (FloatingActionMenu) findViewById(R.id.main_fab);
        msgFab = (FloatingActionButton) findViewById(R.id.msg_fab);
        groupFab = (FloatingActionButton) findViewById(R.id.group_fab);

        mShimmerViewContainer = (ShimmerFrameLayout) findViewById(R.id.shimmer_view_container);
        searchedit_text = (EditText) findViewById(R.id.searchedit_text);
        no_item_found_view =(TextView) findViewById(R.id.no_item_found_view);
        shimmer_layout_container = findViewById(R.id.shimmer_layout_container);

        no_item_found_view.setText(Constants.NO_CHAT_FOUND_TEXT);

        no_item_found_view.setVisibility(View.GONE);

        mShimmerViewContainer.startShimmer();

        mainFab.setClosedOnTouchOutside(true);
    }
    private void setUpChatAdapter() {
        ChatRecyclerView = (RecyclerView) findViewById(R.id.personal_chat_recycler_view);
        personalChatItems = new ArrayList<>();
        chatRecyclerAdapter = new PersonalChatAdapter(personalChatItems, this);
        ChatRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        ChatRecyclerView.setAdapter(chatRecyclerAdapter);
        ((SimpleItemAnimator) ChatRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
    }

    private void bindListeners(){
        msgFab.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), PrivateNewMessage.class);
            // intent.putExtra("chat_data", .appUtils.convertToJson(personalChatItems));

            ChatMainPage activityRef = ((ChatMainPage) getActivity());

            //saving the data
            if(activityRef!=null){
                activityRef.getApplicationRef().recentChat = personalChatItems;
            }


            intent.putExtra("type", "personal_chat");
            intent.putExtra("page_title", "New Message");
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
        groupFab.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), NewGroupMessage.class);
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
    }


    private void getSearchPeopleList(String keyword) {

        ((ChatMainPage) getActivity()).getAPI().getSearchChatPeople(((ChatMainPage) getActivity()).preference.getString(Constants.ACCESS_TOKEN), keyword).enqueue(new Callback<ChatSearchPeopleListResponse>() {
            @Override
            public void onResponse(Call<ChatSearchPeopleListResponse> call, Response<ChatSearchPeopleListResponse> response) {

                Log.e("search res", "" + ((ChatMainPage) getActivity()).appUtils.convertToJson(response.body()));
                if (response.isSuccessful()) {
                    personalChatItems.addAll(response.body().getData().getResult());
                    chatRecyclerAdapter.notifyDataSetChanged();
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<ChatSearchPeopleListResponse> call, Throwable t) {
                Toast.makeText(getContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        EXIT = true;
        personalChatListViewModel.getmRepository().stopTask();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        EXIT = true;
        personalChatListViewModel.getmRepository().stopTask();
    }


    @Override
    public void onResume() {
        super.onResume();
        EXIT = false;
        personalChatListViewModel.getmRepository().startTask(customCallBack);
    }


    public interface SendList{
        void act(List<ChatConversationListDataModel> items);
    }

    public void setCallBack(){
        this.sendList = ((ChatMainPage)getActivity()).getSendList();
    }
}