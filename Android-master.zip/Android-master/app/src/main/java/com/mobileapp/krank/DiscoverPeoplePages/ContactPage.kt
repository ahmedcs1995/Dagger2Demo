package com.mobileapp.krank.DiscoverPeoplePages

import android.app.Dialog
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mobileapp.krank.Activities.DiscoverPeople
import com.mobileapp.krank.Base.BaseFragment
import android.content.Intent
import android.net.Uri
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.SimpleItemAnimator
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.mobileapp.krank.Activities.CompanyProfileView
import com.mobileapp.krank.Activities.UserProfileView
import com.mobileapp.krank.Adapters.ContactsImportAdapter
import com.mobileapp.krank.CallBacks.CallBackWithData
import com.mobileapp.krank.CallBacks.CustomCallBack
import com.mobileapp.krank.Functions.*
import com.mobileapp.krank.Functions.Dialogs.InviteDialog
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Model.Enums.NetworkState
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.ContactsDataModel
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ResponseModels.DeleteContactDataModel
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.BaseViewHolder
import com.mobileapp.krank.ViewModels.ContactsImportViewModel
import java.lang.Exception


class ContactPage : BaseFragment(), DiscoverPeople.ContactsImportResponse, CallBackWithData<GetNetworkEmployeeData> {


    companion object{
        const val MESSAGE_1="Connect them to see their listing and article"
    }

    init {
        title = "Phone contacts"
    }

    //list items
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var mRecyclerAdapter: ContactsImportAdapter


    //other views
    private lateinit var connect_contacts_container: View
    private lateinit var img_view: ImageView
    private lateinit var connect_contacts_heading: TextView
    private lateinit var contact_description: TextView

    private lateinit var loader: ProgressBar
    private lateinit var connect_contacts_btn: Button
    var activityRef: DiscoverPeople? = null


    //view Model
    private var mViewModel: ContactsImportViewModel? = null

    private var isItemHighLighted : Boolean = false

    private var isObserverBind = false


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val me = inflater.inflate(R.layout.contact_fragment_page, container, false)
        fragmentView = me


        initViews()

        loader.visibility = View.GONE

        init()

        setUpAdapter()

        initViewModel()

        registerObserver()

        initContactsScenario()

        return me
    }

    private fun scrollToHighLightIndex() {
        if (activityRef?.userId == null) return
        if(isItemHighLighted) return


        val tempList = mRecyclerAdapter.currentList
        if (tempList != null) {
            for (i in tempList.indices) {
                if (activityRef?.userId == tempList[i]?.id){
                    mRecyclerView.smoothScrollToPosition(i)
                    isItemHighLighted = true
                    break
                }
            }
        }
    }

    private fun initViews() {
        loader = findViewById(R.id.loader) as ProgressBar
        connect_contacts_container = findViewById(R.id.connect_contacts_container)
        connect_contacts_btn = findViewById(R.id.connect_contacts_btn) as Button
        img_view = findViewById(R.id.img_view) as ImageView
        connect_contacts_heading = findViewById(R.id.connect_contacts_heading) as TextView
        contact_description = findViewById(R.id.contact_description) as TextView
    }

    private fun registerObserver() {
        if (mViewModel == null) return


        mViewModel?.getNetworkState()!!.observe(this, Observer {
            if(it == null) return@Observer
            if(it.status == NetworkState.Status.RUNNING){
                loader.visibility = View.VISIBLE
                mRecyclerView.visibility = View.GONE

            }else{
                Log.e("getNetworkState","LOADED")
                if(!isObserverBind){
                    registerDataObserver()
                }

                loader.visibility = View.GONE
                mRecyclerView.visibility = View.VISIBLE
                // scrollToHighLightIndex()
            }
        })

        mViewModel?.getOnKrankUsersCount()!!.observe(this, Observer {
            if(it == null) return@Observer
            Log.e("Count Observer","" + CustomGson.getInstance().toJson(it))
            try{
                mRecyclerAdapter.NotOnKrankUsersCount = it.NotOnKrank
                mRecyclerAdapter.connectedUsersCount = it.Connected
                mRecyclerAdapter.notConnectedUsersCount = it.NotConnected
                mRecyclerAdapter.NotConnectedRequestPendingCounts = it.NotConnectedRequestPendingCounts
                mRecyclerAdapter.notifyItemChanged(0)
            }catch (ex : Exception){

            }

        })


        mRecyclerAdapter.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {

                Log.e("onItemRangeInserted","Yes")
                if(activityRef!!.fromNotification()){
                    scrollToHighLightIndex()
                }else{
                    if (positionStart == 0) {
                        mRecyclerView.scrollToPosition(0)
                    }
                }

            }
        })

    }
    private fun registerDataObserver(){
        isObserverBind = true
        mViewModel!!.getmAllData().observe(this, Observer {
            if (it == null) return@Observer

            Log.e("Data","" + it.size)

            mRecyclerAdapter.submitList(it)

            if(it.size > 0){
                // mRecyclerView.scrollToPosition(0)

            }

        })
    }
    private fun initViewModel() {
        mViewModel = ViewModelProviders.of(this@ContactPage).get(ContactsImportViewModel::class.java)
    }

    private fun bindSyncContactsButton() {
        connect_contacts_btn.setOnClickListener {
            if (activityRef == null) return@setOnClickListener
            activityRef?.showDialog(CustomCallBack {
                showLoader()
            })
        }
    }

    private fun showLoader(){
        loader.visibility = View.VISIBLE
        connect_contacts_container.visibility = View.GONE
        mRecyclerView.visibility = View.GONE
    }

    private fun initContactsScenario() {


        if (activityRef == null) return

        when {
            activityRef!!.fromDashBoard() -> {
                showLoader()
                activityRef!!.importContacts()
                mRecyclerAdapter.contactsImportMessage =MESSAGE_1
            }
            activityRef!!.isContactSyncFromOtherDevices() -> { // contacts are sync from other phones
                //show them contact
                //api call
                //check the sim slots and get the sim(primary)
                //if sim is present, give the button to sync the current active contacts
                //ask to sync the contacts
                //else show the message that contacts cannot be imported
                connect_contacts_container.visibility = View.GONE
                mViewModel?.getUpdatedList()

                if (AppUtils.isSimAvailable(context)) {
                    mRecyclerAdapter.contactsImportMessage =  "Your contacts aren't currently sync with Krank, Goto Settings to turn it on."
                }else{
                    mRecyclerAdapter.contactsImportMessage =  "There is no sim present in your phone. In order to import your contacts we required sim to be placed."
                }

                mRecyclerAdapter.notifyItemChanged(0)

            }
            else -> // first time contacts import
                //if sim is present, give the button to sync the current active contacts
                //ask to sync the contacts
                //else show the message that contacts cannot be imported
                syncContacts()
        }


    }


    private fun syncContacts() {

        if (isContactsAlreadySync()) {

            //if from notifications
            // sync from notification object
            //otherwise update the data here



            connect_contacts_container.visibility = View.GONE

            //update data here
            if(activityRef!!.fromNotification()){
                mViewModel?.getUpdatedList()
            }else{
                activityRef?.fetchContactsAndSendToServer()
            }

        } else {
            connect_contacts_container.visibility = View.VISIBLE


            if (AppUtils.isSimAvailable(context)) {
                connect_contacts_heading.text = "Connect Your Contact"
                contact_description.text = "Find people you know on Krank and choose who to connect"
                bindSyncContactsButton()
            } else {
                //show that contacts cannot be imported
                connect_contacts_btn.visibility = View.GONE
                img_view.setImageDrawable(ContextCompat.getDrawable(context!!, R.drawable.ic_sim_card))
                connect_contacts_heading.text = "Contacts cannot be imported"
                contact_description.text = "There is no sim present in your phone. In order to import your contacts we required sim to be placed."
            }
        }


        mRecyclerAdapter.contactsImportMessage =MESSAGE_1
        mRecyclerAdapter.notifyItemChanged(0)

    }


    private fun isContactsAlreadySync(): Boolean = preference.getBoolean(Constants.CONTACTS_SYNC_ENABLED)


    private fun init() {

        //get activity ref
        activityRef = activity as DiscoverPeople
        if (activityRef != null) {
            activityRef?.mContactsImportResponse = this@ContactPage
            preference = activityRef?.preference
        }

    }


    override fun onContactsImported(contacts: ArrayList<ContactsDataModel>,deleteContacts: ArrayList<DeleteContactDataModel>) {

        //hide
        connect_contacts_container.visibility = View.GONE

        // if(!isContactsAlreadySync()){
        loader.visibility = View.VISIBLE
        // }

        if (mViewModel == null) return


        preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, true)

        //only for connect current phone
        //merged contacts from other devices
        if(activityRef!!.shouldReinitiateAdapter){
            setUpAdapter()
            mRecyclerAdapter.contactsImportMessage =MESSAGE_1
            activityRef!!.shouldReinitiateAdapter = false
        }




        mViewModel?.sendContactsToServer(contacts,deleteContacts)

    }


    override fun act(item: GetNetworkEmployeeData?, type: Int, view: View?) {
        if (mViewModel == null) return
        when (type) {
            BaseViewHolder.SEND_CONNECTION_REQUEST -> {
                mViewModel?.sendConnectionRequest(item)
            }
            BaseViewHolder.REMOVE_CONNECTION -> {
                showRemoveDialog(item)

            }
            BaseViewHolder.CONNECT_ALL -> {
                mViewModel?.connectAll()
            }
            BaseViewHolder.ACCEPT_INVITE -> {
                mViewModel?.acceptInvite(item)
            }
            BaseViewHolder.SEND_INVITE -> {
                if (item == null) return
               inviteThroughMessage(item)
            }
            BaseViewHolder.USER_PROFILE -> {
                if(item?.viewType !=  GetNetworkEmployeeData.INVITE_CONTACTS_VIEW){
                    context?.launchActivity<UserProfileView> {
                        putExtra(UserProfileView.INTENT_USER_ID,item?.id)
                    }
                }
            }
            BaseViewHolder.COMPANY_PROFILE -> {
                if(item?.viewType !=  GetNetworkEmployeeData.INVITE_CONTACTS_VIEW){
                    context?.launchActivity<CompanyProfileView> {
                        putExtra(CompanyProfileView.INTENT_COMPANY_ID,item?.company_id)
                    }
                }
            }
        }
    }

    private fun sendSms(number: String, s1: String) {
        val sms_uri = Uri.parse("smsto:$number")
        val sms_intent = Intent(Intent.ACTION_SENDTO, sms_uri)
        sms_intent.putExtra("sms_body",s1)
        startActivity(sms_intent)
    }

    private fun inviteThroughMessage(item: GetNetworkEmployeeData) {
        val dialog: InviteDialog = (DialogFactory.getDialog(DialogFactory.DialogType.INVITE_CONNECTIONS_DIALOG, context) as InviteDialog)

        dialog.setListener(object : InviteDialog.DialogClickListener{
            override fun onPrivateInviteClick(dialog: Dialog) {
                sendSms(item.country_code + item.number,Constants.PRIVATE_INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL) + "/p ")
            }

            override fun onCompanyInviteClick(dialog: Dialog) {
                sendSms(item.country_code + item.number,Constants.INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL))
            }

            override fun onCloseClick(dialog: Dialog) {
               dialog.dismiss()
            }

        })
        dialog.show()
    }
    private fun showRemoveDialog(item: GetNetworkEmployeeData?) {
        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, context) as NormalAppDialog)
                .setHeading("Are you sure you want to remove this connection?")
                .setDescription("You will also be removed from this user's connection list.")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener {
                    mViewModel?.removeConnection(item)

                }
        dialog.show()
    }

    private fun setUpAdapter() {
        // listItem = ArrayList()
        mRecyclerView = findViewById(R.id.contacts_recycler) as RecyclerView
        mRecyclerAdapter = ContactsImportAdapter(context!!, this, activityRef?.userId)
        mRecyclerView.layoutManager = LinearLayoutManager(context)
        (mRecyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
        mRecyclerView.adapter = mRecyclerAdapter
    }
}