package com.mobileapp.krank.CallBacks

import android.view.View

interface CallBackWithData<T>{
    fun act(item : T?,type : Int,view : View?)
}