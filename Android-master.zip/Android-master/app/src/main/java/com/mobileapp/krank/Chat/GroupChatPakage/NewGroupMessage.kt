package com.mobileapp.krank.Chat.GroupChatPakage

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Database.Dao.GroupChatListDao
import com.mobileapp.krank.Database.KrankRoomDataBase
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel
import com.mobileapp.krank.ResponseModels.GroupConversationCreateResponse
import com.mobileapp.krank.ResponseModels.ConnectionResponse

import java.util.ArrayList

import cn.pedant.SweetAlert.SweetAlertDialog
import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.Utils.AnimationUtils
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.ConnectionViewHolderCircle
import com.mobileapp.krank.ViewHolders.UserViewHolderCheckBox
import kotlinx.android.synthetic.main.activity_new_group_message.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.shimmer_loader_layout.*
import kotlinx.android.synthetic.main.toolbar_with_search.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NewGroupMessage : BaseActivity() {

    //adapter
    lateinit var peopleRecyclerAdapter: AppGeneralAdapter<ConnectionsDataModel>
    lateinit var selectedConnectionAdapter: AppGeneralAdapter<ConnectionsDataModel>

    //list
    lateinit var peopleItems: MutableList<ConnectionsDataModel>
    lateinit var selectedConnection: MutableList<ConnectionsDataModel>


    //loader
    private lateinit var showProgressAlert: SweetAlertDialog


    internal lateinit var groupChatConversationGroupModel: GroupChatConversationGroupModel

    //callbacks
    private lateinit var listCallBack: CallBackWithAdapterPosition
    private lateinit var removeCallBack: CallBackWithAdapterPosition

    //pagination
    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false

    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //typing events
    private var onTypingTimeout: Runnable? = null

    //api
    private var call: Call<ConnectionResponse>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_group_message)


        setUpTypingTimeoutRunnable()

        showProgressAlert = showAlert("Please wait...", SweetAlertDialog.PROGRESS_TYPE, false)


        setNormalPageToolbar( "New Group Message")

        setUpRunnable()

        //views
        shimmer_view_container.startShimmer()
        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT
        no_item_found_view.visibility = View.GONE

        initCallBack()

        bindListeners()

        setUpChipAdapter()

        setUpList()

        getData()

    }
    private fun removeShimmerLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }
    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {
            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            peopleItems.clear()
            peopleItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            peopleRecyclerAdapter.notifyDataSetChanged()

            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }

            //api data
            getData()
        }
    }


    private fun setUpRunnable() {
        runnable = Runnable {
            getData()
        }
    }

    private fun initCallBack() {
        listCallBack = CallBackWithAdapterPosition {
            if (!peopleItems[it].isItemCheck) {

                if (selectedConnection.size <= 0) {
                    showAdapter()

                }


                //add
                selectedConnectionAdapter.add(peopleItems[it])

                //focus
                if (selectedConnection.size > 1) {
                    people_chip_recycler.smoothScrollToPosition(selectedConnection.size - 1)
                }


            } else {
                //remove

                for (i in selectedConnection.indices) {
                    if (selectedConnection[i].companyData.userId == peopleItems[it].companyData.userId) {
                        selectedConnectionAdapter.removeAt(i)
                        break
                    }
                }

                if (selectedConnection.size <= 0 && people_chip_recycler.visibility == View.VISIBLE) {
                    hideAdapter()

                }
            }

            peopleItems[it].isItemCheck = !peopleItems[it].isItemCheck
            peopleRecyclerAdapter.updateListItem(it)
        }


        removeCallBack = CallBackWithAdapterPosition {
            for (j in peopleItems.indices) {
                if (peopleItems[j].companyData.userId == selectedConnection[it].companyData.userId) {
                    peopleItems[j].isItemCheck = !peopleItems[j].isItemCheck
                    peopleRecyclerAdapter.updateListItem(j)
                    break
                }
            }
            selectedConnectionAdapter.removeAt(it)

            if (selectedConnection.size <= 0 && people_chip_recycler.visibility == View.VISIBLE) {
                hideAdapter()
            }

        }
    }

    private fun bindListeners() {
        footer_btn.setOnClickListener {
            if (selectedConnection.isNotEmpty()) {
                showProgressAlert.show()
                createGroup()
            }
        }
        search_btn.setOnClickListener {
            showKeyboard(search_box)
            AnimationUtils.circleReveal(search_container, 1, true, true, this@NewGroupMessage)
        }


        back_btn_search.setOnClickListener {
            AnimationUtils.circleReveal(search_container, 1, true, false, this@NewGroupMessage)
            hideFocusKeyboard()
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

        })

    }

    private fun removeLoader() {
        for (i in peopleItems.indices.reversed()) {
            if (peopleItems[i].type == Constants.LOADER_VIEW) {
                peopleRecyclerAdapter.removeAt(i)
                break
            }
        }
    }


    private fun setUpChipAdapter() {

        selectedConnection = ArrayList()

        selectedConnectionAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(selectedConnection) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                (viewHolder as ConnectionViewHolderCircle).onBind(item)
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.people_view_with_circle, parent, false)
                return ConnectionViewHolderCircle(v, removeCallBack)
            }

        }
        people_chip_recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        people_chip_recycler.adapter = selectedConnectionAdapter
    }


    private fun showAdapter() {
        // appUtils.expand(people_chip_recycler)

        //  people_chip_recycler.animate().alpha(1f)
    }

    private fun hideAdapter() {
        // appUtils.collapse(people_chip_recycler)
        // people_chip_recycler.animate().translationY(0f).duration = 200
        //  people_chip_recycler.animate().alpha(0f)
    }

    private fun setUpList() {
        peopleItems = ArrayList()

        peopleRecyclerAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(peopleItems) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                if (viewHolder is UserViewHolderCheckBox) {
                    viewHolder.onBindConnections(item, appUtils)
                }

            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when (i) {
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                }
            }

            override fun getItemViewType(position: Int): Int {
                return peopleItems[position].type
            }

        }
        contacts_recycler.layoutManager = LinearLayoutManager(this@NewGroupMessage)
        contacts_recycler.adapter = peopleRecyclerAdapter
        peopleRecyclerAdapter.setItemAnimator(contacts_recycler)
        addOnScrollEndListener()
    }

    private fun addOnScrollEndListener() {
        contacts_recycler.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun getData() {
        call = api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", search_box.text.toString(), Constants.PAGE_LIMIT)
        if(call == null) return
        call?.enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {
                removeShimmerLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        // showToast(response.body().message)
                    }
                } else {
                    //onResponseFailure()
                }

            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                removeShimmerLoader()
                // onResponseFailure()
            }
        })
    }

    private fun onSuccess(response: Response<ConnectionResponse>) {

        val tempList = response.body().data.connectionsData

        removeLoader()


        /*set the selected item*/
        for (i in tempList.indices) {
            for (j in selectedConnection.indices) {
                if (tempList[i].companyData.userId == selectedConnection[j].companyData.userId) {
                    tempList[i].isItemCheck = true
                }
            }
        }
        /*set the selected item*/


        /*for pagination*/
        if (tempList.size >= Constants.PAGE_LIMIT) {
            tempList.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /*for pagination*/


        peopleRecyclerAdapter.addAll(tempList)
        checkForData()
    }
    private fun checkForData() {
        if (peopleItems.size <= 0) no_item_found_view.visibility = View.VISIBLE else no_item_found_view.visibility = View.GONE
    }
    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    private fun createGroup() {
        var group_name = "" + preference.getString(Constants.FIRST_NAME) + "" + preference.getString(Constants.LAST_NAME) + ", "
        var group_name_to_send = ""
        val group_message = "Conversation Started"
        val con_ids = ArrayList<String>()
        var isTextBoxEmpty = false

        if (conversation_name_edit_text.text.toString().isEmpty()) {
            isTextBoxEmpty = true
        } else {
            group_name_to_send = conversation_name_edit_text.text.toString()
        }

        for (i in selectedConnection.indices) {
            if (isTextBoxEmpty) {
                group_name += selectedConnection[i].companyData.firstName + " " + selectedConnection[i].companyData.lastName + ", "
            }
            con_ids.add(selectedConnection[i].companyData.userId)
        }
        if (isTextBoxEmpty) {
            group_name = group_name.substring(0, group_name.length - 2)

            if (group_name.length > 254) {
                group_name_to_send = group_name.substring(0, 254)
            } else {
                group_name_to_send = group_name
            }
        }

        api.createGroup(preference.getString(Constants.ACCESS_TOKEN), group_name_to_send, group_message, con_ids).enqueue(object : Callback<GroupConversationCreateResponse> {
            override fun onResponse(call: Call<GroupConversationCreateResponse>, response: Response<GroupConversationCreateResponse>) {
                if (response.isSuccessful) {
                    if (response.body().status == "success") {


                        groupChatConversationGroupModel = GroupChatConversationGroupModel(response.body().data.group_name, response.body().data.member_id, response.body().data.group_id, GroupChatConversationActivity.UN_MUTE_NOTIFICATIONS, GroupChatConversationActivity.MEMBER_EXISTS_TIME, GroupChatConversationActivity.MEMBER_STATUS, preference.getString(Constants.USER_ID))
                        InsertMemberIdInParentTable(KrankRoomDataBase.getDatabase(applicationContext).groupchatConversationListDao()).execute()
                    } else {
                        showProgressAlert.dismiss()
                        Toast.makeText(applicationContext, response.body().message, Toast.LENGTH_SHORT).show()
                    }

                } else {
                    showProgressAlert.dismiss()
                    Toast.makeText(applicationContext, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show()
                }

            }

            override fun onFailure(call: Call<GroupConversationCreateResponse>, t: Throwable) {
                showProgressAlert.dismiss()
                Toast.makeText(applicationContext, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private inner class InsertMemberIdInParentTable internal constructor(private val mAsyncTaskDao: GroupChatListDao?) : AsyncTask<Void, Void, Void?>() {

        override fun doInBackground(vararg params: Void): Void? {
            mAsyncTaskDao?.insert(groupChatConversationGroupModel)
            return null
        }

        override fun onPostExecute(aVoid: Void?) {

            showProgressAlert.dismiss()
            val intent = Intent(this@NewGroupMessage, GroupChatConversationActivity::class.java)
            intent.putExtra("member_id", "" + groupChatConversationGroupModel.memberId)
            intent.putExtra("recipient_name", groupChatConversationGroupModel.groupName)
            startActivity(intent)
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
            finish()
        }
    }


}
