package com.mobileapp.krank.Model;

import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;

import java.util.List;

public class ListingModelForEnquiry {
    private String userId;
    private String id;
    private List<DealerDataListing> dealers = null;
    private String conStatus;
    private String netStatus;
    private int cuId;
    private List<PublicMarketPlaceAssignment> assignments = null;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<DealerDataListing> getDealers() {
        return dealers;
    }

    public void setDealers(List<DealerDataListing> dealers) {
        this.dealers = dealers;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getNetStatus() {
        return netStatus;
    }

    public void setNetStatus(String netStatus) {
        this.netStatus = netStatus;
    }

    public List<PublicMarketPlaceAssignment> getAssignments() {
        return assignments;
    }

    public void setAssignments(List<PublicMarketPlaceAssignment> assignments) {
        this.assignments = assignments;
    }

    public int getCuId() {
        return cuId;
    }

    public void setCuId(int cuId) {
        this.cuId = cuId;
    }

    public ListingModelForEnquiry(int cuId,String userId, String id, List<DealerDataListing> dealers, String conStatus, String netStatus, List<PublicMarketPlaceAssignment> assignments) {
        this.cuId = cuId;
        this.userId = userId;
        this.id = id;
        this.dealers = dealers;
        this.conStatus = conStatus;
        this.netStatus = netStatus;
        this.assignments = assignments;
    }
    public ListingModelForEnquiry(String userId, String id, List<DealerDataListing> dealers, String conStatus, String netStatus, List<PublicMarketPlaceAssignment> assignments) {
        this.userId = userId;
        this.id = id;
        this.dealers = dealers;
        this.conStatus = conStatus;
        this.netStatus = netStatus;
        this.assignments = assignments;
    }

}
