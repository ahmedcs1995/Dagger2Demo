package com.mobileapp.krank.ResponseModels.DataModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupChatMessagesDataModel {
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("convoMsgs")
    @Expose
    private List<GroupChatConversationMessageModel> convoMsgs = null;
    @SerializedName("userDetail")
    @Expose
    private GroupChatMessagesUserDataModel userDetail;
    @SerializedName("groupData")
    @Expose
    private GroupChatMessagesGroupDataModel groupData;
    @SerializedName("group_id")
    @Expose
    private String groupId;
    @SerializedName("memberData")
    @Expose
    private GroupChatMessagesMemberDataModel memberData;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<GroupChatConversationMessageModel> getConvoMsgs() {
        return convoMsgs;
    }

    public void setConvoMsgs(List<GroupChatConversationMessageModel> convoMsgs) {
        this.convoMsgs = convoMsgs;
    }

    public GroupChatMessagesUserDataModel getUserDetail() {
        return userDetail;
    }

    public void setUserDetail(GroupChatMessagesUserDataModel userDetail) {
        this.userDetail = userDetail;
    }

    public GroupChatMessagesGroupDataModel getGroupData() {
        return groupData;
    }

    public void setGroupData(GroupChatMessagesGroupDataModel groupData) {
        this.groupData = groupData;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public GroupChatMessagesMemberDataModel getMemberData() {
        return memberData;
    }

    public void setMemberData(GroupChatMessagesMemberDataModel memberData) {
        this.memberData = memberData;
    }

}

