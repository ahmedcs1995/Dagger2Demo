package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Model.Enums.TypeOfComment;

import java.util.List;

public class CommentsDataResponse {
    @SerializedName("cid")
    @Expose
    private String cid;
    @SerializedName("comments")
    @Expose
    private String comments;
    @SerializedName("ca")
    @Expose
    private Integer ca;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("child_count")
    @Expose
    private String childCount;
    @SerializedName("total_likes")
    @Expose
    private String totalLikes;
    @SerializedName("is_like")
    @Expose
    private Integer isLike;


    @SerializedName("user_id")
    @Expose
    private int user_id;


    @SerializedName("reply")
    @Expose
    private List<CommentsReply> reply = null;


    private int itemIndex;

    private boolean focusComment;


    public int getItemIndex() {
        return itemIndex;
    }

    public void setItemIndex(int itemIndex) {
        this.itemIndex = itemIndex;
    }

    public List<CommentsReply> getReply() {
        return reply;
    }

    public void setReply(List<CommentsReply> reply) {
        this.reply = reply;
    }

    int typeOfComment;







    public CommentsDataResponse(int typeOfComment) {
        this.typeOfComment = typeOfComment;
    }



    public int getTypeOfComment() {
        return typeOfComment;
    }

    public void setTypeOfComment(int typeOfComment) {
        this.typeOfComment = typeOfComment;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getCa() {
        return ca;
    }

    public void setCa(Integer ca) {
        this.ca = ca;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getChildCount() {
        return childCount;
    }

    public void setChildCount(String childCount) {
        this.childCount = childCount;
    }

    public String getTotalLikes() {
        return totalLikes;
    }

    public void setTotalLikes(String totalLikes) {
        this.totalLikes = totalLikes;
    }

    public Integer getIsLike() {
        return isLike;
    }

    public void setIsLike(Integer isLike) {
        this.isLike = isLike;
    }

    public boolean isFocusComment() {
        return focusComment;
    }

    public void setFocusComment(boolean focusComment) {
        this.focusComment = focusComment;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
