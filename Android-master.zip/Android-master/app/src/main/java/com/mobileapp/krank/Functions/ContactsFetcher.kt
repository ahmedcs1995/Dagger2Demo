package com.mobileapp.krank.Functions

import android.Manifest
import android.content.Context
import android.provider.ContactsContract
import android.util.Log
import com.mobileapp.krank.ResponseModels.ContactsDataModel
import com.mobileapp.krank.ResponseModels.DeleteContactDataModel
import com.mobileapp.krank.Utils.SaveInSharedPreference
import kotlin.collections.ArrayList



class ContactsFetcher(private var context: Context) {


    fun getContactsList(preferences: SaveInSharedPreference): ArrayList<ContactsDataModel> {
        if (!AppUtils.isPermissionAllowed(context, Manifest.permission.READ_CONTACTS)) return ArrayList()


       // val contactsHasMap = HashMap<String, ContactsDataModel>()

        //for id
        val contactsArray = ArrayList<String>()


        // val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER)//plus any other properties you wish to query

        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER, ContactsContract.CommonDataKinds.Phone.CONTACT_ID,ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER)

        val contacts = ArrayList<ContactsDataModel>()


        val order = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"


        var cursor = context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, ContactsContract.CommonDataKinds.Phone.CONTACT_LAST_UPDATED_TIMESTAMP + ">=?", arrayOf(preferences.getLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP).toString()), order)



        while (cursor.moveToNext()) {
            if (cursor.getInt(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                val displayName = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                val displayNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                val contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID))


                if (!contactsArray.contains(contactId)) {
                    contactsArray.add(contactId)
                    Log.e("App Name", "readContacts: $displayName")
                    Log.e("App phone", "readContacts: $displayNumber")
                    Log.e("App contactId", "readContacts: $contactId")

                    contacts.add(ContactsDataModel(displayNumber, displayName, contactId))
                 //   contactsHasMap[contactId] = ContactsDataModel(displayNumber, displayName, contactId)
                }
            }
        }

        /**
         * holding timestamp for server response failure
         */
        preferences.setLong(Constants.TEMP_LAST_CONTACT_UPDATE_TIME_STAMP, preferences.getLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP))
        preferences.setLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP, System.currentTimeMillis())


        //for delete contacts after reading all contacts
        if (preferences.getLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP) == 0L) {
            preferences.setLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP, System.currentTimeMillis())
        }


        cursor.close()

        return contacts

    }


    fun getDeleteContactList(preferences: SaveInSharedPreference): ArrayList<DeleteContactDataModel> {

        if (!AppUtils.isPermissionAllowed(context, Manifest.permission.READ_CONTACTS)) return ArrayList()
        var deleteContacts = ArrayList<DeleteContactDataModel>()
        val cr = context.contentResolver


        val cur = cr.query(ContactsContract.DeletedContacts.CONTENT_URI, null, ContactsContract.DeletedContacts.CONTACT_DELETED_TIMESTAMP + ">=?", arrayOf(preferences.getLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP).toString()), null)

        if ((cur?.count ?: 0) > 0) {
            while (cur != null && cur.moveToNext()) {

                val id = cur.getString(cur.getColumnIndex(ContactsContract.DeletedContacts.CONTACT_ID))

                Log.e("ContactId", " ==> $id")

                deleteContacts.add(DeleteContactDataModel(id))

                /**
                 * holding tempstamp for server response failure
                 */
                preferences.setLong(Constants.TEMP_LAST_CONTACT_DELETE_TIME_STAMP, preferences.getLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP))
                preferences.setLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP, System.currentTimeMillis())

            }
        }
        cur?.close()
        return deleteContacts
    }

}
