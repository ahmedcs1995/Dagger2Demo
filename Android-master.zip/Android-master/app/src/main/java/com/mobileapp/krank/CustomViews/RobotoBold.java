package com.mobileapp.krank.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.text.style.TypefaceSpan;
import android.util.AttributeSet;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/**
 * Created by ahmed on 7/18/2017.
 */

public class RobotoBold extends android.support.v7.widget.AppCompatTextView {
    Context context;
    InputMethodManager imm;
    public RobotoBold(Context cntx) {
        super(cntx);
        context = cntx;
        this.setCustomFont(cntx);
        imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    public void requestFocus(Context cntx) {
        super.requestFocus();
        try {
            imm = (InputMethodManager) cntx.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        }catch (Exception e){}
    }

    public RobotoBold(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setCustomFont(context);
    }

    public RobotoBold(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.setCustomFont(context);
    }

    public void setCustomFont(Context context) {
        String fontName = "Roboto-Bold.ttf";
        if (getTypeface() != null && getTypeface().getStyle() == Typeface.BOLD) {
            fontName = "Roboto-Bold.ttf";
        }
        Typeface face1 = Typeface.createFromAsset(context.getAssets(), "fonts/" + fontName);

        setTypeface(face1);
    }

    public void closeKeyboard(Context cntx){
        InputMethodManager imm =  (InputMethodManager) cntx.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(this.getWindowToken(),0);
    }

    @Override
    public void setError(CharSequence error) {
        super.setError(error,null);
    }
}

