package com.mobileapp.krank.ResponseModels.DataModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ListingDetailVideoDataModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("url")
    @Expose
    private String url;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("modified_date")
    @Expose
    private Object modifiedDate;
    @SerializedName("listing_id")
    @Expose
    private String listingId;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("vimeo_thumbnail")
    @Expose
    private String vimeo_thumbnail;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Object getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Object modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getListingId() {
        return listingId;
    }

    public void setListingId(String listingId) {
        this.listingId = listingId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVimeo_thumbnail() {
        return vimeo_thumbnail;
    }

    public void setVimeo_thumbnail(String vimeo_thumbnail) {
        this.vimeo_thumbnail = vimeo_thumbnail;
    }
}
