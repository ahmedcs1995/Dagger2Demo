package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Model.ListingSortModel;
import com.mobileapp.krank.R;

public class SortMarketPlace extends BaseActivity {

    View sortByConnection;
    View sortByNetwork;
    private static int NETWORK_SORT_ACTIVITY_CODE = 10;
    private static int CONNECTION_SORT_ACTIVITY_CODE = 20;

    String companyId;
    String connectionId;
    String sortBy;


    String companyName;
    String connectionName;

    TextView company_name_text;
    TextView connection_name_text;

    View apply_btn;

    View reset_btn;


    ListingSortModel listingSortModel;


    boolean isFavSelected;
    boolean isRecentSelected;

    View fav_uncheck_view;
    View fav_check_view;

    View recent_uncheck_view;
    View recent_check_view;

    View fav_container;
    View recent_container;


    View selected_header;


    private static final String CONNECTION_TEXT = "<b>Connection :- </b>";
    private static final String NETWORK_TEXT = "<b>Network :- </b>";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort_market_place);


        setNormalPageToolbar("Sort Marketplace");
        listingSortModel = gson.fromJson(getIntent().getStringExtra("sort_data"), ListingSortModel.class);

        companyId=listingSortModel.getNetworkId();
        connectionId=listingSortModel.getConnectionId();
        sortBy=listingSortModel.getSort_by();



        selected_header = findViewById(R.id.selected_header);



        sortByConnection=findViewById(R.id.sort_by_connections);
        sortByNetwork=findViewById(R.id.sort_by_networks);


        company_name_text=findViewById(R.id.company_name_text);
        connection_name_text=findViewById(R.id.connection_name_text);


        apply_btn=findViewById(R.id.apply_btn);
        reset_btn = findViewById(R.id.reset_btn);


        fav_uncheck_view = findViewById(R.id.fav_uncheck_view);
        fav_check_view = findViewById(R.id.fav_check_view);


        recent_uncheck_view = findViewById(R.id.recent_uncheck_view);
        recent_check_view = findViewById(R.id.recent_check_view);


        fav_container = findViewById(R.id.fav_container);
        recent_container = findViewById(R.id.recent_container);


        connectionName = listingSortModel.getConnectionName();
        companyName = listingSortModel.getNetworkCompanyName();

        setLabels(CONNECTION_TEXT,connectionName,connection_name_text);
        setLabels(NETWORK_TEXT,companyName,company_name_text);


        sortByConnection.setOnClickListener(view -> {
            Intent intent = new Intent(SortMarketPlace.this,SortByConnectionsAndDealers.class);
            intent.putExtra("selected_connection",connectionId);
            startActivityForResult(intent, CONNECTION_SORT_ACTIVITY_CODE);
        });
        sortByNetwork.setOnClickListener(view -> {
            Intent intent = new Intent(SortMarketPlace.this, SortByNetwork.class);
            intent.putExtra("selected_network_group",companyId);
            startActivityForResult(intent, NETWORK_SORT_ACTIVITY_CODE);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        apply_btn.setOnClickListener(view -> {
            if(!(companyId.equals("0")) || !(connectionId.equals("0")) || !isFavSelected || !isRecentSelected){
                listingSortModel.setConnectionId("" + connectionId);
                listingSortModel.setNetworkId("" + companyId);
                listingSortModel.setSort_by("" + sortBy);
                listingSortModel.setNetworkCompanyName("" + companyName);
                listingSortModel.setConnectionName("" + connectionName);
                Intent intent = new Intent();
                intent.putExtra("sorted_data", appUtils.convertToJson(listingSortModel));
                setResult(RESULT_OK, intent);
                finish();

            }
        });
        reset_btn.setOnClickListener(view -> {

            listingSortModel.setSort_by("0");
            listingSortModel.setNetworkId("0");
            listingSortModel.setConnectionId("0");
            listingSortModel.setNetworkCompanyName("");
            listingSortModel.setConnectionName("");
            Intent intent = new Intent();
            intent.putExtra("sorted_data", appUtils.convertToJson(listingSortModel));
            setResult(RESULT_OK, intent);
            finish();
        });

        fav_container.setOnClickListener(view -> setFavCheck());
        recent_container.setOnClickListener(view -> setRecentCheck());
        if(sortBy.equals("0")){
            setRecentCheck();
        }
        else if (sortBy.equals("2")){
            setFavCheck();
        }
    }

    private void setLabels(String initialText,String text,TextView textView){
        if(text.isEmpty()){
            return;
        }
        selected_header.setVisibility(View.VISIBLE);
        textView.setText(Html.fromHtml(initialText + text));
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            selected_header.setVisibility(View.VISIBLE);
            if (requestCode == NETWORK_SORT_ACTIVITY_CODE) {
                boolean isFirstIndex = data.getBooleanExtra("isFirstIndex",false);
                if(!isFirstIndex){
                    companyId = data.getStringExtra("companyId");
                    companyName = data.getStringExtra("companyName");
                    company_name_text.setText(Html.fromHtml(NETWORK_TEXT + companyName));
                }else{
                    companyId="0";
                    connection_name_text.setText("");
                }
            }
            else if(requestCode == CONNECTION_SORT_ACTIVITY_CODE){
                connectionId= data.getStringExtra("userId");
                connectionName= data.getStringExtra("userName");
                connection_name_text.setText(Html.fromHtml(CONNECTION_TEXT + connectionName));
                Log.e("connectionId","" + connectionId);
                Log.e("userName","" + data.getStringExtra("userName"));
            }
        }
    }

    private void setFavCheck() {
        isRecentSelected = false;
        isFavSelected = true;

        recent_check_view.setVisibility(View.GONE);
        recent_uncheck_view.setVisibility(View.VISIBLE);


        fav_check_view.setVisibility(View.VISIBLE);
        fav_uncheck_view.setVisibility(View.GONE);

        sortBy = "2";
    }

    private void setRecentCheck() {
        isRecentSelected = true;
        isFavSelected = false;



        recent_check_view.setVisibility(View.VISIBLE);
        recent_uncheck_view.setVisibility(View.GONE);


        fav_check_view.setVisibility(View.GONE);
        fav_uncheck_view.setVisibility(View.VISIBLE);

        sortBy = "0";
    }
    private void resetData(){
        isRecentSelected = false;
        isFavSelected = false;


        recent_check_view.setVisibility(View.GONE);
        fav_uncheck_view.setVisibility(View.VISIBLE);


        fav_check_view.setVisibility(View.GONE);
        recent_uncheck_view.setVisibility(View.VISIBLE);

    }
}
