
package com.mobileapp.krank.ResponseModels.DataModel;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.CallBacks.CustomCallBack;

public class NetworkList {


    boolean isItemCheck;

    public boolean isItemCheck() {
        return isItemCheck;
    }

    public void setItemCheck(boolean itemCheck) {
        isItemCheck = itemCheck;
    }

    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("network_company")
    @Expose
    private String networkCompany;
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("company_latlng")
    @Expose
    private String companyLatlng;
    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("business")
    @Expose
    private String business;
    @SerializedName("currency_id")
    @Expose
    private String currencyId;
    @SerializedName("currency_name")
    @Expose
    private String currencyName;
    @SerializedName("company_size_id")
    @Expose
    private String companySizeId;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    @SerializedName("isDelete")
    @Expose
    private String isDelete;
    @SerializedName("dealer_status")
    @Expose
    private String dealerStatus;
    @SerializedName("employees")
    @Expose
    private List<Employee> employees = null;
    @SerializedName("my_company_id")
    @Expose
    private Integer myCompanyId;

    private int type;

    public NetworkList(String companyName){
        this.companyName=companyName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getNetworkCompany() {
        return networkCompany;
    }

    public void setNetworkCompany(String networkCompany) {
        this.networkCompany = networkCompany;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyLatlng() {
        return companyLatlng;
    }

    public void setCompanyLatlng(String companyLatlng) {
        this.companyLatlng = companyLatlng;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getCompanySizeId() {
        return companySizeId;
    }

    public void setCompanySizeId(String companySizeId) {
        this.companySizeId = companySizeId;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }

    public String getDealerStatus() {
        return dealerStatus;
    }

    public void setDealerStatus(String dealerStatus) {
        this.dealerStatus = dealerStatus;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Integer getMyCompanyId() {
        return myCompanyId;
    }

    public void setMyCompanyId(Integer myCompanyId) {
        this.myCompanyId = myCompanyId;
    }


    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public NetworkList(int type) {
        this.type = type;
    }
}
