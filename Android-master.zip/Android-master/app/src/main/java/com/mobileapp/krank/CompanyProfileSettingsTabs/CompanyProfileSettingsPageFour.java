package com.mobileapp.krank.CompanyProfileSettingsTabs;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.mobileapp.krank.Activities.MyCompanyProfileSettings;
import com.mobileapp.krank.Adapters.TypeOfBussinessAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.TypeOfBussinessData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.TypeOfBussinessResponse;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CompanyProfileSettingsPageFour extends BaseFragment {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerAdapter;
    List<TypeOfBussinessData> items;
    List<String> bussinessdatarecieved;
    TextView error_view;

    MyCompanyProfileSettings activityRef;

    public CompanyProfileSettingsPageFour(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.company_profile_settings_page_four, container, false);
        setFragmentView(me);

        activityRef = (MyCompanyProfileSettings) getActivity();
        setUpAdapter();
        return me;
    }
    private void setUpAdapter() {
        recyclerView = (RecyclerView) findViewById(R.id.type_of_bussiness_recycler);
        items = new ArrayList<>();
        error_view = (TextView) findViewById(R.id.error_view);


        ((MyCompanyProfileSettings) getActivity()).getAPI().getTypeOfBussiness(((MyCompanyProfileSettings) getActivity()).preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<TypeOfBussinessResponse>() {
            @Override
            public void onResponse(Call<TypeOfBussinessResponse> call, Response<TypeOfBussinessResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        items.addAll(response.body().getData());
                        if(bussinessdatarecieved !=null){
                            for(int i=0;i<items.size();i++){
                                for(int j=0 ;j < bussinessdatarecieved.size();j++){
                                    if(items.get(i).getName().equals(bussinessdatarecieved.get(j))){
                                        items.get(i).setItemSelected(true);
                                    }
                                }
                            }
                        }

                        recyclerAdapter = new TypeOfBussinessAdapter(items, getActivity());
                        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                        recyclerView.setAdapter(recyclerAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<TypeOfBussinessResponse> call, Throwable t) {

            }
        });
    }
    public void setData(List<String> bussinessdatarecieved){
        this.bussinessdatarecieved = bussinessdatarecieved;
    }

    public void updateProfile(final CustomCallBack customCallBack) {
        ArrayList<String> dataToSend = getSelectedBussiness();
        if (dataToSend.size() <= 0) {
            error_view.setText(Constants.SELECT_BUSSINESS_ERROR);
            return;
        }
        customCallBack.act();

       ServiceManager.getInstance().getAPI().updateCompanyProfileStepFour(((MyCompanyProfileSettings) getActivity()).preference.getString(Constants.ACCESS_TOKEN), dataToSend).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        showToast(response.body().getMessage());

                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST);
                }
            }
            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                showToast(Constants.ERROR_MSG_TOAST);
            }
        });
    }

    private void showToast(String message){
        try {
            activityRef.showToast(message);
        }catch (Exception ex){

        }

    }

    public ArrayList<String> getSelectedBussiness() {
        ArrayList<String> selectedData = new ArrayList<>();
        for (TypeOfBussinessData item : items) {
            if (item.isItemSelected()) {
                selectedData.add(item.getName());
            }
        }
        return selectedData;
    }

}
