
package com.mobileapp.krank.ResponseModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SignupOneResponse {

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private Object data;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("isCodeSend")
    @Expose
    private Boolean isCodeSend;
    @SerializedName("accout_type")
    @Expose
    private String accout_type;
    @SerializedName("url_string")
    @Expose
    private String url_string;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Boolean getIsCodeSend() {
        return isCodeSend;
    }

    public void setIsCodeSend(Boolean isCodeSend) {
        this.isCodeSend = isCodeSend;
    }

    public String getAccout_type() {
        return accout_type;
    }

    public void setAccout_type(String accout_type) {
        this.accout_type = accout_type;
    }

    public String getUrl_string() {
        return url_string;
    }

    public void setUrl_string(String url_string) {
        this.url_string = url_string;
    }
}
