package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Activities.PlayerActivity;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Activities.SendEnquiryPage;
import com.mobileapp.krank.Activities.YoutubePlayer;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.Model.ListingDetailListItem;
import com.mobileapp.krank.Model.ListingModelForEnquiry;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.AddRemoveFavResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ListingInnerDataModel;
import com.mobileapp.krank.Utils.ShareBottomSheet;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListingDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    List<ListingDetailListItem> items;
    ListingDetailDataModel listingDetailDataModel;
    ListingDetail listingDetail;

    ShareBottomSheet shareBottomSheet;

    private class TopDetail extends RecyclerView.ViewHolder {

        TextView listing_name;
        TextView listing_time;
        TextView listing_price;
        //CircleImageView profile_image_view;
        TextView people_name;
        TextView designation;
        View black_user_view;
        View user_detail_view;
        View enquiry_btn;
        SimpleDraweeView company_image_view;
        SimpleDraweeView profile_image_view;
        // TextView designation;
        TextView des_data;
        View share_listing_icon;


        View description_header;
        TextView fav_btn_icon;

        public TopDetail(View itemView) {
            super(itemView);
            listing_name = itemView.findViewById(R.id.listing_name);
            listing_time = itemView.findViewById(R.id.listing_time);
            listing_price = itemView.findViewById(R.id.listing_price);


            profile_image_view = itemView.findViewById(R.id.profile_image_view);
            people_name = itemView.findViewById(R.id.people_name);
            black_user_view = itemView.findViewById(R.id.black_user_view);
            user_detail_view = itemView.findViewById(R.id.user_detail_view);
            enquiry_btn = itemView.findViewById(R.id.enquiry_btn);
            company_image_view = itemView.findViewById(R.id.company_image_view);
            designation = itemView.findViewById(R.id.designation);


            des_data = itemView.findViewById(R.id.des_data);

            share_listing_icon = itemView.findViewById(R.id.share_listing_icon);

            description_header = itemView.findViewById(R.id.description_header);
            fav_btn_icon = itemView.findViewById(R.id.fav_btn_icon);


            fav_btn_icon.setOnClickListener(view -> {
                addToFavUnFav(listingDetailDataModel.getListingData(), fav_btn_icon, getAdapterPosition());
            });

            share_listing_icon.setOnClickListener(view -> {
                shareBottomSheet.openBottomSheetDialog(Integer.parseInt(listingDetailDataModel.getListingData().getId()), listingDetailDataModel.getListingData().getListingName(), listingDetailDataModel.getListingData().getListing_url(), Constants.LISTING_SHARE);
            });

            enquiry_btn.setOnClickListener(view -> {
                final ListingModelForEnquiry listingModelForEnquiry = new ListingModelForEnquiry(listingDetailDataModel.getListingData().getUserId(), listingDetailDataModel.getListingData().getId(), listingDetailDataModel.getDealers(), listingDetailDataModel.getConnectionStatus(), listingDetailDataModel.getNetworkStatus(), listingDetailDataModel.getAssignedUsers());
                Intent intent = new Intent(listingDetail, SendEnquiryPage.class);

                if(listingDetailDataModel.getDealers().size() > 0){
                    intent.putExtra("isDealer", true);
                    intent.putExtra("dealerList", listingDetail.gson.toJson(listingDetailDataModel.getDealers()));
                }
                else if ((listingDetailDataModel.getListingData().getShow_name().equals("Yes") || listingDetailDataModel.isPrivate() || listingDetailDataModel.getIn_my_network() == 1) && listingDetailDataModel.getAssignedUsers().size() > 0) {
                    intent.putExtra("isCoWorkerAssignment", true);
                    intent.putExtra("assignmentData", listingDetail.gson.toJson(listingDetailDataModel.getAssignedUsers()));
                }
                intent.putExtra("listing_data", listingDetail.gson.toJson(listingModelForEnquiry));
                intent.putExtra("item_index", getAdapterPosition());
                listingDetail.startActivityForResult(intent,Constants.ENQUIRY_ACTIVITY_CODE);
            });


        }
    }


    private class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView header_title;

        public HeaderViewHolder(View itemView) {
            super(itemView);
            header_title = itemView.findViewById(R.id.header_title);
        }
    }

    private class ErrorView extends  RecyclerView.ViewHolder{

        TextView error_text;
        TextView btn;
        public ErrorView(View itemView) {
            super(itemView);
            error_text = itemView.findViewById(R.id.error_text);
            btn = itemView.findViewById(R.id.btn);


            btn.setOnClickListener(view -> {
                Intent intent = new Intent(listingDetail,MainPage.class);
                listingDetail.startActivity(intent);
                listingDetail.finishAffinity();
            });
        }
    }


    private class BottomButtonsView extends RecyclerView.ViewHolder {

        View download_document_btn;
        View download_listing_btn;
        View share_listing_btn;

        public BottomButtonsView(View itemView) {
            super(itemView);
            download_document_btn = itemView.findViewById(R.id.download_document_btn);
            download_listing_btn = itemView.findViewById(R.id.download_listing_btn);
            share_listing_btn = itemView.findViewById(R.id.share_listing_btn);


            download_listing_btn.setOnClickListener(view -> {
                Uri uri = Uri.parse(Constants.LISTING_PDF_BASE_URL + listingDetailDataModel.getListingData().getHash());
                AppUtils.openChromeAppForDownload(uri,listingDetail);
            });

            share_listing_btn.setOnClickListener(view -> {
                shareBottomSheet.openBottomSheetDialog(Integer.parseInt(listingDetailDataModel.getListingData().getId()), listingDetailDataModel.getListingData().getListingName(), listingDetailDataModel.getListingData().getListing_url(), Constants.LISTING_SHARE);
            });

            download_document_btn.setOnClickListener(view -> {
                Uri uri = Uri.parse(listingDetailDataModel.getListingData().getZip());
                AppUtils.openChromeAppForDownload(uri,listingDetail);

            });
        }
    }

    private class VideoViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnial;
        ImageView play_icon;

        public VideoViewHolder(View itemView) {
            super(itemView);
            thumbnial = itemView.findViewById(R.id.thumbnail);
            play_icon = itemView.findViewById(R.id.play_icon);


            play_icon.setOnClickListener(view -> {
                Intent intent;
                if (items.get(getAdapterPosition()).getUrl().contains("vimeo")) {
                    intent = new Intent(listingDetail, PlayerActivity.class);
                    intent.putExtra("videoId", "" + AppUtils.getVimeoVideoId(items.get(getAdapterPosition()).getUrl().trim()));
                }else {
                    intent = new Intent(listingDetail, YoutubePlayer.class);
                    intent.putExtra("videoId", "" + AppUtils.getYoutubeIdFromUrl(items.get(getAdapterPosition()).getUrl().trim()));
                }
                listingDetail.startActivity(intent);
            });
        }
    }


    private class MapViewHolder extends RecyclerView.ViewHolder {
        ImageView map_img;
        TextView address_data;

        public MapViewHolder(View itemView) {
            super(itemView);
            map_img = itemView.findViewById(R.id.map_img);
            address_data = itemView.findViewById(R.id.address_data);

        }
    }

    private class SpecificationUrlViewHolder extends RecyclerView.ViewHolder {

        TextView title_text_view;
        TextView url_text_view;

        public SpecificationUrlViewHolder(View itemView) {
            super(itemView);

            title_text_view = itemView.findViewById(R.id.title_text_view);
            url_text_view = itemView.findViewById(R.id.url_text_view);

            url_text_view.setOnClickListener(view -> {
           /* Intent intent = new Intent(listingDetail, InAppWebViewCollapseActivity.class);
            intent.putExtra("web_view_url",item.getUrl().trim());
            listingDetail.startActivity(intent);*/

                listingDetail.appUtils.gotoAppWebViewPageForLink(listingDetail, items.get(getAdapterPosition()).getUrl());
           /* Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getUrl().trim()));
            listingDetail.startActivity(browserIntent);*/
            });
        }
    }

    private class PartItemViewHolder extends RecyclerView.ViewHolder {

        TextView quantity;
        TextView number;
        TextView description;
        TextView type;

        public PartItemViewHolder(View itemView) {
            super(itemView);
            quantity = itemView.findViewById(R.id.quantity);
            number = itemView.findViewById(R.id.number);
            description = itemView.findViewById(R.id.description);
            type = itemView.findViewById(R.id.type);

        }
    }


    private class DetailViewHolder extends RecyclerView.ViewHolder {

        TextView category_title;
        TextView category_name;

        public DetailViewHolder(View itemView) {
            super(itemView);
            category_title = itemView.findViewById(R.id.category_title);
            category_name = itemView.findViewById(R.id.category_name);

        }
    }


    public ListingDetailAdapter(List<ListingDetailListItem> listingDetailListItems, ListingDetail listingDetail, ListingDetailDataModel listingDetailDataModel) {
        this.items = listingDetailListItems;
        this.listingDetailDataModel = listingDetailDataModel;
        this.listingDetail = listingDetail;

        shareBottomSheet = new ShareBottomSheet
                .Builder(listingDetail, listingDetail.preference)
                .setListeners((selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
                    Intent intent = new Intent(listingDetail, SelectPrivacyActivity.class);
                    intent.putExtra("selected_privacy", listingDetail.gson.toJson(selectedPrivacy));
                    intent.putExtra("selected_network_group", listingDetail.gson.toJson(tempNetworkGroup));
                    intent.putExtra("selected_dealer_group", listingDetail.gson.toJson(tempDealerGroup));
                    listingDetail.startActivityForResult(intent, listingDetail.PRIVACY_ACTIVITY_CODE);
                })
                .create();
    }

    public ShareBottomSheet getShareBottomSheet() {
        return shareBottomSheet;
    }


    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getTypeOfDetailInListing()) {
            case TOP_HEADER:
                return 1;
            case BOTTOM_BUTTONS:
                return 2;
            case SPECIFICATION_URL:
                return 3;
            case HEADING:
                return 4;
            case VIDEO_VIEW:
                return 5;
            case PARTS_ITEM:
                return 6;
            case LOCATION:
                return 7;
            case DETAIL_ITEM:
                return 8;
            case ERROR_VIEW:
                return 9;
            default:
                return -1;
        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_top_header, parent, false);
                return new TopDetail(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_bottom_btns_view, parent, false);
                return new BottomButtonsView(view);
            case 3:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.spec_url_item, parent, false);
                return new SpecificationUrlViewHolder(view);
            case 4:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_header_item, parent, false);
                return new HeaderViewHolder(view);
            case 5:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_video_item, parent, false);
                return new VideoViewHolder(view);
            case 6:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.parts_item_layout_listing_detail, parent, false);
                return new PartItemViewHolder(view);
            case 7:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_map, parent, false);
                return new MapViewHolder(view);
            case 8:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_detail_item, parent, false);
                return new DetailViewHolder(view);
            case 9:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_error_view, parent, false);
                return new ErrorView(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listing_detail_bottom_btns_view, parent, false);
                return new BottomButtonsView(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final ListingDetailListItem item = items.get(position);

        switch (item.getTypeOfDetailInListing()) {
            case TOP_HEADER:
                setTopHeader(holder, position);
                break;
            case SPECIFICATION_URL:
                setSpecificationUrl(holder, item);
                break;
            case PARTS_ITEM:
                setPartsItemView(holder, item);
                break;
            case BOTTOM_BUTTONS:
                setBottomButtons(holder);
                break;
            case HEADING:
                setHeading(holder, item);
                break;
            case VIDEO_VIEW:
                setVideoView(holder, item);
                break;
            case LOCATION:
                setMap(holder, item);
                break;
            case DETAIL_ITEM:
                setDetailItem(holder, item);
                break;
            case ERROR_VIEW:
                setErrorView(holder,item);
            default:
                break;
        }
    }

    private void setErrorView(RecyclerView.ViewHolder holder, ListingDetailListItem item){
        ErrorView viewHolder = (ErrorView) holder;


        viewHolder.error_text.setText("" + item.getErrorText());
    }


    private void setDetailItem(RecyclerView.ViewHolder holder, ListingDetailListItem item) {
        DetailViewHolder viewHolder = (DetailViewHolder) holder;

        viewHolder.category_title.setText(item.getDetailItem().getTitle());
        viewHolder.category_name.setText(item.getDetailItem().getName());
    }

    private void setMap(RecyclerView.ViewHolder holder, ListingDetailListItem item) {
        MapViewHolder viewHolder = (MapViewHolder) holder;


        Log.e("map url =>", "https://maps.googleapis.com/maps/api/staticmap?markers=" + item.getLatitude() + "," + item.getLongitude() + "&zoom=" + 13 + "&size=" + 300 + "x300&sensor=false&key=" + Constants.GOOGLE_API_KEY);
        viewHolder.address_data.setText(item.getAddress());
        Glide.with(listingDetail).load("https://maps.googleapis.com/maps/api/staticmap?markers=" + item.getLatitude() + "," + item.getLongitude() + "&zoom=" + 15 + "&size=" + 300 + "x300&sensor=false&key=" + Constants.GOOGLE_API_KEY).into(viewHolder.map_img);


    }

    private void setPartsItemView(RecyclerView.ViewHolder holder, ListingDetailListItem item) {
        PartItemViewHolder viewHolder = (PartItemViewHolder) holder;

        viewHolder.quantity.setText(item.getQuantity());
        viewHolder.number.setText(item.getNumber());
        viewHolder.description.setText(item.getDescription());
        viewHolder.type.setText(item.getType());
    }

    private void setVideoView(RecyclerView.ViewHolder holder, ListingDetailListItem item) {
        VideoViewHolder viewHolder = (VideoViewHolder) holder;


        if (item.getUrl().toLowerCase().contains("vimeo")) {
            //vimeoVideo
            Glide.with(listingDetail).load(item.getVimeo_thumbnail().trim()).into(viewHolder.thumbnial);
        } else if (item.getUrl().toLowerCase().contains("youtube.com")) {
            Glide.with(listingDetail).load(AppUtils.makeThumbnailOfYoutube(item.getUrl().trim())).into(viewHolder.thumbnial);
        } else {
            // other than youtube and vimeo
        }

    }

    private void setHeading(RecyclerView.ViewHolder holder, ListingDetailListItem item) {
        HeaderViewHolder viewHolder = (HeaderViewHolder) holder;

        viewHolder.header_title.setText(item.getHeading());

    }

    private void setBottomButtons(RecyclerView.ViewHolder holder) {
        BottomButtonsView viewHolder = (BottomButtonsView) holder;

        if (listingDetailDataModel.getListingData().getZip() != null && listingDetailDataModel.getListingData().getZip().length() > 0) {
            viewHolder.download_document_btn.setVisibility(View.VISIBLE);
        } else {
            viewHolder.download_document_btn.setVisibility(View.GONE);
        }
        if (listingDetailDataModel.getListingData().getHash() != null && listingDetailDataModel.getListingData().getHash().length() > 0) {
            viewHolder.download_listing_btn.setVisibility(View.VISIBLE);

        } else {
            viewHolder.download_listing_btn.setVisibility(View.GONE);
        }

       /* viewHolder.share_listing_btn.setOnClickListener(view -> {
            //showDialog(listingDetailDataModel);
            openDialog();
            mListingSharePopUp.getBottomSheetDialog();
        });*/

        /*only public listing will be shared*/
        if (listingDetailDataModel.getListingData().getListingPrivacy().equals(Constants.PUBLIC_LISTING)) {
            viewHolder.share_listing_btn.setVisibility(View.VISIBLE);


        } else {
            viewHolder.share_listing_btn.setVisibility(View.GONE);
        }
        /*only public listing will be shared*/
    }

    private void setSpecificationUrl(RecyclerView.ViewHolder holder, final ListingDetailListItem item) {
        SpecificationUrlViewHolder viewHolder = (SpecificationUrlViewHolder) holder;

        viewHolder.title_text_view.setText(item.getTitle());

        // viewHolder.url_text_view.setClickable(true);
        // viewHolder.url_text_view.setMovementMethod(LinkMovementMethod.getInstance());
        //  String text = "<a href='" + item.getUrl() + "'>View Specification</a>";
        //viewHolder.url_text_view.setText(Html.fromHtml(text));


    }

    private void setTopHeader(RecyclerView.ViewHolder holder, final int position) {
        final TopDetail viewHolder = (TopDetail) holder;

        viewHolder.listing_name.setText("" + listingDetailDataModel.getListingData().getListingName());
        viewHolder.listing_time.setText("" + listingDetailDataModel.getListingData().getCreatedDate());
        viewHolder.listing_price.setText(listingDetailDataModel.getListingData().getCurrency_code() + " " + listingDetailDataModel.getListingData().getPricePrivacy());




        if (listingDetailDataModel.getListingData().getDescription() == null || listingDetailDataModel.getListingData().getDescription().isEmpty()) {
            viewHolder.des_data.setVisibility(View.GONE);
            viewHolder.description_header.setVisibility(View.GONE);
        } else {
            viewHolder.des_data.setVisibility(View.VISIBLE);
            viewHolder.description_header.setVisibility(View.VISIBLE);
            viewHolder.des_data.setText(Html.fromHtml("" + listingDetailDataModel.getListingData().getDescription()));
        }

        if (listingDetailDataModel.getListingData().getIs_fav() == null) {
            viewHolder.fav_btn_icon.setTextColor(ContextCompat.getColor(listingDetail, R.color.AppWhiteColor));
        } else {
            viewHolder.fav_btn_icon.setTextColor(ContextCompat.getColor(listingDetail, R.color.yellowColor));
        }

        /*only public listing will be shared*/
        if (listingDetailDataModel.getListingData().getListingPrivacy().equals(Constants.PUBLIC_LISTING)) {
            viewHolder.share_listing_icon.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_listing_icon.setVisibility(View.GONE);
        }
        /*only public listing will be shared*/


        /*logged in user own listing*/
        if (listingDetailDataModel.getListingData().getUserId().equals(listingDetail.preference.getString(Constants.USER_ID))) {
            viewHolder.enquiry_btn.setVisibility(View.GONE);
        } else {
            viewHolder.enquiry_btn.setVisibility(View.VISIBLE);
        }
        /*logged in user own listing*/



        /**
         * Market Place Privacy
         * */

       /* if (listingDetailDataModel.getDealers().size() > 0) {
            setCompanyView(viewHolder, listingDetailDataModel, true);
        } else if ((listingDetailDataModel.getListingData().getShow_name().equals("Yes") || listingDetailDataModel.getNetworkStatus().equals(Constants.CONNECTED_TEXT)) && listingDetailDataModel.getAssignedUsers().size() > 0) {
            setCompanyView(viewHolder, listingDetailDataModel, false);


        } else if (listingDetailDataModel.getListingData().getShow_name().equals("Yes") || listingDetailDataModel.getNetworkStatus().equals(Constants.CONNECTED_TEXT)) {
            setUserView(viewHolder, listingDetailDataModel);

        } else {
            setBlankUserView(viewHolder);
        }*/



        if (listingDetailDataModel.getDealers().size() > 0) {
            setCompanyView(viewHolder, listingDetailDataModel, true);
        }
        else if (listingDetailDataModel.getIn_my_network() == 1  || ( listingDetailDataModel.getListingData().getListingPrivacy().equals("1") && listingDetailDataModel.getListingData().getShow_name().equals("Yes")) || listingDetailDataModel.isPrivate()) {
            if(listingDetailDataModel.getAssignedUsers().size() > 0){
                setCompanyView(viewHolder, listingDetailDataModel, false);
            }else{
                setUserView(viewHolder, listingDetailDataModel);
            }

        }  else {
            setBlankUserView(viewHolder);

        }
        /**
         * Market Place Privacy
         * */


    }

    private void setBlankUserView(TopDetail viewHolder) {
        viewHolder.user_detail_view.setVisibility(View.GONE);
        viewHolder.black_user_view.setVisibility(View.VISIBLE);
    }

    private void setUserView(TopDetail viewHolder, final ListingDetailDataModel item) {

        viewHolder.people_name.setText("" + item.getUserData().getFirstName() + " " + item.getUserData().getLastName());
        viewHolder.black_user_view.setVisibility(View.GONE);
        viewHolder.user_detail_view.setVisibility(View.VISIBLE);
     //   Glide.with(listingDetail).load("" + item.getUserData().getUserProfilePic()).into(viewHolder.profile_image_view);

        viewHolder.profile_image_view.setImageURI(Uri.parse(item.getUserData().getUserProfilePic()));


        viewHolder.company_image_view.setVisibility(View.GONE);
        viewHolder.profile_image_view.setVisibility(View.VISIBLE);
        viewHolder.designation.setText(AppUtils.getCompanyAndDesignation(item.getUserData().getCompanyName(), item.getUserData().getDesignation()));

        viewHolder.people_name.setOnClickListener(view -> listingDetail.appUtils.gotoUserProfile(listingDetail, item.getUserData().getUserId(), listingDetail.preference));

        viewHolder.designation.setOnClickListener(view -> listingDetail.appUtils.gotoCompanyProfile(listingDetail, item.getUserData().getCompanyId(), listingDetail.preference));
    }

    private void setCompanyView(TopDetail viewHolder, final ListingDetailDataModel item, final boolean isDealer) {
        if (isDealer) {
            viewHolder.people_name.setText("" + item.getUserData().getCompanyName() + " (DEALERS)");
        } else {
            viewHolder.people_name.setText("" + item.getUserData().getCompanyName());
        }
        viewHolder.black_user_view.setVisibility(View.GONE);
        viewHolder.user_detail_view.setVisibility(View.VISIBLE);
      //  Glide.with(listingDetail).load("" + item.getUserData().getCompanyProfilePic()).into(viewHolder.company_image_view);

        viewHolder.company_image_view.setImageURI(Uri.parse(item.getUserData().getCompanyProfilePic()));

        viewHolder.company_image_view.setVisibility(View.VISIBLE);
        viewHolder.profile_image_view.setVisibility(View.GONE);
        viewHolder.designation.setText(item.getUserData().getCompanyCity() + ", " + item.getUserData().getCompanyCountry());
        viewHolder.people_name.setOnClickListener(view -> listingDetail.appUtils.gotoCompanyProfile(listingDetail, item.getUserData().getCompanyId(), listingDetail.preference));

    }

    private void addToFavUnFav(final ListingInnerDataModel item, View favView, final int position) {

        favView.setEnabled(false);
        final String isFav = item.getIs_fav();
        final int action;
        if (isFav != null) {
            action = 2;
        } else {
            action = 1;
        }
        listingDetail.getAPI().listingFavUnFav(listingDetail.preference.getString(Constants.ACCESS_TOKEN), String.valueOf(item.getId()), String.valueOf(item.getIs_fav()), String.valueOf(action)).enqueue(new Callback<AddRemoveFavResponse>() {
            @Override
            public void onResponse(Call<AddRemoveFavResponse> call, Response<AddRemoveFavResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (isFav == null) {
                            item.setIs_fav(response.body().getData().getFav_id());
                            notifyItemChanged(position);

                        } else {
                            notifyItemChanged(position);
                            item.setIs_fav(null);
                        }
                        //   updateFavButton();
                    }
                    favView.setEnabled(true);
                }
            }

            @Override
            public void onFailure(Call<AddRemoveFavResponse> call, Throwable t) {
                favView.setEnabled(true);

            }
        });
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

}
