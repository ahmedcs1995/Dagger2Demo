package com.mobileapp.krank.Activities.CustomDropDown;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.mobileapp.krank.Activities.DealerGroupScreen;
import com.mobileapp.krank.Activities.NetworkGroupScreen;
import com.mobileapp.krank.Adapters.SelectPrivacyAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.PrivacyItem;
import com.mobileapp.krank.R;

import java.util.ArrayList;
import java.util.List;

public class SelectPrivacyActivity extends BaseActivity implements CallBackWithAdapterPosition {


    List<PrivacyItem> privacyList;
    PrivacyItem selectedPrivacy;
    LinearLayoutManager layoutManager;

    private RecyclerView countryRecyclerView;
    private SelectPrivacyAdapter countryRecyclerAdapter;


    View done_btn;


    public int selectedIndex;

    //activity codes
    public static int DEALER_GROUP_REQUEST_CODE = 15;
    public static int NETWORK_GROUP_REQUEST_CODE = 18;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_privacy);

        done_btn = findViewById(R.id.done_btn);
        selectedIndex = -1;
        setNormalPageToolbar( "Select Privacy");


        done_btn.setOnClickListener(view -> {
            if (selectedIndex != -1 && (!privacyList.get(selectedIndex).getPrivacy().equals("Network Groups")) && (!privacyList.get(selectedIndex).getPrivacy().equals("Dealer Groups"))) {
                Intent intent = new Intent();
                intent.putExtra("selected_privacy", "" + gson.toJson(privacyList.get(selectedIndex)));
                setResult(RESULT_OK, intent);
                finish();
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
            } else {
                Toast.makeText(SelectPrivacyActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
            }
        });
        setUpAdapter();
    }

    private void setUpAdapter() {
        countryRecyclerView = (RecyclerView) findViewById(R.id.privacy_recycler);

        privacyList = new ArrayList<>();

        privacyList.add(new PrivacyItem(Constants.PUBLIC_PRIVACY, "This post will be available to view by anyone on your company’s public newsfeed", R.drawable.public_icon));
        privacyList.add(new PrivacyItem(Constants.CONNECTIONS_PRIVACY, "Your connection on Krank", R.drawable.connections_icon));
        privacyList.add(new PrivacyItem(Constants.PRIVATE_CONNECTIONS_PRIVACY, "Your private connections on Krank", R.drawable.eye_slash));
        privacyList.add(new PrivacyItem(Constants.CO_WORKER_PRIVACY, "Only your co-worker connections", R.drawable.co_worker_icon));
        privacyList.add(new PrivacyItem(Constants.NETWORK_PRIVACY, "Post to all my networks", R.drawable.networks_icon));
        privacyList.add(new PrivacyItem(Constants.NETWORK_GROUPS_PRIVACY, "All connections in selected network groups", R.drawable.network_group_icon));
        privacyList.add(new PrivacyItem(Constants.DEALER_GROUPS_PRIVACY, "All connections in selected dealer groups", R.drawable.dealer_group_icon));

        layoutManager = new LinearLayoutManager(this);
        countryRecyclerAdapter = new SelectPrivacyAdapter(privacyList, SelectPrivacyActivity.this,this);
        countryRecyclerView.setLayoutManager(layoutManager);
        countryRecyclerView.setAdapter(countryRecyclerAdapter);


        selectedPrivacy = gson.fromJson(getIntent().getStringExtra("selected_privacy"), PrivacyItem.class);
        if (selectedPrivacy != null) {
            for (int i = 0; i < privacyList.size(); i++) {
                if (privacyList.get(i).getPrivacy().equals(selectedPrivacy.getPrivacy())) {
                    privacyList.get(i).setItemSelected(true);
                    countryRecyclerAdapter.prevItem = privacyList.get(i);
                    selectedIndex = i;
                }
            }
            countryRecyclerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == NETWORK_GROUP_REQUEST_CODE) {
                Intent intent = new Intent();
                Log.e("NETWORK_GROUP_REQUEST ", " = " + data.getStringExtra("SelectedDealerGroup"));
                intent.putExtra("SelectedNetworkGroup", data.getStringExtra("SelectedDealerGroup"));
                intent.putExtra("selected_privacy", "" + gson.toJson(privacyList.get(selectedIndex)));
                setResult(RESULT_OK, intent);
                finish();
            } else if (requestCode == DEALER_GROUP_REQUEST_CODE) {
                Intent intent = new Intent();
                intent.putExtra("SelectedDealerGroup", data.getStringExtra("SelectedDealerGroup"));
                intent.putExtra("selected_privacy", "" + gson.toJson(privacyList.get(selectedIndex)));
                setResult(RESULT_OK, intent);
                finish();
            }
        }
    }

    @Override
    public void act(int position) {
        selectedIndex = position;
        countryRecyclerAdapter.notifyDataSetChanged();
        if (privacyList.get(position).getPrivacy().equals("Network Groups")) {
            handleNetworkGroup();
        } else if (privacyList.get(position).getPrivacy().equals("Dealer Groups")) {
            handleDealerGroup();
        }
    }

    private void handleNetworkGroup() {
        Intent networkGroupIntent = new Intent(this, NetworkGroupScreen.class);
        networkGroupIntent.putExtra("selectedArray", "" + getIntent().getStringExtra("selected_network_group"));
        startActivityForResult(networkGroupIntent, NETWORK_GROUP_REQUEST_CODE);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void handleDealerGroup() {
        Intent networkGroupIntent = new Intent(this, DealerGroupScreen.class);
        networkGroupIntent.putExtra("selectedArray", "" + getIntent().getStringExtra("selected_dealer_group"));
        startActivityForResult(networkGroupIntent, DEALER_GROUP_REQUEST_CODE);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
}
