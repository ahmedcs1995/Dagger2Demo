package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NetworkDealersDataModelResponse {
    @SerializedName("dealers_count")
    @Expose
    private String dealers_count;

    @SerializedName("dealer_list")
    @Expose
    private List<NetworkDealersData> dealer_list = null;

    public String getDealers_count() {
        return dealers_count;
    }

    public void setDealers_count(String dealers_count) {
        this.dealers_count = dealers_count;
    }

    public List<NetworkDealersData> getDealer_list() {
        return dealer_list;
    }

    public void setDealer_list(List<NetworkDealersData> dealer_list) {
        this.dealer_list = dealer_list;
    }
}
