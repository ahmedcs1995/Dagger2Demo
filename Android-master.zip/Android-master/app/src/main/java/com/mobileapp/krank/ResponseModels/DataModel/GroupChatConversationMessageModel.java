package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import static android.arch.persistence.room.ForeignKey.CASCADE;


@Entity(tableName = "group_chat_conversation_table",
        foreignKeys = @ForeignKey(entity = GroupChatConversationGroupModel.class,
                parentColumns = "memberId",
                childColumns = "member_id",
                onDelete = CASCADE))
public class GroupChatConversationMessageModel {
    @SerializedName("msg_id")
    @Expose
    @ColumnInfo(name = "msg_id")
    private long msgId;

    @SerializedName("msg_text")
    @Expose
    @ColumnInfo(name = "msg_text")
    private String msgText;

    @SerializedName("msg_user_id")
    @Expose
    @ColumnInfo(name = "msg_user_id")
    private int msgUserId;

    @SerializedName("msg_group_id")
    @Expose
    @ColumnInfo(name = "msg_group_id")
    private int msgGroupId;

    @SerializedName("msg_type")
    @Expose
    @ColumnInfo(name = "msg_type")
    private String msgType;

    @SerializedName("msg_added")
    @Expose
    @ColumnInfo(name = "msg_added")
    private String msgAdded;

    @SerializedName("msg_updated")
    @Expose
    @ColumnInfo(name = "msg_updated")
    private String msgUpdated;

    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    private int id;

    @SerializedName("profile_pic")
    @Expose
    @ColumnInfo(name = "profile_pic")
    private String profilePic;

    @SerializedName("first_name")
    @Expose
    @ColumnInfo(name = "first_name")
    private String firstName;

    @SerializedName("last_name")
    @Expose
    @ColumnInfo(name = "last_name")
    private String lastName;

    @SerializedName("sentTime")
    @Expose
    @ColumnInfo(name = "sentTime")
    private String sentTime;

    @SerializedName("sentByme")
    @Expose
    @ColumnInfo(name = "sentByme")
    private int sentByme;

    @SerializedName("type")
    @Expose
    @ColumnInfo(name = "type")
    private String type;

    @SerializedName("reply")
    @Expose
    @ColumnInfo(name = "reply")
    private String reply;

    @SerializedName("senderImg")
    @Expose
    @ColumnInfo(name = "senderImg")
    private String senderImg;


    @SerializedName("conStatus")
    @Expose
    @ColumnInfo(name = "conStatus")
    private String conStatus;



    @ColumnInfo(name = "typeOfMessage")
    private String typeOfMessage;

    @SerializedName("vCardData")
    @Expose
    @Embedded
    private MessageVCardData vCardData;

    @SerializedName("attachment")
    @Expose
    @Embedded
    private MessageAttachment attachment;

    @SerializedName("system_message")
    @Expose
    @ColumnInfo(name = "system_message")
    private String system_message;

    @ColumnInfo(name = "member_id")
    private String member_id;

    @ColumnInfo(name = "msgStatus")
    private int msgStatus;


    @ColumnInfo(name = "timeStamp")
    private long timeStamp;

    @ColumnInfo(name = "msgBubbleTime")
    private String msgBubbleTime;


    @ColumnInfo(name = "mid")
    @PrimaryKey(autoGenerate = true)
    @NonNull
    private long mid;

    @Ignore
    public GroupChatConversationMessageModel(String typeOfMessage) {
        this.typeOfMessage = typeOfMessage;
    }

    public long getMsgId() {
        return msgId;
    }

    public void setMsgId(long msgId) {
        this.msgId = msgId;
    }

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }

    public int getMsgUserId() {
        return msgUserId;
    }

    public void setMsgUserId(int msgUserId) {
        this.msgUserId = msgUserId;
    }

    public int getMsgGroupId() {
        return msgGroupId;
    }

    public void setMsgGroupId(int msgGroupId) {
        this.msgGroupId = msgGroupId;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getMsgAdded() {
        return msgAdded;
    }

    public void setMsgAdded(String msgAdded) {
        this.msgAdded = msgAdded;
    }

    public String getMsgUpdated() {
        return msgUpdated;
    }

    public void setMsgUpdated(String msgUpdated) {
        this.msgUpdated = msgUpdated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSentTime() {
        return sentTime;
    }

    public void setSentTime(String sentTime) {
        this.sentTime = sentTime;
    }

    public int getSentByme() {
        return sentByme;
    }

    public void setSentByme(int sentByme) {
        this.sentByme = sentByme;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getSenderImg() {
        return senderImg;
    }

    public void setSenderImg(String senderImg) {
        this.senderImg = senderImg;
    }

    public String getTypeOfMessage() {
        return typeOfMessage;
    }

    public void setTypeOfMessage(String typeOfMessage) {
        this.typeOfMessage = typeOfMessage;
    }

    public MessageVCardData getVCardData() {
        return vCardData;
    }

    public void setVCardData(MessageVCardData vCardData) {
        this.vCardData = vCardData;
    }

    public MessageAttachment getAttachment() {
        return attachment;
    }

    public void setAttachment(MessageAttachment attachment) {
        this.attachment = attachment;
    }

    public String getSystem_message() {
        return system_message;
    }

    public void setSystem_message(String system_message) {
        this.system_message = system_message;
    }

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public GroupChatConversationMessageModel() {

    }

    public int getMsgStatus() {
        return msgStatus;
    }

    public void setMsgStatus(int msgStatus) {
        this.msgStatus = msgStatus;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    @Ignore
    public GroupChatConversationMessageModel(String reply, String typeOfMessage,int msgStatus,String memberId) {
        this.reply = reply;
        this.typeOfMessage = typeOfMessage;
        this.msgStatus = msgStatus;
        this.member_id = memberId;
    }

    @NonNull
    public long getMid() {
        return mid;
    }

    public void setMid(@NonNull long mid) {
        this.mid = mid;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getMsgBubbleTime() {
        return msgBubbleTime;
    }

    public void setMsgBubbleTime(String msgBubbleTime) {
        this.msgBubbleTime = msgBubbleTime;
    }
}
