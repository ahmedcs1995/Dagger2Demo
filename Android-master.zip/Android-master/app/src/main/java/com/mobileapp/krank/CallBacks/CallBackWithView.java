package com.mobileapp.krank.CallBacks;

import android.view.View;

public interface CallBackWithView {
    void act(View view);
}
