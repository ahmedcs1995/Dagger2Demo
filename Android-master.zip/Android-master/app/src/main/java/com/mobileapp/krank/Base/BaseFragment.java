package com.mobileapp.krank.Base;

/**
 * Created by ahmed on 2/17/2017.
 */

import android.content.Context;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.mobileapp.krank.Utils.SaveInSharedPreference;


/**
 * Created by ishaquehassan on 08/11/2016.
 */

public class BaseFragment extends Fragment {


    private String setTitle = "";
    private View fragmentView = null;

    public SaveInSharedPreference preference;

    public String getTitle() {
        return setTitle;
    }

    public void setTitle(String setTitle) {
        this.setTitle = setTitle;
    }

    public void setFragmentView(View fragmentView) {
        this.fragmentView = fragmentView;
    }

    public View getFragmentView() {
        return fragmentView;
    }

    public View findViewById(int viewId) {
        return fragmentView.findViewById(viewId);
    }

    public void switchFragment(BaseFragment page) {
        // ((UserProfileView)getActivity()).switchFragment(page);
    }


    public void addFragment(BaseFragment page) {
        //((UserProfileView)getActivity()).addFragment(page);
    }


    public void hideKeyBoard() {
        try {
            InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
        catch (Exception ex){

        }

    }
}

