package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class PrivateChatMessagesDataModel {

    @SerializedName("conversation_detail")
    @Expose
    private List<ConversationDetail> conversation_detail = null;
    @SerializedName("user_detail")
    @Expose
    private List<PrivateChatUserDetail> user_detail;

    @SerializedName("receptId")
    @Expose
    private String receptId;

    @SerializedName("conversation_count")
    @Expose
    private String conversation_count;

    public List<ConversationDetail> getConversation_detail() {
        return conversation_detail;
    }

    public void setConversation_detail(List<ConversationDetail> conversation_detail) {
        this.conversation_detail = conversation_detail;
    }

    public List<PrivateChatUserDetail> getUser_detail() {
        return user_detail;
    }

    public void setUser_detail(List<PrivateChatUserDetail> user_detail) {
        this.user_detail = user_detail;
    }

    public String getReceptId() {
        return receptId;
    }

    public void setReceptId(String receptId) {
        this.receptId = receptId;
    }

    public String getConversation_count() {
        return conversation_count;
    }

    public void setConversation_count(String conversation_count) {
        this.conversation_count = conversation_count;
    }
}
