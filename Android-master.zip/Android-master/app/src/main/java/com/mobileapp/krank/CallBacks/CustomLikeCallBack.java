package com.mobileapp.krank.CallBacks;


public interface CustomLikeCallBack {
     void updateLike(int id,int isLike,int likeCount);
}
