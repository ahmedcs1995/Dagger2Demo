package com.mobileapp.krank.ResponseModels;

import android.arch.persistence.room.ColumnInfo;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FeedListingOwnerModel implements Parcelable {
    @SerializedName("user_id")
    @Expose
    @ColumnInfo(name = "owner_user_id")
    private int user_id;

    @SerializedName("url")
    @Expose
    @ColumnInfo(name = "owner_url")
    private String url;

    @SerializedName("name")
    @Expose
    @ColumnInfo(name = "owner_name")
    private String name;

    @SerializedName("privacy")
    @Expose
    @ColumnInfo(name = "owner_privacy")
    private int privacy;


    @SerializedName("own")
    @Expose
    @ColumnInfo(name = "owner_own")
    private String own;


    protected FeedListingOwnerModel(Parcel in) {
        user_id = in.readInt();
        url = in.readString();
        name = in.readString();
        privacy = in.readInt();
        own = in.readString();
    }

    public static final Creator<FeedListingOwnerModel> CREATOR = new Creator<FeedListingOwnerModel>() {
        @Override
        public FeedListingOwnerModel createFromParcel(Parcel in) {
            return new FeedListingOwnerModel(in);
        }

        @Override
        public FeedListingOwnerModel[] newArray(int size) {
            return new FeedListingOwnerModel[size];
        }
    };

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrivacy() {
        return privacy;
    }

    public void setPrivacy(int privacy) {
        this.privacy = privacy;
    }

    public String getOwn() {
        return own;
    }

    public void setOwn(String own) {
        this.own = own;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(user_id);
        parcel.writeString(url);
        parcel.writeString(name);
        parcel.writeInt(privacy);
        parcel.writeString(own);
    }

    public FeedListingOwnerModel() {
        //Empty Constructor for Db
    }
}
