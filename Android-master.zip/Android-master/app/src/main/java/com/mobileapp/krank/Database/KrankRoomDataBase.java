package com.mobileapp.krank.Database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.mobileapp.krank.Database.Dao.ContactsImportDao;
import com.mobileapp.krank.Database.Dao.GroupChatConversationDao;
import com.mobileapp.krank.Database.Dao.GroupChatListDao;
import com.mobileapp.krank.Database.Dao.GroupChatPeopleList;
import com.mobileapp.krank.Database.Dao.NewsFeedDao;
import com.mobileapp.krank.Database.Dao.PersonalChatConversationDao;
import com.mobileapp.krank.Database.Dao.PersonalChatListDao;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMessageModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

@Database(entities = {NewsFeedArray.class,ChatConversationListDataModel.class,ConversationDetail.class, GroupChatConversationGroupModel.class, GroupChatConversationMessageModel.class, GroupChatMembersDataModel.class, GetNetworkEmployeeData.class}, version = 5,exportSchema = false)
public abstract class KrankRoomDataBase extends RoomDatabase {

    public abstract PersonalChatListDao personalChatListDao();
    public abstract PersonalChatConversationDao chatConversationListDao();
    public abstract GroupChatListDao groupchatConversationListDao();
    public abstract GroupChatConversationDao groupchatConversationDao();
    public abstract NewsFeedDao getNewsFeedDao();
    public abstract GroupChatPeopleList getGroupChatListDao();
    public abstract ContactsImportDao getContactsDao();

    private static KrankRoomDataBase INSTANCE;
    private static final String DATABASE_NAME = "krank_db";

    public static KrankRoomDataBase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (KrankRoomDataBase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            KrankRoomDataBase.class, DATABASE_NAME)
                            // Wipes and rebuilds instead of migrating if no Migration object.
                            // Migration is not part of this codelab.
                            .fallbackToDestructiveMigration()
                            .build();
                    //.addCallback(sRoomDatabaseCallback)
                }
            }
        }
        return INSTANCE;
    }

}
