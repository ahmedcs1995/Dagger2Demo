package com.mobileapp.krank.ResponseModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Model.RequestRecievedItem;

import java.util.List;

public class PendingRecieveRequestResponseModel {
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private PendingReceiveRequestDataModel data;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public PendingReceiveRequestDataModel getData() {
        return data;
    }

    public void setData(PendingReceiveRequestDataModel data) {
        this.data = data;
    }

    public class PendingReceiveRequestDataModel {

        @SerializedName("networkRequests")
        @Expose
        private List<RequestRecievedItem> networkRequest;


        @SerializedName("connectionRequests")
        @Expose
        private List<RequestRecievedItem> connectionRequests;

        @SerializedName("dealerRequests")
        @Expose
        private List<RequestRecievedItem> dealerRequests;

        @SerializedName("totalNetwork")
        @Expose
        private String totalNetwork;

        @SerializedName("totalConnections")
        @Expose
        private String totalConnections;

        @SerializedName("totalDealers")
        @Expose
        private String totalDealers;

        @SerializedName("currentNetwork")
        @Expose
        private String currentNetwork;

        @SerializedName("currentConnections")
        @Expose
        private String currentConnections;

        @SerializedName("currentDealers")
        @Expose
        private String currentDealers;

        public List<RequestRecievedItem> getNetworkRequest() {
            return networkRequest;
        }

        public void setNetworkRequest(List<RequestRecievedItem> networkRequest) {
            this.networkRequest = networkRequest;
        }

        public List<RequestRecievedItem> getConnectionRequests() {
            return connectionRequests;
        }

        public void setConnectionRequests(List<RequestRecievedItem> connectionRequests) {
            this.connectionRequests = connectionRequests;
        }

        public List<RequestRecievedItem> getDealerRequests() {
            return dealerRequests;
        }

        public void setDealerRequests(List<RequestRecievedItem> dealerRequests) {
            this.dealerRequests = dealerRequests;
        }

        public String getTotalNetwork() {
            return totalNetwork;
        }

        public void setTotalNetwork(String totalNetwork) {
            this.totalNetwork = totalNetwork;
        }

        public String getTotalConnections() {
            return totalConnections;
        }

        public void setTotalConnections(String totalConnections) {
            this.totalConnections = totalConnections;
        }

        public String getTotalDealers() {
            return totalDealers;
        }

        public void setTotalDealers(String totalDealers) {
            this.totalDealers = totalDealers;
        }

        public String getCurrentNetwork() {
            return currentNetwork;
        }

        public void setCurrentNetwork(String currentNetwork) {
            this.currentNetwork = currentNetwork;
        }

        public String getCurrentConnections() {
            return currentConnections;
        }

        public void setCurrentConnections(String currentConnections) {
            this.currentConnections = currentConnections;
        }

        public String getCurrentDealers() {
            return currentDealers;
        }

        public void setCurrentDealers(String currentDealers) {
            this.currentDealers = currentDealers;
        }
    }
}


