package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.AppBarLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Adapters.CarousalCardsAdapter;
import com.mobileapp.krank.Adapters.UserProfileViewAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.CustomViews.FeedImageOverlayView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsForCompanyProfileViewDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.DataModel.PublicProfileData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.PersonalNewsFeedResponse;
import com.mobileapp.krank.ResponseModels.PublicProfileResponse;
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse;
import com.mobileapp.krank.Scroll.EndlessOnScrollListener;
import com.mobileapp.krank.Scroll.EndlessRecyclerViewScrollListener;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.NewsFeed.NewsFeedUtils;
import com.mobileapp.krank.Utils.ShareBottomSheet;
import com.stfalcon.frescoimageviewer.ImageViewer;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UserProfileView extends BaseActivity {


    //intent constant
    public static String INTENT_USER_ID = "userId";
    public static String INTENT_USER_NAME = "userName";

    //list items
    private RecyclerView mRecyclerView;
    private UserProfileViewAdapter mFeedAdapter;
    List<NewsFeedArray> mFeedList;


    //pagination
    EndlessRecyclerViewScrollListener scrollListener;


    //animation
    private static final int PERCENTAGE_TO_ANIMATE_IMAGE = 70;
    private boolean mIsImageShown = true;

    //images
    private SimpleDraweeView mProfileImage;
    private SimpleDraweeView company_img;

    private int mMaxScrollSize;
    SimpleDraweeView coverPic;
    View profilePicTakePicture;
    View cover_camera_btn;
    TextView user_name_text_view;
    String currentProfileId;
    String currentUserName;

    //user profile data
    PublicProfileData myProfileData;
    //flag
    private boolean isPersonalProfile;

    //picture type
    private String currentPictureType = null;

    //connections horizontal list
    List<ConnectionsForCompanyProfileViewDataModel> connectionsForCompanyProfileViewDataModels;


    boolean connectionEmptyArray;
    LinearLayoutManager layoutManager;


    String last_num;
    boolean isSwipeRefreshCall;
    boolean isScrollCall;

    //delay
    Runnable runnable;
    Handler handler;
    //activity code
    private static int EDIT_PROFILE_SETTING = 500;
    public static final int PRIVACY_ACTIVITY_CODE = 200;
    public static int COMMENT_ACTIVITY_CODE = 15;

    //item index
    public int clickIndex;


    AppBarLayout appbarLayout;

    //crop
    CustomImagePicker imagePicker;

    //news feed
    NewsFeedUtils newsFeedUtils;

    //share pop up
    private ShareBottomSheet shareBottomSheet;

    /*like comment Anim*/
    Animation myAnim;
    Animation commentShareAnim;
    /*like comment Anim*/

    //swipe refresh
    SwipeRefreshLayout swipe_refresh;


    //api
    Call<PersonalNewsFeedResponse> feedServiceCall;
    Call<PublicProfileResponse> userInfoServiceCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        initViews();


        if (currentUserName != null) {
            setNormalPageToolbar( currentUserName + "'s Profile");
        }else{
            setNormalPageToolbar(this);
        }


        //ImagePicker.setMinQuality(600, 600);

        checkForPersonalAndOtherProfile();

        addAppBarOffSetChangeListener();

        //getProfileData();
        setUpProfileViewAdapter();

        addOnSwipeRefreshListener();
    }


    /**
     * Profile View Loader
     * */
    private void addProfileLoader(){
        mFeedList.add(new NewsFeedArray(Constants.PROFILE_VIEW_LOADER));
    }


    /**
     *
     * Initializing Adapter
     * */
    private void setUpProfileViewAdapter() {
        mRecyclerView = findViewById(R.id.profile_view_recycler_view);
        mFeedList = new ArrayList<>();


        //loader
        addProfileLoader();
        //init adapter
        mFeedAdapter = new UserProfileViewAdapter(mFeedList, UserProfileView.this, getDeviceResolution());
        layoutManager = new LinearLayoutManager(UserProfileView.this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mFeedAdapter);
        setUpAdapterListeners();
        ((SimpleItemAnimator) mRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        // getNewsFeedData();
        setScrollListener();
        new Handler().postDelayed(() -> {
            getUserInfo();
        }, Constants.SECONDS_TO_LOAD);


    }


    /**
     *
     * Adapter Listeners
     * */
    private void setUpAdapterListeners() {
        mFeedAdapter.setListener((position, type, view) -> {
            switch (type) {
                case Constants.IN_APP_WEBVIEW:
                    gotoInAppWebView();
                    break;
                case Constants.EDIT_PROFILE_CALLBACK:
                    gotoProfileSettings();
                    break;
                case Constants.MARKET_PLACE_CALLBACK:
                    gotoMarketPlacePage();
                    break;
                case Constants.MY_LISTING_PAGE:
                    gotoMyListingPage();
                    break;
                case Constants.VIEW_EMPLOYEES_CALLBACK:
                    gotoViewEmployeesScreen();
                    break;
                case Constants.CONNECTION_BTN_CALLBACK:
                    onConnectionButtonClick(position);
                    break;
                case Constants.SHARE_CALLBACK:
                    newsFeedUtils.openDialog(mFeedList.get(position), mFeedList.get(position).getPostType() == Constants.LISTING_POST ? Constants.LISTING_SHARE : Constants.POST_SHARE, view, shareBottomSheet, commentShareAnim);
                    break;
                case Constants.LIKE_CALLBACK:
                    newsFeedUtils.sendLike(mFeedList.get(position), position, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),null);
                    break;
                case Constants.DELETE_CALLBACK:
                    newsFeedUtils.showDeletePopUpMenu(view, mFeedList.get(position), position, this, preference);
                    break;
                case Constants.COMMENT_CALLBACK:
                    view.startAnimation(commentShareAnim);
                    clickIndex = position;
                    Intent intent = new Intent(this, CommentsActivity.class);
                    intent.putExtra("CommentDataObj", mFeedList.get(position));
                    startActivityForResult(intent, COMMENT_ACTIVITY_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                    break;
                case Constants.POST_CALLBACK:
                    onPostClick(position);
                    break;
                case Constants.USER_STATUS_BUTTON:
                    onUserStatusPressed(position);
                    break;
                case Constants.GOTO_CHAT:
                    gotoChat();
                    break;
                case Constants.COMPANY_PROFILE:
                    gotoCompanyProfile("" + mFeedList.get(position).getCompany_id());
                    break;
                case Constants.MY_COMPANY_PROFILE:
                    gotoCompanyProfile("" + preference.getString(Constants.MY_COMPANY_ID));
                    break;
                case Constants.CONNECT_COMPANY_PROFILE:
                    gotoCompanyProfile("" + mFeedList.get(position).getAutoPostHtml().getConnect_company_id());
                    break;
                case Constants.USER_PROFILE:
                    gotoUserProfile("" + mFeedList.get(position).getUser_id());
                    break;
                case Constants.OWNER_USER_PROFILE:
                    gotoUserProfile("" + mFeedList.get(position).getOwner().getUser_id());
                    break;
                case Constants.POST_IMAGE_CALLBACK:
                    animateImage(mFeedList.get(position).getAsset(), mFeedList.get(position).getDescription(), mFeedList.get(position), position);
                    break;

            }
        });
    }
    private void animateImage(String imgPath, String description, NewsFeedArray item, final int position) {
        FeedImageOverlayView overlayView = new FeedImageOverlayView(this);
        String[] posters = new String[]{imgPath};
        new ImageViewer.Builder<>(this, posters)
                .setOverlayView(overlayView)
                .setImageChangeListener(getImageChangeListener(description, item, position, overlayView))
                .show();
    }

    private ImageViewer.OnImageChangeListener getImageChangeListener(final String description, NewsFeedArray item, final int adapterPos, FeedImageOverlayView overlayView) {
        return position -> {
            // CustomImage image = images.get(position);
            overlayView.setDescription(description);
            overlayView.setNo_of_like("" + item.getLike_count());
            overlayView.setNo_of_comments("" + item.getComment_count());

            overlayView.setLikeEffect(item.getIs_like(), this);

            item.setUpdateCommentCountForImageOverlay(() -> {
                overlayView.setNo_of_comments("" + item.getComment_count());
                overlayView.setNo_of_like("" + item.getLike_count());
                overlayView.setLikeEffect(item.getIs_like(), this);
            });


            /**
             *
             *
             * Feed Like
             *
             * */
            overlayView.getLike_container().setOnClickListener(view -> {
                newsFeedUtils.sendLike(item, adapterPos, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),(isLike) -> {
                    overlayView.setLikeEffect(isLike, this);
                    overlayView.setNo_of_like("" + item.getLike_count());
                });

            });

            /**
             * Comments
             * */
            overlayView.getComment_container().setOnClickListener(view -> {
                gotoCommentActivity(overlayView.getComment_container(), adapterPos);
            });
        };
    }

    /**
     * Comments Page
     */
    private void gotoCommentActivity(View view, int position) {
        view.startAnimation(commentShareAnim);
        clickIndex = position;
        Intent intent = new Intent(this, CommentsActivity.class);
        intent.putExtra("CommentDataObj", mFeedList.get(position));
        startActivityForResult(intent, COMMENT_ACTIVITY_CODE);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
    }

    private void gotoUserProfile(String userId) {
        Intent intent = new Intent(this, UserProfileView.class);
        intent.putExtra(UserProfileView.INTENT_USER_ID, userId);
        startActivity(intent);
    }

    private void gotoCompanyProfile(String companyId) {
        Intent intent = new Intent(this, CompanyProfileView.class);
        intent.putExtra(CompanyProfileView.INTENT_COMPANY_ID, companyId);
        startActivity(intent);
    }

    private void gotoChat(){
        Intent intent = new Intent(this, PrivateChatConversationActivity.class);

        intent.putExtra("recipient_name", myProfileData.getFirstName() + " " + myProfileData.getLastName());
        if(myProfileData.getConversation_id() == null){
            intent.putExtra("start_conversation", true);
            intent.putExtra("connection_id", myProfileData.getId());
            intent.putExtra("first_last_name", myProfileData.getFirstName() + myProfileData.getLastName());
            intent.putExtra("profile_pic", myProfileData.getProfilePic());
            intent.putExtra("job_title", myProfileData.getJobTitle());
            intent.putExtra("company_name", myProfileData.getCompanyName());
        }else{
            intent.putExtra("from_notification",true);
            intent.putExtra("conv_id", "" + myProfileData.getConversation_id());
        }

        startActivity(intent);
    }

    private void gotoInAppWebView() {
        if (myProfileData.getWebsiteUrl() == null || myProfileData.getWebsiteUrl().isEmpty())
            return;
        Intent intent = new Intent(this, InAppWebViewCollapseActivity.class);
        intent.putExtra("web_view_url", myProfileData.getWebsiteUrl());
        startActivity(intent);
    }

    private void onUserStatusPressed(int position) {
        switch (AppUtils.getConNetStatus(myProfileData.getConnection_info())) {
            case NOT_CONNECTED:
                sendConnectionRequest(position);
                break;
            case INVITATION_RECEIVED:
                acceptRequest(position);
                break;
            case CONNECTED:
                if(myProfileData.getId().equals(CarousalCardsAdapter.CONNECTION_NOT_TO_REMOVE)){
                    showToast("Can't remove this connection");
                    return;
                }
                showRemoveDialog(position);
                break;

        }
    }

    private void showRemoveDialog(final int position) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Are you sure you want to remove this connection?")
                .setDescription("You will also be removed from this user's connection list.")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    removeConnection(position);
                });

        dialog.show();


    }



    private void changeStatus(final int position, String status) {
        myProfileData.setConnection_info(status);
        mFeedAdapter.notifyItemChanged(position);
    }



    private void gotoMyListingPage() {
        Intent intent = new Intent(this, MyListingPage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void gotoProfileSettings() {
        Intent intent = new Intent(UserProfileView.this, PersonalProfileSettings.class);
        intent.putExtra("profile_data", gson.toJson(UserProfileView.this.myProfileData));
        startActivityForResult(intent, EDIT_PROFILE_SETTING);
        // overridePendingTransition(R.anim.activity_open_translate,R.anim.activity_close_scale);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void onPostClick(int position) {
        NewsFeedArray feed = mFeedList.get(position);
        if (feed.getPostType() == Constants.ARTICLE_POST) {
            Intent articleIntent = new Intent(this, ArticleDetail.class);
            articleIntent.putExtra("article_id", feed.getPost_track_id());
            startActivity(articleIntent);
        } else if (feed.getPostType() == Constants.AUCTION_POST) {
            Intent inAppWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
            inAppWebViewIntent.putExtra("feed_type", "auction");
            inAppWebViewIntent.putExtra("web_view_url", appUtils.getUrlWithUid(feed.getShareUrl(), preference));
            startActivity(inAppWebViewIntent);

        } else if (feed.getPostType() == Constants.LINKED_POST) {
            Intent linkWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
            linkWebViewIntent.putExtra("web_view_url", feed.getShareUrl());
            startActivity(linkWebViewIntent);

        } else if (feed.getPostType() == Constants.LISTING_POST) {
            Intent listingDetailIntent = new Intent(this, ListingDetail.class);
            listingDetailIntent.putExtra("listing_id", "" + feed.getPost_track_id());
            listingDetailIntent.putExtra("listing_pg_name", "" + feed.getHtmlParse().getTitle());
            startActivity(listingDetailIntent);
        }
    }

    private void onConnectionButtonClick(int position) {
    }

    private void gotoViewEmployeesScreen() {
        Intent intent = new Intent(this, ListOfEmployeesAndConnections.class);
        intent.putExtra(ListOfEmployeesAndConnections.USER_NAME, myProfileData.getFirstName() + " " + myProfileData.getLastName());
        intent.putExtra(ListOfEmployeesAndConnections.COMPANY_ID, myProfileData.getCompanyId());
        intent.putExtra(ListOfEmployeesAndConnections.FROM_USER_PROFILE,true);
        startActivity(intent);
    }

    private void gotoMarketPlacePage() {
        Intent intent = new Intent(this, MarketPlacePage.class);
        intent.putExtra("currentItem", 0);
        intent.putExtra("networkId", "0");
        intent.putExtra("connectionId", myProfileData.getId());
        intent.putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE);
        intent.putExtra(MarketPlacePage.TOOLBAR_NAME, myProfileData.getFirstName());
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void setScrollListener() {




        scrollListener =  new EndlessRecyclerViewScrollListener(layoutManager) {
            @Override
            public void onLoadMore(int totalItemsCount, RecyclerView view) {
                if (last_num != null && !isSwipeRefreshCall) {
                    onScroll();
                }else{
                    scrollListener.resetState();
                }
            }
        };

        mRecyclerView.addOnScrollListener(scrollListener);


       /* mRecyclerView.addOnScrollListener(new EndlessOnScrollListener(layoutManager) {
            @Override
            public void onScrolledToEnd() {
                if (last_num != null && !isSwipeRefreshCall && !isScrollCall) {
                    onScroll();
                }
            }
        });*/
    }

    private void onScroll() {
        isScrollCall = true;
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    private void addOnSwipeRefreshListener(){
        swipe_refresh.setOnRefreshListener(() -> {


            //reset scroll
            scrollListener.resetState();


            isSwipeRefreshCall = true;

            mFeedList.clear();

            addProfileLoader();

            mFeedAdapter.notifyDataSetChanged();

            /**
             * Abort the request
             * */
            if(feedServiceCall !=null){
                feedServiceCall.cancel();
            }

            if(userInfoServiceCall!=null){
                userInfoServiceCall.cancel();
            }

            /**
             * Reset Param
             * */
            last_num = null;

            /**
             * Api
             * */
            new Handler().postDelayed(() -> {
                getUserInfo();
            }, Constants.SECONDS_TO_LOAD);
        });
    }

    private void checkForPersonalAndOtherProfile() {
        if (!isPersonalProfile) {
            profilePicTakePicture.setVisibility(View.GONE);
            cover_camera_btn.setVisibility(View.GONE);
        } else {
            profilePicTakePicture.setVisibility(View.VISIBLE);
            cover_camera_btn.setVisibility(View.VISIBLE);
        }

    }

    private void addAppBarOffSetChangeListener() {
        mMaxScrollSize = appbarLayout.getTotalScrollRange();

        appbarLayout.addOnOffsetChangedListener((appBarLayout, i) -> {

            swipe_refresh.setEnabled(i == 0);

            if (mMaxScrollSize == 0)
                mMaxScrollSize = appBarLayout.getTotalScrollRange();

            int percentage = (Math.abs(i)) * 100 / mMaxScrollSize;

            if (percentage >= PERCENTAGE_TO_ANIMATE_IMAGE && mIsImageShown) {
                mIsImageShown = false;
                company_img.animate()
                        .scaleY(0).scaleX(0)
                        .setDuration(200)
                        .start();
                mProfileImage.animate()
                        .scaleY(0).scaleX(0)
                        .setDuration(200)
                        .start();
                profilePicTakePicture.animate()
                        .scaleY(0).scaleX(0)
                        .setDuration(200)
                        .start();
                cover_camera_btn.animate()
                        .scaleY(0).scaleX(0)
                        .setDuration(200)
                        .start();
            }

            if (percentage <= PERCENTAGE_TO_ANIMATE_IMAGE && !mIsImageShown) {
                mIsImageShown = true;

                company_img.animate()
                        .scaleY(1).scaleX(1)
                        .start();
                mProfileImage.animate()
                        .scaleY(1).scaleX(1)
                        .start();
                profilePicTakePicture.animate()
                        .scaleY(1).scaleX(1)
                        .start();
                cover_camera_btn.animate()
                        .scaleY(1).scaleX(1)
                        .start();
            }
        });
    }

    private void init() {

        //intent data
        currentProfileId = getIntent().getStringExtra(INTENT_USER_ID);
        currentUserName = getIntent().getStringExtra(INTENT_USER_NAME);

        isPersonalProfile = currentProfileId !=null && currentProfileId.equals(preference.getString(Constants.USER_ID));


        //myProfileData = new PublicProfileData();
        last_num = null;
        isScrollCall = true;
        isSwipeRefreshCall = false;
        connectionEmptyArray = false;

        handler = new Handler();
        runnable = () -> getNewsFeedData();
        connectionsForCompanyProfileViewDataModels = new ArrayList<>();
        imagePicker = new CustomImagePicker();

        setLikeCommentAnimation();

        shareBottomSheet = new ShareBottomSheet
                .Builder(UserProfileView.this, preference)
                .setListeners(getShareCallBack())
                .create();


        newsFeedUtils = NewsFeedUtils.getInstance();
    }

    private void initViews() {
        appbarLayout = findViewById(R.id.materialup_appbar);
        mProfileImage = findViewById(R.id.profile_img_to_hide);
        company_img = findViewById(R.id.company_img);
        coverPic = findViewById(R.id.cover_pic);
        profilePicTakePicture = findViewById(R.id.profile_pic_take_pic);
        cover_camera_btn = findViewById(R.id.cover_camera_btn);
        user_name_text_view = findViewById(R.id.user_name_text_view);
        swipe_refresh = findViewById(R.id.swipe_refresh);
    }


    private void setLikeCommentAnimation() {
        /*like comment button*/
        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        commentShareAnim = AnimationUtils.loadAnimation(this, R.anim.bounce_for_comment_click);
        /*like comment button*/
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (resultCode == RESULT_OK) {
            if (requestCode == EDIT_PROFILE_SETTING) {
                if (mFeedList.size() > 0) {
                    if (mFeedList.get(0).getPostType() == Constants.PERSONAL_PROFILE_VIEW) {
                        PublicProfileData tempData;
                        tempData = gson.fromJson(intent.getStringExtra("updated_data"), PublicProfileData.class);
                        if (tempData != null) {
                            myProfileData.setJobTitle(tempData.getJobTitle());
                            myProfileData.setDepartmentName(tempData.getDepartmentName());

                            myProfileData.setCountryName(tempData.getCountryName());
                            myProfileData.setCountry_dial_code(tempData.getCountry_dial_code());
                            myProfileData.setCountry_code(tempData.getCountry_code());


                            myProfileData.setCityName(tempData.getCityName());
                            myProfileData.setCity_id(tempData.getCity_id());

                            myProfileData.setMobileNumber(tempData.getMobileNumber());
                            mFeedAdapter.notifyItemChanged(0);
                        }
                    }
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);

                ApiUtils.uploadImage(resultUri, currentPictureType, preference, UserProfileView.this);

                setImage(currentPictureType, resultUri);
            } else if (requestCode == COMMENT_ACTIVITY_CODE) {
                mFeedList.get(clickIndex).setLike_count(intent.getIntExtra("likeCount", 0));
                mFeedList.get(clickIndex).setIs_like(intent.getIntExtra("isLike", 0));
                mFeedList.get(clickIndex).setComment_count(intent.getIntExtra("commentCount", 0));

                if (mFeedList.get(clickIndex).getUpdateCommentCountForImageOverlay() != null) {
                    mFeedList.get(clickIndex).getUpdateCommentCountForImageOverlay().act();
                }

                mFeedAdapter.notifyItemChanged(clickIndex);
            } else if (requestCode == PRIVACY_ACTIVITY_CODE) {
                shareBottomSheet.updateDialogOnActivityResult(intent);
            } else {
                // Bitmap bitmap = ImagePicker.getImageFromResult(this, requestCode, resultCode, intent);
                Bitmap bitmap = imagePicker.handleImagePick(requestCode, UserProfileView.this, intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(this, bitmap), Uri.fromFile(new File(getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, this, currentPictureType);
                    uCrop.start(UserProfileView.this);
                }
            }
        }

    }

    private void setImage(String type, Uri uri) {
        if (type.equals(Constants.USER_PROFILE_IMG)) {
            mProfileImage.setImageURI(uri);


        } else if (type.equals(Constants.USER_COVER_IMG)) {
            coverPic.setImageURI(uri);
        }
    }


    private CustomShareCallBack getShareCallBack() {

        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(UserProfileView.this, SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", appUtils.convertToJson(selectedPrivacy));
            intent.putExtra("selected_network_group", appUtils.convertToJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", appUtils.convertToJson(tempDealerGroup));
            startActivityForResult(intent, PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }



    private void onNewsFeedResponse(Response<PersonalNewsFeedResponse> response) {



        /**
         * Pagination
         * */
        scrollListener.resetState();


        //swipe refresh
        if(isSwipeRefreshCall){
            swipe_refresh.setEnabled(true);
            swipe_refresh.setRefreshing(false);
        }



        //remove loader
        for (int i = (mFeedList.size() - 1); i >= 0; i--) {
            if (mFeedList.get(i).getPostType() == Constants.LOADER) {
                mFeedList.remove(i);
                mFeedAdapter.notifyItemRemoved(i);
                break;
            }
        }

        isSwipeRefreshCall = false;
        last_num = response.body().getData().getLast_num();
        isScrollCall = false;

        //setting newsFeed
        final List<NewsFeedArray> tempItems = response.body().getData().getFeeds();
        for (int i = 0; i < tempItems.size(); i++) {
            newsFeedUtils.getNewsFeedType(tempItems.get(i));
            setCallBacks(tempItems.get(i));
        }

        //updating
        int oldSize = mFeedList.size();
        mFeedList.addAll(tempItems);

        if (connectionEmptyArray) {
            if (mFeedList.size() <= 3) {
                mFeedList.add(new NewsFeedArray(Constants.EMPTY_NEWS_FEED, "" + response.body().getMessage()));
            }
        } else {
            if (mFeedList.size() <= 2) {
                mFeedList.add(new NewsFeedArray(Constants.EMPTY_NEWS_FEED, "" + response.body().getMessage()));
            }
        }

        /**
         * Footer Loader
         * */
        if(last_num != null){
            mFeedList.add(new NewsFeedArray(Constants.LOADER));
        }


        mFeedAdapter.notifyItemRangeInserted(oldSize, mFeedList.size());
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    private void setCallBacks(NewsFeedArray feed) {
        // autPost k elawa Post pr hoga..
        if (feed.getPostType() == Constants.NETWORK_POST || feed.getPostType() == Constants.DEALER_POST || feed.getPostType() == Constants.KRANK_POST) {
            if (feed.getPostType() == Constants.KRANK_POST) {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, true, UserProfileView.this));
            } else {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, false, UserProfileView.this));
            }
        } else {
            feed.setHeaderSpannableString(newsFeedUtils.getSpannablePostHeader(feed, UserProfileView.this, preference));
        }

        if (feed.getPostType() == Constants.CHECK_IN) {
            feed.setCheckInAddress(newsFeedUtils.getSpannableCheckInAddress(feed.getTitle(), feed.getDescription(), feed.getTime_difference(), UserProfileView.this));
        }

    }





    private void onProfileDetailResponse(Response<PublicProfileResponse> response) {

        pictureTakeCallBacks();

        //get the user data..
        myProfileData = response.body().getData();


        //get the profile id
        if (currentProfileId == null) {
            currentProfileId = response.body().getData().getId();
        }

        ConNetStatus status = AppUtils.getConNetStatus(myProfileData.getNetwork_info());


        /**
         *
         * Don't show the profile if network not connected
         *
         * */
        if (status != ConNetStatus.CONNECTED && !myProfileData.isPrivate_connection_info()) {

            if (currentUserName == null) {
                setNormalPageToolbar( myProfileData.getFirstName() + " " + myProfileData.getLastName() + "'s Profile");
            }

            /*remove the loader*/
            mFeedList.remove(0);
            /*remove the loader*/


            mFeedList.add(new NewsFeedArray(Constants.NETWORK_NOT_CONNECTED_VIEW));

            mFeedAdapter.notifyDataSetChanged();

            mProfileImage.setVisibility(View.GONE);

            return;
        }


        if (currentUserName == null) {
            setNormalPageToolbar(myProfileData.getFirstName() + " " + myProfileData.getLastName() + "'s Profile");
        }
        // myProfileData.setConStatus(getIntent().getStringExtra("conStatus"));

        /*sets the picture*/
        mProfileImage.setImageURI(Uri.parse(myProfileData.getProfilePic()));
        coverPic.setImageURI(Uri.parse(myProfileData.getCoverPic()));
        company_img.setImageURI(Uri.parse(myProfileData.getCompanyProfilePic()));
        /*sets the picture*/


        /*remove the loader*/
        mFeedList.remove(0);
        /*remove the loader*/


        /*add the items*/
        if (isPersonalProfile) {
            mFeedList.add(new NewsFeedArray(Constants.PERSONAL_PROFILE_VIEW));
        } else {
            mFeedList.add(new NewsFeedArray(Constants.OTHER_PROFILE_VIEW));
        }
        mFeedList.add(new NewsFeedArray(Constants.INFO_POST));
        /*add the items*/


        /*add horizontal connection item*/
        if (myProfileData.getMyConnections().size() > 0) {
            connectionEmptyArray = true;
            mFeedList.add(new NewsFeedArray(Constants.OTHER_CONNECTION_EMPLOYS_VIEW));
        }
        /*add horizontal connection item*/

        /*update the data*/
        mFeedAdapter.setUpdatedData(myProfileData);

        mFeedList.add(new NewsFeedArray(Constants.LOADER));

        mFeedAdapter.notifyDataSetChanged();
        /*update the data*/


        //get the news Feed Data
        getNewsFeedData();
    }

    private void pictureTakeCallBacks() {

        if (isPersonalProfile) {
            mProfileImage.setOnClickListener(view -> {
                //ImagePicker.pickImage(UserProfileView.this, "Select your profile image:");
                imagePicker.pickImage(UserProfileView.this);
                currentPictureType = Constants.USER_PROFILE_IMG;
            });
            cover_camera_btn.setOnClickListener(view -> {
                //ImagePicker.pickImage(UserProfileView.this, "Select your cover image:");
                imagePicker.pickImage(UserProfileView.this);
                currentPictureType = Constants.USER_COVER_IMG;

            });
        }

        company_img.setOnClickListener(view -> {
            appUtils.gotoCompanyProfile(this, myProfileData.getCompanyId(), preference);
        });
    }

    @Override
    public void onBackPressed() {
        /*phoneNumber Update*/
        if (getIntent().getBooleanExtra("shouldUpdateBackScreen", false)) {
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
        }
        /*phoneNumber Update*/

        //from other screens
        else {
            if (myProfileData != null) {
                Intent intent = new Intent();
                intent.putExtra("connection_status", myProfileData.getConnection_info());
                intent.putExtra("item_index", getIntent().getIntExtra("item_index", 0));
                setResult(RESULT_OK, intent);
            }
        }
        finish();
        overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
    }


    /**
     * Api
     * */

    private void removeConnection(final int position) {

        changeStatus(position, Constants.NO_CONNECTION_TEXT);

        getAPI().removeConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), Integer.parseInt(myProfileData.getId())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals("success")) {
                        showToast(response.body().getMessage());
                        changeStatus(position, Constants.CONNECTED_TEXT);
                    }
                } else {
                    onResponseFailure();
                    changeStatus(position, Constants.CONNECTED_TEXT);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
                changeStatus(position, Constants.CONNECTED_TEXT);

            }
        });
    }

    private void acceptRequest(final int position) {
        changeStatus(position, Constants.CONNECTED_TEXT);

        getAPI().acceptConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), myProfileData.getCon_id()).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals("success")) {
                        showToast(response.body().getMessage());
                        changeStatus(position, Constants.INVITATION_RECEIVED);
                    }
                } else {
                    onResponseFailure();
                    changeStatus(position, Constants.INVITATION_RECEIVED);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
                changeStatus(position, Constants.INVITATION_RECEIVED);
            }
        });
    }

    private void sendConnectionRequest(final int position) {

        changeStatus(position, Constants.REQUEST_PENDING);
        getAPI().sentConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), Integer.parseInt(myProfileData.getId())).enqueue(new Callback<SentConnectionRequestResponse>() {
            @Override
            public void onResponse(Call<SentConnectionRequestResponse> call, Response<SentConnectionRequestResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals("success")) {
                        showToast(response.body().getMessage());
                        changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
                    }
                } else {
                    onResponseFailure();
                    changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
                }
            }

            @Override
            public void onFailure(Call<SentConnectionRequestResponse> call, Throwable t) {
                onResponseFailure();
                changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
            }
        });
    }


    private void getNewsFeedData() {

        /**
         * If My Profile get my feed data
         * */
        if(isPersonalProfile){
            feedServiceCall = getAPI().getMyNewsFeed(preference.getString(Constants.ACCESS_TOKEN), "" + last_num, Constants.PAGE_LIMIT_1,currentProfileId);
        }else{
            feedServiceCall = getAPI().getPersonalNewsFeed(preference.getString(Constants.ACCESS_TOKEN), "" + last_num, Constants.PAGE_LIMIT_1, currentProfileId);
        }

        feedServiceCall.enqueue(new Callback<PersonalNewsFeedResponse>() {
            @Override
            public void onResponse(Call<PersonalNewsFeedResponse> call, Response<PersonalNewsFeedResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        onNewsFeedResponse(response);
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<PersonalNewsFeedResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void getUserInfo() {

        String userSlug = getIntent().getStringExtra("user_slug");


        userInfoServiceCall = getAPI().getPublicProfileDetail(preference.getString(Constants.ACCESS_TOKEN), currentProfileId, userSlug == null ? "" : userSlug);

        userInfoServiceCall.enqueue(new Callback<PublicProfileResponse>() {

            @Override
            public void onResponse(Call<PublicProfileResponse> call, Response<PublicProfileResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        onProfileDetailResponse(response);
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<PublicProfileResponse> call, Throwable t) {
                onResponseFailure();
            }

        });
    }

}