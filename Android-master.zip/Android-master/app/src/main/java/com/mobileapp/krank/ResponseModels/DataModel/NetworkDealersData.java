package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.CallBacks.CustomCallBack;

/**
 * Created by arbaz on 6/12/2018.
 */

public class NetworkDealersData {
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("company_latlng")
    @Expose
    private String companyLatlng;
    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("business")
    @Expose
    private String business;
    @SerializedName("currency_id")
    @Expose
    private String currencyId;
    @SerializedName("currency_name")
    @Expose
    private String currencyName;
    @SerializedName("company_size_id")
    @Expose
    private String companySizeId;
    @SerializedName("company_size_name")
    @Expose
    private String companySizeName;
    @SerializedName("total_assign_groups")
    @Expose
    private String totalAssignGroups;
    @SerializedName("group_names")
    @Expose
    private String groupNames;
    @SerializedName("location")
    @Expose
    private String location;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("dealer_status")
    @Expose
    private String dealerStatus;
    @SerializedName("dealer_id")
    @Expose
    private String dealerId;

    private int viewType;

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getTotalAssignGroups() {
        return totalAssignGroups;
    }

    public void setTotalAssignGroups(String totalAssignGroups) {
        this.totalAssignGroups = totalAssignGroups;
    }

    public String getGroupNames() {
        return groupNames;
    }

    public void setGroupNames(String groupNames) {
        this.groupNames = groupNames;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyLatlng() {
        return companyLatlng;
    }

    public void setCompanyLatlng(String companyLatlng) {
        this.companyLatlng = companyLatlng;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getCompanySizeId() {
        return companySizeId;
    }

    public void setCompanySizeId(String companySizeId) {
        this.companySizeId = companySizeId;
    }

    public String getCompanySizeName() {
        return companySizeName;
    }

    public void setCompanySizeName(String companySizeName) {
        this.companySizeName = companySizeName;
    }

    public String getDealerStatus() {
        return dealerStatus;
    }

    public void setDealerStatus(String dealerStatus) {
        this.dealerStatus = dealerStatus;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public NetworkDealersData(int viewType) {
        this.viewType = viewType;
    }
}
