package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.AssignRepresentativeForMyListing;
import com.mobileapp.krank.CallBacks.AddRemoveListener;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AssignRepresentativeChipAdapter extends RecyclerView.Adapter<AssignRepresentativeChipAdapter.ViewHolder>  {
    private List<GetNetworkEmployeeData> items;
    Context context;
    private AddRemoveListener addRemoveListener;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View cross_btn;
        TextView people_name;
        SimpleDraweeView profile_img;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            cross_btn=itemView.findViewById(R.id.cross_btn);
            people_name=itemView.findViewById(R.id.people_name);
            profile_img=itemView.findViewById(R.id.profile_img);
            cross_btn.setOnClickListener(view -> {
                addRemoveListener.remove(items.get(getAdapterPosition()),AssignRepresentativeForMyListing.SELECTED_LIST_ITEM);
                removeAt(getAdapterPosition());
            });
        }
    }


    public AssignRepresentativeChipAdapter(List<GetNetworkEmployeeData> items, Context context,AddRemoveListener addRemoveListener) {
        this.items = items;
        this.context = context;
        this.addRemoveListener = addRemoveListener;
    }
    @Override
    public AssignRepresentativeChipAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.people_view_with_circle, parent, false);
        return new AssignRepresentativeChipAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final AssignRepresentativeChipAdapter.ViewHolder holder, final int position) {
        final GetNetworkEmployeeData item = items.get(position);

        holder.people_name.setText("" + item.getFirstName() + " " + item.getLastName());

      //  Glide.with(context).load(item.getProfilePic()).into(holder.profile_img);
        holder.profile_img.setImageURI("" + item.getProfilePic());
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,items.size());

    }



    @Override
    public int getItemCount() {
        return items.size();
    }


}

