package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.SignupOneResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUp extends BaseActivity implements View.OnClickListener {
    Button signUpBtn;
    EditText signupEditText;
    TextView error;
    TextView info_text;


    //invite link code
    CompanyInvitationDataModel companyInvitationDataModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setKrankLogoForUserProfiling();

        signUpBtn = findViewById(R.id.signup_btn);
        signupEditText = findViewById(R.id.sigunp_edit_text);
        error = findViewById(R.id.error_view);
        info_text = findViewById(R.id.info_text);


        setScreenHeader("Sign Up");

        setImageIntermsOfDeviceResolution();
        gotoLinkPage();

        signUpBtn.setOnClickListener(this);

        showAlert = showAlert("Checking please wait...", SweetAlertDialog.PROGRESS_TYPE, false);

        /**
         * Invitation label
         * */
        if (!isInviteLinkDataExists()) {
            info_text.setVisibility(View.GONE);
        } else {
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private void firstSignupStep(final String email) {
        showAlert.show();
        getAPI().signupStepOne(email,getInviteUserId()).enqueue(new Callback<SignupOneResponse>() {
            @Override
            public void onResponse(Call<SignupOneResponse> call, Response<SignupOneResponse> response) {

                try{
                    if(response.isSuccessful()){
                        if (response.body().getStatus().equals("success")) {
                            error.setText("");
                            onSignStepOneSuccess(SignUp.this,response,email);
                        } else {
                            error.setText(response.body().getMessage());
                            showAlert.dismiss();
                            // handle request errors depending on status code
                        }
                    }else{
                        showAlert.dismiss();
                        onResponseFailure();
                    }
                }catch (Exception ex){
                    onResponseFailure();
                }

            }
            @Override
            public void onFailure(Call<SignupOneResponse> call, Throwable t) {
                onResponseFailure();
                showAlert.dismiss();

            }
        });

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signup_btn:
                String email = signupEditText.getText().toString().trim();
                if (email.isEmpty()) {
                    error.setText(Constants.ENTER_EMAIL_TEXT);
                } else if (!(AppUtils.validateEmail(email))) {
                    error.setText(Constants.ENTER_VALID_EMAIL_TEXT);
                } else {
                    error.setText("");
                    firstSignupStep(email);
                }
                break;
            default:
                Log.e(getLocalClassName(), "no action!");
        }
    }
}
