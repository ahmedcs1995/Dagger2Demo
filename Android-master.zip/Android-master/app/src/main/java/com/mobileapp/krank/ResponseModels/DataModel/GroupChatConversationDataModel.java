package com.mobileapp.krank.ResponseModels.DataModel;


import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupChatConversationDataModel {
    @SerializedName("groups")
    @Expose
    private List<GroupChatConversationGroupModel> groups = null;
    @SerializedName("convoMsgs")
    @Expose
    private List<GroupChatConvoMsgs> convoMsgs = null;
    @SerializedName("userDetail")
    @Expose
    private GroupChatConversationUserDetailModel userDetail;
    @SerializedName("mygroups")
    @Expose
    private List<GroupChatMyGroupsModel> mygroups = null;

    @SerializedName("group_id")
    @Expose
    private String group_id;

    @SerializedName("memberData")
    @Expose
    private GroupChatMemberDataModel memberData;

    public List<GroupChatConversationGroupModel> getGroups() {
        return groups;
    }

    public void setGroups(List<GroupChatConversationGroupModel> groups) {
        this.groups = groups;
    }

    public List<GroupChatConvoMsgs> getConvoMsgs() {
        return convoMsgs;
    }

    public void setConvoMsgs(List<GroupChatConvoMsgs> convoMsgs) {
        this.convoMsgs = convoMsgs;
    }

    public GroupChatConversationUserDetailModel getUserDetail() {
        return userDetail;
    }

    public void setUserDetail(GroupChatConversationUserDetailModel userDetail) {
        this.userDetail = userDetail;
    }

    public List<GroupChatMyGroupsModel> getMygroups() {
        return mygroups;
    }

    public void setMygroups(List<GroupChatMyGroupsModel> mygroups) {
        this.mygroups = mygroups;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public GroupChatMemberDataModel getMemberData() {
        return memberData;
    }

    public void setMemberData(GroupChatMemberDataModel memberData) {
        this.memberData = memberData;
    }
}
