package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.mobileapp.krank.Adapters.NotificationsAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChatConversationActivity;
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Model.Enums.TypeOfNotification;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NotificationListArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.NotificationListResponse;
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse;
import com.mobileapp.krank.Scroll.EndlessOnScrollListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationsScreen extends BaseActivity implements CallBackWithPosTypeAndView {

    //for list items
    private RecyclerView mRecyclerView;
    private NotificationsAdapter mAdapter;
    List<NotificationListArray> mListItems;

    //for pagination
    int offset;

    //delay for request
    Handler mHandler;
    Runnable mRunnable;

    //flag for scroll
    boolean firstTimeInit;
    boolean isItemsAdded;


    SwipeRefreshLayout mSwipeRefreshLayout;

    // flag for pull to refresh
    boolean isSwipeRefreshCall;

    TextView no_notification_text;
    private int lastSize;

    //shimmer loader
    ShimmerFrameLayout shimmerFrameLayout;

    ArrayList<String> deleteIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications_screen);

        //views
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);
        no_notification_text = findViewById(R.id.no_notification_text);
        shimmerFrameLayout = findViewById(R.id.shimmer_layout);

        initValues();

        //delay for request
        mHandler = new Handler();
        mRunnable = new Runnable() {
            @Override
            public void run() {
                getNotificationList();
            }
        };


        startShimmer();


        setUpNotificationsAdapter();
        setNormalPageToolbar("Notifications");


    }

    private void startShimmer() {
        shimmerFrameLayout.startShimmer();
    }

    private void stopShimmer() {
        shimmerFrameLayout.stopShimmer();
        shimmerFrameLayout.setVisibility(View.GONE);
    }

    private void setUpNotificationsAdapter() {
        mRecyclerView = (RecyclerView) findViewById(R.id.notifications_recycler);
        mListItems = new ArrayList<>();

        // mListItems.add(new NotificationListArray(TypeOfNotification.LOADER));

        mAdapter = new NotificationsAdapter(mListItems, this, this::act);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mHandler.postDelayed(mRunnable, Constants.SECONDS_TO_LOAD);

        addOnScrollListener(layoutManager);

        addOnSwipeToRefreshListener();
    }

    private void addOnScrollListener(LinearLayoutManager layoutManager) {
        mRecyclerView.addOnScrollListener(new EndlessOnScrollListener(layoutManager) {
            @Override
            public void onScrolledToEnd() {
                if (!firstTimeInit && !isSwipeRefreshCall && isItemsAdded) {
                    isItemsAdded = false;
                    offset += Constants.PAGE_LIMIT;
                    mHandler.postDelayed(mRunnable, Constants.SECONDS_TO_LOAD);
                }
            }
        });
    }

    private void addOnSwipeToRefreshListener() {
        mSwipeRefreshLayout.setOnRefreshListener(() -> {
            isSwipeRefreshCall = true;
            mListItems.clear();
            offset = 0;
            mRecyclerView.getRecycledViewPool().clear();
            mAdapter.notifyDataSetChanged();
            mSwipeRefreshLayout.setRefreshing(true);
            mHandler.postDelayed(mRunnable, Constants.SECONDS_TO_LOAD);
        });
    }

    private void getNotificationList() {
        getAPI().getNotificationList(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(offset), Constants.PAGE_LIMIT).enqueue(new Callback<NotificationListResponse>() {
            @Override
            public void onResponse(Call<NotificationListResponse> call, Response<NotificationListResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        onSuccess(response);
                    } else {
                        showToast(response.body().getMessage());
                        removeShimmerLoader();
                    }
                } else {
                    removeShimmerLoader();
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<NotificationListResponse> call, Throwable t) {
                /*remove the loader*/
                removeShimmerLoader();
                /*remove the loader*/

                onResponseFailure();

            }
        });
    }

    private void onSuccess(Response<NotificationListResponse> response) {
        removeLoader();

        if (response.isSuccessful()) {
            List<NotificationListArray> tempData = response.body().getData().getNotifications();
            for (NotificationListArray item : tempData) {
                setTypeNotification(item);
            }

            mSwipeRefreshLayout.setRefreshing(false);


            /*for scroll and pagination*/
            if (tempData.size() <= 0) {
                isItemsAdded = false;
            } else if (tempData.size() < Constants.PAGE_LIMIT) {
                isItemsAdded = false;
                lastSize = mListItems.size();
                mListItems.addAll(tempData);
                mAdapter.notifyItemRangeInserted(lastSize, mListItems.size());
            } else {
                isItemsAdded = true;
                tempData.add(new NotificationListArray(TypeOfNotification.LOADER));
                lastSize = mListItems.size();
                mListItems.addAll(tempData);
                mAdapter.notifyItemRangeInserted(lastSize, mListItems.size());
            }
            /*for scroll and pagination*/


            //first time init
            if (firstTimeInit) {
                stopShimmer();
                if (mListItems.size() <= 0) {
                    no_notification_text.setVisibility(View.VISIBLE);
                } else {
                    no_notification_text.setVisibility(View.GONE);

                }
            }

            firstTimeInit = false;
            isSwipeRefreshCall = false;
        }
    }

    private void removeShimmerLoader() {
        if (firstTimeInit) {
            stopShimmer();
        } else {
            removeLoader();
        }
    }

    private void removeLoader() {
        for (int i = (mListItems.size() - 1); i >= 0; i--) {
            if (mListItems.get(i).getTypeOfNotification() == TypeOfNotification.LOADER) {
                mListItems.remove(i);
                mAdapter.notifyItemRemoved(i);
            }
        }
    }


    private void setTypeNotification(NotificationListArray item) {

        item.setNotifyType(item.getNotifyType() == null ? "" : item.getNotifyType().toLowerCase());

        if (item.getNotifyType().equals("post_like")) {
            Log.e("into", "POST_LIKE");
            item.setTypeOfNotification(TypeOfNotification.POST_LIKE);
        } else if (item.getNotifyType().equals("comments_child")) {
            Log.e("into", "COMMENT_CHILD");
            item.setTypeOfNotification(TypeOfNotification.COMMENT_CHILD);
        } else if (item.getNotifyType().equals("comment_like")) {
            Log.e("into", "COMMENT_LIKE");
            item.setTypeOfNotification(TypeOfNotification.COMMENT_LIKE);
        } else if (item.getNotifyType().equals("comment_reply_like")) {
            Log.e("into", "COMMENT_REPLY_LIKE");
            item.setTypeOfNotification(TypeOfNotification.COMMENT_REPLY_LIKE);
        } else if (item.getNotifyType().equals("network_request") && item.getActivity().equals("request")) {
            Log.e("into", "NETWORK_REQUEST_WITH_BTNS");
            item.setTypeOfNotification(TypeOfNotification.NETWORK_REQUEST_WITH_BTNS);
        } else if (item.getNotifyType().equals("connection_request") && item.getActivity().equals("request")) {
            Log.e("into", "CONNECTION_REQUEST_WITH_BTNS");
            item.setTypeOfNotification(TypeOfNotification.CONNECTION_REQUEST_WITH_BTNS);
        } else if (item.getNotifyType().equals("dealer") && item.getActivity().equals("request")) {
            Log.e("into", "DEALER_REQUEST_WITH_BTNS");
            item.setTypeOfNotification(TypeOfNotification.DEALER_REQUEST_WITH_BTNS);
        } else if (item.getNotifyType().equals("network_request") && !(item.getActivity().equals("request"))) {
            Log.e("into", "NETWORK_REQUEST");
            item.setTypeOfNotification(TypeOfNotification.NETWORK_REQUEST);
        } else if (item.getNotifyType().equals("connection_request") && !(item.getActivity().equals("request"))) {
            Log.e("into", "CONNECTION_REQUEST");
            item.setTypeOfNotification(TypeOfNotification.CONNECTION_REQUEST);
        } else if (item.getNotifyType().equals("dealer")) {
            Log.e("into", "dealer");
            item.setTypeOfNotification(TypeOfNotification.DEALER_REQUEST);
        } else if (item.getNotifyType().equals("listing")) {
            Log.e("into", "listing");
            item.setTypeOfNotification(TypeOfNotification.LISTING);
        } else if (item.getNotifyType().equals("tag")) {
            Log.e("into", "tag");
            item.setTypeOfNotification(TypeOfNotification.TAG);
        } else if (item.getNotifyType().equals("comments")) {
            Log.e("into", "comments");
            item.setTypeOfNotification(TypeOfNotification.COMMENTS);
        } else if (item.getNotifyType().equals("group_msg")) {
            Log.e("into", "GROUP_CHAT");
            item.setTypeOfNotification(TypeOfNotification.GROUP_CHAT);
        } else if (item.getNotifyType().equals("article")) {
            Log.e("into", "article");
            item.setTypeOfNotification(TypeOfNotification.ARTICLE);
        } else if (item.getNotifyType().equals("join")) {
            item.setTypeOfNotification(TypeOfNotification.DISCOVER);
        } else {
            Log.e("into", "else");
            item.setTypeOfNotification(TypeOfNotification.OTHER);
        }
    }

    private void initValues() {
        offset = 0;
        firstTimeInit = true;
        isSwipeRefreshCall = false;
        isItemsAdded = true;
    }


    private void redirectToNextPage(final NotificationListArray item) {

        Intent intent;
        switch (item.getTypeOfNotification()) {
            case CONNECTION_REQUEST:
                gotoUserProfile(item);
                break;
            case NETWORK_REQUEST:
                intent = new Intent(getApplicationContext(), CompanyProfileView.class);
                intent.putExtra("companyId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case DEALER_REQUEST:
                intent = new Intent(getApplicationContext(), CompanyProfileView.class);
                if (item.getCId().equals(preference.getString(Constants.MY_COMPANY_ID))) {
                    intent.putExtra("IsPersonalCompanyProfile", true);
                }
                intent.putExtra("companyId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case CONNECTION_REQUEST_WITH_BTNS:
                if (item.getListing_id() != null) {
                    intent = new Intent(getApplicationContext(), ListingDetail.class);
                    intent.putExtra("listing_id", item.getListing_id());
                } else {
                    intent = new Intent(getApplicationContext(), UserProfileView.class);
                    if (String.valueOf(item.getSenderId()).equals(preference.getString(Constants.USER_ID))) {
                        intent.putExtra("IsPersonalProfile", true);
                    }
                    intent.putExtra("userId", "" + item.getSenderId());
                    intent.putExtra("userName", item.getName());
                }
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case NETWORK_REQUEST_WITH_BTNS:
                intent = new Intent(getApplicationContext(), CompanyProfileView.class);
                intent.putExtra("companyId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case DEALER_REQUEST_WITH_BTNS:
                intent = new Intent(getApplicationContext(), CompanyProfileView.class);
                if (item.getCId().equals(preference.getString(Constants.MY_COMPANY_ID))) {
                    intent.putExtra("IsPersonalCompanyProfile", true);
                }
                intent.putExtra("companyId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case POST_LIKE:
                intent = new Intent(getApplicationContext(), CommentsActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case TAG:
                intent = new Intent(getApplicationContext(), CommentsActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case COMMENTS:
                intent = new Intent(getApplicationContext(), CommentsActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                intent.putExtra("commentId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case COMMENT_LIKE:
                intent = new Intent(getApplicationContext(), CommentsActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                intent.putExtra("commentId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case GROUP_CHAT:
                intent = new Intent(getApplicationContext(), GroupChatConversationActivity.class);
                intent.putExtra("member_id", "" + item.getMember_id());
                intent.putExtra("from_notification", true);
                MyFirebaseMessagingService.CURRENT_MEMBER_ID = item.getMember_id();
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case LISTING:
                intent = new Intent(getApplicationContext(), ListingDetail.class);
                intent.putExtra("listing_id", item.getListing_id());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case COMMENT_REPLY_LIKE:
                intent = new Intent(getApplicationContext(), CommentsReplyActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                intent.putExtra("commentId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case COMMENT_CHILD:
                intent = new Intent(getApplicationContext(), CommentsReplyActivity.class);
                intent.putExtra("from_notification", true);
                intent.putExtra("postId", item.getTrackId());
                intent.putExtra("commentId", item.getCId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case ARTICLE:
                intent = new Intent(getApplicationContext(), ArticleDetail.class);
                intent.putExtra("article_id", item.getTrackId() == null ? 0 : Integer.parseInt(item.getTrackId()));
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
            case DISCOVER:
                if(!item.isDiscover_flag()){
                    gotoUserProfile(item);
                    return;
                }
                intent = new Intent(getApplicationContext(), DiscoverPeople.class);
                intent.putExtra(DiscoverPeople.CURRENT_ITEM_KEY, 1);
                intent.putExtra(DiscoverPeople.FROM_NOTIFICATION, true);
                intent.putExtra(DiscoverPeople.NEW_USER_ID_KEY, item.getTrackId());
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                break;
        }
    }

    private void gotoUserProfile(NotificationListArray item){
        Intent intent = new Intent(getApplicationContext(), UserProfileView.class);
        if (String.valueOf(item.getSenderId()).equals(preference.getString(Constants.USER_ID))) {
            intent.putExtra("IsPersonalProfile", true);
        }
        intent.putExtra("userId", "" + item.getSenderId());
        intent.putExtra("userName", item.getName());
        startActivity(intent);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
    }
    @Override
    public void act(int position, int type, @NotNull View view) {
        switch (type) {
            case NotificationsAdapter.REDIRECT_CALLBACK:
                redirectToNextPage(mListItems.get(position));
                setRead(mListItems.get(position).getId(), position, mListItems.get(position));
                break;
            case NotificationsAdapter.DELETE_CALLBACK:
                deleteNotification(mListItems.get(position).getId(), position, mListItems.get(position), view);
                break;
            case NotificationsAdapter.ACCEPT_BUTTON_CALLBACK:
                onAcceptButtonPressed(position);
                break;
            case NotificationsAdapter.REJECT_BUTTON_CALLBACK:
                onRejectButtonPressed(position);
                break;
            case NotificationsAdapter.REMOVE_DEALER_CALLBACK:
                showRemoveDialog(position);
                break;
            case NotificationsAdapter.SEND_REQUEST_CALLBACK:
                sendConnectionRequest(position);
                break;
            case NotificationsAdapter.DO_NETWORK_REQUEST_CALLBACK:
                doNetworkRequest(position);
                break;
        }
    }

    private void doNetworkRequest(final int position) {

        updateStatus(position, Constants.REQUEST_PENDING);


        getAPI().doNetworkRequest(preference.getString(Constants.ACCESS_TOKEN),mListItems.get(position).getTrackId()).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        updateStatus(position, Constants.NO_CONNECTION_TEXT);
                    }
                } else {
                    updateStatus(position, Constants.NO_CONNECTION_TEXT);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                updateStatus(position, Constants.NO_CONNECTION_TEXT);
            }
        });
    }

    private void sendConnectionRequest(final int position) {

        updateStatus(position, Constants.REQUEST_PENDING);


        getAPI().sentConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), Integer.parseInt(mListItems.get(position).getTrackId())).enqueue(new Callback<SentConnectionRequestResponse>() {
            @Override
            public void onResponse(Call<SentConnectionRequestResponse> call, Response<SentConnectionRequestResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        updateStatus(position, Constants.NO_CONNECTION_TEXT);
                    }
                } else {
                    updateStatus(position, Constants.NO_CONNECTION_TEXT);
                }
            }

            @Override
            public void onFailure(Call<SentConnectionRequestResponse> call, Throwable t) {
                updateStatus(position, Constants.NO_CONNECTION_TEXT);
            }
        });
    }

    private void updateStatus(final int position, String status) {
        mListItems.get(position).setConStatus(status);
        mAdapter.notifyItemChanged(position);
    }

    private void showRemoveDialog(int position) {

        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Remove Dealer")
                .setDescription("Are you sure you want to remove dealer?")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    try {
                        removeDealerApi(Integer.parseInt(mListItems.get(position).getTrackId()));
                        dialog1.dismiss();
                        mAdapter.removeAt(position);
                    } catch (Exception ex) {

                    }

                });
        dialog.show();

    }

    private void removeDealerApi(int dealerId) {

        getAPI().removeDealer(preference.getString(Constants.ACCESS_TOKEN), dealerId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        showToast("Successfully removed dealer");
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void onAcceptButtonPressed(int position) {


        if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.CONNECTION_REQUEST_WITH_BTNS) {
            acceptConnectionRequest(mListItems.get(position).getTrackId(), position);
        } else if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.NETWORK_REQUEST_WITH_BTNS) {
            acceptNetworkRequest(mListItems.get(position).getTrackId(), position);
        } else if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.DEALER_REQUEST_WITH_BTNS) {
            acceptRejectDealerRequest(mListItems.get(position).getTrackId(), position, "accept");
        }

        mAdapter.removeAt(position);
    }

    private void onRejectButtonPressed(int position) {
        if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.CONNECTION_REQUEST_WITH_BTNS) {
            rejectConnectionRequest(mListItems.get(position).getTrackId(), position);
        } else if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.NETWORK_REQUEST_WITH_BTNS) {
            rejectNetworkRequest(mListItems.get(position).getTrackId(), position);
        } else if (mListItems.get(position).getTypeOfNotification() == TypeOfNotification.DEALER_REQUEST_WITH_BTNS) {
            acceptRejectDealerRequest(mListItems.get(position).getTrackId(), position, "reject");

        }
        mAdapter.removeAt(position);
    }

    private void setRead(String nId, final int position, final NotificationListArray item) {
        getAPI().setNotificationRead(preference.getString(Constants.ACCESS_TOKEN), nId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        item.setIsRead("1");
                        mAdapter.notifyItemChanged(position);
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void deleteNotification(String nId, final int position, final NotificationListArray item, View deleteBtn) {

        //  deleteBtn.setEnabled(false);

        deleteIds.clear();
        deleteIds.add(nId);
        getAPI().deleteNotification(preference.getString(Constants.ACCESS_TOKEN), deleteIds).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                //    deleteBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {

                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                deleteBtn.setEnabled(true);
                onResponseFailure();
            }
        });
    }

    private void acceptConnectionRequest(String connectionId, final int position) {
        getAPI().acceptConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if(response.body().getStatus().equals(Constants.SUCCESS_STATUS))
                   // mAdapter.removeAt(position);
                    showToast("" + response.body().getMessage());
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void rejectConnectionRequest(String connectionId, final int position) {
        getAPI().rejectConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {

                    showToast("" + response.body().getMessage());
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void acceptNetworkRequest(String connectionId, final int position) {
        getAPI().acceptNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {

                    showToast("" + response.body().getMessage());
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void rejectNetworkRequest(String connectionId, final int position) {
        getAPI().rejectNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    showToast("" + response.body().getMessage());
                } else {
                    onResponseFailure();
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void acceptRejectDealerRequest(String connectionId, final int position, String requestType) {
        getAPI().acceptRejectDealerRequest(preference.getString(Constants.ACCESS_TOKEN), connectionId, requestType).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                   // mAdapter.removeAt(position);
                    showToast("" + response.body().getMessage());

                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }
}
