package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;

import java.util.List;
@Dao
public interface PersonalChatListDao {

    // LiveData is a data holder class that can be observed within a given lifecycle.
    // Always holds/caches latest version of data. Notifies its active observers when the
    // data has changed. Since we are getting all the contents of the database,
    // we are notified whenever any of the database contents have changed.
    @Query("Select * from personal_chat_conversation_list_table order by msgTime desc")
    LiveData<List<ChatConversationListDataModel>> getAllChatList();

    @Query("select count(*) from personal_chat_conversation_list_table")
    int getCount();

    // We do not need a conflict strategy, because the word is our primary key, and you cannot
    // add two items with the same primary key to the database. If the table has more than one
    // column, you can use @Insert(onConflict = OnConflictStrategy.REPLACE) to update a row.
    @Insert
    void insert(ChatConversationListDataModel data);

    @Query("DELETE FROM personal_chat_conversation_list_table")
    void deleteAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<ChatConversationListDataModel> list);

    @Update
    void bulkUpdate(List<ChatConversationListDataModel> list);


    @Query("UPDATE personal_chat_conversation_list_table SET id=:newId,from_local_db=:from_local_db  WHERE id=:oldId;")
    void updateConvId(int newId,int oldId,String from_local_db);

    @Query("select id from personal_chat_conversation_list_table where user_one=:user_one and user_two=:user_two")
    int getIdAgaintUserOneAndUserTwo(String user_one,String user_two);

    @Query("select id from personal_chat_conversation_list_table where id=:conId")
    int getIdOfParentTable(String conId);
}

