package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.SignupTwoResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpPage3 extends BaseActivity {
    Button verifyBtn;
    private TextView termsAndCondition;
    private ImageView sideImg;
    private EditText firstNameEditText, lastNameEditText, emailEditText;
    private TextView error;
    private SweetAlertDialog showAlert;
    CompanyInvitationDataModel companyInvitationDataModel;

    TextView info_text;

    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page3);

        error = findViewById(R.id.error_view);
        info_text = findViewById(R.id.info_text);

        verifyBtn = (Button) findViewById(R.id.verify_btn);
        termsAndCondition = (TextView) findViewById(R.id.termsconditions_text);
        sideImg = findViewById(R.id.side_img);

        firstNameEditText = findViewById(R.id.first_name_edit_text);
        lastNameEditText = findViewById(R.id.last_name_edit_text);
        emailEditText = findViewById(R.id.email_edit_text);

        userEmail = getIntent().getStringExtra("user_email");

        emailEditText.setText(userEmail);

        showAlert = showAlert("Checking please wait...", SweetAlertDialog.PROGRESS_TYPE, false);


        if(!(isInviteLinkDataExists())){
            info_text.setVisibility(View.GONE);
        }
        else{
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }


        emailEditText.setEnabled(false);
//        if (!preference.getString(Constants.COMPANY_NAME).isEmpty()) {
//        }
        setScreenHeader("Sign Up");

        setKrankLogoForUserProfiling();


        DeviceInfo deviceInfo = getDeviceResolution();
        sideImg.getLayoutParams().height = (int) (deviceInfo.getDeviceHeight() / 6.5);
        sideImg.requestLayout();




        setTextOnTermsAndConditions();


        verifyBtn.setOnClickListener(view -> {
            secondSignupStep();
        });

        lastNameEditText.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == event.KEYCODE_ENTER)
                hideKeyBoard();
            return false;
        });

    }

    private void setTextOnTermsAndConditions(){

        String text_1 ="By clicking on VERIFY EMAIL below you are agreeing to Krank’s ";
        String text_2 ="Terms of Use, ";
        String text_3 ="Privacy Policy, ";
        String text_4 ="Cookie Policy. ";
        String text_5 ="Please take time to review each of them before agreeing";

        SpannableStringBuilder ssb = new SpannableStringBuilder();
        ssb.append(text_1);
        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_2,()->{
            openWebViewPages(getApplicationContext(),Constants.TERMS_CONDITION);
        }, this);

        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_3,()->{
            openWebViewPages(getApplicationContext(),Constants.PRIVACY);
        }, this);
        ssb.append("and ");
        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_4, () -> {
            openWebViewPages(getApplicationContext(),Constants.COOKIES_POLICY);
        }, this);
        ssb.append(text_5);

        termsAndCondition.setMovementMethod(LinkMovementMethod.getInstance());   // make our spans selectable
        termsAndCondition.setText(ssb);
    }

    private void secondSignupStep() {
        error.setText("");
        String firstName = firstNameEditText.getText().toString().trim();
        String lastName = lastNameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        if(firstName.isEmpty()){
            error.setText(Constants.ENTER_FIRST_NAME);
        }
        else if(lastName.isEmpty()){
            error.setText(Constants.ENTER_LAST_NAME);
        }
        else if(email.isEmpty()){
            error.setText(Constants.ENTER_EMAIL_TEXT);
        }
        else if(!(AppUtils.validateEmail(email))){
            error.setText(Constants.ENTER_VALID_EMAIL_TEXT);
        }
        else{
            sendRequestToServer(email,firstName,lastName);
        }
    }




    private void sendRequestToServer(String email,String firstName,String lastName){
        showAlert.show();
        getAPI().signupStepTwo(email, firstName, lastName,getInviteUserId(),Constants.ANDROID_DEVICE).enqueue(new Callback<SignupTwoResponse>() {
            @Override
            public void onResponse(Call<SignupTwoResponse> call, Response<SignupTwoResponse> response) {
                SignupTwoResponse signupTwoResponse = response.body();

                if(response.isSuccessful()){
                    if (signupTwoResponse.getStatus().equals("success")) {
                        showAlert.dismiss();

                        //for redirect to forget pass
                        preference.setBoolean(Constants.GOTO_VERIFICATION_SCREEN,true);
                        //save email in local
                        preference.setString(Constants.USER_EMAIL, email);

                        Intent intent = new Intent(SignUpPage3.this, SignUpPage4.class);
                        startActivity(intent);
                        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                    } else {
                        showAlert.dismiss();
                        error.setText(signupTwoResponse.getMessage());
                    }
                }else{
                    showAlert.dismiss();
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<SignupTwoResponse> call, Throwable t) {
                showAlert.dismiss();
                onResponseFailure();
            }
        });
    }
}
