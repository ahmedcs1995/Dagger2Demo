package com.mobileapp.krank.Functions;

import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;

import java.util.Comparator;

public class SortConversationDetail implements Comparator<ConversationDetail>
{


    @Override
    public int compare(ConversationDetail conversationDetail, ConversationDetail t1) {
        return conversationDetail.getId().compareTo(t1.getId());
    }

}
