package com.mobileapp.krank.CallBacks;

public interface LikeUpdateCallBack {
    void update(int isLike);
}
