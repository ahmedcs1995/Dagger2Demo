package com.mobileapp.krank.CallBacks;

public interface PhoneCodeAutoReadListener {
    void onCodeReceived(String code);
}