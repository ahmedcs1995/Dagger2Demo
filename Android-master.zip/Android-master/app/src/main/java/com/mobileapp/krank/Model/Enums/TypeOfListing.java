package com.mobileapp.krank.Model.Enums;

public enum TypeOfListing {
    POST,
    LOADER
}
