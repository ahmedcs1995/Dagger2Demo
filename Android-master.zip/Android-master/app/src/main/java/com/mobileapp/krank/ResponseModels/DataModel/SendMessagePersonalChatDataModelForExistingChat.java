package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SendMessagePersonalChatDataModelForExistingChat {
    @SerializedName("message")
    @Expose
    private ConversationDetail message;

    public ConversationDetail getMessage() {
        return message;
    }

    public void setMessage(ConversationDetail message) {
        this.message = message;
    }
}
