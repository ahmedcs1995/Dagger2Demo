package com.mobileapp.krank.ResponseModels.DataModel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NetworkSearch implements Parcelable {

    public static final int PROGRESS_BAR = 1;
    public static final int ITEM_VIEW = 0;


    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("totalNetwork")
    @Expose
    private String totalNetwork;
    @SerializedName("network_company")
    @Expose
    private String networkCompany;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("userID")
    @Expose
    private String userID;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("companyID")
    @Expose
    private String companyID;
    @SerializedName("countryName")
    @Expose
    private String countryName;
    @SerializedName("cityName")
    @Expose
    private String cityName;
    @SerializedName("company_url")
    @Expose
    private String companyUrl;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("totalEmployee")
    @Expose
    private String totalEmployee;

    private int itemType;


    protected NetworkSearch(Parcel in) {
        companySlug = in.readString();
        totalNetwork = in.readString();
        networkCompany = in.readString();
        status = in.readString();
        emailAddress = in.readString();
        userID = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        companyName = in.readString();
        profilePic = in.readString();
        companyID = in.readString();
        countryName = in.readString();
        cityName = in.readString();
        companyUrl = in.readString();
        companyProfilePic = in.readString();
        totalEmployee = in.readString();
        itemType = in.readInt();
    }

    public static final Creator<NetworkSearch> CREATOR = new Creator<NetworkSearch>() {
        @Override
        public NetworkSearch createFromParcel(Parcel in) {
            return new NetworkSearch(in);
        }

        @Override
        public NetworkSearch[] newArray(int size) {
            return new NetworkSearch[size];
        }
    };

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getTotalNetwork() {
        return totalNetwork;
    }

    public void setTotalNetwork(String totalNetwork) {
        this.totalNetwork = totalNetwork;
    }

    public String getNetworkCompany() {
        return networkCompany;
    }

    public void setNetworkCompany(String networkCompany) {
        this.networkCompany = networkCompany;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCompanyID() {
        return companyID;
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getTotalEmployee() {
        return totalEmployee;
    }

    public void setTotalEmployee(String totalEmployee) {
        this.totalEmployee = totalEmployee;
    }

    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public NetworkSearch(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(companySlug);
        parcel.writeString(totalNetwork);
        parcel.writeString(networkCompany);
        parcel.writeString(status);
        parcel.writeString(emailAddress);
        parcel.writeString(userID);
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(companyName);
        parcel.writeString(profilePic);
        parcel.writeString(companyID);
        parcel.writeString(countryName);
        parcel.writeString(cityName);
        parcel.writeString(companyUrl);
        parcel.writeString(companyProfilePic);
        parcel.writeString(totalEmployee);
        parcel.writeInt(itemType);
    }
}



