package com.mobileapp.krank.ResponseModels.DataModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ConnectionsForCompanyProfileViewDataModel {
    @SerializedName("user_id")
    @Expose
    private String user_id;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("user_pic")
    @Expose
    private String userPic;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("online")
    @Expose
    private String online;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("con_id")
    @Expose
    private Integer conId;
    @SerializedName("isDelete")
    @Expose
    private Integer isDelete;
    @SerializedName("conStatus")
    @Expose
    private String conStatus;

    public String getUserId() {
        return user_id;
    }

    public void setUserId(String id) {
        this.user_id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String profilePic) {
        this.userPic = profilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getConId() {
        return conId;
    }

    public void setConId(Integer conId) {
        this.conId = conId;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

}
