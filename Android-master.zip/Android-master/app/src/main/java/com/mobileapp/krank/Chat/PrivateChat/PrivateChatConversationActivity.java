package com.mobileapp.krank.Chat.PrivateChat;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.PrivateChatMessagesAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Chat.AddPeopleInPrivateChat;
import com.mobileapp.krank.Chat.ChatUtils.ChatUtils;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.MyViewModelFactory;
import com.mobileapp.krank.Database.Dao.PersonalChatConversationDao;
import com.mobileapp.krank.Database.Dao.PersonalChatListDao;
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.SortConversationDetail;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.ChatImageUploadResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.MessageVCardData;
import com.mobileapp.krank.ResponseModels.DataModel.PrivateChatUserDetail;
import com.mobileapp.krank.ResponseModels.DataModel.SendMessagePersonalChatResponseForExistingChat;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.PrivateChatMessagesResponse;
import com.mobileapp.krank.ResponseModels.SendMessagePersonalChatResponse;
import com.mobileapp.krank.Utils.AnimationUtils;
import com.mobileapp.krank.ViewModels.ChatConversationListViewModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PrivateChatConversationActivity extends BaseActivity {
    private RecyclerView chatMessagesRecyclerView;
    private PrivateChatMessagesAdapter chatMessagesRecyclerAdapter;
    List<ConversationDetail> chatMessagesItems;
    LinearLayoutManager layoutManager;
    View moreOptions;
    View collapseAbleHeader;
    View addPeopleClick;
    View view_profile_btn;
    View add_people_footer_btn;
    View loader;
    boolean iscollapseAbleHeaderVisible;

    private static int SECONDS_TO_REFRESH = 1000;
    public long lastMsgId;
    public long firstId;
    public long oldFirstId;

    View send_btn;
    View attachment_btn;
    View image_btn;
    View v_card_btn;
    EditText msg_box;

    private static int MAX_FILE_COUNT = 6;
    List<String> imagesPath;
    List<String> filesPath;

    private static final int V_CARD_PAGE_CODE = 500;

    private boolean exit;
    private String conv_id;


    private int filesCount;
    private int startConversationResponseCount;

    int firstVisibleItem, visibleItemCount, totalItemCount;
    private int visibleThreshold = 5;
    private int previousTotal = 0;
    private boolean loading = true;
    ArrayList<String> limit;
    private boolean isScrollCalled;
    //  private boolean isScrollCalled;

    private static String ASEC = "1";
    private static String DESC = "0";

    Handler handler;
    Runnable runnable;
    public SweetAlertDialog showProgressAlert;
    List<PrivateChatUserDetail> userDetail;
    int lastMsgsSize;
    long lastMsgMIdForAppendMsgs;
    private ChatConversationListViewModel chatConversationListViewModel;

    boolean isFirstTimeInit;
    AppExecutors executors;
    ConversationDetail sendMsgInstance;

    MessageVCardData sendMsgVCard;
    long lastMsgTime;
    List<ConversationDetail> tempMsgs;
    SortConversationDetail sortConversationDetail;
    ConnectionsDataModel connectionsDataModel;
    ChatConversationListDataModel chatConversationListDataModel;


    boolean onFailureCall;


    private static String TEXT_MSG = "text";
    private static String CONTACT_CARD_MSG = "vcard";
    private static String ATTACHEMENT_MSG = "attachment";

    public boolean booleanisRetryClickAble;

    List<ConversationDetail> tempAttachmentMsgs;
    List<ConversationDetail> newMsgs;

    ChatUtils chatUtils;

    private static String TAG = PrivateChatConversationActivity.class.getSimpleName();







    /**
     *
     * For Start Conversation
     * */
    String name;
    String id;
    String profilePic;
    String designation;
    String companyName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat_conversation);

        init();

        if (getIntent().getStringExtra("recipient_name") != null) {
            setNormalPageToolbar( getIntent().getStringExtra("recipient_name"));
        }

        initViews();

        setUpUserDetail();

        setUpChatMessages();


        setCallBacks();


        chatMessagesRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                handleScroll();
            }
        });
    }


    private void handleScroll() {
        visibleItemCount = chatMessagesRecyclerView.getChildCount();
        totalItemCount = layoutManager.getItemCount();
        firstVisibleItem = layoutManager.findFirstVisibleItemPosition();
        if (loading) {
            if (totalItemCount > previousTotal) {
                loading = false;
                previousTotal = totalItemCount;
            }
        }
        if (!loading && !isScrollCalled && (totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)) {
            isScrollCalled = true;
            limit.clear();
            //  limit.add(String.valueOf(chatMessagesItems.size()));
            //  limit.add("20");
            chatMessagesItems.add(new ConversationDetail(Constants.PROGRESS_BAR));
            chatMessagesRecyclerAdapter.notifyItemInserted(chatMessagesItems.size() - 1);
            Log.e("calling from scroll", "yes");
            getMessages("0", String.valueOf(firstId), limit, true, false);
            loading = true;
        }
    }

    private void initViews() {
        moreOptions = findViewById(R.id.more_options);
        collapseAbleHeader = findViewById(R.id.collpaseable_header);
        addPeopleClick = findViewById(R.id.add_people_click);
        view_profile_btn = findViewById(R.id.view_profile_btn);
        add_people_footer_btn = findViewById(R.id.add_people_footer_btn);
        loader = findViewById(R.id.loader);
        send_btn = findViewById(R.id.send_btn);
        msg_box = findViewById(R.id.msg_box);
        attachment_btn = findViewById(R.id.attachment_btn);
        image_btn = findViewById(R.id.image_btn);
        v_card_btn = findViewById(R.id.v_card_btn);
    }

    private void init() {
        executors = AppExecutors.getInstance();
        imagesPath = new ArrayList<>();
        tempAttachmentMsgs = new ArrayList<>();
        filesPath = new ArrayList<>();
        limit = new ArrayList<>();
        newMsgs = new ArrayList<>();
        conv_id = null;
        exit = false;
        booleanisRetryClickAble = true;
        onFailureCall = false;
        isFirstTimeInit = true;
        filesCount = 0;
        userDetail = new ArrayList<>();
        tempMsgs = new ArrayList<>();
        showProgressAlert = showAlert(Constants.UPLOAD_FILES_MESSAGE, SweetAlertDialog.PROGRESS_TYPE, false);
        chatUtils = new ChatUtils();

        isScrollCalled = true;
        handler = new Handler();
        runnable = () -> getMessages(String.valueOf(lastMsgId), "0", limit, false, true);


        iscollapseAbleHeaderVisible = false;
        lastMsgId = -1;
        firstId = 0;
        oldFirstId = 0;


        connectionsDataModel = gson.fromJson(getIntent().getStringExtra("selected_data"), ConnectionsDataModel.class);


        if (!(getIntent().getBooleanExtra("start_conversation", false)) && getIntent().getStringExtra("conv_id") != null) {
            conv_id = getIntent().getStringExtra("conv_id");
            chatConversationListViewModel = ViewModelProviders.of(PrivateChatConversationActivity.this, new MyViewModelFactory(this.getApplication(), conv_id)).get(ChatConversationListViewModel.class);
        }

        sendMsgInstance = new ConversationDetail("", Constants.TEXT_RIGHT, Constants.STATUS_PENDING, conv_id);
        sendMsgVCard = new MessageVCardData();

        sortConversationDetail = new SortConversationDetail();
    }

    private void addFurtherPeopleInChat(){
        Intent intent = new Intent(PrivateChatConversationActivity.this, AddPeopleInPrivateChat.class);

        /**
         * For Start Conversation
         * */
        if(userDetail.size() <= 0){
            userDetail.add(new PrivateChatUserDetail(id,name,"",profilePic,designation,companyName));
        }


        intent.putExtra("people_list_in_chat", appUtils.convertToJson(userDetail));
        intent.putExtra("isPersonalChat", true);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }
    private void setCallBacks() {
        moreOptions.setOnClickListener(view -> {
            if (iscollapseAbleHeaderVisible) {
                AnimationUtils.collapse(collapseAbleHeader);
                chatMessagesRecyclerView.setAlpha(1);
                iscollapseAbleHeaderVisible = false;
                return;
            }
            AnimationUtils.expand(collapseAbleHeader);
            chatMessagesRecyclerView.setAlpha((float) 0.2);
            iscollapseAbleHeaderVisible = true;
        });
        //deleteClick.setOnClickListener(view -> showDeleteDialogBox());

        addPeopleClick.setOnClickListener(view -> {
            addFurtherPeopleInChat();
        });

        add_people_footer_btn.setOnClickListener(view -> {
            addFurtherPeopleInChat();
        });


        view_profile_btn.setOnClickListener(view -> {
            if(userDetail == null || userDetail.size() <=0) return;
            appUtils.gotoUserProfile(PrivateChatConversationActivity.this,userDetail.get(0).getId(),preference);
        });

        
        send_btn.setOnClickListener(view -> {
            String msg = appUtils.replaceScriptString(msg_box.getText().toString());
            if (!(msg.trim().isEmpty()) && !(msg.equals(Constants.NBSP))) {
                if (conv_id != null) {

                    /*updating object*/
                    sendMsgInstance.setReply(msg);
                    sendMsgInstance.setTimeStamp(appUtils.getCurrentTimeStamp());
                    sendMsgInstance.setVCardData(null);
                    sendMsgInstance.setTime(appUtils.getcurrentUTCTime());
                    sendMsgInstance.setConversationId(conv_id);
                    sendMsgInstance.setSentTime("Just Now");
                    /*updating object*/

                    executors.diskIO().execute(() -> {
                        long lastMsgMId = chatConversationListViewModel.getDao().insert(sendMsgInstance);
                        sendMessage(msg, TEXT_MSG, null, lastMsgMId);
                    });
                    msg_box.setText("");
                } else {
                    sendMessage(msg_box.getText().toString(), TEXT_MSG, null, 0);
                    msg_box.setText("");
                }
            }else{
                if(msg_box.getText().toString().length() > 0 && msg.trim().isEmpty()){
                    //means <script></script> entered
                    Toast.makeText(PrivateChatConversationActivity.this,Constants.INVALID_INPUT,Toast.LENGTH_SHORT).show();
                    msg_box.setText("");
                }
            }
        });

        attachment_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickFile(PrivateChatConversationActivity.this));

        image_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickPhoto(PrivateChatConversationActivity.this));
        v_card_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), PrivateNewMessage.class);
            intent.putExtra("type", "visiting_card");
            intent.putExtra("page_title", "Select Contact Card");
            startActivityForResult(intent, V_CARD_PAGE_CODE);
        });
    }


    private void setUpChatMessages() {
        chatMessagesRecyclerView = (RecyclerView) findViewById(R.id.chat_messages_recycler_view);
        chatMessagesItems = new ArrayList<>();

        layoutManager = new LinearLayoutManager(PrivateChatConversationActivity.this);

        layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        DeviceInfo deviceInfo = getDeviceResolution();
        chatMessagesRecyclerAdapter = new PrivateChatMessagesAdapter(chatMessagesItems, this, deviceInfo);
        chatMessagesRecyclerView.setLayoutManager(layoutManager);
        chatMessagesRecyclerView.setAdapter(chatMessagesRecyclerAdapter);
        ((SimpleItemAnimator) chatMessagesRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

        handleChatMsgs();
    }

    /**
     * For Start Conversation
     * */
    private void setUpUserDetail(){
        try{
            name = connectionsDataModel == null ? getIntentData("first_last_name") : connectionsDataModel.getCompanyData().getFirstName() + connectionsDataModel.getCompanyData().getLastName();
            id = connectionsDataModel == null ?getIntentData("connection_id") : connectionsDataModel.getCompanyData().getUserId();
            profilePic = connectionsDataModel == null ? getIntentData("profile_pic") : connectionsDataModel.getCompanyData().getUserProfilePic();
            designation = connectionsDataModel == null ?getIntentData("job_title") : connectionsDataModel.getCompanyData().getJobTitle();
            companyName = connectionsDataModel == null ? getIntentData("company_name") : connectionsDataModel.getCompanyData().getCompanyName();
        }
        catch (Exception ex){

        }


    }

    private String getIntentData(String key){
        return getIntent().getStringExtra(key);
    }

    private void setSpannableBuilder(List<ConversationDetail> msgs){
        for(ConversationDetail item : msgs){
            item.setSsb(chatUtils.setSpannableString(item,this));
        }
    }


    private void observeMsgs() {
        chatConversationListViewModel.getAllMsgs().observe(this, msgs -> {
            loader.setVisibility(View.GONE);
            setSpannableBuilder(msgs);
            if (isFirstTimeInit && msgs.size() > 0) {
                lastMsgsSize = chatMessagesItems.size();
                chatMessagesItems.addAll(msgs);
                if (onFailureCall) {
                    chatMessagesItems.add(new ConversationDetail(Constants.RETRY_BUTTON_CHAT));
                }
                chatMessagesRecyclerAdapter.notifyItemRangeInserted(lastMsgsSize, chatMessagesItems.size());


                lastMsgTime = msgs.get(0).getTimeStamp();
                lastMsgMIdForAppendMsgs = msgs.get(0).getMid();
                Log.e("lastMsgMIdForAppendMsgs", "=> " + lastMsgMIdForAppendMsgs);
                Log.e("lastMsgTime", "=> " + lastMsgTime);
                isFirstTimeInit = false;


              /*  try {
                    firstId = Long.parseLong(msgs.get(msgs.size() - 1).getUserId());
                } catch (NumberFormatException ex) {

                }*/

            } else {
                int index = -1;
                for (int i = 0; i < msgs.size(); i++) {
                    if (msgs.get(i).getTimeStamp() <= lastMsgTime) {
                        break;
                    }
                    index = i;
                }
                if (index != -1) {
                    appendElement(msgs.subList(0, index + 1));
                    lastMsgTime = msgs.get(0).getTimeStamp();
                    lastMsgMIdForAppendMsgs = msgs.get(0).getMid();
                    if (msgs.subList(0, index + 1).size() > 0) {
                        chatMessagesRecyclerView.scrollToPosition(0);
                    }
                }

                //status copy in UI
                int j = 0;
                while (j < msgs.size()) {
                    int k = 0;
                    boolean shouldIterate = true;
                    while (k < chatMessagesItems.size() && shouldIterate) {
                        if (chatMessagesItems.get(k).getMid() == msgs.get(j).getMid()) {
                            if (msgs.get(j).getMsgStatus() == Constants.STATUS_FAIL) {
                                chatMessagesItems.get(k).setMsgStatus(Constants.STATUS_FAIL);
                                chatMessagesRecyclerAdapter.notifyItemChanged(k);
                            }
                            shouldIterate = false;
                        }
                        k++;
                    }
                    j++;
                }
                /*for (int j = 0; j < msgs.size(); j++) {
                    for(int k=0;k<chatMessagesItems.size();k++){
                        if(chatMessagesItems.get(k).getMid() == msgs.get(j).getMid()){

                        }
                    }
                    if (chatMessagesItems.get(j).getMid() == msgs.get(j).getMid() && msgs.get(j).getMsgStatus() == Constants.STATUS_FAIL) {
                        chatMessagesItems.get(j).setMsgStatus(Constants.STATUS_FAIL);
                        chatMessagesRecyclerAdapter.notifyItemChanged(j);
                        //break;
                    }
                }*/
            }

            /*if (msgs.size() > 0) {
                try {
                    Collections.sort(msgs, sortConversationDetail);
                    Log.e("sort_msgs","" + gson.toJson(msgs));
                    lastMsgId = Long.parseLong(msgs.get(0).getUserId());
                     Log.e("lastMsgId", "Observer => " + lastMsgId);
                } catch (Exception ex) {

                }
            }*/


        });
    }

    private void handleChatMsgs() {
        if (getIntent().getBooleanExtra("from_notification", false)) {
            // validate if id exists in parent column then proceed

            MyFirebaseMessagingService.CURRENT_CONV_ID = conv_id;

            chatConversationListDataModel = new ChatConversationListDataModel(
                    0,
                    "",
                    preference.getString(Constants.USER_ID),
                    "",
                    "0",
                    "text",
                    "0",
                    "",
                    "", Constants.FROM_LOCAL_DB_FALSE,
                    preference.getString(Constants.USER_ID),
                    "");
            new GetIdFromParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).personalChatListDao()).execute(conv_id);

        } else if (!(getIntent().getBooleanExtra("start_conversation", false))) {
            limit.clear();
            getMessages("0", "0", limit, false, false);
        } else {
            if (getIntent().getBooleanExtra("start_conversation", false)) {
                /*code change*/
                loader.setVisibility(View.GONE);

                chatConversationListDataModel = new ChatConversationListDataModel(
                        0,
                        "",
                        preference.getString(Constants.USER_ID),
                        "2018-10-03 05:40:31",
                        "0",
                        "text",
                        "0",
                        connectionsDataModel == null ? "" : connectionsDataModel.getCompanyData().getFirstName() + "" + connectionsDataModel.getCompanyData().getLastName(),
                        connectionsDataModel == null ? "" :  connectionsDataModel.getCompanyData().getUserProfilePic(), Constants.FROM_LOCAL_DB_FALSE,
                        preference.getString(Constants.USER_ID),
                        getIntent().getStringExtra("user_two_id"));

                /*code change*/

            }
        }
    }

    public void retryChatData() {
        isScrollCalled = true;
        getMessages("0", String.valueOf(firstId), limit, true, false);
    }



    private void getMessages(String latest_id, String first_id, final ArrayList<String> limit, final boolean isScrollCalled, final boolean pullRequest) {
        getAPI().getPrivateChatMessages(preference.getString(Constants.ACCESS_TOKEN), conv_id, latest_id, first_id, limit, DESC).enqueue(new Callback<PrivateChatMessagesResponse>() {
            @Override
            public void onResponse(Call<PrivateChatMessagesResponse> call, Response<PrivateChatMessagesResponse> response) {
                if (response.isSuccessful()) {
                    if(response.body().getStatus().equals("success")){

                        /*clear the old temp chat convo msgs and add new data*/
                        tempMsgs.clear();
                        tempMsgs.addAll(response.body().getData().getConversation_detail());
                        /*clear the old temp chat convo msgs and add new data*/



                        if (pullRequest) {
                            if (tempMsgs.size() > 0) {
                                lastMsgId = Long.parseLong(tempMsgs.get(tempMsgs.size() - 1).getId());
                                Log.e("lastMsgId", "=> " + lastMsgId);
                                readConversation();
                                chatUtils.setPersonalChatMsgsType(tempMsgs, true,PrivateChatConversationActivity.this,preference);
                                checkMsgAlreadyExists();
                            }

                        }
                        /*block for pulling*/

                        /*block for first time and pagination*/
                        else {
                            if (isScrollCalled) {
                                if (tempMsgs.size() <= 0) {
                                    PrivateChatConversationActivity.this.isScrollCalled = true;
                                }
                            }
                            if (tempMsgs.size() > 0) {

                                /*setting userData and toolbar name*/
                                if (response.body().getData().getUser_detail().size() > 0 && userDetail.size() <= 0) {
                                    userDetail.addAll(response.body().getData().getUser_detail());
                                    if (getIntent().getStringExtra("recipient_name") == null) {
                                        setNormalPageToolbar( response.body().getData().getUser_detail().get(0).getFirstName() + " " + response.body().getData().getUser_detail().get(0).getLastName());
                                    }
                                }
                                /*setting userData and toolbar name*/

                                /*read api*/
                                readConversation();
                                /*read api*/

                                /*setting values in chat msgs object*/
                                chatUtils.setPersonalChatMsgsType(tempMsgs, false,PrivateChatConversationActivity.this,preference);
                                /*setting values in chat msgs object*/

                                //get the first id for pagination
                                firstId = Long.parseLong(tempMsgs.get(0).getId());

                                /*block for first time init data*/
                                if (isFirstTimeInit) {
                                    lastMsgId = Long.parseLong(tempMsgs.get(tempMsgs.size() - 1).getId());
                                    Log.e("lastMsgId", "=> " + lastMsgId);

                                    //new GetUnSentMsgs(chatConversationListViewModel.getDao()).execute(conv_id);

                                    executors.diskIO().execute(() -> {
                                        chatConversationListViewModel.getDao().deleteByConvId(conv_id);
                                        chatConversationListViewModel.getDao().bulkInsert(tempMsgs);
                                        observeMsgs();
                                    });

                                }
                                /*block for first time init data*/

                                /*block for scroll pagination*/
                                else {
                                    Collections.reverse(tempMsgs);
                                    lastMsgsSize = chatMessagesItems.size();
                                    chatMessagesItems.addAll(tempMsgs);
                                    removeProgressBar(false);
                                    chatMessagesRecyclerAdapter.notifyItemRangeInserted(lastMsgsSize, chatMessagesItems.size());
                                    //  firstId = Long.parseLong(tempMsgs.get(tempMsgs.size() - 1).getUserId());
                                }
                                /*block for scroll pagination*/


                                if (tempMsgs.size() >= 20) {
                                    loading = false;
                                    PrivateChatConversationActivity.this.isScrollCalled = false;
                                }
                            } else {
                                removeProgressBar(false);
                            }
                        }
                    }else{
                        Toast.makeText(PrivateChatConversationActivity.this,response.body().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                    if (!exit && !isScrollCalled) {
                        pull();
                    }
                }else{
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<PrivateChatMessagesResponse> call, Throwable t) {

                /*get the last Msg Id and First Msg Id and observe the msgs*/
                if (isFirstTimeInit) {
                    new getLastMsgId(chatConversationListViewModel.getDao()).execute(conv_id);
                    return;
                }
                /*get the last Msg Id and First Msg Id and observe the msgs*/


                /*remove the progress bar and set retry icon*/
                removeProgressBar(true);
                /*remove the progress bar and set retry icon*/


                /*pull the data from backend*/
                if (!exit && !isScrollCalled) {
                    pull();
                }
                /*pull the data from backend*/

            }
        });
    }


    private void checkMsgAlreadyExists() {

        newMsgs.clear();
        for (int i = 0; i < tempMsgs.size(); i++) {
            if (!(tempMsgs.get(i).getTypeOfMessage().equals(Constants.TEXT_RIGHT))) {
                newMsgs.add(tempMsgs.get(i));
            }
            //tempMsgs.get(i).getDevice_id()!=null
            //(tempMsgs.get(i).getDevice_id().equals(appUtils.getDeviceId(getApplicationContext())))
            else if(tempMsgs.get(i).getTypeOfMessage().equals(Constants.TEXT_RIGHT)){
                if(tempMsgs.get(i).getDevice_id()==null){
                    newMsgs.add(tempMsgs.get(i));
                }
                else if(!(isDeviceIdEqual(tempMsgs.get(i).getDevice_id()))){
                    newMsgs.add(tempMsgs.get(i));
                }

            }
        }
        NewMsgBulkInsert(newMsgs);
    }


    private boolean isDeviceIdEqual(String deviceId){
        return deviceId.equals(AppUtils.getDeviceId(getApplicationContext()));
    }


    public void removeProgressBar(boolean retryIcon) {
        for (int i = (chatMessagesItems.size() - 1); i >= 0; i--) {

            if (chatMessagesItems.get(i).getTypeOfMessage().equals(Constants.PROGRESS_BAR)) {
                if (retryIcon) {
                    chatMessagesItems.get(i).setTypeOfMessage(Constants.RETRY_BUTTON_CHAT);
                    chatMessagesRecyclerAdapter.notifyItemChanged(i);
                } else {
                    chatMessagesItems.remove(i);
                    chatMessagesRecyclerAdapter.notifyItemRemoved(i);
                }
                break;
            }
        }
    }

    public void NewMsgBulkInsert(final List<ConversationDetail> msgs) {

        //   new NewMsgBulkInsertAsyncTask(chatConversationListViewModel.getDao()).execute(msgs);
        chatConversationListViewModel.newMsgBulkInsert(msgs);

    }


    private void readConversation() {
        getAPI().readConversation(preference.getString(Constants.ACCESS_TOKEN), conv_id).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                if (response.isSuccessful()) {

                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });
    }

    private void appendElement(List<ConversationDetail> newMsgs) {

        for (int i = 0; i < newMsgs.size(); i++) {
            //  if (!(newMsgs.get(i).getTypeOfMessage() == TypeOfMessage.TEXT_RIGHT)) {
            chatMessagesItems.add(i, newMsgs.get(i));
            //   }
        }
        chatMessagesRecyclerAdapter.notifyItemRangeInserted(0, newMsgs.size());
        // chatMessagesRecyclerAdapter.notifyDataSetChanged();
    }


    private void pull() {
        exit = false;
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }

    @Override
    protected void onStop() {
        super.onStop();
        exit = true;
        MyFirebaseMessagingService.CURRENT_CONV_ID = "-1";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exit = true;
        MyFirebaseMessagingService.CURRENT_CONV_ID = "-1";
    }


    public void sendMessage(String msg, final String type, String filePath, final long lastMsgMid) {
        ArrayList<String> filePaths = new ArrayList<>();
        filePaths.clear();
        if (filePath != null) {
            filePaths.add(filePath);
        }
        if (conv_id == null) {
            getAPI().chatStartConversation(preference.getString(Constants.ACCESS_TOKEN), getIntent().getStringExtra("connection_id"), msg, type, filePaths,type.equals(TEXT_MSG) ? AppUtils.getDeviceId(getApplicationContext()) : "").enqueue(new Callback<SendMessagePersonalChatResponse>() {
                @Override
                public void onResponse(Call<SendMessagePersonalChatResponse> call, Response<SendMessagePersonalChatResponse> response) {



                    if (response.isSuccessful()) {

                        /*setting type of message*/
                        if (type.equals(TEXT_MSG)) {
                            response.body().getData().getConvo_msg().setTypeOfMessage(Constants.TEXT_RIGHT);
                            chatConversationListDataModel.setConvoPreview(msg);
                        } else if (type.equals(CONTACT_CARD_MSG)) {
                            response.body().getData().getConvo_msg().setTypeOfMessage(Constants.V_CARD_RIGHT);
                        } else if (type.equals(ATTACHEMENT_MSG)) {
                            if (response.body().getData().getConvo_msg().getAttachment().getFileExt().equals("jpg") || response.body().getData().getConvo_msg().getAttachment().getFileExt().equals("jpeg") || response.body().getData().getConvo_msg().getAttachment().getFileExt().equals("png")) {
                                if (response.body().getData().getConvo_msg().getSenderId().equals(preference.getString(Constants.USER_ID))) {
                                    response.body().getData().getConvo_msg().setTypeOfMessage(Constants.IMAGE_RIGHT);
                                } else {
                                    response.body().getData().getConvo_msg().setTypeOfMessage(Constants.IMAGE_LEFT);
                                }
                            } else {
                                if (response.body().getData().getConvo_msg().getSenderId().equals(preference.getString(Constants.USER_ID))) {
                                    response.body().getData().getConvo_msg().setTypeOfMessage(Constants.OTHER_ATTACHMENT_RIGHT);
                                } else {
                                    response.body().getData().getConvo_msg().setTypeOfMessage(Constants.OTHER_ATTACHMENT_LEFT);
                                }
                            }
                        }
                        /*setting type of msg*/





                        /*setting other fields of msg*/
                        response.body().getData().getConvo_msg().setMsgStatus(Constants.STATUS_SEND);
                        response.body().getData().getConvo_msg().setTimeStamp(appUtils.getCurrentTimeStamp());
                        response.body().getData().getConvo_msg().setMsgBubbleTime(appUtils.setTimeInChatBubble(response.body().getData().getConvo_msg().getTime()));
                        /*setting other fields of msg*/






                        /*checking of attachment msg if yes then add into tempAttachmentMsgs*/
                        if(type.equals(ATTACHEMENT_MSG)){
                            startConversationResponseCount++;
                            tempAttachmentMsgs.add(response.body().getData().getConvo_msg());
                        }
                        /*checking of attachment msg if yes then add into tempAttachmentMsgs*/


                        Log.e("filesCount","=>" + filesCount);
                        Log.e("startConversation","=>" + startConversationResponseCount);

                        if (filesCount == startConversationResponseCount) {
                            filesCount =0;
                            startConversationResponseCount = 0;
                            conv_id = response.body().getData().getConversation_id();

                            Log.e("conv_id=> ", conv_id);


                            /*setting fields of parent table of msg*/
                            chatConversationListDataModel.setId(Integer.parseInt(conv_id));
                            chatConversationListDataModel.setMsgTime(appUtils.getcurrentUTCTime());
                            /*setting fields of parent table of msg*/


                            /*initiate observer and view model*/
                            chatConversationListViewModel = ViewModelProviders.of(PrivateChatConversationActivity.this, new MyViewModelFactory(PrivateChatConversationActivity.this.getApplication(), conv_id)).get(ChatConversationListViewModel.class);
                            observeMsgs();
                            /*initiate observer and view model*/


                            hideLoader();
                            lastMsgId = Long.parseLong(response.body().getData().getConvo_msg().getId());


                            /*inserting msg into db*/

                            if (type.equals(ATTACHEMENT_MSG)){

                                new InsertRecordInParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).personalChatListDao()).execute(chatConversationListDataModel);
                                new BulkInsertMessage(chatConversationListViewModel.getDao()).execute(tempAttachmentMsgs);

                            }else{
                                executors.diskIO().execute(() -> {
                                    new InsertRecordInParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).personalChatListDao()).execute(chatConversationListDataModel);
                                    new InsertMessage(chatConversationListViewModel.getDao()).execute(response.body().getData().getConvo_msg());
                                });
                            }

                            /*inserting msg into db*/

                            /*start service for pull request*/
                            pull();
                            /*start service for pull request*/

                        }

                    }
                }

                @Override
                public void onFailure(Call<SendMessagePersonalChatResponse> call, Throwable t) {
                    Log.e("Start Conversation", "onFailure");
                    Toast.makeText(getApplicationContext(), "Error while sending message", Toast.LENGTH_SHORT).show();

                }
            });
        } else {
            getAPI().sendChatMsg(preference.getString(Constants.ACCESS_TOKEN), conv_id, msg, type, filePaths,type.equals(TEXT_MSG) ? AppUtils.getDeviceId(getApplicationContext()) : "").enqueue(new Callback<SendMessagePersonalChatResponseForExistingChat>() {
                @Override
                public void onResponse(Call<SendMessagePersonalChatResponseForExistingChat> call, Response<SendMessagePersonalChatResponseForExistingChat> response) {


                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            if (type.equals("text")) {
                                response.body().getData().getMessage().setMsgStatus(Constants.STATUS_SEND);

                                Log.e("updateting_msg", "=> " + gson.toJson(response.body().getData()));

                                if (type.equals(TEXT_MSG)) {
                                    chatConversationListViewModel.updateMsgByMid(conv_id, lastMsgMid, response.body().getData().getMessage());

                                }
                            }
                            if(type.equals(ATTACHEMENT_MSG)){
                                startConversationResponseCount++;
                            }

                            if (startConversationResponseCount == filesCount) {
                                startConversationResponseCount = 0;
                                filesCount = 0;
                                hideLoader();
                            }
                        }
                        // PrivateChatConversationActivity.this.attachments.clear();
                    }
                }

                @Override
                public void onFailure(Call<SendMessagePersonalChatResponseForExistingChat> call, Throwable t) {

                    if (type.equals("text")) {
                        //  handler.postDelayed(() -> chatConversationListViewModel.updateMsgStatusByMid(conv_id, lastMsgMid, Constants.STATUS_FAIL), 1500);

                        chatConversationListViewModel.updateMsgStatusByMid(conv_id, lastMsgMid, Constants.STATUS_FAIL);
                    }

                    if (type.equals("attachment")) {
                        hideLoader();
                        Toast.makeText(PrivateChatConversationActivity.this, "Error While Uploading Files", Toast.LENGTH_SHORT).show();

                    }

                }
            });
        }

    }

    public void reSendMessage(String msg, String type, String filePath, final long msgMid, int position) {
        ArrayList<String> filePaths = new ArrayList<>();
        if (filePath != null) {
            filePaths.add(filePath);
        }
        if (conv_id == null) {

        } else {
            getAPI().sendChatMsg(preference.getString(Constants.ACCESS_TOKEN), conv_id, msg, type, filePaths,type.equals(TEXT_MSG) ? AppUtils.getDeviceId(getApplicationContext()) : "").enqueue(new Callback<SendMessagePersonalChatResponseForExistingChat>() {
                @Override
                public void onResponse(Call<SendMessagePersonalChatResponseForExistingChat> call, Response<SendMessagePersonalChatResponseForExistingChat> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            Toast.makeText(getApplicationContext(), "Message successfully sent", Toast.LENGTH_SHORT).show();
                            response.body().getData().getMessage().setMsgStatus(Constants.STATUS_SEND);
                            response.body().getData().getMessage().setTypeOfMessage(Constants.TEXT_RIGHT);

                            chatConversationListViewModel.deleteByMid(msgMid);


                            chatMessagesItems.remove(position);

                            chatMessagesRecyclerAdapter.notifyItemRemoved(position);

                            response.body().getData().getMessage().setTimeStamp(appUtils.getCurrentTimeStamp());


                            chatConversationListViewModel.insert(response.body().getData().getMessage());

                            if (filesCount == 0) {
                                hideLoader();
                            }
                            booleanisRetryClickAble = true;
                        }
                        // PrivateChatConversationActivity.this.attachments.clear();

                    }
                }

                @Override
                public void onFailure(Call<SendMessagePersonalChatResponseForExistingChat> call, Throwable t) {
                    handler.postDelayed(() -> {
                        Toast.makeText(getApplicationContext(), "Message not sent...", Toast.LENGTH_SHORT).show();
                        chatMessagesItems.get(position).setMsgStatus(Constants.STATUS_FAIL);
                        chatMessagesRecyclerAdapter.notifyItemChanged(position);
                        booleanisRetryClickAble = true;
                    }, 2000);

                }
            });
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FilePickerConst.REQUEST_CODE_PHOTO:
                if (resultCode == RESULT_OK && data != null) {

                    imagesPath.clear();
                    imagesPath.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));
                    // Log.e("file paths", "" + appUtils.convertToJson(imagesPath));
                    // filesCount = imagesPath.size();

                    for (String item : imagesPath) {
                        uploadFiles(item);
                    }
                    //uploadFiles(imagesPath);
                }
                break;
            case FilePickerConst.REQUEST_CODE_DOC:
                if (resultCode == RESULT_OK && data != null) {

                    filesPath.clear();
                    filesPath.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    //  filesCount = filesPath.size();

                    for (String item : filesPath) {
                        uploadFiles(item);
                    }
                    //  uploadFiles(filesPath);
                }
                break;
            case V_CARD_PAGE_CODE:
                if (data.getStringExtra("selected_data") != null && resultCode == RESULT_OK) {

                    ConnectionsDataModel connectionsDataModel = gson.fromJson(data.getStringExtra("selected_data"), ConnectionsDataModel.class);

                    /*sendMsgInstance.setReply(connectionsDataModel.getCompanyData().getUserId());

                    sendMsgVCard.setUserPic(connectionsDataModel.getCompanyData().getUserProfilePic());
                    sendMsgVCard.setCompanyProfilePic(connectionsDataModel.getCompanyData().getCompanyProfilePic());
                    sendMsgVCard.setFirstName(connectionsDataModel.getCompanyData().getFirstName());
                    sendMsgVCard.setLastName(connectionsDataModel.getCompanyData().getLastName());
                    sendMsgVCard.setCompanyId(connectionsDataModel.getCompanyData().getCompanyName());
                    sendMsgVCard.setDesignation(connectionsDataModel.getCompanyData().getJobTitle());
                    sendMsgVCard.setCity(connectionsDataModel.getCompanyData().getUserCityName());
                    sendMsgVCard.setCountry(connectionsDataModel.getCompanyData().getUserCountryName());
                    sendMsgInstance.setVCardData(sendMsgVCard);


                    executors.diskIO().execute(()->{
                        sendMsgInstance.setTimeStamp(getCurrentTimeStamp());
                        lastMsgMId = chatConversationListViewModel.getDao().insert(sendMsgInstance);
                        sendMessage(connectionsDataModel.getCompanyData().getUserId(), "vcard", null,lastMsgMId);
                        executors.mainThread().execute(()-> msg_box.setText(""));

                    });*/
                    sendMessage(connectionsDataModel.getCompanyData().getUserId(), CONTACT_CARD_MSG, null, 0);
                }
                break;
        }
    }


    private void uploadFiles(String attachmentsToSend) {
        ArrayList<String> filePaths = new ArrayList<>();

        boolean isDataAdded=false;

        filePaths.add(attachmentsToSend);

        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);


        for (int i = 0; i < filePaths.size(); i++) {
            File file = new File(filePaths.get(i));
            Log.e("file.getName()","" + file.getName());
            // Log.e(TAG,"=> file size " + appUtils.getFileSize(file));
            if(appUtils.getFileSize(file) < Constants.MAX_FILE_SIZE && appUtils.getFileSize(file) > 0){
                isDataAdded = true;
                filesCount+=1;
                builder.addFormDataPart("upload_file[]", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
            }else{
                Toast.makeText(PrivateChatConversationActivity.this,"Could Not upload file " + file.getName(),Toast.LENGTH_SHORT).show();
            }

        }

        if(!isDataAdded){
            return;
        }
        showLoader();
        MultipartBody requestBody = builder.build();

        getAPI().uploadChatImages(preference.getString(Constants.ACCESS_TOKEN), "chat-attachment", requestBody).enqueue(new Callback<ChatImageUploadResponse>() {
            @Override
            public void onResponse(Call<ChatImageUploadResponse> call, Response<ChatImageUploadResponse> response) {
                //  Log.e("on Success file", "attachment " + appUtils.convertToJson(response.body()));
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        //  attachments.clear();


                        //   Log.e("files count", "" + filesCount);
                        for (int i = 0; i < response.body().getData().getSuccess().size(); i++) {
                            //   attachments.add(response.body().getData().getSuccess().get(i).getFileName());
                            sendMessage("", ATTACHEMENT_MSG, response.body().getData().getSuccess().get(i).getFileName(), 0);
                        }
                    } else {
                        Toast.makeText(PrivateChatConversationActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(PrivateChatConversationActivity.this, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChatImageUploadResponse> call, Throwable t) {
                hideLoader();
                Toast.makeText(PrivateChatConversationActivity.this, "Error while uploading files", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (isTaskRoot()) {
            appUtils.gotoHomePage(PrivateChatConversationActivity.this);
            return;
        }
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
        overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
    }

    private void showLoader() {
        chatMessagesRecyclerView.setAlpha(0.2f);
        showProgressAlert.setContentText(Constants.UPLOAD_FILES_MESSAGE);
        showProgressAlert.show();
        msg_box.setEnabled(false);
    }

    private void hideLoader() {
        chatMessagesRecyclerView.setAlpha(1f);
        showProgressAlert.dismiss();
        msg_box.setEnabled(true);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //  Log.e("into", "onRestart");
        MyFirebaseMessagingService.CURRENT_CONV_ID = conv_id;
        pull();
    }


    private class getLastMsgId extends AsyncTask<String, Void, String> {

        private PersonalChatConversationDao mAsyncTaskDao;

        getLastMsgId(PersonalChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected String doInBackground(final String... params) {
            return mAsyncTaskDao.getLatestMsgId(params[0]);

        }

        @Override
        protected void onPostExecute(String longVal) {
            try {
                lastMsgId = Long.parseLong(longVal);

            }
            catch (NumberFormatException ex){

            }
            new getFirstMsgId(chatConversationListViewModel.getDao()).execute(conv_id);

        }
    }

    private class getFirstMsgId extends AsyncTask<String, Void, String> {

        private PersonalChatConversationDao mAsyncTaskDao;

        getFirstMsgId(PersonalChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected String doInBackground(final String... params) {
            return mAsyncTaskDao.getFirstMsgId(params[0]);

        }

        @Override
        protected void onPostExecute(String longVal) {
            try {
                firstId = Long.parseLong(longVal);

            }
            catch (NumberFormatException ex){

            }
            onFailureCall = true;
            observeMsgs();
            removeProgressBar(true);
            if (!exit) {
                pull();
            }
        }
    }


    private class InsertRecordInParentTable extends AsyncTask<ChatConversationListDataModel, Void, Void> {

        private PersonalChatListDao mAsyncTaskDao;

        InsertRecordInParentTable(PersonalChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final ChatConversationListDataModel... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }

    }

    private class GetIdFromParentTable extends AsyncTask<String, Void, Integer> {

        private PersonalChatListDao mAsyncTaskDao;

        GetIdFromParentTable(PersonalChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Integer doInBackground(final String... params) {
            return mAsyncTaskDao.getIdOfParentTable(params[0]);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            if(integer ==0){
                // record does not exists
                new InsertConvIdInParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).personalChatListDao()).execute();
            }
            else{
                getMessages("0", "0", limit, false, false);
            }
        }
    }

    private class InsertConvIdInParentTable extends AsyncTask<Void, Void, Void> {

        private PersonalChatListDao mAsyncTaskDao;

        InsertConvIdInParentTable(PersonalChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Void... params) {
            chatConversationListDataModel.setId(Integer.parseInt(conv_id));
            chatConversationListDataModel.setMsgTime(appUtils.getcurrentUTCTime());
            mAsyncTaskDao.insert(chatConversationListDataModel);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            getMessages("0", "0", limit, false, false);
        }
    }


    private class InsertMessage extends AsyncTask<ConversationDetail, Void, Void> {

        private PersonalChatConversationDao mAsyncTaskDao;

        InsertMessage(PersonalChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final ConversationDetail... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }

    }

    private class BulkInsertMessage extends AsyncTask<List<ConversationDetail>, Void, Void> {

        private PersonalChatConversationDao mAsyncTaskDao;

        BulkInsertMessage(PersonalChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(List<ConversationDetail>... lists) {
            mAsyncTaskDao.bulkInsert(lists[0]);
            return null;
        }



    }

}
