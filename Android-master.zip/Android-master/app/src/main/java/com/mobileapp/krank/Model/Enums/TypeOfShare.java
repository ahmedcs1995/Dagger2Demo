package com.mobileapp.krank.Model.Enums;

public enum TypeOfShare {
    PUBLIC_COMPANY_NEWS_FEED,
    CONNECTIONS,
    CO_WORKERS,
    NETWORK,
    NETWORK_GROUP,
    DEALER_GROUP,
    PRIVATE_CONNECTION,
}
