package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ChatSearchListPeopleDataModel {

    @SerializedName("result")
    @Expose
    private List<ChatConversationListDataModel> result = null;

    public List<ChatConversationListDataModel> getResult() {
        return result;
    }

    public void setResult(List<ChatConversationListDataModel> result) {
        this.result = result;
    }
}
