package com.mobileapp.krank.ResponseModels

import com.google.gson.annotations.SerializedName
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData

data class ContactsImportResponseModel (

        @SerializedName("status") val status : String,
        @SerializedName("message") val message : String,
        @SerializedName("data") val data : UsersData
)

data class UsersData(
        @SerializedName("connected_users") val connected_users : ArrayList<GetNetworkEmployeeData>,
        @SerializedName("non_connected_users") val non_connected_users : ArrayList<GetNetworkEmployeeData>,
        @SerializedName("no_users") val no_users : ArrayList<GetNetworkEmployeeData>,
        @SerializedName("connectedUsersCount") val connectedUsersCount : Int,
        @SerializedName("nonConnectedUsersCount") val nonConnectedUsersCount : Int,
        @SerializedName("totalUsersCount") val totalUsersCount : Int,
        @SerializedName("total_contacts") val total_contacts : Int,
        @SerializedName("my_contacts") val my_contacts : Int)


