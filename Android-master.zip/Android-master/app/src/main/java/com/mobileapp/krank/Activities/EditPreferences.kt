package com.mobileapp.krank.Activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.mobileapp.krank.R

class EditPreferences : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_preferences)
    }
}
