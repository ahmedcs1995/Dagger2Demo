package com.mobileapp.krank.Functions;

import com.google.gson.Gson;

public class CustomGson {
    private static Gson INSTANCE;

    public static Gson getInstance(){
        if(INSTANCE==null){
            INSTANCE = new Gson();
            return INSTANCE;
        }
        return INSTANCE;
    }
}
