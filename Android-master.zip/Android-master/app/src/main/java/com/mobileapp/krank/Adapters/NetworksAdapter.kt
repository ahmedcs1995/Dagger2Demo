package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.HomePageTabs.MyNetworks
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ViewHolders.CommonViewHolder.RecyclerHeaderViewHolder

/**
 * Created by Yaseen on 26/04/2018.
 */

class NetworksAdapter(private val items: List<NetworkList>, internal var context: Context?, internal var callBack: CallBackWithAdapterPosition) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    inner class NetworkViewHolder(internal var item: View) : RecyclerView.ViewHolder(item) {
        internal var network_profile_image_view: SimpleDraweeView = item.findViewById(R.id.network_profile_image_view)
        internal var network_name_textView: TextView = item.findViewById(R.id.network_name_textView)
        internal var city_and_country_text_view: TextView = item.findViewById(R.id.city_and_country_text_view)
        internal var official_dealer_image_view: ImageView = item.findViewById(R.id.official_dealer_image_view)

        init {
            item.setOnClickListener { callBack.act(adapterPosition) }
        }
    }


    override fun getItemViewType(position: Int): Int {
        return when (items[position].type) {
            Constants.LOADER_VIEW -> 1
            Constants.ITEM_VIEW -> 2
            MyNetworks.TYPE_HEADER -> 0
            else -> Constants.LOADER_VIEW
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View
        return when (viewType) {
            0 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.recycler_header, parent, false)
                RecyclerHeaderViewHolder(v)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.my_networks_list_item, parent, false)
                NetworkViewHolder(v)
            }
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]

        if (item.type == Constants.ITEM_VIEW) {
            setItemView(item, holder as NetworkViewHolder)
        } else {

        }

    }

    private fun setItemView(item: NetworkList, holder: NetworkViewHolder) {
        holder.network_name_textView.text = item.companyName
        val country = if (item.countryName != null) item.countryName else "N/A"
        val city = if (item.cityName != null) item.cityName else "N/A"

        holder.city_and_country_text_view.text = "$city, $country"
        if (item.dealerStatus == "Not a dealer") {
            holder.official_dealer_image_view.visibility = View.GONE
        } else {
            holder.official_dealer_image_view.visibility = View.VISIBLE

        }
        if (item.dealerStatus == "Request Pending") {
            holder.official_dealer_image_view.visibility = View.GONE
        }

        holder.network_profile_image_view.setImageURI( Constants.BASE_IMG_URL + item.profilePic)

    }

}





