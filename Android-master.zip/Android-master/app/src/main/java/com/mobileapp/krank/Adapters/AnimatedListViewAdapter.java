package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobileapp.krank.CustomViews.AnimatedExpandableListView;
import com.mobileapp.krank.Model.DrawerMenu;
import com.mobileapp.krank.Model.DrawerSubItem;
import com.mobileapp.krank.R;

import java.util.List;

/**
 * Created by Ahmed on 5/9/2018.
 */


public class AnimatedListViewAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter {
    private LayoutInflater inflater;

    private List<DrawerMenu> items;
    private Context context;

    public AnimatedListViewAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public void setData(List<DrawerMenu> items) {
        this.items = items;
    }

    @Override
    public DrawerSubItem getChild(int groupPosition, int childPosition) {
        return items.get(groupPosition).getItems().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getRealChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        final DrawerSubItem item = getChild(groupPosition, childPosition);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.sub_item_drawer, parent, false);

        }
        TextView name = convertView.findViewById(R.id.child_text_view);
        ImageView hand_finger = convertView.findViewById(R.id.hand_finger);



        name.setOnClickListener(view -> {
            if(item.getSubItemClick()!=null){
                item.getSubItemClick().act();
            }
        });

        if(item.isFocusView()){
            hand_finger.setVisibility(View.VISIBLE);

            Animation anim = new AlphaAnimation(0.0f, 1.0f);
            anim.setDuration(250); //You can manage the blinking time with this parameter
            anim.setStartOffset(20);
            anim.setRepeatMode(Animation.REVERSE);
            anim.setRepeatCount(Animation.INFINITE);
            name.startAnimation(anim);
        }else{
            hand_finger.setVisibility(View.GONE);
            name.clearAnimation();
        }
        name.setText(item.getName());


        return convertView;
    }

    @Override
    public int getRealChildrenCount(int groupPosition) {
        return items.get(groupPosition).getItems() == null ?  0 : items.get(groupPosition).getItems().size();
    }

    @Override
    public DrawerMenu getGroup(int groupPosition) {
        return items.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return items.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        final DrawerMenu item = getGroup(groupPosition);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.drawer_menu_item, parent, false);

        }


        TextView itemName = convertView.findViewById(R.id.item_name);
        View container =  convertView.findViewById(R.id.header);
        ImageView collapse_btn=  convertView.findViewById(R.id.collapse_btn);
        ImageView img_icon=  convertView.findViewById(R.id.img_icon);



        img_icon.setImageDrawable(ContextCompat.getDrawable(context,item.getDrawableIcon()));


        if(item.getSign() != null){
            collapse_btn.setVisibility(View.VISIBLE);

            if(item.getSign().equals("+")){
                collapse_btn.setRotation(0);
                itemName.setTextColor(ContextCompat.getColor(context,R.color.AppDarkGray));

            }else{
                collapse_btn.setRotation(180);
                itemName.setTextColor(ContextCompat.getColor(context,R.color.drawer_background));
            }

        }else{
            collapse_btn.setVisibility(View.GONE);

            itemName.setTextColor(ContextCompat.getColor(context,R.color.AppDarkGray));
        }




        itemName.setText(item.getName());

        if(item.getItemClick() != null){
            container.setOnClickListener(view -> item.getItemClick().act());
        }

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int arg0, int arg1) {
        return true;
    }

}
