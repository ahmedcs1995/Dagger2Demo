package com.mobileapp.krank.Adapters;

import android.support.design.widget.BottomSheetDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import com.mobileapp.krank.Chat.GroupChatPakage.PeopleListInGroupChat;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ChildCommentDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PeopleListInGroupChatAdapter extends RecyclerView.Adapter<PeopleListInGroupChatAdapter.ViewHolder> {
    private List<GroupChatMembersDataModel> items;
    PeopleListInGroupChat peopleListInGroupChat;
    boolean isGroupAdmin;

    View dialogView;
    final BottomSheetDialog dialog;
    View remove_btn;


    public class ViewHolder extends RecyclerView.ViewHolder {
        View item;
        View delete_view;
        CircleImageView profile_image_view;
        TextView employee_name_text_view;
        TextView company_name_text_view;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            profile_image_view = item.findViewById(R.id.profile_image_view);
            employee_name_text_view = item.findViewById(R.id.employee_name_text_view);
            company_name_text_view = item.findViewById(R.id.company_name_text_view);
            delete_view = item.findViewById(R.id.delete_view);


            delete_view.setOnClickListener(view -> openBottomSheetDialog(items.get(getAdapterPosition()), getAdapterPosition()));

            profile_image_view.setOnClickListener(view -> {
                peopleListInGroupChat.appUtils.gotoUserProfile(peopleListInGroupChat, items.get(getAdapterPosition()).getId(), peopleListInGroupChat.preference);
            });

            employee_name_text_view.setOnClickListener(view -> {

                peopleListInGroupChat.appUtils.gotoUserProfile(peopleListInGroupChat, items.get(getAdapterPosition()).getId(), peopleListInGroupChat.preference);
            });

            company_name_text_view.setOnClickListener(view -> {

                peopleListInGroupChat.appUtils.gotoCompanyProfile(peopleListInGroupChat, items.get(getAdapterPosition()).getCompanyId(), peopleListInGroupChat.preference);
            });
        }
    }

    public PeopleListInGroupChatAdapter(List<GroupChatMembersDataModel> items, PeopleListInGroupChat peopleListInGroupChat, boolean isGroupAdmin) {
        this.items = items;
        this.peopleListInGroupChat = peopleListInGroupChat;
        this.isGroupAdmin = isGroupAdmin;

        dialogView = peopleListInGroupChat.getLayoutInflater().inflate(R.layout.delete_bottom_pop_up, null);
        dialog = new BottomSheetDialog(peopleListInGroupChat);
        dialog.setContentView(dialogView);

        remove_btn = dialogView.findViewById(R.id.remove_btn);
    }


    @Override
    public PeopleListInGroupChatAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.people_list_recycler_item, parent, false);
        return new PeopleListInGroupChatAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PeopleListInGroupChatAdapter.ViewHolder holder, final int position) {
        final GroupChatMembersDataModel item = items.get(position);
        Glide.with(peopleListInGroupChat.getApplicationContext()).load(item.getProfilePic()).into(holder.profile_image_view);
        holder.employee_name_text_view.setText("" + item.getFirstName() + " " + item.getLastName());
        holder.company_name_text_view.setText("" + AppUtils.getCompanyAndDesignation(item.getCompanyName(), item.getDesignation()));
        if (isGroupAdmin && item.getIsGroupAdmin() == 0) {
            holder.delete_view.setVisibility(View.VISIBLE);
        } else {
            holder.delete_view.setVisibility(View.GONE);
        }


    }

    @Override
    public int getItemCount() {
        return items.size();
    }




    private void showDialog(final GroupChatMembersDataModel item, final int position) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, peopleListInGroupChat))
                .setHeading("Are you sure?")
                .setDescription("Are you sure you want to remove this person")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    removePersonFromGroup(item.getMemberId());
                    items.remove(position);
                    notifyDataSetChanged();
                });
        dialog.show();
    }
    private void openBottomSheetDialog(final GroupChatMembersDataModel item, final int position) {




        remove_btn.setOnClickListener(view -> {
            showDialog(item,position);
            dialog.dismiss();
        });

        dialog.getWindow().getAttributes().windowAnimations = R.style.slide_up_down_animation;
        dialog.show();
    }

    private void removePersonFromGroup(String memberId) {
        peopleListInGroupChat.getAPI().removeMemberFromGroup(peopleListInGroupChat.preference.getString(Constants.ACCESS_TOKEN), memberId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                    }
                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });
    }
}






