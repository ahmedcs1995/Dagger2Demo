package com.mobileapp.krank.Network;


import com.mobileapp.krank.AccountSetupPages.MarketPlaceInterestPage;
import com.mobileapp.krank.CompanyProfileSettingsTabs.CompanyProfileSettingsPageTwo;
import com.mobileapp.krank.Model.CreatePostData;
import com.mobileapp.krank.ResponseModels.AddRemoveFavResponse;
import com.mobileapp.krank.ResponseModels.ArticleDetailResponseModel;
import com.mobileapp.krank.ResponseModels.ChatConversationListResponse;
import com.mobileapp.krank.ResponseModels.ChatImageUploadResponse;
import com.mobileapp.krank.ResponseModels.ChatSearchPeopleListResponse;
import com.mobileapp.krank.ResponseModels.ChildCommentAddResponse;
import com.mobileapp.krank.ResponseModels.ChildCommentResponse;
import com.mobileapp.krank.ResponseModels.CityListResponse;
import com.mobileapp.krank.ResponseModels.CodeVerificationResponse;
import com.mobileapp.krank.ResponseModels.CommentGetByIdResponse;
import com.mobileapp.krank.ResponseModels.CommentLikeResponse;
import com.mobileapp.krank.ResponseModels.CommentPostModel;
import com.mobileapp.krank.ResponseModels.CommentsResponse;
import com.mobileapp.krank.ResponseModels.CompanyInterestListResponse;
import com.mobileapp.krank.ResponseModels.CompanyInvitationResponse;
import com.mobileapp.krank.ResponseModels.CompanyNewsFeedResponse;
import com.mobileapp.krank.ResponseModels.CompanyProfileDetailResponseModel;
import com.mobileapp.krank.ResponseModels.CompanySizeResponse;
import com.mobileapp.krank.ResponseModels.ConnectionsForCompanyProfileViewResponse;
import com.mobileapp.krank.ResponseModels.ContactsImportResponseModel;
import com.mobileapp.krank.ResponseModels.ContactsPostDataModel;
import com.mobileapp.krank.ResponseModels.CountryListResponse;
import com.mobileapp.krank.ResponseModels.CreateCompanyProfile;
import com.mobileapp.krank.ResponseModels.CreatePostResponse;
import com.mobileapp.krank.ResponseModels.CurrenciesListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.GroupConversationSendResponse;
import com.mobileapp.krank.ResponseModels.DataModel.SendMessagePersonalChatResponseForExistingChat;
import com.mobileapp.krank.ResponseModels.DealerGroupResponse;
import com.mobileapp.krank.ResponseModels.DealerListFromGroup;
import com.mobileapp.krank.ResponseModels.DealersForCompanyProfileViewPage;
import com.mobileapp.krank.ResponseModels.ExportConnectionsResponseModel;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.GetNetworkEmployeeResponse;
import com.mobileapp.krank.ResponseModels.GroupChatConversationResponse;
import com.mobileapp.krank.ResponseModels.GroupChatMembersResponse;
import com.mobileapp.krank.ResponseModels.GroupChatMessagesResponse;
import com.mobileapp.krank.ResponseModels.GroupConversationCreateResponse;
import com.mobileapp.krank.ResponseModels.GroupConversationMemberAddResponseModel;
import com.mobileapp.krank.ResponseModels.ImportConnectionsResponseModel;
import com.mobileapp.krank.ResponseModels.IndustriesListResponse;
import com.mobileapp.krank.ResponseModels.InviteCompaniesResponse;
import com.mobileapp.krank.ResponseModels.ListingDealerResponseModel;
import com.mobileapp.krank.ResponseModels.ListingDetailResponseModel;
import com.mobileapp.krank.ResponseModels.ListingFilterDataResponse;
import com.mobileapp.krank.ResponseModels.ListingWebviewResponse;
import com.mobileapp.krank.ResponseModels.NetworkDealersResponse;
import com.mobileapp.krank.ResponseModels.NetworkGroupResponse;
import com.mobileapp.krank.ResponseModels.NetworkListFromGroup;
import com.mobileapp.krank.ResponseModels.NetworkListResponse;
import com.mobileapp.krank.ResponseModels.NewsFeedByIdResponse;
import com.mobileapp.krank.ResponseModels.NewsFeedLikeResponse;
import com.mobileapp.krank.ResponseModels.NewsFeedListResponse;
import com.mobileapp.krank.ResponseModels.NotificationListResponse;
import com.mobileapp.krank.ResponseModels.NotificationMsgBadgeResponse;
import com.mobileapp.krank.ResponseModels.PendingRecieveRequestResponseModel;
import com.mobileapp.krank.ResponseModels.PersonalNewsFeedResponse;
import com.mobileapp.krank.ResponseModels.PrivateChatMessagesResponse;
import com.mobileapp.krank.ResponseModels.ProfileMenuResponse;
import com.mobileapp.krank.ResponseModels.PublicCompanyProfileResponse;
import com.mobileapp.krank.ResponseModels.PublicMarketPlaceResponse;
import com.mobileapp.krank.ResponseModels.PublicProfileResponse;
import com.mobileapp.krank.ResponseModels.SearchResponseModel;
import com.mobileapp.krank.ResponseModels.SendMessagePersonalChatResponse;
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse;
import com.mobileapp.krank.ResponseModels.ShareToKrankPost;
import com.mobileapp.krank.ResponseModels.SigninResponse;
import com.mobileapp.krank.ResponseModels.SignupOneResponse;
import com.mobileapp.krank.ResponseModels.SignupResendVerificationResponse;
import com.mobileapp.krank.ResponseModels.SignupTwoResponse;
import com.mobileapp.krank.ResponseModels.TagConnectionNewsFeedPost;
import com.mobileapp.krank.ResponseModels.ConnectionResponse;
import com.mobileapp.krank.ResponseModels.TypeOfBussinessResponse;
import com.mobileapp.krank.ResponseModels.UpdateInterestCompanyResponse;
import com.mobileapp.krank.ResponseModels.UpdateProfileRespose;
import com.mobileapp.krank.ResponseModels.UploadImageResponse;
import com.mobileapp.krank.ResponseModels.UrlScrapperResponse;
import com.mobileapp.krank.ResponseModels.UserMetaModel;
import com.mobileapp.krank.ResponseModels.UserMetaModelBody;
import com.mobileapp.krank.ResponseModels.UserOnlineStatusResponseModel;

import java.util.ArrayList;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.Url;

/**
 * Created by arbaz on 10/13/2017.
 */

public interface ApiInterface {


    //User Authorization Section

    @FormUrlEncoded
    @POST("UserAuthorization/email-register")
    Call<SignupOneResponse> signupStepOne(@Field("email_address") String email_address,
                                          @Field("invite_by") int invite_by);

    @FormUrlEncoded
    @POST("UserAuthorization/temp-register")
    Call<SignupTwoResponse> signupStepTwo(@Field("email_address") String email_address,
                                          @Field("first_name") String first_name,
                                          @Field("last_name") String last_name,
                                          @Field("invite_by") int invite_by,
                                          @Field("device_type") String device_type);

    @FormUrlEncoded
    @POST("UserAuthorization/registration-code-verify")
    Call<CodeVerificationResponse> codeVerification(@Field("email_address") String email_address,
                                                    @Field("verify_code") String verify_code);

    @FormUrlEncoded
    @POST("UserAuthorization/resend-verification-code")
    Call<SignupResendVerificationResponse> signupResendVerification(@Field("email_address") String email_address);

    @FormUrlEncoded
    @POST("UserAuthorization/registration")
    Call<SigninResponse> createAccount(@Field("email_address") String email_address,
                                       @Field("tmp_user_id") String tmp_user_id,
                                       @Field("verify_code") String verify_code,
                                       @Field("new_company") Boolean new_company,
                                       @Field("company_name") String company_name,
                                       @Field("country_code") String country_code,
                                       @Field("city_id") String city_id,
                                       @Field("password") String password,
                                       @Field("confirm_password") String confirm_password,
                                       @Field("device_id") String device_id,
                                       @Field("history_os") String history_os,
                                       @Field("history_device_name") String history_device_name,
                                       @Field("history_device_brand") String history_device_brand,
                                       @Field("history_unique_id") String history_unique_id,
                                       @Field("device_type") String device_type,
                                       @Field("invite_by") int invite_by,
                                       @Field("invite_type") String invite_type);

    @FormUrlEncoded
    @POST("UserAuthorization/forgot-password")
    Call<GeneralResponse> forgotPassword(@Field("email_address") String email_address);

    @FormUrlEncoded
    @POST("UserAuthorization/password-verification")
    Call<GeneralResponse> forgotPasswordVerification(@Field("email_address") String email_address,
                                                     @Field("verification_code") String verification_code);

    @FormUrlEncoded
    @POST("UserAuthorization/change-password")
    Call<SigninResponse> changePassword(@Field("email_address") String email_address,
                                        @Field("verification_code") String verification_code,
                                        @Field("password") String password,
                                        @Field("confirm_password") String confirm_password,
                                        @Field("device_id") String device_id,
                                        @Field("history_os") String history_os,
                                        @Field("history_device_name") String history_device_name,
                                        @Field("history_device_brand") String history_device_brand,
                                        @Field("history_unique_id") String history_unique_id);

    @FormUrlEncoded
    @POST("UserAuthorization/login")
    Call<SigninResponse> signin(@Field("email_address") String email_address,
                                @Field("password") String password,
                                @Field("device_id") String device_id,
                                @Field("history_os") String history_os,
                                @Field("history_device_name") String history_device_name,
                                @Field("history_device_brand") String history_device_brand,
                                @Field("history_unique_id") String history_unique_id);

    @GET("UserAuthorization/countries-list")
    Call<CountryListResponse> countryList();


    @FormUrlEncoded
    @POST("UserAuthorization/country-cities")
    Call<CityListResponse> cityList(@Field("country_code") String country_code,
                                    @Field("city_keyword") String city_keyword);


    //User Profile Section

    @GET("UserProfile/public-profile")
    Call<PublicProfileResponse> getPublicProfile(@Header("Access-Token") String access_token,
                                                 @Query("user_id") String id);

    @GET("UserProfile/user-profile-detail")
    Call<PublicProfileResponse> getPublicProfileDetail(@Header("Access-Token") String access_token,
                                                       @Query("user_id") String id,
                                                       @Query("slug") String slug);

    @Multipart
    @POST("UserProfile/image-upload")
    Call<UploadImageResponse> uploadProfileImage(@Header("Access-Token") String access_token,
                                                 @Header("Upload-Type") String upload_type,
                                                 @Part MultipartBody.Part upload_file);

    @Multipart
    @POST("Connect/import-connections")
    Call<ImportConnectionsResponseModel> importConnectionsFile(@Header("Access-Token") String access_token,
                                                               @Header("Upload-Type") String upload_type,
                                                               @Part MultipartBody.Part upload_file,
                                                               @Part("con_file_password") String con_file_password);


    @Multipart
    @POST("UserProfile/image-upload")
    Call<UploadImageResponse> uploadNewsFeedImg(@Header("Access-Token") String access_token,
                                                @Header("Upload-Type") String upload_type,
                                                @Part MultipartBody.Part upload_file);


    @POST("UserProfile/image-upload")
    Call<ChatImageUploadResponse> uploadChatImages(@Header("Access-Token") String access_token,
                                                   @Header("Upload-Type") String upload_type,
                                                   @Body RequestBody file);

    @FormUrlEncoded
    @POST("UserProfile/wizard-update-profile")
    Call<UpdateProfileRespose> updateWizardProfile(@Header("Access-Token") String access_token,
                                                   @Field("job_title") String job_title,
                                                   @Field("mobile_number") String mobile_number,
                                                   @Field("country_code") String country_code,
                                                   @Field("city_id") String city_id,
                                                   @Field("verify_force") int verify_force);

    @FormUrlEncoded
    @POST("UserProfile/update-profile")
    Call<UpdateProfileRespose> updateProfile(@Header("Access-Token") String access_token,
                                             @Field("job_title") String job_title,
                                             @Field("department") String department,
                                             @Field("country_id") String country_code,
                                             @Field("city_id") String city_id,
                                             @Field("mobile_number") String mobile_number,
                                             @Field("verify_force") int verify_force);


    @GET("UserProfile/profile-menu")
    Call<ProfileMenuResponse> getProfileMenu(@Header("Access-Token") String access_token, @Query("device_id") String device_id);


    //Company Profile Section

    @GET("CompanyProfile/company-size")
    Call<CompanySizeResponse> getCompanySize(@Header("Access-Token") String access_token);


    @GET("CompanyProfile/industries-list")
    Call<IndustriesListResponse> getIndustryList(@Header("Access-Token") String access_token);

    @GET("CompanyProfile/business-types")
    Call<TypeOfBussinessResponse> getTypeOfBussiness(@Header("Access-Token") String access_token);


    @GET("CompanyProfile/currencies-list")
    Call<CurrenciesListResponse> getCurrencyList(@Header("Access-Token") String access_token);


    @GET("CompanyProfile/company-profile-details")
    Call<CompanyProfileDetailResponseModel> getCompanyProfileDetails(@Header("Access-Token") String access_token,
                                                                     @Query("company_id") String id,
                                                                     @Query("slug") String slug);

    @GET("CompanyProfile/my-company-profile")
    Call<PublicCompanyProfileResponse> getMyCompanyProfile(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("CompanyProfile/create-company-profile")
    Call<CreateCompanyProfile> createCompanyProfile(@Header("Access-Token") String access_token,
                                                    @Field("company_bio") String company_bio,
                                                    @Field("address") String address,
                                                    @Field("telephone_number") String telephone_number,
                                                    @Field("country_code") String country_code,
                                                    @Field("city_id") String city_id,
                                                    @Field("zip_code") String zip_code,
                                                    @Field("company_size") String company_size,
                                                    @Field("industry") String industry,
                                                    @Field("website") String website,
                                                    @Field("business") String business,
                                                    @Field("currency") Integer currency);

    @FormUrlEncoded
    @POST("CompanyProfile/update-company-profile")
    Call<GeneralResponse> updateCompanyProfile(@Header("Access-Token") String access_token,
                                               @Field("company_bio") String company_bio,
                                               @Field("country_code") String country_code,
                                               @Field("city_id") Integer city_id,
                                               @Field("telephone_number") String telephone_number);


    @FormUrlEncoded
    @POST("CompanyProfile/update-step-one")
    Call<GeneralResponse> updateCompanyProfileStepOne(@Header("Access-Token") String access_token,
                                                      @Field("address") String address,
                                                      @Field("country_code") String country_code,
                                                      @Field("city_id") String city_id,
                                                      @Field("zip_code") String zip_code,
                                                      @Field("telephone") String telephone);


    @POST("CompanyProfile/update-step-two")
    Call<GeneralResponse> updateCompanyProfileStepTwo(@Header("Access-Token") String access_token,
                                                      @Body CompanyProfileSettingsPageTwo.CompanyProfileStepTwoPostParams params);

    @FormUrlEncoded
    @POST("CompanyProfile/update-step-three")
    Call<GeneralResponse> updateCompanyProfileStepThree(@Header("Access-Token") String access_token,
                                                        @Field("industries[]") ArrayList<String> industries);

    @FormUrlEncoded
    @POST("CompanyProfile/update-step-four")
    Call<GeneralResponse> updateCompanyProfileStepFour(@Header("Access-Token") String access_token,
                                                       @Field("business[]") ArrayList<String> business);

    @GET("CompanyProfile/company-interest")
    Call<CompanyInterestListResponse> getCompanyInterestList(@Header("Access-Token") String access_token);


    @POST("CompanyProfile/company-interest-update")
    Call<UpdateInterestCompanyResponse> updateCompanyInterest(@Header("Access-Token") String access_token,
                                                              @Body MarketPlaceInterestPage.UpdateInterestPostModel params);


    //Network Section
    @FormUrlEncoded
    @POST("Network/networks-pagination")
    Call<NetworkListResponse> getNetworkByPage(@Header("Access-Token") String access_token, @Field("offset") int offset, @Field("user_id") String user_id, @Field("keyword") String keyword, @Field("limit") int limit);


    @FormUrlEncoded
    @POST("Network/dealer-add")
    Call<GeneralResponse> addNetworkDealers(@Header("Access-Token") String access_token,
                                            @Field("company_ids[]") ArrayList<String> company_ids);


    @GET("Network/network-dealers-list")
    Call<NetworkDealersResponse> getNetworkDealers(@Header("Access-Token") String access_token);


    @FormUrlEncoded
    @POST("Network/network-employees")
    Call<GetNetworkEmployeeResponse> getNetworkEmployee(@Header("Access-Token") String access_token,
                                                        @Field("company_id") int company_id,
                                                        @Field("limit") int limit,
                                                        @Field("offset") int offset,
                                                        @Field("keyword") String keyword,
                                                        @Field("type") String type);


    @POST("Listing/listing-network-employees")
    Call<GetNetworkEmployeeResponse> getListingNetworkEmployee(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Listing/listing-dealers")
    Call<ListingDealerResponseModel> getListingDealers(@Header("Access-Token") String access_token,
                                                       @Field("listing_id") String listing_id,
                                                       @Field("dealer_id") String dealer_id);

    @GET("Network/network-groups")
    Call<NetworkGroupResponse> getNetworkGroup(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Network/network-group-add")
    Call<NetworkGroupResponse> addNetworkGroup(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Network/network-remove")
    Call<GeneralResponse> removeNetwork(@Header("Access-Token") String access_token,
                                        @Field("network_company") int network_company);


    @FormUrlEncoded
    @POST("Network/dealer-remove")
    Call<GeneralResponse> removeDealer(@Header("Access-Token") String access_token,
                                       @Field("dealer_id") int dealer_id);

    @GET("Network/dealer-group")
    Call<DealerGroupResponse> getDealerGroup(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Connect/do-network-request")
    Call<GeneralResponse> doNetworkRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Connect/do-network-request")
    Call<GeneralResponse> doNetworkRequestWithTrackId(@Header("Access-Token") String access_token, @Field("con_id") String con_id,@Field("track_id") String track_id,@Field("type") String type);

    @FormUrlEncoded
    @POST("Connect/do-network-request")
    Call<GeneralResponse> doNetworkRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id, @Field("type") String type);


    @FormUrlEncoded
    @POST("Connect/do-company-network-request")
    Call<GeneralResponse> doNetworkRequestOnly(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    //NewsFeed Section
   /* @FormUrlEncoded
    @POST("NewsFeed/newsfeed-add")
    Call<CreatePostResponse> createPost(@Header("Access-Token") String access_token,
                                        @Field("is_company_news") String is_company_news,
                                        @Field("post_type") String post_type,
                                        @Field("asset") String asset,
                                        @Field("privacy_id") String privacy_id,
                                        @Field("tag_id[]") ArrayList<String> tag_id,
                                        @Field("groups[]") ArrayList<String> groups,
                                        @Field("desc") String desc,
                                        @Field("title") String title);*/

    @POST("NewsFeed/newsfeed-add")
    Call<CreatePostResponse> createPost(@Header("Access-Token") String access_token,
                                        @Body CreatePostData createPostData);

    @GET("NewsFeed/newsfeed-list-new")
    Call<NewsFeedListResponse> getNewsFeedList(@Header("Access-Token") String access_token, @Query("last-num") String last_num, @Query("limit") int limit);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-company-list-new")
    Call<CompanyNewsFeedResponse> getCompanyNewsFeed(@Header("Access-Token") String access_token, @Query("last-num") String last_num, @Query("limit") int limit, @Field("company_id") String company_id);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-user-list-new")
    Call<PersonalNewsFeedResponse> getPersonalNewsFeed(@Header("Access-Token") String access_token, @Query("last-num") String last_num, @Query("limit") int limit, @Field("user_id") String user_id);

   @FormUrlEncoded
   @POST("NewsFeed/my-newsfeed-list")
   Call<PersonalNewsFeedResponse> getMyNewsFeed(@Header("Access-Token") String access_token, @Query("last-num") String last_num, @Query("limit") int limit,@Field("user_id") String user_id);


    @FormUrlEncoded
    @POST("Connections/my-connections-pagination")
    Call<ConnectionResponse> getConnectionByPage(@Header("Access-Token") String access_token, @Field("offset") int offset, @Field("company_id") String company_id, @Field("keyword") String keyword, @Field("limit") int limit);


    @GET("Connections/my-connections")
    Call<ConnectionResponse> getConnectionsList(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Connect/connection-request")
    Call<SentConnectionRequestResponse> sentConnectionRequest(@Header("Access-Token") String access_token,
                                                              @Field("to_connection") int to_connection);

    @FormUrlEncoded
    @POST("Connections/connection-remove")
    Call<GeneralResponse> removeConnectionRequest(@Header("Access-Token") String access_token,
                                                  @Field("con_id") int con_id);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-tag-connections")
    Call<TagConnectionNewsFeedPost> getTagConnectionsNewsFeed(@Header("Access-Token") String access_token,
                                                              @Field("privacy_id") String privacy_id,
                                                              @Field("ngids[]") ArrayList<String> ngids,
                                                              @Field("dgids[]") ArrayList<String> dgids,
                                                              @Field("offset") int offset,
                                                              @Field("limit") int limit,
                                                              @Field("keyword") String keyword);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-like")
    Call<NewsFeedLikeResponse> newsFeedLike(@Header("Access-Token") String access_token,
                                            @Field("post_id") String postId,
                                            @Field("like") String like);


    @FormUrlEncoded
    @POST("Article/article-like")
    Call<GeneralResponse> articleLike(@Header("Access-Token") String access_token,
                                      @Field("article_id") int article_id,
                                      @Field("like") int like);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-comment-list")
    Call<CommentsResponse> getComments(@Header("Access-Token") String access_token,
                                       @Field("post_id") String post_id);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-child-comment-list")
    Call<ChildCommentResponse> getChildComments(@Header("Access-Token") String access_token,
                                                @Field("cmt_id") String cmt_id);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-comment-add")
    Call<CommentPostModel> postComment(@Header("Access-Token") String access_token,
                                       @Field("post_id") String post_id,
                                       @Field("comment") String comment);

    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-reply-add")
    Call<ChildCommentAddResponse> postChildComment(@Header("Access-Token") String access_token,
                                                   @Field("cmt_id") String cmt_id,
                                                   @Field("cmt") String cmt);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-comment-like")
    Call<CommentLikeResponse> postCommentLike(@Header("Access-Token") String access_token,
                                              @Field("comment_id") String comment_id,
                                              @Field("like") String like);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-child-comment-like")
    Call<CommentLikeResponse> postChildCommentLike(@Header("Access-Token") String access_token,
                                                   @Field("cmt_id") String cmt_id,
                                                   @Field("like") String like);

    @FormUrlEncoded
    @POST("UserProfile/push-notification-token")
    Call<GeneralResponse> sendPushNotificationToken(@Header("Access-Token") String access_token,
                                                    @Field("device_id") String device_id,
                                                    @Field("device_token") String device_token,
                                                    @Field("device_new_token") String device_new_token,
                                                    @Field("device_type") String device_type);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-comment-remove")
    Call<GeneralResponse> newsFeedCommentRemove(@Header("Access-Token") String access_token,
                                                @Field("comment_id") String comment_id);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-child-comment-remove")
    Call<GeneralResponse> newsFeedChildCommentRemove(@Header("Access-Token") String access_token,
                                                     @Field("cmt_id") String cmt_id);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-remove")
    Call<GeneralResponse> newsFeedRemove(@Header("Access-Token") String access_token,
                                         @Field("post_id") String post_id);


    @GET("CompanyProfile/company-invitation")
    Call<InviteCompaniesResponse> inviteCompanies(@Header("Access-Token") String access_token);


    @FormUrlEncoded
    @POST("UserAuthorization/url-extractor")
    Call<UrlScrapperResponse> urlScrapper(@Field("url") String url);

    @FormUrlEncoded
    @POST("UserProfile/logout")
    Call<GeneralResponse> logOut(@Header("Access-Token") String access_token,
                                 @Field("history_id") int history_id);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-company-list")
    Call<GeneralResponse> getNewsFeedForCompanyProfile(@Header("Access-Token") String access_token, @Field("company_id") String company_id, @Field("limit") String limit, @Field("offset") String offset);

    @FormUrlEncoded
    @POST("Network/network-employees")
    Call<ConnectionsForCompanyProfileViewResponse> getConnectionsForCompanyProfileView(@Header("Access-Token") String access_token, @Field("company_id") String company_id);


    @FormUrlEncoded
    @POST("Network/network-public-dealers")
    Call<DealersForCompanyProfileViewPage> getDealersForCompanyProfileView(@Header("Access-Token") String access_token, @Field("company_id") String company_id);


    @POST("NewsFeed/newsfeed-share")
    Call<GeneralResponse> shareToKrank(@Header("Access-Token") String access_token, @Body ShareToKrankPost shareToKrankPost);

    @FormUrlEncoded
    @POST("Search/search")
    Call<SearchResponseModel> searhcKrank(@Header("Access-Token") String access_token, @Field("keyword") String keyword, @Field("stP") int stp, @Field("enP") int enP, @Field("type") String type);


    @FormUrlEncoded
    @POST("Listing/listing-detail")
    Call<ListingDetailResponseModel> getListingDetail(@Header("Access-Token") String access_token,
                                                      @Field("listing") String listing,
                                                      @Field("listing_id") String listing_id);


    @GET("Network/pending-receive-request")
    Call<PendingRecieveRequestResponseModel> getPendingReceiveRequests(@Header("Access-Token") String access_token);


    @GET("Network/pending-sent-request")
    Call<PendingRecieveRequestResponseModel> getPendingSentRequests(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Connect/accept-connection-request")
    Call<GeneralResponse> acceptConnectionRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Connect/reject-connection-request")
    Call<GeneralResponse> rejectConnectionRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Connect/accept-network-request")
    Call<GeneralResponse> acceptNetworkRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Connect/reject-network-request")
    Call<GeneralResponse> rejectNetworkRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);


    @FormUrlEncoded
    @POST("Network/dealer-request")
    Call<GeneralResponse> acceptRejectDealerRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id, @Field("request_type") String request_type);


    @FormUrlEncoded
    @POST("Connect/cancel-connection-request")
    Call<GeneralResponse> cancelConnectionRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);


    @FormUrlEncoded
    @POST("Connect/cancel-network-request")
    Call<GeneralResponse> cancelNetworkRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Connect/cancel-dealer-request")
    Call<GeneralResponse> cancelDealerRequest(@Header("Access-Token") String access_token, @Field("con_id") String con_id);

    @FormUrlEncoded
    @POST("Listing/public-marketplace")
    Call<PublicMarketPlaceResponse> getPublicMarketPlaceData(@Header("Access-Token") String access_token,
                                                             @Field("listing_type") String listing_type,
                                                             @Field("category_id") String category_id,
                                                             @Field("sub_category_id") String sub_category_id,
                                                             @Field("type_id") String type_id,
                                                             @Field("keyword") String keyword,
                                                             @Field("search_type") String search_type,
                                                             @Field("sort_by") String sort_by,
                                                             @Field("sort_by_network") String sort_by_network,
                                                             @Field("sort_by_connection") String sort_by_connection,
                                                             @Field("offset") int offset,
                                                             @Field("limit") int limit);

    @FormUrlEncoded
    @POST("Listing/network-marketplace")
    Call<PublicMarketPlaceResponse> getNetworkMarketPlaceData(@Header("Access-Token") String access_token,
                                                              @Field("listing_type") String listing_type,
                                                              @Field("category_id") String category_id,
                                                              @Field("sub_category_id") String sub_category_id,
                                                              @Field("type_id") String type_id,
                                                              @Field("keyword") String keyword,
                                                              @Field("search_type") String search_type,
                                                              @Field("sort_by") String sort_by,
                                                              @Field("sort_by_network") String sort_by_network,
                                                              @Field("sort_by_connection") String sort_by_connection,
                                                              @Field("offset") int offset,
                                                              @Field("limit") int limit);

    @FormUrlEncoded
    @POST("Listing/listing-user")
    Call<PublicMarketPlaceResponse> getUserListing(@Header("Access-Token") String access_token,
                                                   @Field("offset") String offset,
                                                   @Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("Listing/my-listing")
    Call<PublicMarketPlaceResponse> getMyListingData(@Header("Access-Token") String access_token,
                                                     @Field("listing_type") String listing_type,
                                                     @Field("category_id") String category_id,
                                                     @Field("sub_category_id") String sub_category_id,
                                                     @Field("type_id") String type_id,
                                                     @Field("keyword") String keyword,
                                                     @Field("search_type") String search_type,
                                                     @Field("sort_by") String sort_by,
                                                     @Field("sort_by_network") String sort_by_network,
                                                     @Field("sort_by_connection") String sort_by_connection,
                                                     @Field("offset") int offset,
                                                     @Field("limit") int limit);


    @FormUrlEncoded
    @POST("Listing/listing-catsubtype")
    Call<ListingFilterDataResponse> getListingFilterData(@Header("Access-Token") String access_token, @Field("category_id") String category_id, @Field("sub_category_id") String sub_category_id);

    @FormUrlEncoded
    @POST("Listing/listing-favorite")
    Call<AddRemoveFavResponse> listingFavUnFav(@Header("Access-Token") String access_token,
                                               @Field("listing_id") String listing_id,
                                               @Field("fav_id") String fav_id,
                                               @Field("action") String action);

    @GET("Notification/notification-list")
    Call<NotificationListResponse> getNotificationList(@Header("Access-Token") String access_token, @Query("offset") String offset, @Query("limit") int limit);

    @FormUrlEncoded
    @POST("Notification/notification-read")
    Call<GeneralResponse> setNotificationRead(@Header("Access-Token") String access_token, @Field("nid") String nid);

    @FormUrlEncoded
    @POST("Notification/notification-delete")
    Call<GeneralResponse> deleteNotification(@Header("Access-Token") String access_token, @Field("nid[]") ArrayList<String> nids);


    @FormUrlEncoded
    // @POST("Posts/share-on-myfeed")
    @POST("NewsFeed/newsfeed-share")
    Call<GeneralResponse> listingShare(@Header("Access-Token") String access_token,
                                       @Field("track_id") String track_id,
                                       @Field("post_from") String post_from,
                                       @Field("privacy_id") String privacy_id,
                                       @Field("group_ids[]") ArrayList<String> group_ids,
                                       @Field("post_title") String post_title);


    @GET("NewsFeed/newsfeed")
    Call<NewsFeedByIdResponse> newsFeedGetById(@Header("Access-Token") String access_token,
                                               @Query("nfid") String nfid);


    @FormUrlEncoded
    @POST("NewsFeed/newsfeed-comment-childs")
    Call<CommentGetByIdResponse> commentGetById(@Header("Access-Token") String access_token,
                                                @Field("post_id") String post_id,
                                                @Field("cmt_id") String cmt_id);

    @GET("Listing/listing-login")
    Call<ListingWebviewResponse> ListingLogin(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Listing/listing-delete")
    Call<GeneralResponse> listingDelete(@Header("Access-Token") String access_token, @Field("listing_id") String listing_id);

    @FormUrlEncoded
    @POST("Listing/listing-status")
    Call<GeneralResponse> listingStatus(@Header("Access-Token") String access_token, @Field("listing_id") String listing_id, @Field("listing_status") String listing_status);

    @GET("UserProfile/profile-wizard-close")
    Call<GeneralResponse> profileWizardClose(@Header("Access-Token") String access_token);


    @GET("Chat/conversation-list")
    Call<ChatConversationListResponse> getChatConversationList(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("UserProfile/change-password")
    Call<GeneralResponse> updatePassword(@Header("Access-Token") String access_token, @Field("password_old") String password_old, @Field("password_new") String password_new, @Field("password_confirm") String password_confirm);

    @FormUrlEncoded
    @POST("Chat/user-search")
    Call<ChatSearchPeopleListResponse> getSearchChatPeople(@Header("Access-Token") String access_token,
                                                           @Field("keyword") String keyword);

    @FormUrlEncoded
    @POST("Chat/user-conversation-list")
    Call<PrivateChatMessagesResponse> getPrivateChatMessages(@Header("Access-Token") String access_token,
                                                             @Field("conv_id") String conv_id,
                                                             @Field("latest_id") String latest_id,
                                                             @Field("first_id") String first_id,
                                                             @Field("limit[]") ArrayList<String> limit,
                                                             @Field("sort_by") String sort_by);


    @FormUrlEncoded
    @POST("Chat/send-message")
    Call<SendMessagePersonalChatResponseForExistingChat> sendChatMsg(@Header("Access-Token") String access_token,
                                                                     @Field("conv_id") String conv_id,
                                                                     @Field("message_body") String message_body,
                                                                     @Field("message_type") String message_type,
                                                                     @Field("message_attachment[]") ArrayList<String> message_attachment,
                                                                     @Field("device_id") String device_id);


    @FormUrlEncoded
    @POST("Chat/group-conversation-send")
    Call<GroupConversationSendResponse> sendGroupChatMsg(@Header("Access-Token") String access_token,
                                                         @Field("group_id") String group_id,
                                                         @Field("member_id") String member_id,
                                                         @Field("message_body") String message_body,
                                                         @Field("message_type") String message_type,
                                                         @Field("message_attachment[]") ArrayList<String> message_attachment);

    @FormUrlEncoded
    @POST("Chat/start-conversation")
    Call<SendMessagePersonalChatResponse> chatStartConversation(@Header("Access-Token") String access_token,
                                                                @Field("message_to") String message_to,
                                                                @Field("message_body") String message_body,
                                                                @Field("message_type") String message_type,
                                                                @Field("message_attachment[]") ArrayList<String> message_attachment,
                                                                @Field("device_id") String device_id);


    @FormUrlEncoded
    @POST("Network/people-you-may-know")
    Call<GetNetworkEmployeeResponse> suggestedPeoples(@Header("Access-Token") String access_token,
                                                      @Field("offset") int offset,
                                                      @Field("limit") int limit);

    @FormUrlEncoded
    @POST("Chat/read-message")
    Call<GeneralResponse> readConversation(@Header("Access-Token") String access_token,
                                           @Field("conv_id") String conv_id);


    @GET("UserProfile/user-status")
    Call<UserOnlineStatusResponseModel> onlineStatus(@Header("Access-Token") String access_token,
                                                     @Query("history_id") int history_id);


    @GET("Chat/group-conversation-list")
    Call<GroupChatConversationResponse> groupConversationList(@Header("Access-Token") String access_token);


    @FormUrlEncoded
    @POST("Chat/group-conversation")
    Call<GroupChatMessagesResponse> getGroupMsgs(@Header("Access-Token") String access_token, @Field("member_id") String member_id, @Field("first_id") String first_id, @Field("latest_id") String latest_id, @Field("limit[]") ArrayList<String> limit, @Field("sort") String sort);


    @FormUrlEncoded
    @POST("Chat/group-conversation-create")
    Call<GroupConversationCreateResponse> createGroup(@Header("Access-Token") String access_token,
                                                      @Field("group_name") String group_name,
                                                      @Field("group_message") String group_message,
                                                      @Field("con_ids[]") ArrayList<String> con_ids);

    @FormUrlEncoded
    @POST("Chat/group-conversation-leave")
    Call<GeneralResponse> leaveGroup(@Header("Access-Token") String access_token,
                                     @Field("memb_id") String memb_id);


    @FormUrlEncoded
    @POST("Chat/group-notification")
    Call<GeneralResponse> muteNotificationGroupChat(@Header("Access-Token") String access_token,
                                                    @Field("memb_id") String memb_id,
                                                    @Field("noti_status") String noti_status);


    @GET("Chat/group-conversation-members")
    Call<GroupChatMembersResponse> groupMembersList(@Header("Access-Token") String access_token, @Query("group_id") String group_id);

    @GET("Notification/notification-badge")
    Call<NotificationMsgBadgeResponse> notification_msg_badge(@Header("Access-Token") String access_token);

    @FormUrlEncoded
    @POST("Chat/group-conversation-member-remove")
    Call<GeneralResponse> removeMemberFromGroup(@Header("Access-Token") String access_token, @Field("member_id") String member_id);

    @FormUrlEncoded
    @POST("Chat/group-conversation-member-add")
    Call<GroupConversationMemberAddResponseModel> addFurtherPeopleInGroupChat(@Header("Access-Token") String access_token, @Field("group_id") String group_id, @Field("con_ids[]") ArrayList<String> con_ids);


    @FormUrlEncoded
    @POST("UserAuthorization/company-invitation-verification")
    Call<CompanyInvitationResponse> companyInvitationVerification(@Field("invite_code") String invite_code, @Field("invite_type") String invite_type, @Field("is_dealer") int is_dealer);

    @FormUrlEncoded
    @POST("CompanyProfile/company-invitation-accept")
    Call<GeneralResponse> companyAcceptInvitation(@Header("Access-Token") String access_token, @Field("invite_code") String invite_code, @Field("dealer") String dealer);


    @FormUrlEncoded
    @POST("Chat/listing-send-message")
    Call<GeneralResponse> listingSendMsg(@Header("Access-Token") String access_token, @Field("userid_to") String userid_to, @Field("listing_id") String listing_id, @Field("type_id") String type_id, @Field("message_text") String message_text, @Field("isDealer") String dealer);

    @FormUrlEncoded
    @POST("Listing/listing-representative")
    Call<GeneralResponse> listingRepresentativePost(@Header("Access-Token") String access_token, @Field("listing_id") String listing_id, @Field("representative_id[]") ArrayList<String> representative_id);


    @FormUrlEncoded
    @POST("Connect/exclude-suggestion")
    Call<GeneralResponse> excludeConnections(@Header("Access-Token") String access_token, @Field("user_id") String user_id);


    @GET
    Call<String> _301RedirectRequest(@Url String url);

    @FormUrlEncoded
    @POST("Article/article-detail")
    Call<ArticleDetailResponseModel> articleDetail(@Header("Access-Token") String access_token, @Field("slug") String slug, @Field("article_id") int article_id);

    @FormUrlEncoded
    @POST("Network/more-network-groups")
    Call<NetworkListFromGroup> getNetworkListFromGroup(@Header("Access-Token") String access_token, @Field("group_id") String group_id, @Field("offset") int offset, @Field("limit") int limit);

    @FormUrlEncoded
    @POST("Network/more-dealer-groups")
    Call<DealerListFromGroup> getDealerListFromGroup(@Header("Access-Token") String access_token, @Field("group_id") String group_id, @Field("offset") int offset, @Field("limit") int limit);

    @FormUrlEncoded
    @POST("UserProfile/verify-cell-number-code")
    Call<GeneralResponse> verifyCellNumberCode(@Header("Access-Token") String access_token, @Field("mobile_number") String mobile_number, @Field("hash") String hash);

    @FormUrlEncoded
    @POST("UserProfile/verification-cell-number")
    Call<GeneralResponse> verifyCellNumber(@Header("Access-Token") String access_token, @Field("verify_code") String verify_code);


    @POST("Connect/mobile-contacts")
    Call<ContactsImportResponseModel> mobileContactsConnect(@Header("Access-Token") String access_token,
                                                            @Body ContactsPostDataModel postDataModel);

    @FormUrlEncoded
    @POST("Connect/connect-all-request")
    Call<GeneralResponse> connectAllRequest(@Header("Access-Token") String access_token,
                                            @Field("con_id[]") ArrayList<String> con_id,
                                            @Field("type") String String);

    @FormUrlEncoded
    @POST("Connect/mobile-contacts-delete")
    Call<GeneralResponse> unSyncMobileContacts(@Header("Access-Token") String access_token,
                                               @Field("sim_id") String sim_id,
                                               @Field("type") int type);


    @FormUrlEncoded
    @POST("Chat/send-message-company")
    Call<GeneralResponse> sendMessageToCompanyRep(@Header("Access-Token") String access_token,
                                                  @Field("message_to") String message_to,
                                                  @Field("message_body") String message_body);


    @POST("Connect/set-user-meta")
    Call<GeneralResponse> setUserMeta(@Header("Access-Token") String access_token,
                                      @Body UserMetaModelBody metaBody);

    @FormUrlEncoded
    @POST("Connections/private-connection")
    Call<GeneralResponse> privateConnection(@Header("Access-Token") String access_token,
                                      @Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("Connect/export-connections")
    Call<ExportConnectionsResponseModel> exportConnections(@Header("Access-Token") String access_token,
                                   @Field("current_password") String current_password,
                                   @Field("file_password") String file_password,
                                   @Field("file_password2") String file_password2);
}
