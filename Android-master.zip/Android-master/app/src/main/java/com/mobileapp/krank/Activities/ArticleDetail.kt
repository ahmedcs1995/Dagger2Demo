package com.mobileapp.krank.Activities

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.SimpleItemAnimator
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import cn.pedant.SweetAlert.SweetAlertDialog
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity
import com.mobileapp.krank.Adapters.ArticleDetailAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView
import com.mobileapp.krank.CallBacks.CustomShareCallBack
import com.mobileapp.krank.CallBacks.ResponseCallBacks
import com.mobileapp.krank.CustomViews.MyBounceInterpolator
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.launchActivity
import com.mobileapp.krank.Model.Enums.ConNetStatus
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.ArticleDetailDataModel
import com.mobileapp.krank.ResponseModels.ArticleDetailResponseModel
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse
import com.mobileapp.krank.Utils.ApiUtils
import com.mobileapp.krank.Utils.ShareBottomSheet
import kotlinx.android.synthetic.main.activity_article_detail.*
import kotlinx.android.synthetic.main.app_progress_bar.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

class ArticleDetail : BaseActivity(), CallBackWithAdapterPosAndType, CallBackWithPosTypeAndView {

    companion object {
        const val HEADER = 1
        const val USER_VIEW = 2
        const val DESCRIPTION = 3
        const val FOOTER = 4
        const val PRIVACY_ACTIVITY_CODE = 200

        //listeners values
        const val GOTO_USER_PROFILE = 1
        const val COMPANY_PROFILE = 2
        const val SHARE_CLICK = 3
        const val LIKE_CLICK = 4
        const val REQUEST = 5

        //intent extras
        const val ARTICLE_ID ="article_id"

    }

    private lateinit var adapter: ArticleDetailAdapter
    private lateinit var items: MutableList<Int>

    private var dateConvertFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")


    lateinit var myAnim: Animation

    internal lateinit var interpolator: MyBounceInterpolator

    internal lateinit var shareBottomSheet: ShareBottomSheet


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article_detail)

        setNormalPageToolbar(this)

        init()

        setUpBottomSheet()

        items = ArrayList()


        setUpAdapter()

        getArticleDetail()
    }

    private fun init() {

        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce)
        interpolator = MyBounceInterpolator(0.2, 20.0)


    }

    private fun setUpAdapter() {
        adapter = ArticleDetailAdapter(items, this, this, this)
        article_detail_recycler.adapter = adapter

        article_detail_recycler.layoutManager = LinearLayoutManager(this@ArticleDetail)

        (article_detail_recycler.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false

    }

    private fun setUpBottomSheet() {
        shareBottomSheet = ShareBottomSheet.Builder(this@ArticleDetail, preference)
                .setListeners(getShareCallBack())
                .create()
    }

    private fun getShareCallBack(): CustomShareCallBack {

        return CustomShareCallBack { selectedPrivacy, tempDealerGroup, tempNetworkGroup ->
            val intent = Intent(this@ArticleDetail, SelectPrivacyActivity::class.java)
            intent.putExtra("selected_privacy", gson.toJson(selectedPrivacy))
            intent.putExtra("selected_network_group", gson.toJson(tempNetworkGroup))
            intent.putExtra("selected_dealer_group", gson.toJson(tempDealerGroup))
            startActivityForResult(intent, PRIVACY_ACTIVITY_CODE)
        }
    }

    private fun getArticleDetail() {


        //   var slug = "article-testing"
        //  var slug = "video-test"
        // var slug = "testing-again"
        var id = 0

        var slug: String?

        if (intent.getStringExtra("slug") == null) {
            id = intent.getIntExtra(ARTICLE_ID, 0)
            slug = ""
        } else {
            slug = intent.getStringExtra("slug")
        }

        api.articleDetail(preference.getString(Constants.ACCESS_TOKEN), slug, id).enqueue(object : Callback<ArticleDetailResponseModel> {

            override fun onResponse(call: Call<ArticleDetailResponseModel>?, response: Response<ArticleDetailResponseModel>?) {

                Log.e("article res ", "==> " + gson.toJson(response!!.body()))
                Log.e("call", "==> " + gson.toJson(call!!.request()))

                loader.visibility = View.GONE

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response.body().data)

                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }
            }


            override fun onFailure(call: Call<ArticleDetailResponseModel>?, t: Throwable?) {
                loader.visibility = View.GONE
                onResponseFailure()
            }
        })
    }

    private fun onSuccess(data: ArticleDetailDataModel?) {
        if (data != null) {
            //for article img
            when {
                data.articleData.article_image == null -> {
                    article_img.visibility = View.GONE
                }
                data.articleData.article_image.isEmpty() -> {
                    article_img.visibility = View.GONE
                }
                else -> {
                    article_img.visibility = View.VISIBLE
                }
            }


            data.articleData.formattedDate = getFormattedDate(data.articleData.article_added)

            setNormalPageToolbar(data.articleData.first_name + " " + data.articleData.last_name + " 's Article")

            article_img.setImageURI("" + data.articleData.article_image)

            items.add(HEADER)
            items.add(USER_VIEW)
            items.add(DESCRIPTION)
            items.add(FOOTER)

            adapter.data = data

            adapter.notifyDataSetChanged()


        }
    }

    private fun getFormattedDate(date: String): String? {

        val cal = Calendar.getInstance()

        cal.time = dateConvertFormat.parse(date)

        var month: String = getMonthForInt(cal.get(Calendar.MONTH))

        return (month + " " + cal.get(Calendar.DAY_OF_MONTH) + "," + cal.get(Calendar.YEAR))
    }

    fun getMonthForInt(num: Int): String {
        var month = "wrong"
        val dfs = DateFormatSymbols()
        val months = dfs.months
        if (num in 0..11) {
            month = months[num]
        }
        return month
    }

    override fun act(position: Int, type: Int) {
        when (type) {

            GOTO_USER_PROFILE -> {
                this@ArticleDetail.launchActivity<UserProfileView> {
                    putExtra(UserProfileView.INTENT_USER_ID, adapter.data?.articleData?.user_id.toString())
                }
            }
            COMPANY_PROFILE -> {
                this@ArticleDetail.launchActivity<CompanyProfileView> {
                    putExtra(CompanyProfileView.INTENT_COMPANY_ID, adapter.data?.articleData?.company_id.toString())
                }
            }
            REQUEST -> {
                var con = AppUtils.getConNetStatus(adapter.data?.articleData?.conStatus)
                when (con) {
                    ConNetStatus.NOT_CONNECTED -> {
                        sendConnectionRequest(position)
                    }
                    ConNetStatus.INVITATION_RECEIVED -> {
                        startActivity(Intent(this@ArticleDetail, PendingRequestActivity::class.java))
                    }
                }
            }
        }
    }

    private fun sendConnectionRequest(position: Int) {


        adapter.data?.articleData?.conStatus = Constants.REQUEST_PENDING
        adapter.notifyItemChanged(position)


        //request from api
        api.doNetworkRequestWithTrackId(preference.getString(Constants.ACCESS_TOKEN), adapter.data?.articleData?.user_id.toString(),adapter.data?.articleData?.article_id.toString(),"Article").enqueue(object : Callback<GeneralResponse> {
            override fun onFailure(call: Call<GeneralResponse>?, t: Throwable?) {
                onResponseFailure()
                adapter.data?.articleData?.conStatus = Constants.REQUEST_PENDING
                adapter.notifyItemChanged(position)
            }

            override fun onResponse(call: Call<GeneralResponse>?, response: Response<GeneralResponse>?) {
                if (response == null) return

                if (response.isSuccessful) {
                    if (response.body().status != Constants.SUCCESS_STATUS) {
                        adapter.data?.articleData?.conStatus = Constants.REQUEST_PENDING
                        adapter.notifyItemChanged(position)
                    }
                    showToast(response.body().message)
                } else {
                    onResponseFailure()
                }
            }


        })
    }

    override fun act(position: Int, type: Int, view: View) {
        when (type) {
            LIKE_CLICK -> {
                //view animte
                myAnim.interpolator = interpolator
                view.startAnimation(myAnim)
                view.isEnabled = false

                //api
                articleLike(adapter.data?.articleData!!.article_id, adapter.data?.articleData!!.isLike, view)

                //update adapter
                if (adapter.data?.articleData?.isLike == 0) {
                    adapter.data?.articleData?.isLike = 1

                    adapter.data?.articleData?.likes = (adapter.data?.articleData?.likes!! + 1)
                } else {
                    adapter.data?.articleData?.isLike = 0

                    adapter.data?.articleData?.likes = (adapter.data?.articleData?.likes!! - 1)
                }
                adapter.notifyItemChanged(position)
            }
            SHARE_CLICK -> {
                view.startAnimation(myAnim)
                shareBottomSheet.openBottomSheetDialog(adapter.data?.articleData?.article_id!!, adapter.data?.page_title, adapter.data?.articleData?.article_url, Constants.ARTICLE_SHARE)
            }

        }
    }


    private fun articleLike(id: Int, isLike: Int, view: View) {
        api.articleLike(preference.getString(Constants.ACCESS_TOKEN), id, if (isLike == 1) 0 else 1).enqueue(object : Callback<GeneralResponse> {

            override fun onResponse(call: Call<GeneralResponse>?, response: Response<GeneralResponse>?) {
                view.isEnabled = true
            }

            override fun onFailure(call: Call<GeneralResponse>?, t: Throwable?) {
                view.isEnabled = true
            }
        })
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            if (requestCode == PRIVACY_ACTIVITY_CODE) {
                shareBottomSheet.updateDialogOnActivityResult(data)
            }
        }
    }


}

