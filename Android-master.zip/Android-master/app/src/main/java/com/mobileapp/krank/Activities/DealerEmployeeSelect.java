package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.mobileapp.krank.Adapters.DealerEmployeeAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDealerRepDataModel;
import com.mobileapp.krank.ResponseModels.ListingDealerResponseModel;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DealerEmployeeSelect extends BaseActivity {

    private RecyclerView networksRecyclerEmpView;
    private DealerEmployeeAdapter networksEmpRecyclerAdapter;
    List<ListingDealerRepDataModel> listingDealerRepDataModels;
    private ShimmerFrameLayout mShimmerViewContainer;
    View no_connection_text;
    View done_btn;
    public int selectedIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealer_employee_select);
        mShimmerViewContainer = findViewById(R.id.shimmer_view_container);
        mShimmerViewContainer.startShimmer();
        no_connection_text = findViewById(R.id.no_connection_text);
        done_btn = findViewById(R.id.done_btn);
        selectedIndex = -1;
        setUpAdapter();
        setCompanyNameOnToolbar(getIntent().getExtras().getString("company_name"));
        done_btn.setOnClickListener(view -> {
            if (selectedIndex != -1) {
                Intent intent = new Intent();
                intent.putExtra("selected_employee", gson.toJson(listingDealerRepDataModels.get(selectedIndex)));
                intent.putExtra("dealer_item_index", getIntent().getIntExtra("dealer_item_index",0));
                setResult(RESULT_OK, intent);
                finish();
            }


        });
    }

    private void setUpAdapter() {
        networksRecyclerEmpView = (RecyclerView) findViewById(R.id.view_network_employees);
        listingDealerRepDataModels = new ArrayList<>();
        networksEmpRecyclerAdapter = new DealerEmployeeAdapter(listingDealerRepDataModels, DealerEmployeeSelect.this);
        networksRecyclerEmpView.setLayoutManager(new LinearLayoutManager(DealerEmployeeSelect.this));
        networksRecyclerEmpView.setAdapter(networksEmpRecyclerAdapter);
        getData();
    }

    private void setCompanyNameOnToolbar(String companyName) {
        setNormalPageToolbar( companyName + "'s Representative");
    }

    private void getData() {
        getAPI().getListingDealers(preference.getString(Constants.ACCESS_TOKEN),getIntent().getExtras().getString("listing_id"),getIntent().getExtras().getString("companyId"))
                .enqueue(new Callback<ListingDealerResponseModel>() {
                    @Override
                    public void onResponse(Call<ListingDealerResponseModel> call, Response<ListingDealerResponseModel> response) {
                        if (response.isSuccessful()) {
                            ListingDealerRepDataModel listingDealerRepDataModel = gson.fromJson(getIntent().getStringExtra("selected_employee"),ListingDealerRepDataModel.class);

                            listingDealerRepDataModels.clear();
                            listingDealerRepDataModels.addAll(response.body().getData().getReps());
                            if(listingDealerRepDataModel!=null){
                                for(int i=0 ; i < listingDealerRepDataModels.size();i++){
                                    if(listingDealerRepDataModels.get(i).getId().equals(listingDealerRepDataModel.getId())){
                                        selectedIndex=i;
                                        listingDealerRepDataModels.get(i).setItemSelected(true);
                                        networksEmpRecyclerAdapter.prevData= listingDealerRepDataModels.get(i);
                                    }
                                }
                            }

                            networksEmpRecyclerAdapter.notifyDataSetChanged();
                            networksRecyclerEmpView.setVisibility(View.VISIBLE);
                        }
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);

                        if (listingDealerRepDataModels.size() <= 0) {
                            no_connection_text.setVisibility(View.VISIBLE);
                            networksRecyclerEmpView.setVisibility(View.GONE);
                        }

                    }

                    @Override
                    public void onFailure(Call<ListingDealerResponseModel> call, Throwable t) {
                        Log.e("view connection", "call" + appUtils.convertToJson(call.request()));

                        Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                        mShimmerViewContainer.stopShimmer();
                    }
                });
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
}
