package com.mobileapp.krank.ResponseModels.DataModel;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class CompanyProfileDetailDataModel {
    @SerializedName("user_id")
    @Expose
    private String user_id;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("company_hash")
    @Expose
    private String companyHash;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("business")
    @Expose
    private List<String> business = null;
    @SerializedName("currency_id")
    @Expose
    private String currencyId;
    @SerializedName("currency_name")
    @Expose
    private String currencyName;
    @SerializedName("zip_code")
    @Expose
    private String zipCode;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("package_id")
    @Expose
    private String packageId;
    @SerializedName("payment_status")
    @Expose
    private Object paymentStatus;
    @SerializedName("is_public")
    @Expose
    private String isPublic;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("cover_pic")
    @Expose
    private String coverPic;
    @SerializedName("cover_setting")
    @Expose
    private String coverSetting;
    @SerializedName("telephone_number")
    @Expose
    private String telephoneNumber;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    @SerializedName("company_size_name")
    @Expose
    private String companySizeName;
    @SerializedName("company_bio")
    @Expose
    private String companyBio;
    @SerializedName("company_latlng")
    @Expose
    private String companyLatlng;
    @SerializedName("city_id")
    @Expose
    private String cityId;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("country_code")
    @Expose
    private String countryCode;
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("dialing_code")
    @Expose
    private String dialingCode;
    @SerializedName("size")
    @Expose
    private SizeForPublicCompanyProfileData size;
    @SerializedName("country")
    @Expose
    private CountryForPublicCompanyProfileData country;
    @SerializedName("city")
    @Expose
    private CityForPublicCompanyProfileData city;
    @SerializedName("interest")
    @Expose
    private List<String> interest = null;
    @SerializedName("currency")
    @Expose
    private CurrencyForPublicCompanyProfileData currency;
    @SerializedName("industry")
    @Expose
    private List<String> industry = null;
    @SerializedName("network_info")
    @Expose
    private String network_info;

    @SerializedName("my_connections")
    @Expose
    private List<ConnectionsForCompanyProfileViewDataModel> my_connections = null;

    @SerializedName("connections")
    @Expose
    private List<ConnectionsForCompanyProfileViewDataModel> connections = null;

    @SerializedName("my_dealers")
    @Expose
    private List<DealersDataForCompanyProfileViewPage> my_dealers = null;


    @SerializedName("dealer_of")
    @Expose
    private List<DealersDataForCompanyProfileViewPage> dealer_of = null;

    private String businessValue;
    private String industryValue;


    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyHash() {
        return companyHash;
    }

    public void setCompanyHash(String companyHash) {
        this.companyHash = companyHash;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public List<String> getBusiness() {
        return business;
    }

    public void setBusiness(List<String> business) {
        this.business = business;
    }

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public Object getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(Object paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getIsPublic() {
        return isPublic;
    }

    public void setIsPublic(String isPublic) {
        this.isPublic = isPublic;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCoverPic() {
        return coverPic;
    }

    public void setCoverPic(String coverPic) {
        this.coverPic = coverPic;
    }

    public String getCoverSetting() {
        return coverSetting;
    }

    public void setCoverSetting(String coverSetting) {
        this.coverSetting = coverSetting;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public String getCompanySizeName() {
        return companySizeName;
    }

    public void setCompanySizeName(String companySizeName) {
        this.companySizeName = companySizeName;
    }

    public String getCompanyBio() {
        return companyBio;
    }

    public void setCompanyBio(String companyBio) {
        this.companyBio = companyBio;
    }

    public String getCompanyLatlng() {
        return companyLatlng;
    }

    public void setCompanyLatlng(String companyLatlng) {
        this.companyLatlng = companyLatlng;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getDialingCode() {
        return dialingCode;
    }

    public void setDialingCode(String dialingCode) {
        this.dialingCode = dialingCode;
    }

    public SizeForPublicCompanyProfileData getSize() {
        return size;
    }

    public void setSize(SizeForPublicCompanyProfileData size) {
        this.size = size;
    }

    public CountryForPublicCompanyProfileData getCountry() {
        return country;
    }

    public void setCountry(CountryForPublicCompanyProfileData country) {
        this.country = country;
    }

    public CityForPublicCompanyProfileData getCity() {
        return city;
    }

    public void setCity(CityForPublicCompanyProfileData city) {
        this.city = city;
    }

    public List<String> getInterest() {
        return interest;
    }

    public void setInterest(List<String> interest) {
        this.interest = interest;
    }

    public CurrencyForPublicCompanyProfileData getCurrency() {
        return currency;
    }

    public void setCurrency(CurrencyForPublicCompanyProfileData currency) {
        this.currency = currency;
    }

    public List<String> getIndustry() {
        return industry;
    }

    public void setIndustry(List<String> industry) {
        this.industry = industry;
    }

    public String getBusinessValue() {
        return businessValue;
    }

    public void setBusinessValue(String businessValue) {
        this.businessValue = businessValue;
    }

    public String getIndustryValue() {
        return industryValue;
    }

    public void setIndustryValue(String industryValue) {
        this.industryValue = industryValue;
    }

    public String getNetwork_info() {
        return network_info;
    }

    public void setNetwork_info(String network_info) {
        this.network_info = network_info;
    }

    public List<ConnectionsForCompanyProfileViewDataModel> getMy_connections() {
        return my_connections;
    }

    public void setMy_connections(List<ConnectionsForCompanyProfileViewDataModel> my_connections) {
        this.my_connections = my_connections;
    }

    public List<ConnectionsForCompanyProfileViewDataModel> getConnections() {
        return connections;
    }

    public void setConnections(List<ConnectionsForCompanyProfileViewDataModel> connections) {
        this.connections = connections;
    }

    public List<DealersDataForCompanyProfileViewPage> getMy_dealers() {
        return my_dealers;
    }

    public void setMy_dealers(List<DealersDataForCompanyProfileViewPage> my_dealers) {
        this.my_dealers = my_dealers;
    }

    public List<DealersDataForCompanyProfileViewPage> getDealer_of() {
        return dealer_of;
    }

    public void setDealer_of(List<DealersDataForCompanyProfileViewPage> dealer_of) {
        this.dealer_of = dealer_of;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
