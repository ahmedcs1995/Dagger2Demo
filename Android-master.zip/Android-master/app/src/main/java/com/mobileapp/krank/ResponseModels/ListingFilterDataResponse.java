package com.mobileapp.krank.ResponseModels;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.ResponseModels.DataModel.ListingFilterDataModel;

public class ListingFilterDataResponse {

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<ListingFilterDataModel> data = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<ListingFilterDataModel> getData() {
        return data;
    }

    public void setData(List<ListingFilterDataModel> data) {
        this.data = data;
    }

}