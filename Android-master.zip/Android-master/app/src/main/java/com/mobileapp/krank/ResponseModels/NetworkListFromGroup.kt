package com.mobileapp.krank.ResponseModels

import com.google.gson.annotations.SerializedName
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList

data class NetworkListFromGroup (@SerializedName("status") val status : String,
                                 @SerializedName("message") val message : String,
                                 @SerializedName("data") val data : ArrayList<NetworkList>)

