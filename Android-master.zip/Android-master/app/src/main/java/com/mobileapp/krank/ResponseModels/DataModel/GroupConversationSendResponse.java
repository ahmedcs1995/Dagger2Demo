package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupConversationSendResponse {

    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("data")
    @Expose
    GroupConversationSendResponseDataModel data;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public GroupConversationSendResponseDataModel getData() {
        return data;
    }

    public void setData(GroupConversationSendResponseDataModel data) {
        this.data = data;
    }
}
