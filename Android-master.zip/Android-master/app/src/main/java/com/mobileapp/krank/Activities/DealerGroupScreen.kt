package com.mobileapp.krank.Activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.mobileapp.krank.Adapters.AppGeneralAdapter

import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.DealerGroupDataModel
import com.mobileapp.krank.ResponseModels.DealerGroupResponse
import com.mobileapp.krank.ViewHolders.NetworkDealerGroupViewHolder
import kotlinx.android.synthetic.main.activity_dealer_group_screen.*
import kotlinx.android.synthetic.main.app_progress_bar.*

import java.util.ArrayList
import java.util.Arrays

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DealerGroupScreen : BaseActivity() {

    //list items
    internal lateinit var dealerGroupList: MutableList<DealerGroupDataModel>
    private lateinit var dealerGroupRecyclerAdapter: AppGeneralAdapter<DealerGroupDataModel>


    //previous selected
    internal var dealerDataReceived: List<DealerGroupDataModel>? = null

    //adapter listeners
    private lateinit var callBack: CallBackWithAdapterPosAndType


    private val selectedDealerGroup: List<DealerGroupDataModel>
        get() {

            val dealerGroup = ArrayList<DealerGroupDataModel>()
            for (item in dealerGroupList) {
                if (item.isItemChecked) {
                    dealerGroup.add(item)
                }
            }
            return dealerGroup
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dealer_group_screen)

        setUpCallBack()



        setNormalPageToolbar( "Dealer Groups")

        setUpAdapter()


        getDealerGroupData()


        onBindDoneBtn()

    }
    private fun setUpCallBack(){
        callBack = object : CallBackWithAdapterPosAndType{
            override fun act(position: Int, type: Int) {
                when(type){
                    NetworkDealerGroupViewHolder.ITEM_CLICK -> {
                        dealerGroupList[position].isItemChecked = !dealerGroupList[position].isItemChecked
                        dealerGroupRecyclerAdapter.updateListItem(position)
                    }
                    NetworkDealerGroupViewHolder.MORE_BTN_CLICK -> {
                        //goto Next Page
                        val intent = Intent(this@DealerGroupScreen,NetworkAndDealerListInGroup::class.java)
                        with(intent){
                            putExtra("id",dealerGroupList[position].id)
                            putExtra(NetworkAndDealerListInGroup.PAGE_KEY,NetworkAndDealerListInGroup.DEALER_LIST)
                            putExtra(NetworkAndDealerListInGroup.PAGE_TITLE,dealerGroupList[position].groupName)

                        }
                        startActivity(intent)
                    }
                }
            }
        }
    }

    private fun onBindDoneBtn() {
        done_btn.setOnClickListener {
            if (dealerGroupList != null) {
                val selectedDealerGroup = selectedDealerGroup
                if (selectedDealerGroup.isNotEmpty()) {
                    val intent = Intent()
                    Log.e("selected dealer groups", "" + appUtils.convertToJson(selectedDealerGroup))
                    intent.putExtra("SelectedDealerGroup", "" + appUtils.convertToJson(selectedDealerGroup))
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                    overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
                } else {
                    Toast.makeText(this@DealerGroupScreen, "Please Select Dealer Group", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    private fun setUpAdapter() {
        dealerGroupList = ArrayList()
        dealerGroupRecyclerAdapter = object : AppGeneralAdapter<DealerGroupDataModel>(dealerGroupList) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: DealerGroupDataModel, position: Int) {
                if (viewHolder is NetworkDealerGroupViewHolder) {
                    viewHolder.onBindDealerGroup(item, this@DealerGroupScreen)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.dealer_group_parent_item, parent, false)
                return NetworkDealerGroupViewHolder(v, callBack)
            }
        }
        dealer_group_recycler_view.layoutManager = LinearLayoutManager(this@DealerGroupScreen)
        dealer_group_recycler_view.adapter = dealerGroupRecyclerAdapter
        dealerGroupRecyclerAdapter.setItemAnimator(dealer_group_recycler_view)
    }


    private fun getDealerGroupData() {
        api.getDealerGroup(preference.getString(Constants.ACCESS_TOKEN)).enqueue(object : Callback<DealerGroupResponse> {
            override fun onResponse(call: Call<DealerGroupResponse>, response: Response<DealerGroupResponse>) {
                hideLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }
            }

            override fun onFailure(call: Call<DealerGroupResponse>, t: Throwable) {
                hideLoader()
                onResponseFailure()
            }
        })
    }

    private fun onSuccess(response: Response<DealerGroupResponse>) {
        //previous screen data
        val dataReceived = intent.getStringExtra("selectedArray").toString()

        dealerDataReceived = Arrays.asList(*gson.fromJson(dataReceived, Array<DealerGroupDataModel>::class.java))

        //updating data

        if (dealerDataReceived != null) {
            for (i in dealerGroupList.indices) {
                for (j in dealerDataReceived!!.indices) {
                    if (dealerDataReceived!![j].id == dealerGroupList!![i].id) {
                        dealerGroupList[i].isItemChecked = dealerDataReceived!![j].isItemChecked
                    }
                }
            }
        }



        dealerGroupRecyclerAdapter.addAll(response.body().data)

        checkForData()
    }


    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    private fun checkForData() {
        if (dealerGroupList.size <= 0) {
            no_dealer_group_text.visibility = View.VISIBLE
        }
    }

    private fun hideLoader() {
        loader.visibility = View.GONE
    }
}
