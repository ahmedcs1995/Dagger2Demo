package com.mobileapp.krank.Model.Enums;

/**
 * Created by Yaseen on 03/05/2018.
 */

public enum TypeOfNotification {
    CONNECTION_REQUEST,
    CONNECTION_REQUEST_WITH_BTNS,
    NETWORK_REQUEST,
    NETWORK_REQUEST_WITH_BTNS,
    DEALER_REQUEST,
    DEALER_REQUEST_WITH_BTNS,
    TAG,
    LISTING,
    POST_LIKE,
    COMMENT_REPLY_LIKE,
    COMMENT_LIKE,
    COMMENT_CHILD,
    LOADER,
    COMMENTS,
    OTHER,
    GROUP_CHAT,
    ARTICLE,
    DISCOVER
}
