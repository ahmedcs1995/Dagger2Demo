package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ConnectionsDataModel {

    public static final String PRIVATE_CONNECTION = "private";
    public static final String NORMAL_CONNECTION = "normal";

    private int type;

    @SerializedName("total_connections")
    @Expose
    private String totalConnections;
    @SerializedName("network_connection")
    @Expose
    private String networkConnection;

    @SerializedName("con_type")
    @Expose
    private String con_type;

    @SerializedName("company_data")
    @Expose
    private ConnectionsCompanyData companyData;
    boolean isItemCheck;


    public boolean isItemCheck() {
        return isItemCheck;
    }

    public void setItemCheck(boolean itemCheck) {
        isItemCheck = itemCheck;
    }

    public String getTotalConnections() {
        return totalConnections;
    }

    public void setTotalConnections(String totalConnections) {
        this.totalConnections = totalConnections;
    }

    public ConnectionsDataModel(String networkConnection) {
        this.networkConnection = networkConnection;
    }

    public String getNetworkConnection() {
        return networkConnection;
    }

    public void setNetworkConnection(String networkConnection) {
        this.networkConnection = networkConnection;
    }

    public ConnectionsCompanyData getCompanyData() {
        return companyData;
    }

    public void setCompanyData(ConnectionsCompanyData companyData) {
        this.companyData = companyData;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public ConnectionsDataModel(int type) {
        this.type = type;
    }

    public String getCon_type() {
        return con_type;
    }

    public void setCon_type(String con_type) {
        this.con_type = con_type;
    }

    public boolean isConnectionPrivate(){
        if(con_type == null) return false;

        if(con_type.toLowerCase().equals(PRIVATE_CONNECTION)) return true;

        return false;
    }
}
