package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.HomePageTabs.Newsfeed;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.InviteCoWorkersViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.InviteCompaniesViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.KrankPostViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.Loader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.RetryButtonViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ShareAndUpdateViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.SuggestedConnectionViewHolders;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VerifyPhoneNumberViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.List;

/**
 * Created by Ahmed on 4/20/2018.
 */

public class NewsFeedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public List<NewsFeedArray> items;

    //horizontal list
    public List<GetNetworkEmployeeData> suggestedPeoples;


    //horizontal adapter flag
    boolean updateInnerAdapter;

    //remove the horizontal_thread
    CustomCallBack removeCallBack;

    public SaveInSharedPreference preference;
    DeviceInfo deviceInfo;
    Newsfeed newsfeed;
    NewsFeedFunctions newsFeedFunctions;


    //callBack
    CallBackWithPosTypeAndView callBack;

    //phoneNumber
    VerifyPhoneNumberViewHolder.PhoneNumberCallBack phoneNumberCallBack;


    public void setListener(CallBackWithPosTypeAndView callBack) {
        this.callBack = callBack;
    }
    public void setPhoneNumberListeners(VerifyPhoneNumberViewHolder.PhoneNumberCallBack phoneNumberCallBack) {
        this.phoneNumberCallBack = phoneNumberCallBack;
    }

    public NewsFeedAdapter(List<NewsFeedArray> items, DeviceInfo deviceInfo, Newsfeed newsfeed, SaveInSharedPreference preference, List<GetNetworkEmployeeData> suggestedPeoples) {
        this.items = items;
        this.preference = preference;
        this.suggestedPeoples = suggestedPeoples;
        this.deviceInfo = deviceInfo;
        this.newsfeed = newsfeed;
        newsFeedFunctions = new NewsFeedFunctions(newsfeed, deviceInfo, false);

        //suggested connections
        removeCallBack = () -> {
            removeHorizontalAdapter();
        };
    }

    private void removeHorizontalAdapter() {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getPostType() == Constants.SUGGESTED_CONNECTIONS) {
                items.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }

    public void setUpdateInnerAdapter(boolean updateInnerAdapter) {
        this.updateInnerAdapter = updateInnerAdapter;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case Constants.SHARE_UPDATE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_one_header_post_item, parent, false);
                return new ShareAndUpdateViewHolder(view, callBack);
            case Constants.INVITE_COMPANIES:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_two_header_post_item, parent, false);
                return new InviteCompaniesViewHolder(view, callBack);
            case Constants.ADD_CO_WORKERS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_three_header_post_item, parent, false);
                return new InviteCoWorkersViewHolder(view, callBack);
            case Constants.TEXT_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_post_item_layout, parent, false);
                return new TextPostHolder(view, callBack);
            case Constants.IMAGE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_post_item_layout, parent, false);
                return new ImageViewHolder(view, callBack);
            case Constants.LINKED_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view, callBack);
            case Constants.LOADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case Constants.CHECK_IN:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkin_post_item_layout, parent, false);
                return new CheckInHolder(view, callBack);
            case Constants.NETWORK_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_post_item_layout, parent, false);
                return new NetworkPost(view, callBack);
            case Constants.LISTING_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.YOUTUBE_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.ARTICLE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.DEALER_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_post_item_layout, parent, false);
                return new DealerPost(view, callBack);
            case Constants.VIMEO_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.KRANK_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.krank_post_item_layout, parent, false);
                return new KrankPostViewHolder(view);
            case Constants.RETRY_ITEM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.retry_button_item, parent, false);
                return new RetryButtonViewHolder(view);
            case Constants.AUCTION_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.SUGGESTED_CONNECTIONS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.suggested_connections_recycler_item, parent, false);
                return new SuggestedConnectionViewHolders(view, callBack, newsfeed.getContext(), suggestedPeoples, preference, removeCallBack);
            case Constants.VERIFY_PHONE_NUMBER_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.phone_number_verify_item_view, parent, false);
                return new VerifyPhoneNumberViewHolder(view, phoneNumberCallBack,newsfeed.getContext(),items,this);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view, callBack);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).getPostType();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final NewsFeedArray item = items.get(position);


        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        params.topMargin = 16;

        item.setCallBackWithAdapterPosition((pos) -> {
            removeAt(pos);
            newsfeed.newsFeedViewModel.deleteById(item.getId());
        });

        item.setLikeCallBack((id, isLike, likeCount) -> newsfeed.newsFeedViewModel.updateLike(id, isLike, likeCount));

        item.setCommentClick((position1, item1, view) -> {
            if (callBack == null) return;
            callBack.act(position1, Constants.COMMENT_CALLBACK, view);
        });

        switch (item.getPostType()) {
            case Constants.SHARE_UPDATE:
                setHeaderTypeOne(holder, item);
                break;
            case Constants.INVITE_COMPANIES:
                setTypeTwoHeader(holder, item);
                break;
            case Constants.ADD_CO_WORKERS:
                setTypeThreeHeader(holder, item);
                break;
            case Constants.IMAGE_POST:
                newsFeedFunctions.setTypeImgPost(holder, item);
                break;
            case Constants.LINKED_POST:
                newsFeedFunctions.setTypeLinkedPost(holder, item);
                break;
            case Constants.TEXT_POST:
                newsFeedFunctions.setTypeTextPost(holder, item);
                break;
            case Constants.LOADER:
                setLoader(holder, item);
                break;
            case Constants.CHECK_IN:
                newsFeedFunctions.setCheckInTypePost(holder, item);
                break;
            case Constants.NETWORK_POST:
                newsFeedFunctions.setNetworkPost(holder, item);
                break;
            case Constants.DEALER_POST:
                newsFeedFunctions.setDealerPost(holder, item);
                break;
            case Constants.LISTING_POST:
                newsFeedFunctions.setTypeListingPost(holder, item);
                break;
            case Constants.YOUTUBE_VIDEO:
                newsFeedFunctions.setTypeYoutubeVideoPost(holder, item);
                break;
            case Constants.ARTICLE_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Article");
                break;
            case Constants.AUCTION_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Auction");
                break;
            case Constants.VIMEO_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, item);
                break;
            case Constants.KRANK_POST:
                newsFeedFunctions.setTypeKrankPost(holder, item);
                break;
            case Constants.OTHER_POST:
                break;
            case Constants.RETRY_ITEM:
                setRetryButton(holder, item, position);
                break;
            case Constants.VERIFY_PHONE_NUMBER_VIEW:
                if(holder instanceof VerifyPhoneNumberViewHolder){
                    ((VerifyPhoneNumberViewHolder)holder).onBind(item);
                }
                break;
            case Constants.SUGGESTED_CONNECTIONS:
                setSuggestedConnectionsView(holder);
                break;
        }
    }


    private void setSuggestedConnectionsView(final RecyclerView.ViewHolder holder) {
        SuggestedConnectionViewHolders viewHolder = ((SuggestedConnectionViewHolders) holder);
        if (updateInnerAdapter) {
            viewHolder.getHorizontalAdapter().notifyDataSetChanged();
            updateInnerAdapter = false;
        }

    }

    private void setRetryButton(final RecyclerView.ViewHolder holder, final NewsFeedArray item, final int position) {
        RetryButtonViewHolder retryButtonViewHolder = ((RetryButtonViewHolder) holder);

        retryButtonViewHolder.itemView.setOnClickListener(view -> {
            items.get(position).setPostType(Constants.LOADER);
            notifyItemChanged(position);
            newsfeed.retryNewsFeedData();
        });
    }

    private void setHeaderTypeOne(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {

        ShareAndUpdateViewHolder shareAndUpdateViewHolder = ((ShareAndUpdateViewHolder) holder);


        Glide.with(newsfeed.getContext()).load(AppUtils.getImgUrl(preference.getString(Constants.PROFILE_PICTURE))).into(shareAndUpdateViewHolder.profile_img_share_an_update);
    }


    private void setLoader(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {

        Loader viewHolder = (Loader) holder;


    }


    private void setTypeThreeHeader(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {


        InviteCoWorkersViewHolder inviteCoWorkersViewHolder = ((InviteCoWorkersViewHolder) holder);


    }

    private void setTypeTwoHeader(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {


        InviteCompaniesViewHolder inviteCompaniesViewHolder = ((InviteCompaniesViewHolder) holder);

    }

    public void removeLoader(boolean retryIcon) {
        for (int i = (items.size() - 1); i >= 0; i--) {
            if (items.get(i).getPostType() == Constants.LOADER) {
                if (retryIcon) {
                    items.get(i).setPostType(Constants.RETRY_ITEM);
                    notifyItemChanged(i);
                } else {
                    items.remove(i);
                    notifyItemRemoved(i);
                }
                break;
            }
        }
    }

}





