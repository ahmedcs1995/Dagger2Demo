package com.mobileapp.krank.DiscoverPeoplePages

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.SimpleItemAnimator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.facebook.shimmer.ShimmerFrameLayout
import com.mobileapp.krank.Activities.DiscoverPeople
import com.mobileapp.krank.Activities.UserProfileView
import com.mobileapp.krank.Adapters.ListOfEmployeesAndConnectionsAdapter

import com.mobileapp.krank.Base.BaseFragment
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CallBacks.CustomCallBack
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ResponseModels.GetNetworkEmployeeResponse
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.Utils.ServiceManager
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.BaseViewHolder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * Created by Ahmed on 3/22/2018.
 */

class SuggestedPeople : BaseFragment(), CallBackWithAdapterPosAndType {
    //list
    private lateinit var listItem: MutableList<GetNetworkEmployeeData>
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var mRecyclerAdapter: ListOfEmployeesAndConnectionsAdapter

    //api
    private lateinit var serviceManager: ServiceManager

    //activity ref
    private var activityRef: DiscoverPeople? = null


    //other views
    private lateinit var swipe_refresh: SwipeRefreshLayout
    private lateinit var no_item_found_view: TextView
    private lateinit var shimmer_view_container: ShimmerFrameLayout

    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false
    // private var suggested_connection: Boolean = false


    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null


    init {
        title = "Suggested"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val me = inflater.inflate(R.layout.suggested_people_fragment_page, container, false)
        fragmentView = me

        init()

        initViews()

        setUpRunnable()

        setUpAdapter()

        getSuggestedPeopleData()

        addOnPullToRefreshListener()

        return me
    }

    private fun setUpRunnable() {
        runnable = Runnable {
            getSuggestedPeopleData()
        }
    }

    private fun setUpAdapter() {
        listItem = ArrayList()
        mRecyclerView = findViewById(R.id.discover_people_recycler) as RecyclerView
        mRecyclerAdapter = ListOfEmployeesAndConnectionsAdapter(listItem, context!!, this)
        mRecyclerView.layoutManager = LinearLayoutManager(context)
        mRecyclerView.adapter = mRecyclerAdapter
        (mRecyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
        addOnScrollEndListener()
    }

    private fun init() {
        serviceManager = ServiceManager.getInstance()

        activityRef = activity as DiscoverPeople

        preference = activityRef?.preference
    }

    private fun initViews() {
        swipe_refresh = findViewById(R.id.swipe_refresh) as SwipeRefreshLayout
        no_item_found_view = findViewById(R.id.no_item_found_view) as TextView
        shimmer_view_container = findViewById(R.id.shimmer_view_container) as ShimmerFrameLayout
    }

    private fun addOnScrollEndListener() {
        mRecyclerView.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun addOnPullToRefreshListener(){
        swipe_refresh.setOnRefreshListener {
            listItem.clear()
            mRecyclerAdapter.notifyDataSetChanged()
            offset=0
            shouldScrollCalled = false
            getSuggestedPeopleData()
        }
    }

    private fun getSuggestedPeopleData() {
        serviceManager.api.suggestedPeoples(preference.getString(Constants.ACCESS_TOKEN), offset, Constants.PAGE_LIMIT).enqueue(object : Callback<GetNetworkEmployeeResponse> {
            override fun onResponse(call: Call<GetNetworkEmployeeResponse>, response: Response<GetNetworkEmployeeResponse>) {
                swipe_refresh.isRefreshing = false
                removeLoader()
                mRecyclerAdapter.removeListLoader()

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        checkForData(response.body().message)
                    }
                } else {
                    onFailure()
                }
            }

            override fun onFailure(call: Call<GetNetworkEmployeeResponse>, t: Throwable) {
                onFailure()
                removeLoader()
            }
        })
    }

    private fun onSuccess(response: Response<GetNetworkEmployeeResponse>) {
        if (offset <= 0) {
            addPhoneBookView()
        }
        var tempList = response.body().data


        for (item in tempList) {
            item.conStatus = Constants.CONNECTION_NOT_CONNECTED
        }
        listItem.addAll(tempList)

        /*for pagination*/
        if (response.body().data.size >= Constants.PAGE_LIMIT) {
            listItem.add(GetNetworkEmployeeData(GetNetworkEmployeeData.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /*for pagination*/


        if (offset <= 0) {
            mRecyclerAdapter.notifyItemRangeInserted(listItem.size - tempList.size + 1, listItem.size)
        } else {
            mRecyclerAdapter.notifyItemRangeInserted(listItem.size - tempList.size, listItem.size)
        }


        checkForData(response.body().message)
    }

    private fun addPhoneBookView() {
        if (preference.getBoolean(Constants.CONTACTS_SYNC_ENABLED)) return

        if(!AppUtils.isSimAvailable(context)) return


        listItem.add(GetNetworkEmployeeData(GetNetworkEmployeeData.CONNECT_PHONE_BOOK_VIEW))
        if (activityRef != null) {
            if (activityRef!!.isContactSyncFromOtherDevices()) {
                mRecyclerAdapter.phoneBookViewText = "Connect your current Phone"
            } else {
                mRecyclerAdapter.phoneBookViewText = "Connect your Phonebook"

            }
        }


    }


    private fun onFailure() {
        if (activityRef != null) {
            activityRef?.onResponseFailure()
        }
    }

    private fun removeLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }

    private fun checkForData(errorMessage: String) {
        if (listItem.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
            no_item_found_view.text = errorMessage
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }


    override fun act(position: Int, type: Int) {
        when (type) {
            BaseViewHolder.USER_PROFILE -> {
                onUserProfile(position)
            }
            BaseViewHolder.SYNC_CONTACTS -> {
                if (activityRef != null) {

                    when {

                        //for connect current phone book
                        activityRef!!.isContactSyncFromOtherDevices() -> {
                            activityRef?.shouldReinitiateAdapter = true
                            activityRef?.importContacts()

                        }

                        //first time contact init
                        AppUtils.isSimAvailable(context) -> activityRef?.showDialog(null)

                        //no sim available
                        else -> activityRef?.changeTab()
                    }
                }
            }
        }
    }

    fun removeConnectThread() {
        if(listItem.size <=0) return
        if(listItem[0].viewType != GetNetworkEmployeeData.CONNECT_PHONE_BOOK_VIEW) return

        listItem.removeAt(0)
        mRecyclerAdapter.notifyItemRemoved(0)
    }

    private fun onUserProfile(position: Int) {
        val intent = Intent(context, UserProfileView::class.java)
        intent.putExtra("userId", listItem[position].id)
        intent.putExtra("userName", listItem[position].firstName)
        intent.putExtra("IsPersonalProfile", false)
        intent.putExtra("conStatus", listItem[position].conStatus)
        intent.putExtra("item_index", position)
        startActivity(intent)
    }
}
