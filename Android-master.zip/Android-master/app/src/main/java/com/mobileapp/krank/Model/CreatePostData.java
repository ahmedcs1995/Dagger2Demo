package com.mobileapp.krank.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
/*
* Sending post params to API
*/
public class CreatePostData {
    @SerializedName("is_company_news")
    @Expose
    String is_company_news;

    @SerializedName("post_type")
    @Expose
    String post_type;

    @SerializedName("asset")
    @Expose
    String asset;

    @SerializedName("privacy_id")
    @Expose
    String privacy_id;

    @SerializedName("tag_id")
    @Expose
    ArrayList<String> tag_id;

    @SerializedName("groups")
    @Expose
    ArrayList<String> groups;

    @SerializedName("desc")
    @Expose
    String desc;

    @SerializedName("title")
    @Expose
    String title;

    @SerializedName("link_data")
    @Expose
    LinkDataToSend link_data;



    public CreatePostData(String is_company_news, String post_type, String asset, String privacy_id, ArrayList<String> tag_id, ArrayList<String> groups, String desc, String title,LinkDataToSend link_data) {
        this.is_company_news = is_company_news;
        this.post_type = post_type;
        this.asset = asset;
        this.privacy_id = privacy_id;
        this.tag_id = tag_id;
        this.groups = groups;
        this.desc = desc;
        this.title = title;
        this.link_data = link_data;
    }

}
