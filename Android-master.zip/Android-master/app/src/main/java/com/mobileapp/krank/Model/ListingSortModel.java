package com.mobileapp.krank.Model;

public class ListingSortModel {
    private String networkId;
    private String connectionId;
    private String sort_by;
    private String networkCompanyName="";
    private String connectionName="";

    public ListingSortModel(String networkId, String connectionId, String sort_by) {
        this.networkId = networkId;
        this.connectionId = connectionId;
        this.sort_by = sort_by;
    }

    public String getNetworkId() {
        return networkId;
    }

    public void setNetworkId(String networkId) {
        this.networkId = networkId;
    }

    public String getConnectionId() {
        return connectionId;
    }

    public void setConnectionId(String connectionId) {
        this.connectionId = connectionId;
    }

    public String getSort_by() {
        return sort_by;
    }

    public void setSort_by(String sort_by) {
        this.sort_by = sort_by;
    }

    public String getNetworkCompanyName() {
        return networkCompanyName;
    }

    public void setNetworkCompanyName(String networkCompanyName) {
        this.networkCompanyName = networkCompanyName;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }
}
