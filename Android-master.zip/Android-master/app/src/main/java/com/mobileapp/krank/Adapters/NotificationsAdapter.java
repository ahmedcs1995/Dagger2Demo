package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.NotificationsScreen;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.CustomViews.CustomFaView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.Model.Enums.TypeOfNotification;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NotificationListArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.SpannableUtils;


import java.util.List;

import retrofit2.http.PUT;

/**
 * Created by Yaseen on 03/05/2018.
 */

public class NotificationsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    //types
    public static final int REDIRECT_CALLBACK = 1;
    public static final int DELETE_CALLBACK = 2;

    public static final int ACCEPT_BUTTON_CALLBACK = 3;
    public static final int REJECT_BUTTON_CALLBACK = 4;


    public static final int REMOVE_DEALER_CALLBACK = 5;


    public static final int SEND_REQUEST_CALLBACK = 6;


    public static final int DO_NETWORK_REQUEST_CALLBACK = 7;


    private List<NotificationListArray> items;
    Context context;

    SaveInSharedPreference preference;
    private final ViewBinderHelper binderHelper = new ViewBinderHelper();


    CallBackWithPosTypeAndView callBack;


    public class BaseViewHolder extends RecyclerView.ViewHolder{

        View item;
        SimpleDraweeView profile_img;
        TextView time_text_view;
        TextView name;
        TextView company_text;
        TextView description;

        View view_container;

        public BaseViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            profile_img = item.findViewById(R.id.profile_img);
            time_text_view = item.findViewById(R.id.time_text_view);
            name = item.findViewById(R.id.name);
            company_text = item.findViewById(R.id.company_text);
            description = item.findViewById(R.id.description);

            view_container = item.findViewById(R.id.view_container);

            view_container.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                callBack.act(getAdapterPosition(),REDIRECT_CALLBACK,view_container);
            });

        }

        public void onBindList(NotificationListArray item, int position){
            //read unread
            if (item.getIsRead().equals("1")) {
                this.item.setBackgroundColor(ContextCompat.getColor(context, R.color.AppWhiteColor));
            } else {
                this.item.setBackgroundColor(ContextCompat.getColor(context, R.color.unread_notification));
            }


            if(item.showRemoveDealerView()){
                description.setMovementMethod(LinkMovementMethod.getInstance());
                description.setText(SpannableUtils.getRemoveDealerMessage(item.getDesc(), context,callBack,position));
            }else{
                description.setText("" + Html.fromHtml("" + item.getDesc()));
            }

            name.setText("" + item.getName());


            company_text.setText("" + item.getTitle());
            time_text_view.setText("" + item.getDate());

            profile_img.setImageURI(Uri.parse("" + item.getImage()));
        }

    }


    public class ViewHolder extends BaseViewHolder {

        View delete_btn;

        private SwipeRevealLayout swipeLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;

            delete_btn = item.findViewById(R.id.delete_btn);

            swipeLayout = (SwipeRevealLayout) itemView.findViewById(R.id.swipe_layout);


            delete_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                callBack.act(getAdapterPosition(),DELETE_CALLBACK,delete_btn);
                binderHelper.closeLayout(items.get(getAdapterPosition()).getId());
                removeAt(getAdapterPosition());
            });

        }


        public void onBind(NotificationListArray item,final int position){
            binderHelper.bind(swipeLayout, item.getId());
            onBindList(item,position);
        }
    }

    public class ViewHolderTwo extends BaseViewHolder {



        View reject_btn;
        View accept_btn;



        public ViewHolderTwo(View itemView) {
            super(itemView);
            item = itemView;

            accept_btn = item.findViewById(R.id.accept_btn);
            reject_btn = item.findViewById(R.id.reject_btn);

            accept_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                callBack.act(getAdapterPosition(),ACCEPT_BUTTON_CALLBACK,accept_btn);
            });

            reject_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                callBack.act(getAdapterPosition(),REJECT_BUTTON_CALLBACK,reject_btn);
            });
        }

        public void onBind(NotificationListArray item,final int position){
            onBindList(item,position);
        }
    }

    public class NotificationTypeDiscoverViewHolder extends BaseViewHolder{

        CustomFaView icon;
        TextView status_text;
        View status_btn_container;
        View cancel_btn_container;

        View delete_btn;
       // View delete_box_container;

        private SwipeRevealLayout swipeLayout;


        public NotificationTypeDiscoverViewHolder(View itemView) {
            super(itemView);

            //fa icon
            icon = item.findViewById(R.id.icon);
            //status text
            status_text = item.findViewById(R.id.status_text);
            status_btn_container = item.findViewById(R.id.status_btn_container);
            cancel_btn_container = item.findViewById(R.id.cancel_btn_container);

            status_btn_container.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                if(items.get(getAdapterPosition()).getConnectionStatus() == ConNetStatus.NOT_CONNECTED){
                    callBack.act(getAdapterPosition(),DO_NETWORK_REQUEST_CALLBACK,status_btn_container);
                }

            });


            delete_btn = item.findViewById(R.id.delete_btn);
         //   delete_box_container = item.findViewById(R.id.delete_box_container);

            swipeLayout = (SwipeRevealLayout) itemView.findViewById(R.id.swipe_layout);


            delete_btn.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                deleteNotification(delete_btn);
            });

            cancel_btn_container.setOnClickListener(view -> {
                if(getAdapterPosition() < 0 || callBack == null) return;
                deleteNotification(cancel_btn_container);
            });

        }

        private void deleteNotification(View view){
            callBack.act(getAdapterPosition(),DELETE_CALLBACK, view);
            binderHelper.closeLayout(items.get(getAdapterPosition()).getId());
            removeAt(getAdapterPosition());
        }

        public void onBind(final NotificationListArray item,final int position){
            binderHelper.bind(swipeLayout, item.getId());

            onBindList(item,position);
            switch (item.getConnectionStatus()){
                case CONNECTED:
                    status_btn_container.setVisibility(View.GONE);
                    cancel_btn_container.setVisibility(View.GONE);
                    setMinDeleteBoxHeight();
                    break;
                case INVITATION_RECEIVED:
                    status_btn_container.setVisibility(View.GONE);
                    cancel_btn_container.setVisibility(View.GONE);
                    setMinDeleteBoxHeight();
                    break;
                case NOT_CONNECTED:
                    status_btn_container.setVisibility(View.VISIBLE);
                    cancel_btn_container.setVisibility(View.VISIBLE);
                    status_text.setText("Connect");
                    status_text.setTextColor(ContextCompat.getColor(context,R.color.AppWhiteColor));
                    icon.setTextColor(ContextCompat.getColor(context,R.color.AppWhiteColor));
                    icon.setText(AppUtils.fromHtml("&#xf067;"));
                    icon.setVisibility(View.VISIBLE);
                    status_btn_container.setBackground(ContextCompat.getDrawable(context, R.drawable.connect_btn_background));
                    setMaxDeleteBoxHeight();
                    break;
                case REQUEST_PENDING:
                    status_btn_container.setVisibility(View.VISIBLE);
                    cancel_btn_container.setVisibility(View.GONE);
                    status_text.setText("Request Pending");
                    status_text.setTextColor(ContextCompat.getColor(context,R.color.blackColor));
                    icon.setTextColor(ContextCompat.getColor(context,R.color.blackColor));
                    icon.setText(AppUtils.fromHtml("&#xf253;"));
                    icon.setVisibility(View.VISIBLE);
                    status_btn_container.setBackground(ContextCompat.getDrawable(context, R.drawable.request_pending_text_view));
                    setMaxDeleteBoxHeight();
                    break;
            }


        }

        private void setMaxDeleteBoxHeight(){
          //  delete_box_container.getLayoutParams().height = (int) context.getResources().getDimension(R.dimen.max_delete_box_height);
        }
        private void setMinDeleteBoxHeight(){
        //    delete_box_container.getLayoutParams().height = (int) context.getResources().getDimension(R.dimen.min_delete_box_height);
        }

    }

    public class Loader extends RecyclerView.ViewHolder {

        View item;

        public Loader(View itemView) {
            super(itemView);
            item = itemView;

        }
    }

    public NotificationsAdapter(List<NotificationListArray> items, NotificationsScreen notificationsScreen,CallBackWithPosTypeAndView callBack) {
        this.items = items;
        this.context = notificationsScreen;
        preference = SaveInSharedPreference.getInstance(notificationsScreen.getApplicationContext());
        this.callBack = callBack;
        binderHelper.setOpenOnlyOne(true);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notifications_type_1_item, parent, false);
                return new ViewHolder(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case 3:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notifications_type_2_item, parent, false);
                return new ViewHolderTwo(view);
            case 4:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notifications_type_discover, parent, false);
                return new NotificationTypeDiscoverViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notifications_type_1_item, parent, false);
                return new ViewHolder(view);


        }
    }

    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getTypeOfNotification()) {
            case POST_LIKE:
            case COMMENTS:
            case COMMENT_REPLY_LIKE:
            case NETWORK_REQUEST:
            case LISTING:
            case DEALER_REQUEST:
            case TAG:
            case ARTICLE:
                return 1;
            case NETWORK_REQUEST_WITH_BTNS:
            case CONNECTION_REQUEST_WITH_BTNS:
            case DEALER_REQUEST_WITH_BTNS:
                return 3;
            case DISCOVER:
                return 4;
            case LOADER:
                return 2;
            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final NotificationListArray item = items.get(position);


        if (item.getTypeOfNotification() == TypeOfNotification.CONNECTION_REQUEST_WITH_BTNS || item.getTypeOfNotification() == TypeOfNotification.NETWORK_REQUEST_WITH_BTNS || item.getTypeOfNotification() == TypeOfNotification.DEALER_REQUEST_WITH_BTNS) {
            setTypeTwoNotification(holder, position, item);


        }
        else if(item.getTypeOfNotification() == TypeOfNotification.DISCOVER){
            ((NotificationTypeDiscoverViewHolder)holder).onBind(item,position);
        }
        else if (item.getTypeOfNotification() != TypeOfNotification.LOADER) {
            setTypeOneNotification(holder, position, item);
        }
    }

    private void setTypeTwoNotification(final RecyclerView.ViewHolder holder, final int position, final NotificationListArray item) {
        ViewHolderTwo viewHolder = (ViewHolderTwo) holder;

        //  viewHolder.name.setText("" + item.getUserId());


       viewHolder.onBind(item,position);



    }

    private void setTypeOneNotification(final RecyclerView.ViewHolder holder, final int position, final NotificationListArray item) {
        final ViewHolder viewHolder = (ViewHolder) holder;



        viewHolder.onBind(item,position);

    }
    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,items.size());

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}