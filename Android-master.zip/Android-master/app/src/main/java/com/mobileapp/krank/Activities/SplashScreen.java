package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.Model.Enums.SplashLinkReceived;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CompanyInvitationResponse;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.ProfileMenuResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SplashScreen extends BaseActivity {

    View img_container;
    String TAG = "Splash Screen ->";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("into the splash", "yes");
        setContentView(R.layout.activity_splash_screen);

        img_container = findViewById(R.id.img_container);

        //logo
        setKrankLogoForUserProfiling();

        //bottom imge
        setAlignmentOfImage();


        new Handler().postDelayed(() -> {


            proceedToOtherScreens();
        }, 1000);
    }

    private void setAlignmentOfImage() {
        DeviceInfo deviceInfo = getDeviceResolution();
        int marginBottomToset = (int) ((deviceInfo.getDeviceHeight() / 2) / 4.5);
        img_container.setPadding(0, 0, 0, marginBottomToset);

    }

    private void _301RedirectRequest(String url) {
        getAPI()._301RedirectRequest(url).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {

                String networkRequestUrl = response.raw().networkResponse().request().url().url().toString();

                String priorResponseUrl = response.raw().priorResponse().request().url().url().toString();

                Log.e("priorResponseUrl",priorResponseUrl);

                Log.e("networkRequestUrl",networkRequestUrl);


                if(networkRequestUrl.contains("/login")){
                    //use prior response
                    onLinkReceived(priorResponseUrl);
                }else{
                    onLinkReceived(networkRequestUrl);
                }

            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.e(TAG, "==> " + call.request());
                Log.e(TAG, "==> " + t.getMessage());
            }
        });
    }

    private void proceedToOtherScreens() {

        /*get the deep Link Code*/
        String action = getIntent().getAction();
        String url = getIntent().getDataString();
        /*get the deep Link Code*/


        Log.e("link", "===> " + url);


        /* Check the Deep Link code */
        if (Intent.ACTION_VIEW.equals(action) && url != null) {

            if (url.contains("email.invitation.krank.com")) {
                _301RedirectRequest(url);
            } else {
                onLinkReceived(url);
            }


        }
        /* Check the Deep Link code */


        /*Check For Notifications data exists in System Tray*/
        else if (getIntent().getExtras() != null && getIntent().getExtras().get("id") != null) {
            onNotificationReceived();
        }
        /*Check For Notifications data exists in System Tray*/

        else {
            otherActionsOnLink(SplashLinkReceived.APP_VIEW, null);
        }


    }


    private void otherActionsOnLink(SplashLinkReceived pageToRedirect, String url) {
        /*If User is Logged In then get the user data updated User data */
        if (!preference.getString(Constants.ACCESS_TOKEN).isEmpty()) {
            // get the updated user data....
            getUserInfo(shouldRedirectToWizard() ? SplashLinkReceived.WIZARD  : pageToRedirect, url);
        } else {

            //hold the data

            CustomApplication app = (CustomApplication) getApplicationContext();
            app.listingUrl = url;
            app.pageToRedirect = pageToRedirect;


            /*Check If temp User Id exists. to continue the Sign Up*/
            if (preference.getBoolean(Constants.GOTO_VERIFICATION_SCREEN)) {
                Intent mainIntent = new Intent(SplashScreen.this, SignUpPage4.class);
                startActivity(mainIntent);
            }
            else if (!(preference.getString(Constants.TEMP_USER_ID).isEmpty())) {
                Intent mainIntent = new Intent(SplashScreen.this, SignUpPage5.class);
                startActivity(mainIntent);
            }
            /*Check If temp User Id exists. to continue the Sign Up*/


            /*goto get started Screen*/
            else {
                Intent mainIntent = new Intent(SplashScreen.this, FirstPage.class);
                startActivity(mainIntent);
            }
            /*goto get started Screen*/


            SplashScreen.this.finish();
        }
    }
    public boolean shouldRedirectToWizard(){
        return !preference.getString(Constants.IS_PHONE_NUMBER_ON_WIZARD_ENTERED).isEmpty() && preference.getString(Constants.IS_PHONE_NUMBER_ON_WIZARD_ENTERED).equals("no");

    }

    private void onLinkReceived(String link) {
        if (link.contains("/ci/") || link.contains("/u/")) {
            onDeepLinkReceived(link);
        } else {
            // redirect to pages
            if(link.contains("notifications?pg=discover")){
                otherActionsOnLink(SplashLinkReceived.DISCOVER,null);
            }
            else if (link.contains("listing")) {
                otherActionsOnLink(SplashLinkReceived.LISTING_PAGE, link.substring(link.lastIndexOf('/') + 1));
            } else if (link.contains("pending-requests")) {
                otherActionsOnLink(SplashLinkReceived.PENDING_REQUEST, link.substring(link.lastIndexOf('/') + 1));
            } else if (link.contains("people-you-may-know")) {
                otherActionsOnLink(SplashLinkReceived.PEOPLE_YOU_MAY_KNOW, link.substring(link.lastIndexOf('/') + 1));
            }
            else if (link.contains("article")) {
                otherActionsOnLink(SplashLinkReceived.ARTICLE, link.substring(link.lastIndexOf('/') + 1));
            }
            else if(link.contains("messages/group-chat")){
                otherActionsOnLink(SplashLinkReceived.GROUP_CHAT, link.substring(link.lastIndexOf('=') + 1));
            }
            else if(link.contains("messages")){
                otherActionsOnLink(SplashLinkReceived.CHAT, link.substring(link.lastIndexOf('=') + 1));
            }
            else {
                //    String tempUrl = link.replaceAll("(http:\\/\\/|https:\\/\\/)+[a-z0-9-]+\\.krank.com", "");

                String tempUrl = link.replaceAll("(?i)(http:\\/\\/|https:\\/\\/)+[a-z0-9-]+\\.krank.com/", "");

                String[] arr = tempUrl.split("/");

                if (arr.length > 0) {
                    if (arr[0].equals("company") && arr.length == 3) {
                        otherActionsOnLink(SplashLinkReceived.USER_PROFILE, arr[2]);
                    }
                    else if (arr[0].equals("company") && arr.length == 2) {
                        otherActionsOnLink(SplashLinkReceived.COMPANY_PROFILE, arr[1]);
                    }
                    else{
                        otherActionsOnLink(SplashLinkReceived.APP_VIEW, link);
                    }
                }
                else{
                    otherActionsOnLink(SplashLinkReceived.APP_VIEW, link);
                }
            }
        }
    }


    private String[] getSpitedString(String url) {
        return url.split("/");
    }


    private void onDeepLinkReceived(String code) {

        String[] splittedString = getSpitedString(code);

       // String dealerString = "";
        String inviteType="";
        String inviteCode = "";
        String codeType = "";

        try {

            /**
             * Dealer Invitation || Private Invitation
             * */
            if (splittedString[splittedString.length - 1].equals("d") || splittedString[splittedString.length - 1].equals("p")) {
                inviteType = splittedString[splittedString.length - 1];
                inviteCode = splittedString[splittedString.length - 2];
                codeType = splittedString[splittedString.length - 3];
            }
            /**
             * Normal Invitation
             * */
            else {
                inviteCode = splittedString[splittedString.length - 1];
                codeType = splittedString[splittedString.length - 2];

            }

            verifyInvitationCode(inviteCode, inviteType, codeType);
        } catch (Exception ex) {
            otherActionsOnLink(SplashLinkReceived.APP_VIEW, null);
        }


    }

    private void verifyInvitationCode(final String code, final String inviteType, String codeType) {

        int isDealer = 0;

        if(inviteType.equals("d")){
            isDealer = 1;
        }

        getAPI().companyInvitationVerification(code, codeType,isDealer).enqueue(new Callback<CompanyInvitationResponse>() {
            @Override
            public void onResponse(Call<CompanyInvitationResponse> call, Response<CompanyInvitationResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (preference.getString(Constants.ACCESS_TOKEN).isEmpty()) {
                            preference.setString(Constants.INVITATION_CODE, response.body().getData().getCod());
                            preference.setString(Constants.TYPE_OF_INVITATION, inviteType);  // p or d
                            preference.setString(Constants.INVITATION_RESPONSE_DATA, gson.toJson(response.body().getData()));
                            Intent intent = new Intent(SplashScreen.this, InvitationRecievePage.class);
                            startActivity(intent);
                            return;
                        }
                        companyAcceptInvitation(response.body().getData().getCod(), inviteType);
                        return;
                    }
                    Toast.makeText(SplashScreen.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    handleInvitationCodeFailure();

                } else {
                    handleInvitationCodeFailure();
                }

            }

            @Override
            public void onFailure(Call<CompanyInvitationResponse> call, Throwable t) {
                onResponseFailure();
                //   Toast.makeText(SplashScreen.this,Constants.ERROR_MSG_TOAST_1,Toast.LENGTH_SHORT).show();

                handleInvitationCodeFailure();
            }
        });
    }

    private void handleInvitationCodeFailure() {
        if (preference.getString(Constants.ACCESS_TOKEN).isEmpty()) {
            Intent intent = new Intent(this, FirstPage.class);
            startActivity(intent);
            finish();
            return;
        }
        gotoMainPage();
    }


    private void companyAcceptInvitation(String code, String dealerString) {
        getAPI().companyAcceptInvitation(preference.getString(Constants.ACCESS_TOKEN), code, dealerString).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

               if (response.isSuccessful()) {
                    gotoMainPage();
                    if (!(response.body().getStatus().equals(Constants.SUCCESS_STATUS))) {
                        Toast.makeText(SplashScreen.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    gotoMainPage();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
                gotoMainPage();
            }
        });
    }

    private void gotoMainPage() {
        Intent intent = new Intent(SplashScreen.this, MainPage.class);
        startActivity(intent);
        finish();
    }

    private void getUserInfo(SplashLinkReceived pageToRedirect, final String url) {
        getAPI().getProfileMenu(preference.getString(Constants.ACCESS_TOKEN),AppUtils.getDeviceId(this)).enqueue(new Callback<ProfileMenuResponse>() {
            @Override
            public void onResponse(Call<ProfileMenuResponse> call, Response<ProfileMenuResponse> response) {

                Intent mainIntent = null;
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                        updateUserData(response);
                        mainIntent = getIntentToRedirectNextPage(SplashScreen.this, url, pageToRedirect);
                    } else {

                        //for block user
                        logOut();
                    }

                } else {
                    clearCache();
                    mainIntent = new Intent(SplashScreen.this, FirstPage.class);
                }
                startActivity(mainIntent);
                finish();

            }

            @Override
            public void onFailure(Call<ProfileMenuResponse> call, Throwable t) {
                Intent mainIntent = new Intent(SplashScreen.this, MainPage.class);
                startActivity(mainIntent);
                finish();
            }

        });

    }

    private void onNotificationReceived() {
        try{
            String id = getIntent().getExtras().get("id").toString();
            String nt = getIntent().getExtras().get("nt").toString();
            Intent notificationIntent = MyFirebaseMessagingService.getNotificationIntent(getApplicationContext(), nt, id);
            startActivity(notificationIntent);
            finish();
        }catch (Exception e){
            otherActionsOnLink(SplashLinkReceived.APP_VIEW, null);
        }

    }
}


