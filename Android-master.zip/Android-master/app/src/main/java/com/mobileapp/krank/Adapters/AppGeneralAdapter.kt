package com.mobileapp.krank.Adapters
import android.support.annotation.NonNull
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.SimpleItemAnimator
import android.view.ViewGroup
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList


abstract class AppGeneralAdapter<T>(private var listItems: MutableList<T>?) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    @NonNull
    override fun onCreateViewHolder(@NonNull viewGroup: ViewGroup, i: Int): RecyclerView.ViewHolder {
        return onCreate(viewGroup, i)
    }

    override fun onBindViewHolder(@NonNull viewHolder: RecyclerView.ViewHolder, position: Int) {

        onBind(viewHolder, listItems!![position], position)
    }

    override fun getItemCount(): Int {
        return if (listItems == null) 0 else listItems!!.size
    }

    abstract fun onBind(@NonNull viewHolder: RecyclerView.ViewHolder, item: T, position: Int)
    abstract fun onCreate(@NonNull parent: ViewGroup, i: Int): RecyclerView.ViewHolder

    fun removeAt(position: Int){
            listItems?.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, listItems?.size!!)
    }

    fun add(item : T){
        if(listItems !=null){
            listItems?.add(item)
            notifyItemInserted(listItems?.size!! - 1)
        }
    }
    fun addAll(items: MutableList<T>){
        if(listItems !=null){
            listItems?.addAll(items)
            notifyItemRangeInserted(listItems?.size!! - items.size,listItems?.size!!)
        }
    }
    fun updateListItem(position: Int){
        notifyItemChanged(position)
    }

    fun setItemAnimator(recyclerView: RecyclerView){
        (recyclerView.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
    }


    fun removeNetworkListLoader(listItem : MutableList<NetworkList>){
        for (i in listItem.indices){
            if(listItem[i].type == Constants.LOADER_VIEW){
                removeAt(i)
                break
            }
        }
    }

    fun removeDealerListLoader(listItem : MutableList<NetworkDealersData>){
        for (i in listItem.indices){
            if(listItem[i].viewType == Constants.LOADER_VIEW){
                removeAt(i)
                break
            }
        }
    }

    fun removeLoader(){

            for (i in listItems!!.indices){
                if(listItems!![i] is NetworkList){
                    if((listItems as MutableList<NetworkList>)[i].type == Constants.LOADER_VIEW){
                        removeAt(i)
                        break
                    }
                }else  if(listItems!![i] is NetworkDealersData){
                    if((listItems as MutableList<NetworkDealersData>)[i].viewType == Constants.LOADER_VIEW){
                        removeAt(i)
                        break
                    }
                }

            }

    }


}