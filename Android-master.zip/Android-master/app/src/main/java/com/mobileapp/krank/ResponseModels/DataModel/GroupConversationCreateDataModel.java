package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.ResponseModels.GroupChatMessagesResponse;

public class GroupConversationCreateDataModel {
    @SerializedName("member_id")
    @Expose
    private String member_id;


    @SerializedName("group_id")
    @Expose
    private String group_id;


    @SerializedName("group_name")
    @Expose
    private String group_name;

    @SerializedName("group_data")
    @Expose
    GroupChatMessagesResponse group_data;

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public GroupChatMessagesResponse getGroup_data() {
        return group_data;
    }

    public void setGroup_data(GroupChatMessagesResponse group_data) {
        this.group_data = group_data;
    }
}
