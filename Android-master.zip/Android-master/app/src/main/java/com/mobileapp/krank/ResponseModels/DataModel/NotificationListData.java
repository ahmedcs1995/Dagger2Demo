package com.mobileapp.krank.ResponseModels.DataModel;



import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class NotificationListData {
    @SerializedName("notifications")
    @Expose
    private List<NotificationListArray> notifications = null;
    @SerializedName("total")
    @Expose
    private int total;
    @SerializedName("unread")
    @Expose
    private String unread;

    public List<NotificationListArray> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<NotificationListArray> notifications) {
        this.notifications = notifications;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getUnread() {
        return unread;
    }

    public void setUnread(String unread) {
        this.unread = unread;
    }

}

