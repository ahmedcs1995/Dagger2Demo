package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;

import java.util.List;
@Dao
public interface GroupChatListDao {


   // @Query("SELECT c.*, (SELECT cc.memberId FROM group_chat_conversation_list_table cc.group_id = c.group_id ORDER BY cc.memberId DESC LIMIT 1) member_id  FROM  group_chat_conversation_list_table c GROUP BY c.group_id")

    // @Query("Select * from group_chat_conversation_list_table order by msg_updated desc")
    @Query("SELECT * FROM group_chat_conversation_list_table gc WHERE gc.memberId IN (SELECT (SELECT cc.memberId FROM group_chat_conversation_list_table cc WHERE cc.group_id = c.group_id ORDER BY cc.memberId DESC LIMIT 1) member_id FROM group_chat_conversation_list_table c GROUP BY c.group_id) order by msg_updated desc")
    LiveData<List<GroupChatConversationGroupModel>> getAllChatList();

    @Query("select count(*) from group_chat_conversation_list_table")
    int getCount();

    @Insert
    void insert(GroupChatConversationGroupModel data);

    @Query("DELETE FROM group_chat_conversation_list_table")
    void deleteAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<GroupChatConversationGroupModel> list);

    @Update
    void bulkUpdate(List<GroupChatConversationGroupModel> list);


    @Query("select memberId from group_chat_conversation_list_table where memberId=:memberId")
    int getIdOfParentTable(String memberId);
}
