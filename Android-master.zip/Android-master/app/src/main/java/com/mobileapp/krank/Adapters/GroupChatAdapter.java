package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.mobileapp.krank.Chat.AddPeopleInPrivateChat;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChat;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChatConversationActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yaseen on 30/04/2018.
 */


public class GroupChatAdapter extends RecyclerView.Adapter<GroupChatAdapter.ViewHolder> {
    private List<GroupChatConversationGroupModel> items;
    GroupChat groupChat;
    private final ViewBinderHelper binderHelper = new ViewBinderHelper();
    AppUtils appUtils;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View addPeopleBtn;
        View chatItem;
        View online_view;
        CircleImageView profile_image_view;
        TextView name;
        TextView date;
        TextView msg;
        View un_read_count;
        private SwipeRevealLayout swipeLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            addPeopleBtn=itemView.findViewById(R.id.add_people_btn);
            chatItem=itemView.findViewById(R.id.chat_item);
            profile_image_view=itemView.findViewById(R.id.profile_image_view);
            name=itemView.findViewById(R.id.name);
            date=itemView.findViewById(R.id.date);
            msg=itemView.findViewById(R.id.msg);
            online_view=itemView.findViewById(R.id.online_view);
            un_read_count=itemView.findViewById(R.id.un_read_count);
            swipeLayout = (SwipeRevealLayout) itemView.findViewById(R.id.swipe_layout);


        }
    }

    public GroupChatAdapter(List<GroupChatConversationGroupModel> items, GroupChat groupChat) {
        this.items = items;
        this.groupChat = groupChat;
        binderHelper.setOpenOnlyOne(true);
        appUtils = AppUtils.getInstance();
    }


    @Override
    public GroupChatAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.personal_chat_item, parent, false);
        return new GroupChatAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final GroupChatAdapter.ViewHolder holder, int position) {
        final GroupChatConversationGroupModel item = items.get(position);

        binderHelper.bind(holder.swipeLayout, "" + item.getGroupId());


        //for add people
        /*unlock the swipe if admin*/
        if (item.getMemberUserId() == item.getMemberAddedBy()){
            binderHelper.unlockSwipe("" + item.getGroupId());
        }else{
            binderHelper.lockSwipe("" + item.getGroupId());
        }
        //for add people
        /*unlock the swipe if admin*/


        holder.addPeopleBtn.setOnClickListener(view -> {
            Intent intent = new Intent(groupChat.getContext(),AddPeopleInPrivateChat.class);
            intent.putExtra("group_id","" + item.getGroupId());
            groupChat.startActivity(intent);
            groupChat. getActivity(). overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });
        holder.chatItem.setOnClickListener(view -> {
            Intent intent = new Intent(groupChat.getContext(),GroupChatConversationActivity.class);
            intent.putExtra("recipient_name","" +  item.getGroupName());
            intent.putExtra("member_id","" +  item.getMemberId());
            intent.putExtra("group_id","" +  item.getGroupId());
            intent.putExtra("member_notifications","" +  item.getMemberNotifications());

            // Log.e("getMemberUserId","" + item.getMemberUserId());
            //  Log.e("getMemberAddedBy","" + item.getMemberAddedBy());

            intent.putExtra("from_adapter",true);

            intent.putExtra("member_notifications","" +  item.getMemberNotifications());
            intent.putExtra("member_leave_on","" +  item.getMemberLeaveOn());

            if(item.getMemberUserId() == item.getMemberAddedBy()){
                intent.putExtra("isGroupAdmin",true);
            }
            if(item.getMemberStatus() == 1){
                intent.putExtra("isMember_Exists",true);
            }else{
                intent.putExtra("isMember_Exists",false);
            }
            groupChat.startActivity(intent);
            groupChat. getActivity(). overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });

        holder.name.setText("" + item.getGroupName());
        if(item.getMsg() !=null){
            if(item.getMsg().getProfilePic()!=null){
                Glide.with(groupChat.getContext()).load(item.getMsg().getProfilePic()).into(holder.profile_image_view);
            }
            if(item.getMsg().getMsgAdded() !=null){
                holder.date.setText("" + item.getMsg().getMsgAdded());

                //holder.date.setText("" + appUtils.setTimeInChatList(item.getMsg().getMsgUpdated()));
            }


            if(item.getMsg().getMsgType() !=null){
                if(item.getMsg().getMsgType().equals("vcard")){
                    holder.msg.setText(item.getMsg().getFirstName() +" " + item.getMsg().getLastName() + ": " + "Sent a contact card");
                }
                else if(item.getMsg().getMsgType().equals("attachment")){
                    holder.msg.setText(item.getMsg().getFirstName() +" " + item.getMsg().getLastName()  + ": " + "Sent an attachment");
                }
                else{
                    holder.msg.setText(item.getMsg().getFirstName() +" " + item.getMsg().getLastName() + ": " + Html.fromHtml("" + item.getMsg().getMsgText()));
                }
            }
            if(item.getMsg().getOnline()!=null){
                if(item.getMsg().getOnline().equals("0")){
                    holder.online_view.setVisibility(View.GONE);
                }
                else{
                    holder.online_view.setVisibility(View.VISIBLE);
                }
            }

        }
        if(item.getUnread_count() !=null && Integer.parseInt(item.getUnread_count()) > 0){
            //  holder.un_read_count.setText("" + item.getUnread_count());
            holder.un_read_count.setVisibility(View.VISIBLE);
        }else{
            holder.un_read_count.setVisibility(View.GONE);
        }
    }
    @Override
    public int getItemCount() {
        return items.size();
    }
}