package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.mobileapp.krank.Activities.SearchKrank;
import com.mobileapp.krank.Functions.AppUtils;

import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.Network.ApiInterface;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.SearchTabs.Posts;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.List;


public class PostSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<NewsFeedArray> items;
    Context context;
    public SaveInSharedPreference preference;
    DeviceInfo deviceInfo;
    Posts posts;
    ApiInterface apiInterface;
    AppUtils appUtils;
    NewsFeedFunctions newsFeedFunctions;
    Gson gson;

    public PostSearchAdapter(List<NewsFeedArray> items, Context context, DeviceInfo deviceInfo, Posts posts) {
        this.items = items;
        this.context = context;
        preference = new SaveInSharedPreference(context);
        this.deviceInfo = deviceInfo;
        this.posts = posts;
        gson = CustomGson.getInstance();
        apiInterface = ((SearchKrank) posts.getActivity()).getAPI();
        appUtils = AppUtils.getInstance();

        newsFeedFunctions = new NewsFeedFunctions(posts, deviceInfo, true);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        Log.e("View Type ", "" + viewType);
        switch (viewType) {
            case 4:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_post_item_layout, parent, false);
                return new TextPostHolder(view);
            case 5:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_post_item_layout, parent, false);
                return new ImageViewHolder(view);
            case 6:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view);
            case 8:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkin_post_item_layout, parent, false);
                return new CheckInHolder(view);
            case 9:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_post_item_layout, parent, false);
                return new NetworkPost(view);
            case 10:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view);
            case 11:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view);
            case 12:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view);
            case 13:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_post_item_layout, parent, false);
                return new DealerPost(view);
            case 14:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view);
            case 15:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view);

        }


    }

    @Override
    public int getItemViewType(int position) {

        switch (items.get(position).getPostType()) {
            case Constants.TEXT_POST:
                return 4;
            case Constants.IMAGE_POST:
                return 5;
            case Constants.LINKED_POST:
                return 6;
            case Constants.CHECK_IN:
                return 8;
            case Constants.NETWORK_POST:
                return 9;
            case Constants.LISTING_POST:
                return 10;
            case Constants.YOUTUBE_VIDEO:
                return 11;
            case Constants.ARTICLE_POST:
                return 12;
            case Constants.DEALER_POST:
                return 13;
            case Constants.VIMEO_VIDEO:
                return 14;
            case Constants.AUCTION_POST:
                return 15;
            default:
                return -1;
        }
    }


    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final NewsFeedArray item = items.get(position);


        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        if (position == 0) {
            params.topMargin = 0;
        } else {
            params.topMargin = 16;
        }

      /*  item.setCommentClick(() -> {
            posts.clickIndex = position;
            Intent intent = new Intent(context, CommentsActivity.class);
            intent.putExtra("CommentDataObj", item);
            posts.startActivityForResult(intent, posts.COMMENT_ACTIVITY_CODE);
            posts.getActivity().overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);

        });*/

        item.setCallBackWithAdapterPosition((pos) -> {
            removeAt(pos);
        });

        switch (item.getPostType()) {
            case Constants.IMAGE_POST:
                newsFeedFunctions.setTypeImgPost(holder, item);
                break;
            case Constants.LINKED_POST:
                newsFeedFunctions.setTypeLinkedPost(holder, item);
                break;
            case Constants.TEXT_POST:
                newsFeedFunctions.setTypeTextPost(holder, item);
                break;
            case Constants.CHECK_IN:
                newsFeedFunctions.setCheckInTypePost(holder, item);
                break;
            case Constants.NETWORK_POST:
                newsFeedFunctions.setNetworkPost(holder, item);
                break;
            case Constants.DEALER_POST:
                newsFeedFunctions.setDealerPost(holder, item);
                break;
            case Constants.LISTING_POST:
                newsFeedFunctions.setTypeListingPost(holder, item);
                break;
            case Constants.YOUTUBE_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, item);
                break;
            case Constants.ARTICLE_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Article");
                break;
            case Constants.AUCTION_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Auction");
                break;
            case Constants.VIMEO_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, item);
                break;
            case Constants.OTHER_POST:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}


