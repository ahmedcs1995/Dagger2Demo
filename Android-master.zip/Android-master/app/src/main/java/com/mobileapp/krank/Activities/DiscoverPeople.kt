package com.mobileapp.krank.Activities

import android.app.Dialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.Fragment
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Base.BaseFragment
import com.mobileapp.krank.DiscoverPeoplePages.ContactPage
import com.mobileapp.krank.DiscoverPeoplePages.SuggestedPeople
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.FollowPeopleDialog
import com.mobileapp.krank.R
import kotlinx.android.synthetic.main.activity_discover_people.*
import android.util.Log
import android.view.View
import com.mobileapp.chatapp.Activities.ChatMessagesPage
import com.mobileapp.krank.CallBacks.CustomCallBack
import com.mobileapp.krank.Functions.ContactsFetcher
import com.mobileapp.krank.ResponseModels.ContactsDataModel
import com.mobileapp.krank.ResponseModels.DeleteContactDataModel
import com.mobileapp.krank.SynchronizationFromServer.SyncUtils
import kotlin.collections.ArrayList


class DiscoverPeople : BaseActivity() {


    companion object {
        const val CURRENT_ITEM_KEY = "current_item"
        const val NEW_USER_ID_KEY = "new_user_id"
        const val FROM_NOTIFICATION = "from_notification"
        const val FROM_DASHBOARD = "from_dashboard"
    }

    @FunctionalInterface
    interface ContactsImportResponse {
        fun onContactsImported(contacts: ArrayList<ContactsDataModel>, deleteContacts: ArrayList<DeleteContactDataModel>)
    }


    internal var mContactsImportResponse: ContactsImportResponse? = null

    private lateinit var contactsFetch: ContactsFetcher


    var userId: String? = null

    var tempCallBack: CustomCallBack? = null


    lateinit var pages: ArrayList<BaseFragment>


    var shouldReinitiateAdapter = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_discover_people)

        contactsFetch = applicationRef.contactsFetcher


        setNormalPageToolbar(if (fromChatApp()) ChatMessagesPage.DISCOVER_PEOPLE_PAGE_TITLE else "Discover People")


        pages = ArrayList()



        if (!fromChatApp()) {
            pages.add(SuggestedPeople())
        }

        pages.add(ContactPage())
        setViewPagerAndTabLayout(viewpager, sliding_tabs, pages, pages.size, getInitialPage())

        if (fromChatApp()) {
            sliding_tabs.visibility = View.GONE
        }
        else if (fromNotification() || fromDashBoard()) {
            setCurrentPage()
        }
    }

    /**
     * For Contact Sending
     * */
    private fun fromChatApp() = intent.getBooleanExtra(ChatMessagesPage.DISCOVER_PEOPLE_INTENT, false)

    private fun getSelectedFragment(position: Int): Fragment = pages[position]


    private fun getInitialPage() = intent.getIntExtra(CURRENT_ITEM_KEY, 0)

    private fun setCurrentPage() {
        viewpager.currentItem = getInitialPage()

        userId = intent.getStringExtra(NEW_USER_ID_KEY)

    }


    fun isContactSyncFromOtherDevices(): Boolean = applicationRef.getmTotalContactsCount() > 0 && applicationRef.getmMyContactsCount() <= 0


    fun showDialog(callBack: CustomCallBack? = null) {
        //show the dialog
        var dialog: FollowPeopleDialog = DialogFactory.getDialog(DialogFactory.DialogType.FOLLOW_PEOPLE, this) as FollowPeopleDialog
        dialog.setListener(object : FollowPeopleDialog.DialogClickListener {
            override fun onGetStartedClick(dialog: Dialog) {
                importContacts(callBack)

            }

            override fun onDontAskMeClick(dialog: Dialog) {

            }

            override fun onCloseClick(dialog: Dialog) {

            }
        })

        dialog.show()

    }

    fun importContacts(callBack: CustomCallBack? = null) {
        viewpager.currentItem = 1

        //ask permission
        /*check permission*/
        if (!isReadContactsPermissionAllowed) {
            tempCallBack = callBack
            requestContactsPermission()
            return
        }
        /*check permission*/

        callBack?.act()

        fetchContactsAndSendToServer()
    }


    fun fromNotification(): Boolean = previousScreenFlag(FROM_NOTIFICATION)


    fun fromDashBoard(): Boolean = previousScreenFlag(FROM_DASHBOARD)


    private fun previousScreenFlag(flagType: String) = intent.getBooleanExtra(flagType, false)

    fun fetchContactsAndSendToServer() {
        //fetch contacts

        // AppExecutors.getInstance().diskIO().execute(Runnable {
        //  var contacts = contactsFetch.getContactList(preferences = preference)

        try {
            (getSelectedFragment(0) as SuggestedPeople).removeConnectThread()

        } catch (ex: Exception) {

        }
        var contacts = contactsFetch.getContactsList(preference)
        var deleteContacts = contactsFetch.getDeleteContactList(preferences = preference)

        //  AppExecutors.getInstance().mainThread().execute(Runnable {
        //send contacts to server
        sendContactsToServer(contacts, deleteContacts)
        //sync Adapter
        createSyncAccount()
        // })

        //})


        Log.e("FetchContacts", "Yes")
        //  FetchContacts()

    }

    private fun createSyncAccount() {

        if (!preference.getBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE)) {
            SyncUtils.createSyncAccount(this@DiscoverPeople, false) {
                preference.setBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE, true)
            }
        }
        preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, true)

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CONTACTS_PERMISSION && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (tempCallBack != null) {
                    tempCallBack?.act()
                }
                fetchContactsAndSendToServer()
            }
        }
    }

    fun changeTab() {
        viewpager.currentItem = 1
    }

    private fun sendContactsToServer(contacts: ArrayList<ContactsDataModel>, deleteContacts: ArrayList<DeleteContactDataModel>) {

        //val locale = AppUtils.getSimCountryCode(this@DiscoverPeople)

        if (mContactsImportResponse != null) {
            mContactsImportResponse?.onContactsImported(contacts, deleteContacts)
        }

    }

    override fun onBackPressed() {
        if (isTaskRoot) {
            appUtils.gotoHomePage(this)
            return
        }
        super.onBackPressed()
    }
}

