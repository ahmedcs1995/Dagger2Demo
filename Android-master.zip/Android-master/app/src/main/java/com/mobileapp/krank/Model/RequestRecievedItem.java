package com.mobileapp.krank.Model;

import android.text.SpannableStringBuilder;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Model.Enums.TypeOfRequest;

/**
 * Created by Yaseen on 28/04/2018.
 */

public class RequestRecievedItem {
    TypeOfRequest typeOfRequest;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("con_id")
    @Expose
    private String conId;
    @SerializedName("company_pic")
    @Expose
    private String companyPic;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("date_added")
    @Expose
    private String dateAdded;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("online")
    @Expose
    private String online;
    @SerializedName("user_slug")
    @Expose
    private String userSlug;
    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("user_url")
    @Expose
    private String userUrl;
    @SerializedName("company_url")
    @Expose
    private String companyUrl;
    @SerializedName("location")
    @Expose
    private String location;
    @SerializedName("time")
    @Expose
    private String time;

    @SerializedName("track_id")
    @Expose
    private int track_id;

    @SerializedName("type")
    @Expose
    private String type;

    @SerializedName("show_name")
    @Expose
    private String show_name;
    @SerializedName("track_url")
    @Expose
    private String track_url;
    @SerializedName("text")
    @Expose
    private String text;

    @SerializedName("track_name")
    @Expose
    private String track_name;

    private SpannableStringBuilder enquiryMessageBuilder;


    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getConId() {
        return conId;
    }

    public void setConId(String conId) {
        this.conId = conId;
    }

    public String getCompanyPic() {
        return companyPic;
    }

    public void setCompanyPic(String companyPic) {
        this.companyPic = companyPic;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getUserUrl() {
        return userUrl;
    }

    public void setUserUrl(String userUrl) {
        this.userUrl = userUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public RequestRecievedItem(TypeOfRequest typeOfRequest) {
        this.typeOfRequest = typeOfRequest;
    }

    public TypeOfRequest getTypeOfRequest() {
        return typeOfRequest;
    }

    public void setTypeOfRequest(TypeOfRequest typeOfRequest) {
        this.typeOfRequest = typeOfRequest;
    }

    public int getTrack_id() {
        return track_id;
    }

    public void setTrack_id(int track_id) {
        this.track_id = track_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getShow_name() {
        return show_name;
    }

    public void setShow_name(String show_name) {
        this.show_name = show_name;
    }


    public SpannableStringBuilder getEnquiryMessageBuilder() {
        return enquiryMessageBuilder;
    }

    public void setEnquiryMessageBuilder(SpannableStringBuilder enquiryMessageBuilder) {
        this.enquiryMessageBuilder = enquiryMessageBuilder;
    }

    public String getTrack_url() {
        return track_url;
    }

    public void setTrack_url(String track_url) {
        this.track_url = track_url;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


    public String getTrack_name() {
        return track_name;
    }

    public void setTrack_name(String track_name) {
        this.track_name = track_name;
    }





    public boolean shouldShowListItem() {
        return ((track_id == 0 || type.equals("Invitation")  || type.equals("Dealer Invitation") || type.equals("Private Invitation")  || type.equals("Article") || type.equals("Auction") || (type.equals("none") && track_id !=0)  || (type.equals("Listing") && show_name .equals("Yes"))));
    }

    public boolean shouldShowBottomLabel(){
        return (track_id != 0 && track_name !="" && !(track_url.isEmpty()));
    }
}
