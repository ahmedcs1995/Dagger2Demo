package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v7.widget.PopupMenu;


import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.CommentsActivity;
import com.mobileapp.krank.Activities.CommentsReplyActivity;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.CustomViews.MyBounceInterpolator;
import com.mobileapp.krank.Functions.AppUtils;

import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ResponseModels.DataModel.ChildCommentDataModel;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.support.v4.content.ContextCompat;
import android.widget.Toast;

import com.mobileapp.krank.ResponseModels.CommentLikeResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsDataResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsReply;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

/**
 * Created by Yaseen on 25/04/2018.
 */


/**
 * Created by Ahmed on 4/20/2018.
 */

public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<CommentsDataResponse> items = new ArrayList<>();
    CommentsActivity commentsActivity;
    NewsFeedArray newsFeedItem;
    public SaveInSharedPreference preference;
    DeviceInfo deviceInfo;
    NewsFeedFunctions newsFeedFunctions;

    Animation myAnim;

    AppUtils appUtils = AppUtils.getInstance();


    //callBack
    CallBackWithPosTypeAndView callBack;

    public void setCallBack(CallBackWithPosTypeAndView callBack) {
        this.callBack = callBack;
    }

    public class CommentViewHolder extends RecyclerView.ViewHolder {

        View item;
        CircleImageView profileImgCommentPost;
        TextView timeTextViewCommentPost;
        TextView comentName;
        TextView comentDes;
        View likeContainerCommentPost;
        View reply_count_img_container;
        View replyContainer;
        View delete_comment;
        TextView viewReplyText;
        TextView commentReplyName;
        ImageView likeImgCommentPost;
        ImageView commentReplyImg;
        TextView likeTextCommentPost;
        TextView noOfReplies;
        TextView noOfLikesCommentPost;


        public CommentViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            profileImgCommentPost = itemView.findViewById(R.id.profile_img_comment_post);
            timeTextViewCommentPost = itemView.findViewById(R.id.time_text_view_comment_post);
            comentName = itemView.findViewById(R.id.commentName);
            comentDes = itemView.findViewById(R.id.comment_des);
            likeContainerCommentPost = itemView.findViewById(R.id.like_container_comment_post);
            likeImgCommentPost = itemView.findViewById(R.id.like_img_comment_post);
            likeTextCommentPost = itemView.findViewById(R.id.like_text_comment_post);
            noOfLikesCommentPost = itemView.findViewById(R.id.no_of_likes_comment_post);
            noOfReplies = itemView.findViewById(R.id.no_of_replies_comment_post);
            replyContainer = itemView.findViewById(R.id.reply_container);
            viewReplyText = itemView.findViewById(R.id.view_reply_text);
            commentReplyImg = itemView.findViewById(R.id.comment_reply_img);
            commentReplyName = itemView.findViewById(R.id.comment_reply_name);
            reply_count_img_container = itemView.findViewById(R.id.reply_count_img_container);
            delete_comment = itemView.findViewById(R.id.delete_view_comment_post);


            reply_count_img_container.setOnClickListener(view -> {
                if(callBack == null) return;
                callBack.act(getAdapterPosition(),Constants.GOTO_COMMENTS_REPLAY,reply_count_img_container);
            });

            delete_comment.setOnClickListener(view -> showDeletePopUpMenu(view, items.get(getAdapterPosition()), getAdapterPosition()));


            likeContainerCommentPost.setOnClickListener(view -> sendLike(items.get(getAdapterPosition()), getAdapterPosition(), likeContainerCommentPost));

            replyContainer.setOnClickListener(view -> {
                if(callBack == null) return;
                callBack.act(getAdapterPosition(),Constants.GOTO_COMMENTS_REPLAY ,null);
            });

            profileImgCommentPost.setOnClickListener(view -> {
                if(callBack == null) return;
                callBack.act(getAdapterPosition(),Constants.COMMENTS_USER_ID ,null);
            });

            comentName.setOnClickListener(view -> {
                if(callBack == null) return;
                callBack.act(getAdapterPosition(),Constants.COMMENTS_USER_ID ,null);
            });
        }

    }



    public CommentsAdapter(List<CommentsDataResponse> items, CommentsActivity commentsActivity, NewsFeedArray newsFeedItem, DeviceInfo deviceInfo, SaveInSharedPreference preference) {
        this.items = items;
        this.commentsActivity = commentsActivity;
        this.newsFeedItem = newsFeedItem;
        this.preference = preference;
        this.deviceInfo = deviceInfo;

        newsFeedFunctions = new NewsFeedFunctions(commentsActivity, deviceInfo,  true);

        myAnim = AnimationUtils.loadAnimation(commentsActivity, R.anim.bounce_for_comment_click);

    }

    public CommentsAdapter(CommentsDataResponse[] items, CommentsActivity commentsActivity) {

        this.items.addAll(Arrays.asList(items));
        this.commentsActivity = commentsActivity;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).getTypeOfComment();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view;
        switch (viewType) {
            case Constants.LINKED_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view, callBack);
            case Constants.IMAGE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_post_item_layout, parent, false);
                return new ImageViewHolder(view, callBack);
            case Constants.TEXT_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_post_item_layout, parent, false);
                return new TextPostHolder(view, callBack);
            case Constants.CHECK_IN:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkin_post_item_layout, parent, false);
                return new CheckInHolder(view, callBack);
            case Constants.NETWORK_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_post_item_layout, parent, false);
                return new NetworkPost(view, callBack);
            case Constants.LISTING_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.YOUTUBE_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.ARTICLE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.DEALER_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_post_item_layout, parent, false);
                return new DealerPost(view, callBack);
            case Constants.VIMEO_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.AUCTION_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.COMMENT:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_item, parent, false);
                return new CommentViewHolder(view);
            default:
                return null;

        }
    }


    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final CommentsDataResponse item = items.get(position);


        switch (item.getTypeOfComment()) {
            case Constants.LINKED_POST:
                newsFeedFunctions.setTypeLinkedPost(holder, newsFeedItem);
                break;
            case Constants.IMAGE_POST:
                newsFeedFunctions.setTypeImgPost(holder, newsFeedItem);
                break;
            case Constants.TEXT_POST:
                newsFeedFunctions.setTypeTextPost(holder, newsFeedItem);
                break;
            case Constants.COMMENT:
                setTypeComment(holder, item, position);
                break;
            case Constants.CHECK_IN:
                newsFeedFunctions.setCheckInTypePost(holder, newsFeedItem);
                break;
            case Constants.NETWORK_POST:
                newsFeedFunctions.setNetworkPost(holder, newsFeedItem);
                break;
            case Constants.DEALER_POST:
                newsFeedFunctions.setDealerPost(holder, newsFeedItem);
                break;
            case Constants.LISTING_POST:
                newsFeedFunctions.setTypeListingPost(holder, newsFeedItem);
                break;
            case Constants.YOUTUBE_VIDEO:
                newsFeedFunctions.setTypeYoutubeVideoPost(holder, newsFeedItem);
                break;
            case Constants.ARTICLE_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, newsFeedItem, "Article");
                break;
            case Constants.VIMEO_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, newsFeedItem);
                break;
            case Constants.AUCTION_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, newsFeedItem, "Auction");
        }

    }

    private void sendLike(final CommentsDataResponse commentItem, final int position, final View likeBtn) {

        /*animate like btn*/

        final Animation myAnim = AnimationUtils.loadAnimation(commentsActivity, R.anim.bounce);

        MyBounceInterpolator interpolator = new MyBounceInterpolator(0.2, 20);
        myAnim.setInterpolator(interpolator);

        likeBtn.startAnimation(myAnim);

        /*animate like btn*/

        int isLike = commentItem.getIsLike();
        final int likeToSend;
        if (isLike == 1) {
            likeToSend = 0;
        } else {
            likeToSend = 1;
        }

        /*changing runtime*/
        if (likeToSend == 0) {
            commentItem.setTotalLikes("" + (Integer.parseInt(commentItem.getTotalLikes()) - 1));
        } else {
            commentItem.setTotalLikes("" + (Integer.parseInt(commentItem.getTotalLikes()) + 1));
        }
        commentItem.setIsLike(likeToSend);
        notifyItemChanged(position);
        likeBtn.setEnabled(false);
        /*changing runtime*/
        commentsActivity.getAPI().postCommentLike(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(commentItem.getCid()), String.valueOf(likeToSend)).enqueue(new Callback<CommentLikeResponse>() {
            @Override
            public void onResponse(Call<CommentLikeResponse> call, Response<CommentLikeResponse> response) {


                likeBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                    }

                }
            }

            @Override
            public void onFailure(Call<CommentLikeResponse> call, Throwable t) {

                Log.e("Error like ->", "" + t.getMessage());
                likeBtn.setEnabled(true);
            }
        });
    }

    private void removeComment(final CommentsDataResponse commentItem, final int position) {
        commentsActivity.getAPI().newsFeedCommentRemove(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(commentItem.getCid())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        removeAt(position);
                        newsFeedItem.setComment_count(items.size() - 1);
                        notifyItemChanged(0);

                        if (items.size() == 1) {
                            commentsActivity.lastCommentId = -1;
                        }

                        return;
                    }
                }
                Toast.makeText(commentsActivity.getApplicationContext(), Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                Toast.makeText(commentsActivity.getApplicationContext(), Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }

    private void showDialog(CommentsDataResponse commentItem, int position) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, commentsActivity))
                .setHeading("Are you sure?")
                .setDescription("Are you sure you want to delete the comment")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    removeComment(commentItem, position);
                });

        dialog.show();
    }

    private void showDeletePopUpMenu(View view, final CommentsDataResponse commentItem, final int position) {
        final PopupMenu popupMenu = new PopupMenu(commentsActivity, view);


        popupMenu.setOnMenuItemClickListener(menuItem -> {
            switch (menuItem.getItemId()) {
                case R.id.delete_option:
                    showDialog(items.get(position), position);
                    return true;

                default:
                    return false;
            }
        });

        popupMenu.inflate(R.menu.delete_pop_up);


        // if you want icon with menu items then write this try-catch block.
        try {
            Field[] fields = popupMenu.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popupMenu);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod(
                            "setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // if you want icon with menu items then write this try-catch block.

        popupMenu.show();

    }


    private void setTypeComment(final RecyclerView.ViewHolder holder, final CommentsDataResponse item, final int position) {

        final CommentViewHolder commentViewHolder = (CommentViewHolder) holder;


        if (item.getReply().size() > 0) {
            commentViewHolder.replyContainer.setVisibility(View.VISIBLE);
            CommentsReply commentsReply = item.getReply().get(0);
            String boldText = commentsReply.getFullName();
            String normalText = " " + commentsReply.getReply();
            SpannableString str = new SpannableString(boldText + normalText);
            str.setSpan(new StyleSpan(Typeface.BOLD), 0, boldText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            commentViewHolder.commentReplyName.setText(str);

            Glide.with(commentsActivity).load(AppUtils.getImgUrl(commentsReply.getProfile_pic())).into(commentViewHolder.commentReplyImg);

            // if (item.getReply().size() > 1) {
            if (Integer.parseInt(item.getChildCount()) > 1) {
                commentViewHolder.viewReplyText.setText("View " + item.getChildCount() + " replies");
            } else {
                commentViewHolder.viewReplyText.setText("View " + item.getChildCount() + " reply");
            }
        } else {
            commentViewHolder.replyContainer.setVisibility(View.GONE);
        }
        if (item.getProfilePic() != null) {
            Glide.with(commentsActivity).load(AppUtils.getImgUrl(item.getProfilePic())).into(commentViewHolder.profileImgCommentPost);
        }


        commentViewHolder.timeTextViewCommentPost.setText(item.getDate());
        commentViewHolder.comentName.setText(item.getFirstName() + " " + item.getLastName());
        commentViewHolder.comentDes.setText(Html.fromHtml(item.getComments()));

        if (item.getIsLike() == 0) {
            commentViewHolder.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(commentsActivity, R.drawable.like_img_new));
            //  holder.likeImgForTextPost.setColorFilter(ContextCompat.getColor(activity, R.color.drawerGray), android.graphics.PorterDuff.Mode.MULTIPLY);
            commentViewHolder.likeTextCommentPost.setTextColor(ContextCompat.getColor(commentsActivity, R.color.drawerGray));
        } else {
            commentViewHolder.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(commentsActivity, R.drawable.liked_img_new));
            commentViewHolder.likeTextCommentPost.setTextColor(ContextCompat.getColor(commentsActivity, R.color.drawer_background));
        }
        commentViewHolder.noOfReplies.setText(item.getChildCount());

        commentViewHolder.noOfLikesCommentPost.setText(item.getTotalLikes());


        if (item.getCa() == 1) {
            commentViewHolder.delete_comment.setVisibility(View.VISIBLE);

        } else {
            commentViewHolder.delete_comment.setVisibility(View.GONE);
        }


        if (item.isFocusComment()) {
            commentViewHolder.item.setBackgroundColor(ContextCompat.getColor(commentsActivity, R.color.unread_notification));
        } else {
            commentViewHolder.item.setBackgroundColor(ContextCompat.getColor(commentsActivity, R.color.AppWhiteColor));
        }
    }


}




