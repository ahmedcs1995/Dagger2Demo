package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.util.Log
import com.mobileapp.krank.Adapters.CarousalCardsAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Functions.launchActivity
import com.mobileapp.krank.Model.Enums.CardsListenerType
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.ConnectionResponse
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsCompanyData
import com.yarolegovich.discretescrollview.DiscreteScrollView
import com.yarolegovich.discretescrollview.transform.ScaleTransformer
import kotlinx.android.synthetic.main.activity_my_connection_cards2.carosuel_view
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.ArrayList

class MyConnectionCards : BaseActivity() {

    //list items
    private lateinit var items: MutableList<ConnectionsDataModel>
    private var cardsAdapter: CarousalCardsAdapter<ConnectionsDataModel>? = null

    //current index
    private var currentItem: Int = 0
    private var reminderCount: Int = 0

    //pagination
    internal var offset: Int = 0

    //flags
    var isDataUpdated: Boolean = false
    var shouldScrollCall = true

    val handler = Handler()
    var runnable: Runnable? = null


    lateinit var app: CustomApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_connection_cards2)


        runnable = Runnable {
            getData()
        }

        init()

        setUpAdapter()
    }

    private fun init() {
        items = ArrayList()

        currentItem = intent.getIntExtra("currentItem", 0)



        offset = intent.getIntExtra("offset", 0)
        reminderCount = intent.getIntExtra("reminderCount", 0)


        shouldScrollCall = reminderCount > 0


        app = applicationContext as CustomApplication

    }


    private fun setUpAdapter() {


        items.addAll(app.connectionItems)

        cardsAdapter = CarousalCardsAdapter(CarousalCardsAdapter.USER_VIEW, items, this, deviceResolution, object : CarousalCardsAdapter.CardsListeners {
            override fun onBind(holder: RecyclerView.ViewHolder, position: Int) {
                if (items[position].type == Constants.ITEM_VIEW) {

                    cardsAdapter?.setUserCardView(holder as CarousalCardsAdapter<ConnectionsDataModel>.ConnectionsCardsViewHolder, items[position], position)
                }
            }

            override fun getViewType(position: Int): Int {
                var item: ConnectionsDataModel = items[position]
                return when (item.type) {
                    Constants.ITEM_VIEW -> CarousalCardsAdapter.ITEM_VIEW
                    Constants.LOADER_VIEW -> CarousalCardsAdapter.LOADER_VIEW
                    else -> CarousalCardsAdapter.LOADER_VIEW
                }
            }

        }, object : CarousalCardsAdapter.ClickListeners {
            override fun itemClickListener(position: Int, type: CardsListenerType) {
                when (type) {
                    CardsListenerType.DELETE -> {
                        if(items[position].companyData.userId == CarousalCardsAdapter.CONNECTION_NOT_TO_REMOVE){
                            showToast("Can't remove this connection")
                            return
                        }
                        showRemoveDialog(items[position].companyData.userId.toInt(), position)
                    }
                    CardsListenerType.SEND_MESSAGE -> {
                        sendMsg(items[position])
                    }

                    CardsListenerType.SEND_CONTACT_CARD -> {
                        sendContactCardAs(items[position])
                    }
                    CardsListenerType.VIEW_LISTING -> {
                        gotoListing(items[position])
                    }
                    CardsListenerType.VIEW_PROFILE -> {
                        gotoProfile(items[position])
                    }
                    CardsListenerType.COMPANY_IMG -> {
                        this@MyConnectionCards.launchActivity<CompanyProfileView> {
                            putExtra(CompanyProfileView.INTENT_COMPANY_ID,items[position].companyData.companyId)
                        }
                    }
                    CardsListenerType.PRIVATE_CONNECTION ->{

                        if(!items[position].isConnectionPrivate){
                            privateConnection(items[position],position)
                            return
                        }
                        showToast("Already a private connection")

                    }
                }
            }

        })

        carosuel_view.adapter = cardsAdapter

        carosuel_view.setItemTransitionTimeMillis(130)

        carosuel_view.setItemTransformer(ScaleTransformer.Builder().setMinScale(0.90f)
                .build())

        carosuel_view.scrollToPosition(currentItem)
        setNameOnToolbar(items[currentItem].companyData)


        carosuel_view.addScrollStateChangeListener(object : DiscreteScrollView.ScrollStateChangeListener<RecyclerView.ViewHolder> {
            override fun onScrollStart(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {

            }

            override fun onScrollEnd(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {
                Log.e("onScrollEnd", "==> $adapterPosition")


                if (items[adapterPosition].type == Constants.ITEM_VIEW) {
                    setNameOnToolbar(items[adapterPosition].companyData)
                }


                if (adapterPosition == items.size - 1 && shouldScrollCall) {

                    shouldScrollCall = false


                    shouldScrollCall = false
                    Log.e("onScrollEnd", "Items End ==> $adapterPosition")


                    items.add(ConnectionsDataModel(Constants.LOADER_VIEW))
                    cardsAdapter!!.notifyItemInserted(items.size)


                    offset += Constants.PAGE_LIMIT

                    handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong() * 2)

                }
            }

            override fun onScroll(scrollPosition: Float, currentPosition: Int, newPosition: Int, currentHolder: RecyclerView.ViewHolder?, newCurrent: RecyclerView.ViewHolder?) {
               /* if (items[newPosition].type == Constants.ITEM_VIEW) {
                    setNameOnToolbar(items[newPosition].companyData)
                }*/
            }
        })
    }

    private fun changePrivateConnectionStatus(position: Int,status : String){
        items[position].con_type = status
        cardsAdapter?.notifyItemChanged(position)
    }
    private fun privateConnection(connectionsDataModel: ConnectionsDataModel, position: Int) {
        changePrivateConnectionStatus(position,ConnectionsDataModel.PRIVATE_CONNECTION)
        isDataUpdated = true
        api.privateConnection(preference.getString(Constants.ACCESS_TOKEN),connectionsDataModel.companyData.userId).enqueue(object : Callback<GeneralResponse>{
            override fun onResponse(call: Call<GeneralResponse>?, response: Response<GeneralResponse>?) {
                if(response == null) return

                if(response.isSuccessful){
                    if(response.body().status != Constants.SUCCESS_STATUS){



                        changePrivateConnectionStatus(position,ConnectionsDataModel.NORMAL_CONNECTION)
                    }
                    showToast(response.body().message)
                }else{
                    onResponseFailure()
                    changePrivateConnectionStatus(position,ConnectionsDataModel.NORMAL_CONNECTION)
                }
            }

            override fun onFailure(call: Call<GeneralResponse>?, t: Throwable?) {
                onResponseFailure()
            }

        })
    }
    private fun getData() {
        api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "",intent.getStringExtra("keyword"),Constants.PAGE_LIMIT).enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        if (response.body().data.connectionsData.size > 0) {



                            items[items.size - 1] = response.body().data.connectionsData[0]
                            cardsAdapter!!.notifyItemChanged(items.size - 1)


                            //setting toolbar name
                            if (carosuel_view.currentItem == items.size - 1) {
                                setNameOnToolbar(items[items.size - 1].companyData)
                            }


                            if (response.body().data.connectionsData.size > 2) {
                                val oldSize = items.size

                                items.addAll(response.body().data.connectionsData.subList(1, response.body().data.connectionsData.size))


                                cardsAdapter!!.notifyItemRangeInserted(oldSize, items.size)

                                //enable the scroll
                                shouldScrollCall = response.body().data.reminderCount > 0

                            }
                        }
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                }
            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {

                showToast(Constants.ERROR_MSG_TOAST_1)
            }
        })
    }


    private fun setNameOnToolbar(comapanyData: ConnectionsCompanyData?) {
        if(comapanyData == null) return
        setNormalPageToolbar( comapanyData.firstName + " " + comapanyData.lastName + "'s Card")

    }

    private fun gotoProfile(item: ConnectionsDataModel) {
        this@MyConnectionCards.launchActivity<UserProfileView> {
            putExtra(UserProfileView.INTENT_USER_ID, item.companyData.userId)
        }
    }

    private fun gotoListing(item: ConnectionsDataModel) {
        val intent = Intent(this, MarketPlacePage::class.java)
        with(intent) {
            putExtra("currentItem", 0)
            putExtra("currentItem", 0)
            putExtra("networkId", "0")
            putExtra("connectionId", item.companyData.userId)
            putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE)
            putExtra(MarketPlacePage.TOOLBAR_NAME, item.companyData.firstName)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }

    private fun sendMsg(item: ConnectionsDataModel) {
        if (item.companyData.user_chat.size > 0) {
            val intent = Intent(this, PrivateChatConversationActivity::class.java)
            with(intent) {
                putExtra("from_notification", true)
                putExtra("recipient_name", item.companyData.firstName + " " + item.companyData.lastName)
                putExtra("selected_data", appUtils.convertToJson(item))
                putExtra("conv_id", "" + item.companyData.user_chat[0].conversation_id)
            }

            MyFirebaseMessagingService.CURRENT_CONV_ID = item.companyData.user_chat[0].conversation_id
            startActivity(intent)
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
            return
        }
        val intent = Intent(this, PrivateChatConversationActivity::class.java)

        intent.putExtra("start_conversation", true)
        intent.putExtra("recipient_name", item.companyData.firstName + " " + item.companyData.lastName)
        intent.putExtra("connection_id", item.companyData.userId)
        intent.putExtra("selected_data", appUtils.convertToJson(item))

        startActivity(intent)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun sendContactCardAs(item: ConnectionsDataModel) {
        val intent = Intent(this, SendContactCardPage::class.java)

        if (item.companyData.user_chat.size > 0) {
            intent.putExtra("conv_id", "" + item.companyData.user_chat[0].conversation_id)

        }
        intent.putExtra("con_id", "" + item.companyData.userId)
        startActivity(intent)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }



    private fun showRemoveDialog(userId: Int, position: Int) {


        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this) as NormalAppDialog)
                .setHeading("Are you sure you want to remove this connection?")
                .setDescription("You will also be removed from this user's connection list.")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener {
                    isDataUpdated = true
                    deleteConnection(userId)

                    it.dismiss()

                    //remove the thread
                    items.removeAt(position)
                    cardsAdapter!!.notifyDataSetChanged()


                    if(items.size == 0){
                        onBackPressed()
                        return@setConfirmButtonListener
                    }


                    if(position < items.size && position  >= 0 && items[position].type == Constants.ITEM_VIEW){
                        setNameOnToolbar(items[position].companyData)
                    }
                    else if(position -1  >= 0 && position - 1 < items.size && items[position - 1].type == Constants.ITEM_VIEW){
                        setNameOnToolbar(items[position -1].companyData)
                    }
                    else{
                        setNameOnToolbar(null)
                    }
                }
        dialog.show()

    }

    private fun deleteConnection(userId: Int) {
        api.removeConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), userId).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        showToast("Successfully removed connection")
                    }else {
                        showToast(response.body().message)
                    }

                }else {
                    onResponseFailure()
                }
            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                onResponseFailure()

            }
        })
    }
    override fun onBackPressed() {
        if (isDataUpdated) {
            app.connectionItems = items
            val intent = Intent()
            intent.putExtra("isDataDeleted", isDataUpdated)
            intent.putExtra("offset", offset)
            setResult(RESULT_OK, intent)
            finish()
            overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
            return
        }
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }



}
