package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NetworkGroupCompanyDataModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("cnt")
    @Expose
    private String cnt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

}
