package com.mobileapp.krank.FirstPageFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.R;

/**
 * Created by Yaseen on 10/04/2018.
 */

public class PageTwo extends BaseFragment {
    public PageTwo(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.page_two_fragment, container, false);
        setFragmentView(me);

        return me;
    }
}
