package com.mobileapp.krank.Repository.NewsFeed;


import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.util.Log;

import com.mobileapp.krank.CallBacks.ResponseCallBacks;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.Dao.NewsFeedDao;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.HomePageTabs.Newsfeed;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.NewsFeedListResponse;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.ServiceManager;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VerifyPhoneNumberViewHolder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsFeedRepository {

    AppExecutors executors;

    private NewsFeedDao newsFeedDao;

    ServiceManager serviceManager;

    public NewsFeedRepository(Application application) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        newsFeedDao = db.getNewsFeedDao();
        executors = AppExecutors.getInstance();
        serviceManager = ServiceManager.getInstance();
    }

    public LiveData<List<NewsFeedArray>> getmAllFeeds() {
        return newsFeedDao.getAllRecords();
    }

    public void deleteAllData() {
        executors.diskIO().execute(() -> newsFeedDao.deleteAll());

    }

    public NewsFeedDao getNewsFeedDao() {
        return newsFeedDao;
    }

    public void bulkInsert(final List<NewsFeedArray> feed) {
        executors.diskIO().execute(() -> newsFeedDao.bulkInsert(feed));
    }

    public void updateLike(int id, int isLike, int likeCount) {
        executors.diskIO().execute(() -> newsFeedDao.updateLikeByFeedId(id, isLike, likeCount));
    }

    public void updateLikeComment(int id, int isLike, int likeCount, int commentCount) {
        executors.diskIO().execute(() -> newsFeedDao.updateLikeCommentByFeedId(id, isLike, likeCount, commentCount));
    }

    public void deleteById(int id) {
        executors.diskIO().execute(() -> newsFeedDao.deleteById(id));
    }


    public void getNewsFeedData(String AccessToken, String last_num, ResponseCallBacks callBack) {

        serviceManager.getAPI().getNewsFeedList(AccessToken, "0" + last_num, Constants.PAGE_LIMIT_1).enqueue(new Callback<NewsFeedListResponse>() {
            @Override
            public void onResponse(Call<NewsFeedListResponse> call, Response<NewsFeedListResponse> response) {
                // network_text_view.setText(response.body().getData().getNetworkCount());
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {


                        callBack.success(call, response);
                    } else {
                        callBack.failure(call, response);
                    }
                } else {
                    callBack.failure(call, response);
                }
            }

            @Override
            public void onFailure(Call<NewsFeedListResponse> call, Throwable t) {
                callBack.failure(call, t);
            }
        });
    }


    public void verifyCellNumberCode(String AccessToken,String hash, ResponseCallBacks callBack) {

        serviceManager.getAPI().verifyCellNumberCode(AccessToken,"",hash).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        callBack.success(call, response);
                    } else {
                        callBack.failure(call, response);
                    }
                } else {
                    callBack.failure(call, response);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                callBack.failure(call, t);
            }
        });
    }

    public void sendCodeToServer(String AccessToken, String code,ResponseCallBacks callBack) {
        serviceManager.getAPI().verifyCellNumber(AccessToken,code).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        callBack.success(call,response);
                    } else {
                        callBack.failure(call,response);
                    }
                } else {
                    callBack.failure(call,response);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                callBack.failure(call,t);
            }
        });
    }
}