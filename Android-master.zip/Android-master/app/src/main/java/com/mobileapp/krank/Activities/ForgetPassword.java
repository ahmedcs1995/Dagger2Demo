package com.mobileapp.krank.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPassword extends BaseActivity {
    private Button retrieveBtn;

    //input fields
    private EditText email_edit_text;
    private TextView error;


    //invite text
    TextView info_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //views
        setContentView(R.layout.activity_forget_password);
        retrieveBtn = findViewById(R.id.retrieve_btn);
        email_edit_text = findViewById(R.id.email_edit_text);
        error = findViewById(R.id.error_view);
        info_text = findViewById(R.id.info_text);
        setImageIntermsOfDeviceResolution();

        //enable bottom links
        gotoLinkPage();

        setScreenHeader("Forgot Password");


        /*invitation text*/
        setInviteText(info_text);
        /*invitation text*/

        showAlert = showAlert("Please wait...", SweetAlertDialog.PROGRESS_TYPE, false);

        retrieveBtn.setOnClickListener(view -> {
            onRetrieveListener();
        });
    }

    private void onRetrieveListener() {
        String email = email_edit_text.getText().toString().trim();

        if (email.isEmpty()) {
            error.setText(Constants.ENTER_EMAIL_TEXT);
        } else if (!(AppUtils.validateEmail(email))) {
            error.setText(Constants.ENTER_VALID_EMAIL_TEXT);
        } else {
            forgotPass(email);
        }
    }

    private void forgotPass(final String email) {
        showAlert.show();
        getAPI().forgotPassword(email).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    GeneralResponse forgotPasswordResponse = response.body();
                    if (forgotPasswordResponse.getStatus().equals(Constants.SUCCESS_STATUS)) {
                        Intent intent = new Intent(ForgetPassword.this, ForgetPasswordVerification.class);
                        intent.putExtra("USER_EMAIL", email);
                        startActivity(intent);
                        showAlert.dismiss();
                        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);


                    } else {
                        showAlert.dismiss();
                        error.setText(forgotPasswordResponse.getMessage());
                    }
                } else {
                    showAlert.dismiss();
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
                showAlert.dismiss();
            }
        });
    }


}
