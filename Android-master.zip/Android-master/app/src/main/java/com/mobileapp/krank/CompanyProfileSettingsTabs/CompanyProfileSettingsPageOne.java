package com.mobileapp.krank.CompanyProfileSettingsTabs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mobileapp.krank.Activities.CustomDropDown.CityListActivity;
import com.mobileapp.krank.Activities.CustomDropDown.CountryListActivity;
import com.mobileapp.krank.Activities.MyCompanyProfileSettings;
import com.mobileapp.krank.Base.BaseFragment;

import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CompanyProfileSettingsPageOne extends BaseFragment {


    public EditText company_name_edit_text, company_address_edit_text, country_text, city_text, postal_code_edit_text, phone_edit_text;
    public TextView mobile_code_edit_text;
    String company_name, company_address, postalCode, telephone_number;
    public CountyListData selectedCountryData;
    public CityListData selectedCityData;

    private static int COUNTRY_LIST_ACTIVITY_CODE = 100;
    private static int CITY_LIST_ACTIVITY_CODE = 200;
    Gson gson;

    MyCompanyProfileSettings activityRef;


    ScrollView scroll_view;
    public CompanyProfileSettingsPageOne() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.company_profile_settings_page_one, container, false);
        setFragmentView(me);


        init();


        initViews();

        setValues();

        country_text.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), CountryListActivity.class);
            if(selectedCountryData!=null){
                intent.putExtra("countryData", ((MyCompanyProfileSettings) getActivity()).appUtils.convertToJson(selectedCountryData));
            }
            startActivityForResult(intent, COUNTRY_LIST_ACTIVITY_CODE);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        city_text.setOnClickListener(view -> {
            if (selectedCountryData != null) {
                Intent intent = new Intent(getContext(), CityListActivity.class);
                intent.putExtra("countryData", ((MyCompanyProfileSettings) getActivity()).appUtils.convertToJson(selectedCountryData));
                startActivityForResult(intent, CITY_LIST_ACTIVITY_CODE);
                getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            } else {
                Toast.makeText(getContext(), "Please Select Country", Toast.LENGTH_SHORT).show();
            }
        });
        return me;
    }

    private void init() {

        gson = CustomGson.getInstance();
        activityRef = (MyCompanyProfileSettings) getActivity();
    }

    private void initViews(){
        company_name_edit_text = (EditText) findViewById(R.id.company_name_edit_text);
        company_address_edit_text = (EditText) findViewById(R.id.company_address_edit_text);
        country_text = (EditText) findViewById(R.id.country_text);
        city_text = (EditText) findViewById(R.id.city_text);
        postal_code_edit_text = (EditText) findViewById(R.id.postal_code_edit_text);
        mobile_code_edit_text = (TextView) findViewById(R.id.mobile_code_edit_text);
        phone_edit_text = (EditText) findViewById(R.id.phone_edit_text);
        scroll_view = (ScrollView) findViewById(R.id.scroll_view);
     //   error_view = (TextView) findViewById(R.id.error_view);
    }

    public void setData(String company_name, String company_address, String postalCode, String telephone_number, CountyListData selectedCountryData, CityListData selectedCityData) {
        this.company_name = company_name;
        this.company_address = company_address;
        this.postalCode = postalCode;
        this.telephone_number = telephone_number;
        this.selectedCountryData = selectedCountryData;
        this.selectedCityData = selectedCityData;
    }

    private void setValues() {


        company_name_edit_text.setText("" + company_name);
        if(company_address !=null){
            company_address_edit_text.setText("" + company_address);
        }

        setTelephoneNumber();
        if(postalCode !=null){
            postal_code_edit_text.setText("" + postalCode);
        }
        if (selectedCountryData != null) {
            country_text.setText("" + selectedCountryData.getName());
            mobile_code_edit_text.setText("" + selectedCountryData.getPhoneCode());
        }
        if (selectedCityData != null) {
            city_text.setText("" + selectedCityData.getCityName());
        }
    }

    private void setTelephoneNumber() {
        if (telephone_number !=null && telephone_number.indexOf('-') != -1) {
            phone_edit_text.setText(telephone_number.substring(telephone_number.indexOf('-') + 1, telephone_number.length()));
        }
    }

    private void focusToView(EditText mEditText,String errorMessage){
        scroll_view.scrollTo(0,mEditText.getTop());
        activityRef.showToast(errorMessage);
    }

    public void updateProfile() {
       // error_view.setText("");
            ((MyCompanyProfileSettings) getActivity()).getAPI().updateCompanyProfileStepOne(((MyCompanyProfileSettings) getActivity()).preference.getString(Constants.ACCESS_TOKEN),company_address_edit_text.getText().toString(),selectedCountryData.getCode(),selectedCityData.getCityId(),postal_code_edit_text.getText().toString(),selectedCountryData.getPhoneCode() + "-" +phone_edit_text.getText().toString()).enqueue(new Callback<GeneralResponse>() {
                @Override
                public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            showToast(response.body().getMessage());
                        } else {
                            showToast(response.body().getMessage());
                        }
                    } else {
                        showToast(Constants.ERROR_MSG_TOAST);
                    }
                }

                @Override
                public void onFailure(Call<GeneralResponse> call, Throwable t) {
                    showToast(Constants.ERROR_MSG_TOAST);
                }
            });
    }


    public boolean checkForError() {
        boolean error = false;
        if (company_address_edit_text.getText().toString().isEmpty()) {
            error = true;
         //   error_view.setText(Constants.ENTER_COMPANY_ADDRESS);
            focusToView(company_address_edit_text,Constants.ENTER_COMPANY_ADDRESS);

        }
        else if(selectedCountryData ==null){
            error = true;
           // error_view.setText(Constants.SELECT_COUNTRY);
            focusToView(country_text,Constants.SELECT_COUNTRY);
        }
        else if(selectedCityData ==null){
            error = true;
          //  error_view.setText(Constants.SELECT_CITY);
            focusToView(city_text,Constants.SELECT_CITY);
        }
        else if(postal_code_edit_text.getText().toString().isEmpty()){
            error = true;
          //  error_view.setText(Constants.ENTER_POSTAL_CODE);
            focusToView(postal_code_edit_text,Constants.ENTER_POSTAL_CODE);
         //   postal_code_edit_text.setError(Constants.ENTER_POSTAL_CODE);
        }
        else if(phone_edit_text.getText().toString().isEmpty()){
            error = true;
         //   error_view.setText(Constants.ENTER_PHONE_NUMBER);
            focusToView(phone_edit_text,Constants.ENTER_PHONE_NUMBER);
        }
        return error;
    }

    private void showToast(String message){
        try {
            activityRef.showToast(message);
        }catch (Exception ex){

        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COUNTRY_LIST_ACTIVITY_CODE) {
                selectedCountryData = gson.fromJson(data.getStringExtra("selectedCountry"), CountyListData.class);
                mobile_code_edit_text.setText(selectedCountryData.getPhoneCode());
                city_text.setText("");
                selectedCityData = null;
                country_text.setText("" + selectedCountryData.getName());
            } else if (requestCode == CITY_LIST_ACTIVITY_CODE) {
                selectedCityData = gson.fromJson(data.getStringExtra("cityData"), CityListData.class);
                city_text.setText("" + selectedCityData.getCityName());
            }

        }
    }
}

