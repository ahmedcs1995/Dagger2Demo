package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ListingWebviewData {
    @SerializedName("login_url")
    @Expose
    private String login_url;

    @SerializedName("encoded_url")
    @Expose
    private String encoded_url;

    public String getLogin_url() {
        return login_url;
    }

    public void setLogin_url(String login_url) {
        this.login_url = login_url;
    }

    public String getEncoded_url() {
        return encoded_url;
    }

    public void setEncoded_url(String encoded_url) {
        this.encoded_url = encoded_url;
    }
}
