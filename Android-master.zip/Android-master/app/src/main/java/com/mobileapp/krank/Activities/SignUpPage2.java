package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.Utils.ApiUtils;

public class SignUpPage2 extends BaseActivity {

    //views
    Button continueBtn;
    TextView linkText;
    TextView info_text;

    //invite link code
    CompanyInvitationDataModel companyInvitationDataModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page2);
        continueBtn = (Button) findViewById(R.id.continue_btn);
        linkText = findViewById(R.id.link_text);
        setScreenHeader("Sign Up");
        setKrankLogoForUserProfiling();
        setImageIntermsOfDeviceResolution();
        gotoLinkPage();
        SpannableStringBuilder ssb = new SpannableStringBuilder("");

        info_text = findViewById(R.id.info_text);

        /*invite text*/
        if (!isInviteLinkDataExists()) {
            info_text.setVisibility(View.GONE);
        } else {
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }
        /*invite text*/



        /*set up messages*/
        if (isFreeUser()) {
            if (getIntent().getStringExtra("res_message") != null) {
                String emailTemplate = getIntent().getStringExtra("email_template") == null ? "" :  getIntent().getStringExtra("email_template");
                AppUtils.addClickableText(ssb, ssb.length(), getIntent().getStringExtra("res_message").replace(emailTemplate,""), this, R.color.AppDarkGray);
                AppUtils.addClickableText(ssb, ssb.length(), emailTemplate, this, R.color.drawer_background);
            }
        } else {
            if (preference.getBoolean(Constants.NEW_COMPANY)) {
                AppUtils.addClickableText(ssb, ssb.length(), "You are the first person from ", this, R.color.AppDarkGray);
                AppUtils.addClickableText(ssb, ssb.length(), preference.getString(Constants.COMPANY_NAME), this, R.color.drawer_background);
                AppUtils.addClickableText(ssb, ssb.length(), " to join Krank", this, R.color.AppDarkGray);

            } else {
                AppUtils.addClickableText(ssb, ssb.length(), preference.getString(Constants.COMPANY_NAME), this, R.color.drawer_background);
                AppUtils.addClickableText(ssb, ssb.length(), " is already on Krank You can join ", this, R.color.AppDarkGray);
                AppUtils.addClickableText(ssb, ssb.length(), preference.getString(Constants.COMPANY_NAME), this, R.color.drawer_background);
                AppUtils.addClickableText(ssb, ssb.length(), " by verifying your email.", this, R.color.AppDarkGray);

            }
        }
        linkText.setMovementMethod(LinkMovementMethod.getInstance());   // make our spans selectable
        linkText.setText(ssb);
        /*set up messages*/



        //btn
        if(isFreeUser()){
            continueBtn.setText("Edit E-mail Address");
        }
        continueBtn.setOnClickListener(view -> {
            if(isFreeUser()){
                onBackPressed();
                return;
            }
            Intent intent = new Intent(SignUpPage2.this, SignUpPage3.class);
            intent.putExtra("user_email",getIntent().getStringExtra("user_email"));
            startActivity(intent);
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });
    }

    private boolean isFreeUser(){
        return getIntent().getBooleanExtra("free_company", false);
    }
}
