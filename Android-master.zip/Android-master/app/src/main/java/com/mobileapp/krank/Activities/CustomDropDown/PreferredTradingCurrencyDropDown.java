package com.mobileapp.krank.Activities.CustomDropDown;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.PreferredTradingCurrencyAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CurrenciesListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CurrenciesListData;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PreferredTradingCurrencyDropDown extends BaseActivity {

    List<CurrenciesListData> CurrenciesListData;
    List<String> currencyResponseData;
    String CurrenciesListDataReceived;
    LinearLayoutManager layoutManager;
    private RecyclerView countryRecyclerView;
    private PreferredTradingCurrencyAdapter countryRecyclerAdapter;
    View done_btn;
    public int selectedIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferred_trading_currency_drop_down);
        done_btn=findViewById(R.id.done_btn);
        selectedIndex= -1;
        setNormalPageToolbar("Preferred Trading Currency");

        done_btn.setOnClickListener(view -> {
            if(selectedIndex != -1){
                Intent intent = new Intent();
                intent.putExtra("selectedCurrency","" + CurrenciesListData.get(selectedIndex).getCurrencyValue());
                setResult(RESULT_OK, intent);
                finish();
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
            }
            else{
                Toast.makeText(PreferredTradingCurrencyDropDown.this,"Please select an option",Toast.LENGTH_SHORT).show();
            }
        });
        setUpAdapter();
    }

    private void getCountries() {
        getAPI().getCurrencyList(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<CurrenciesListResponse>() {
            @Override
            public void onResponse(Call<CurrenciesListResponse> call, Response<CurrenciesListResponse> response) {
                if(response.isSuccessful()){
                    currencyResponseData.addAll(response.body().getData());
                    String dataReceived = getIntent().getStringExtra("selectedCurrency");

                    if(dataReceived !=null){
                        CurrenciesListDataReceived =dataReceived;
                        for(int i=0;i<currencyResponseData.size();i++){
                            if(CurrenciesListDataReceived.equals(currencyResponseData.get(i))){
                                selectedIndex = i;
                                CurrenciesListData.add(new CurrenciesListData(true,currencyResponseData.get(i)));
                            }
                            else{
                                CurrenciesListData.add(new CurrenciesListData(false,currencyResponseData.get(i)));
                            }
                        }
                    }
                    else{
                        for(int i=0;i<currencyResponseData.size();i++){
                                CurrenciesListData.add(new CurrenciesListData(false,currencyResponseData.get(i)));
                        }
                    }
                    countryRecyclerAdapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onFailure(Call<CurrenciesListResponse> call, Throwable t) {
                Log.e("currency_data","call " + appUtils.convertToJson(call.request()));
            }
        });
    }
    private void setUpAdapter() {
        countryRecyclerView = (RecyclerView) findViewById(R.id.country_recycler_view);

        CurrenciesListData = new ArrayList<>();
        currencyResponseData = new ArrayList<>();

        layoutManager=new LinearLayoutManager(this);
        countryRecyclerAdapter = new PreferredTradingCurrencyAdapter(CurrenciesListData, PreferredTradingCurrencyDropDown.this);
        countryRecyclerView.setLayoutManager(layoutManager);
        countryRecyclerView.setAdapter(countryRecyclerAdapter);
        getCountries();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
}
