package com.mobileapp.krank.ResponseModels.DataModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InviteCompaniesDataModel {

    @SerializedName("company_invitation")
    @Expose
    private String companyInvitation;

    public String getCompanyInvitation() {
        return companyInvitation;
    }

    public void setCompanyInvitation(String companyInvitation) {
        this.companyInvitation = companyInvitation;
    }

}
