package com.mobileapp.krank.Network;

import com.mobileapp.krank.ResponseModels.VimeoVideoResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface VimeoUrl {

    @GET("v2/video/{videoId}.json")
    Call<List<VimeoVideoResponse>> getVimeoThumbnailImg(@Path("videoId") String videoId);
}
