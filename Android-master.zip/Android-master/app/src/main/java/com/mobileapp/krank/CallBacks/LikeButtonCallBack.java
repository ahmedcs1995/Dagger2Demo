package com.mobileapp.krank.CallBacks;

import android.view.View;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

public interface LikeButtonCallBack {
    void act(NewsFeedArray item,int position,View likeBtn);
}
