package com.mobileapp.krank.Activities;

import android.graphics.Typeface;
import android.support.annotation.StringDef;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.SearchTabsDataModel;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.AllSearchResult;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkEmpSearch;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkSearch;
import com.mobileapp.krank.ResponseModels.SearchResponseModel;
import com.mobileapp.krank.SearchTabs.All;
import com.mobileapp.krank.SearchTabs.Networks;
import com.mobileapp.krank.SearchTabs.People;
import com.mobileapp.krank.SearchTabs.RentSaleListing;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchKrank extends BaseActivity {


    public interface ServiceCallback {
        void act(int stP,int enP,@TypeOfTab String tabType);
    }


    //font family
    private Typeface mTypefaceBold;
    private Typeface mTypefaceNormal;


    //for tabs
    public ViewPager mViewPager;
    public TabLayout mCustomTabLayout;
    private static int TAB_TEXT_SIZE = 15;

    //pages
    All all;
    People people;
    Networks networks;
    RentSaleListing rentListings;
    RentSaleListing saleListings;
    // Posts posts;

    //views
    EditText search_edit_text;
    View searchIcon;
    View back_icon;

    //flag
    boolean loadDataOnTabChange;

    //callback
    ServiceCallback callback;


    //min characters to search
    private static final int MIN_CHARACTERS = 3;

    //tab Type Constants
    public static final String ALL = "all";
    public static final String PEOPLE = "people";
    public static final String NETWORK = "network";
    public static final String RENT_LISTING = "rent";
    public static final String SALE_LISTING = "sale";


    // itemSize for Each Page
    public static final int SIZE = 20;


    // Bundling them under one definition
    @Retention(RetentionPolicy.SOURCE)
    @StringDef({ALL, PEOPLE, NETWORK, RENT_LISTING,SALE_LISTING})
    public @interface TypeOfTab { }


    //store result of all result items
    List<AllSearchResult> searchResultItems;
    public SearchTabsDataModel allTab;


    //list items network
    SearchTabsDataModel networkTab;
    public ArrayList<NetworkSearch> networkSearches;

    //list items people
    SearchTabsDataModel peopleTab;
    public ArrayList<NetworkEmpSearch> networkEmpSearches;

    //list items rent listings
    SearchTabsDataModel renListingTab;
    public ArrayList<ListingDataArray> rentListingSearchData;

    //list items sale listings
    SearchTabsDataModel saleListingTab;
    public ArrayList<ListingDataArray> saleListingSearchData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_krank);

        //fonts
        mTypefaceBold = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_BOLD);
        mTypefaceNormal = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_NORMAL);

        //views
        search_edit_text = findViewById(R.id.search_edit_text);
        searchIcon = findViewById(R.id.search_icon);
        back_icon = findViewById(R.id.back_icon);


        //flags
        loadDataOnTabChange = false;


        //all search result items
        searchResultItems = new ArrayList<>();
        allTab = new SearchTabsDataModel(true);


        setUpSearchTabData();

        setUpCallBack();

        //pages
        all = new All();

        setUpPeopleTab();

        setUpNetworkTab();

        setUpRentListingTab();

        setUpSaleListingTab();

        // posts = new Posts();

        setViewPagerAndTabLayout();


        searchIcon.setOnClickListener(view -> {
            searchIcon.setEnabled(false);
            addOnSearchIconClickListener();
        });

        back_icon.setOnClickListener(view -> onBackPressed());


    }

    private void setUpSearchTabData(){
        networkTab = getInitializeSearchTabData();
        peopleTab = getInitializeSearchTabData();
        saleListingTab = getInitializeSearchListingTabData("sale");
        renListingTab = getInitializeSearchListingTabData("rent");

        rentListingSearchData = new ArrayList<>();
        saleListingSearchData = new ArrayList<>();

        networkEmpSearches = new ArrayList<>();
        networkSearches = new ArrayList<>();
    }

    private SearchTabsDataModel getInitializeSearchTabData(){
        return new SearchTabsDataModel(0,false,true,false);
    }

    private SearchTabsDataModel getInitializeSearchListingTabData(String listingType){
        return new SearchTabsDataModel(0,false,true,false,listingType);
    }

    public SearchTabsDataModel getNetworkTab(){
        return networkTab;
    }

    public SearchTabsDataModel getPeopleTab(){
        return peopleTab;
    }


    public SearchTabsDataModel getRenListingTab(){
        return renListingTab;
    }

    public SearchTabsDataModel getSaleListingTab(){
        return saleListingTab;
    }

    private void setUpNetworkTab(){
        networks = new Networks();
    }


    private void setUpRentListingTab(){
        rentListings = new RentSaleListing();
    }
    private void setUpSaleListingTab(){
        saleListings = new RentSaleListing();
    }

    private void setUpPeopleTab(){
        people = new People();
    }

    public ServiceCallback getCallback(){
        return callback;
    }

    private void setUpCallBack(){
        callback = (stP, enP, tabType) -> {
            getSearchResult(search_edit_text.getText().toString().trim(),stP,enP,tabType);
        };
    }
    private void addOnSearchIconClickListener(){
        if(search_edit_text.getText().toString().length() >= MIN_CHARACTERS){




            hideKeyBoard();

            setAllTab();

            getSearchResult(search_edit_text.getText().toString().trim(),all.getStP(),all.getEnP(),ALL);

        }else{
            searchIcon.setEnabled(true);
            Toast.makeText(SearchKrank.this,"Please currentType at least 3 characters to search",Toast.LENGTH_SHORT).show();
        }
    }


    private void setAllTab(){
        getmViewPager().setCurrentItem(0);

        all.setLoader();

        //clear the tab data
        resetTabFlag();
    }

    private void resetTabFlag(){

        resetModel(peopleTab);


        resetModel(networkTab);

        // rent listing tab
        resetModel(renListingTab);

        // sale listing tab
        resetModel(saleListingTab);
    }

    private void resetModel(SearchTabsDataModel model){
        model.setDataLoaded(false);
        model.setFirstTimeInit(true);
        model.setScrollShouldCall(false);
        model.setStP(0);
    }

    private void setViewPagerAndTabLayout() {
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mCustomTabLayout = findViewById(R.id.sliding_tabs);

        //adding pages
        ArrayList<BaseFragment> pages = new ArrayList<>();
        pages.add(all);
        pages.add(people);
        pages.add(networks);

        rentListings.setTitle("Rent Listing");
        pages.add(rentListings);


        saleListings.setTitle("Sale Listing");
        pages.add(saleListings);

        // pages.add(posts);
        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));

        mCustomTabLayout.setupWithViewPager(mViewPager);

        mViewPager.setOffscreenPageLimit(1);


        setInitialTabLayoutConfig();

        mCustomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
                TextView text = (TextView) tab.getCustomView();
                text.setTypeface(mTypefaceBold);
                text.setTextColor(getResources().getColor(R.color.AppDarkGray));
                text.setTextSize(TAB_TEXT_SIZE);

                if(loadDataOnTabChange){
                    setStpAndEnp(tab.getPosition());
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TextView text = (TextView) tab.getCustomView();
                text.setTypeface(mTypefaceNormal);
                text.setTextColor(getResources().getColor(R.color.drawerGray));
                text.setTextSize(TAB_TEXT_SIZE);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });

    }

    private void setStpAndEnp(final int tabPos){
        switch (tabPos){
            case 1:
                if(!peopleTab.isDataLoaded()){
                    people.setLoading();
                    getSearchResult(search_edit_text.getText().toString().trim(),0,SIZE,PEOPLE);
                    peopleTab.setDataLoaded(true);
                }
                break;
            case 2:
                if(!networkTab.isDataLoaded()){
                    networks.setLoading();
                    getSearchResult(search_edit_text.getText().toString().trim(),0,SIZE,NETWORK);
                    networkTab.setDataLoaded(true);
                }
                break;
            case 3:
                if(!renListingTab.isDataLoaded()){
                    rentListings.setLoading();
                    getSearchResult(search_edit_text.getText().toString().trim(),0,SIZE,RENT_LISTING);
                    renListingTab.setDataLoaded(true);
                }
                break;
            case 4:
                if(!saleListingTab.isDataLoaded()){
                    saleListings.setLoading();
                    getSearchResult(search_edit_text.getText().toString().trim(),0,SIZE,SALE_LISTING);
                    saleListingTab.setDataLoaded(true);
                }
                break;

        }
    }


    private void setInitialTabLayoutConfig() {
        for (int i = 0; i < mCustomTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mCustomTabLayout.getTabAt(i);
            if (tab != null) {
                TextView tabTextView = new TextView(this);
                tab.setCustomView(tabTextView);

                tabTextView.getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
                tabTextView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;

                tabTextView.setTextColor(getResources().getColor(R.color.drawerGray));
                tabTextView.setTypeface(mTypefaceNormal);
                tabTextView.setTextSize(TAB_TEXT_SIZE);

                tabTextView.setText(tab.getText());

                // First tab is the selected tab, so if i==0 then set BOLD typeface
                if (i == 0) {
                    tabTextView.setTypeface(mTypefaceBold);
                    tabTextView.setTextColor(getResources().getColor(R.color.AppDarkGray));
                }
            }
        }
    }


    private void getSearchResult(String text,int stP,int enP,@TypeOfTab String tabType){

        // enable load data on tab change
        loadDataOnTabChange = true;

        getAPI().searhcKrank(preference.getString(Constants.ACCESS_TOKEN),text,stP,enP,tabType).enqueue(new Callback<SearchResponseModel>() {
            @Override
            public void onResponse(Call<SearchResponseModel> call, Response<SearchResponseModel> response) {
                searchIcon.setEnabled(true);

                if(response.isSuccessful()){
                    if(response.body().getStatus().equals(Constants.SUCCESS_STATUS)){
                        try {
                            //set data on tabs
                            if(tabType.equals(ALL)){
                                all.loadData(response.body().getData(),SearchKrank.this);
                                all.removeLoader();
                            }

                            else if(tabType.equals(PEOPLE)){
                                peopleTab.setDataLoaded(true);
                                people.loadData(response.body().getData().getNetworkEmp());
                            }
                            else if(tabType.equals(NETWORK)){
                                networkTab.setDataLoaded(true);
                                networks.loadData(response.body().getData().getNetwork());
                            }
                            else if(tabType.equals(RENT_LISTING)){
                                renListingTab.setDataLoaded(true);
                                rentListings.loadData(response.body().getData().getListing());
                            }
                            else if(tabType.equals(SALE_LISTING)){
                                saleListingTab.setDataLoaded(true);
                                saleListings.loadData(response.body().getData().getListingSale());
                            }
                        }
                        catch (Exception ex){

                        }
                    }else{
                        Toast.makeText(getApplicationContext(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                    // posts.loadData(response.body().getData().getPostSearch().getNewsFeedArrays());
                    // posts.removeLoader();

                }else{
                    onResponseFailure();
                }
            }
            @Override
            public void onFailure(Call<SearchResponseModel> call, Throwable t) {
                searchIcon.setEnabled(true);
                Log.e("Search error ->","" + appUtils.convertToJson(call.request()));
                onResponseFailure();
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    public ViewPager getmViewPager() {
        return mViewPager;
    }

    public void setmViewPager(ViewPager mViewPager) {
        this.mViewPager = mViewPager;
    }



    public List<AllSearchResult> getSearchResultItems() {
        return searchResultItems;
    }
}
