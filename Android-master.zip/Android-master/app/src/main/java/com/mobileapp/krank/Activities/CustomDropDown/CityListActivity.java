package com.mobileapp.krank.Activities.CustomDropDown;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.google.gson.Gson;
import com.mobileapp.krank.Adapters.CityListAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CityListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CityListActivity extends BaseActivity {



    List<CityListData> cityListData;
    CountyListData countryDataReceived;
    LinearLayoutManager layoutManager;
    private RecyclerView cityRecyclerView;
    private RecyclerView.Adapter cityRecyclerAdapter;
    EditText search_box;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_list);

        setNormalPageToolbar("Select City");
        search_box=findViewById(R.id.search_box);

        countryDataReceived =gson.fromJson(getIntent().getStringExtra("countryData"), CountyListData.class);
        setUpAdapter();
        search_box.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {

                if(search_box.getText().toString().length() >= 3){
                    getCities(countryDataReceived.getCode(),search_box.getText().toString());
                }

            }
        });
    }

    private void getCities(String countryCode, String keyword) {


        getAPI().cityList(countryCode, keyword).enqueue(new Callback<CityListResponse>() {
            @Override
            public void onResponse(Call<CityListResponse> call, Response<CityListResponse> response) {
                cityListData.clear();
                cityListData.addAll(response.body().getData());
                cityRecyclerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<CityListResponse> call, Throwable t) {

            }
        });

    }
    private void setUpAdapter() {
        cityRecyclerView =  findViewById(R.id.city_recycler_view);

        cityListData = new ArrayList<>();

        layoutManager=new LinearLayoutManager(this);
        cityRecyclerAdapter = new CityListAdapter(cityListData, this);
        cityRecyclerView.setLayoutManager(layoutManager);
        cityRecyclerView.setAdapter(cityRecyclerAdapter);
    }

}
