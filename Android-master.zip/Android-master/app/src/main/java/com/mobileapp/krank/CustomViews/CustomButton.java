package com.mobileapp.krank.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

/**
 * Created by Ishaq Hassan on 5/4/2016.
 */
public class CustomButton extends android.support.v7.widget.AppCompatButton {
    public CustomButton(Context context) {
        super(context);
        this.setCustomFont(context);
    }

    public CustomButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setCustomFont(context);
    }

    public CustomButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.setCustomFont(context);
    }

    public void setCustomFont(Context context) {
        String fontName = "HELR65W.ttf";
        if (getTypeface() != null && getTypeface().getStyle() == Typeface.BOLD) {
            fontName = "HELR65W.ttf";
        }
        Typeface face1 = Typeface.createFromAsset(context.getAssets(), "fonts/" + fontName);
        setTypeface(face1);
    }
}
