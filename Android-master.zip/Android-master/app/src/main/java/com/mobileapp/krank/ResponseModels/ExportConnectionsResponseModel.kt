package com.mobileapp.krank.ResponseModels

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ExportConnectionsResponseModel (
    @SerializedName("status") @Expose var status: String,
    @SerializedName("message") @Expose var message: String,
    @SerializedName("data") @Expose var data: ExportConnectionsDataModel?
)

data class ExportConnectionsDataModel (@SerializedName("file_json") @Expose var file_json: String?)