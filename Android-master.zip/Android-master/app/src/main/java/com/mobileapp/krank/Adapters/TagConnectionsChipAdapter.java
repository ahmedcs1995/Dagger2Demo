package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.TagConnectionsNewsFeedPostDataModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TagConnectionsChipAdapter extends RecyclerView.Adapter<TagConnectionsChipAdapter.ViewHolder>  {
    private List<TagConnectionsNewsFeedPostDataModel> items = new ArrayList<>();
    Context context;
    TextView label;
    View container;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View cancelBtn;
        TextView name;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            cancelBtn=itemView.findViewById(R.id.cancel_btn);
            name=itemView.findViewById(R.id.name);
        }
    }

    public TagConnectionsChipAdapter(List<TagConnectionsNewsFeedPostDataModel> items, Context context,TextView label,View container) {
        this.items = items;
        this.context = context;
        this.label = label;
        this.container = container;
    }

    public TagConnectionsChipAdapter(TagConnectionsNewsFeedPostDataModel[] items, Context context) {

        this.items.addAll(Arrays.asList(items));
        this.context = context;
    }

    @Override
    public TagConnectionsChipAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chip_view_item, parent, false);
        return new TagConnectionsChipAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final TagConnectionsChipAdapter.ViewHolder holder, final int position) {
        final TagConnectionsNewsFeedPostDataModel item = items.get(position);

        holder.name.setText("" + item.getFirstName()  + " " + item.getLastName());
/*
        item.setCancelChipView(() -> {
            items.remove(position);
            checkTagConnectionsContainerVisibility();
            notifyDataSetChanged();
        });

        holder.cancelBtn.setOnClickListener(view -> {
            if(item.getCancelChipView() !=null){
                item.getCancelChipView().act();
            }
        });*/
    }

    private void checkTagConnectionsContainerVisibility(){
        if(items.size() <=0){
            container.setVisibility(View.GONE);
            return;
        }
        label.setText("You have selected " + items.size() + " tagged people");
        container.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}


