package com.mobileapp.krank.FirstPageFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.R;

/**
 * Created by Ahmed on 3/22/2018.
 */

public class PageOne extends BaseFragment{
    public PageOne(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.page_one_fragment, container, false);
        setFragmentView(me);

        return me;
    }
}
