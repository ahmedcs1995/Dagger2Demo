package com.mobileapp.krank.ResponseModels.DataModel;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ListingDetailDataModel {
    @SerializedName("assignedUsers")
    @Expose
    private List<PublicMarketPlaceAssignment> assignedUsers = null;
    @SerializedName("dealers")
    @Expose
    private List<DealerDataListing> dealers = null;
    @SerializedName("cu_id")
    @Expose
    private int cuId;
    @SerializedName("listing_name")
    @Expose
    private String listingName;
    @SerializedName("price")
    @Expose
    private int price;
    @SerializedName("images")
    @Expose
    private List<ListingDetailImageModel> images = null;
    @SerializedName("video")
    @Expose
    private List<ListingDetailVideoDataModel> video;
    @SerializedName("userData")
    @Expose
    private ListingDetailUserData userData;
    @SerializedName("networkStatus")
    @Expose
    private String networkStatus;
    @SerializedName("connectionStatus")
    @Expose
    private String connectionStatus;
    @SerializedName("listingData")
    @Expose
    private ListingInnerDataModel listingData;
    @SerializedName("connectionData")
    @Expose
    private List<ListingDetaileConnectionDataModel> connectionData = null;
    @SerializedName("page_title")
    @Expose
    private String pageTitle;
    @SerializedName("page_meta_desc")
    @Expose
    private String pageMetaDesc;
    @SerializedName("og_image")
    @Expose
    private String ogImage;

    @SerializedName("specUrl")
    @Expose
    private List<ListingDetailSpecUrlDataModel> specUrl = null;


    @SerializedName("partItems")
    @Expose
    private List<ListingDetailPartsItemDataModel> partItems = null;


    @SerializedName("isPrivate")
    @Expose
    private boolean isPrivate;

    @SerializedName("in_my_network")
    @Expose
    private int in_my_network;


    public List<PublicMarketPlaceAssignment> getAssignedUsers() {
        return assignedUsers;
    }

    public void setAssignedUsers(List<PublicMarketPlaceAssignment> assignedUsers) {
        this.assignedUsers = assignedUsers;
    }

    public int getCuId() {
        return cuId;
    }

    public void setCuId(int cuId) {
        this.cuId = cuId;
    }

    public String getListingName() {
        return listingName;
    }

    public void setListingName(String listingName) {
        this.listingName = listingName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public List<ListingDetailImageModel> getImages() {
        return images;
    }

    public void setImages(List<ListingDetailImageModel> images) {
        this.images = images;
    }

    public List<ListingDetailVideoDataModel> getVideo() {
        return video;
    }

    public void setVideo(List<ListingDetailVideoDataModel> video) {
        this.video = video;
    }

    public ListingDetailUserData getUserData() {
        return userData;
    }

    public void setUserData(ListingDetailUserData userData) {
        this.userData = userData;
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public void setNetworkStatus(String networkStatus) {
        this.networkStatus = networkStatus;
    }

    public String getConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(String connectionStatus) {
        this.connectionStatus = connectionStatus;
    }

    public ListingInnerDataModel getListingData() {
        return listingData;
    }

    public void setListingData(ListingInnerDataModel listingData) {
        this.listingData = listingData;
    }

    public List<ListingDetaileConnectionDataModel> getConnectionData() {
        return connectionData;
    }

    public void setConnectionData(List<ListingDetaileConnectionDataModel> connectionData) {
        this.connectionData = connectionData;
    }

    public String getPageTitle() {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }

    public String getPageMetaDesc() {
        return pageMetaDesc;
    }

    public void setPageMetaDesc(String pageMetaDesc) {
        this.pageMetaDesc = pageMetaDesc;
    }

    public String getOgImage() {
        return ogImage;
    }

    public void setOgImage(String ogImage) {
        this.ogImage = ogImage;
    }

    public List<DealerDataListing> getDealers() {
        return dealers;
    }

    public void setDealers(List<DealerDataListing> dealers) {
        this.dealers = dealers;
    }

    public List<ListingDetailSpecUrlDataModel> getSpecUrl() {
        return specUrl;
    }

    public void setSpecUrl(List<ListingDetailSpecUrlDataModel> specUrl) {
        this.specUrl = specUrl;
    }

    public List<ListingDetailPartsItemDataModel> getPartItems() {
        return partItems;
    }

    public void setPartItems(List<ListingDetailPartsItemDataModel> partItems) {
        this.partItems = partItems;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean aPrivate) {
        isPrivate = aPrivate;
    }

    public int getIn_my_network() {
        return in_my_network;
    }

    public void setIn_my_network(int in_my_network) {
        this.in_my_network = in_my_network;
    }
}
