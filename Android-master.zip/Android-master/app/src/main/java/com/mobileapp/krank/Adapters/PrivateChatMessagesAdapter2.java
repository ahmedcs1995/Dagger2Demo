package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.PendingRequestActivity;
import com.mobileapp.krank.Chat.ChatUtils.ChatUtils;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity2;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.AttachmentLeft;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.AttachmentRight;
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.ContactCardLeft;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.ContactCardRight;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.ImageMessagRight;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.ImageMessageLeft;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.RetryButtonChat;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.TextMessageLeft;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.TextMessageRight;
import com.mobileapp.krank.ViewHolders.ChatMessageViewHolders.TypingViewHolder;
import com.mobileapp.krank.CustomViews.ChatImageOverlayView;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.stfalcon.frescoimageviewer.ImageViewer;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Ahmed on 4/30/2018.
 */


public class PrivateChatMessagesAdapter2 extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<ConversationDetail> items;
    PrivateChatConversationActivity2 activity;
    DeviceInfo deviceInfo;
    private static double SIZE_IN_PERCENT = 0.55;
    ChatUtils chatUtils;
    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getTypeOfMessage()) {
            case Constants.TEXT_RIGHT:
                return 1;
            case Constants.TEXT_LEFT:
                return 2;
            case Constants.IMAGE_RIGHT:
                return 3;
            case Constants.IMAGE_LEFT:
                return 4;
            case Constants.OTHER_ATTACHMENT_LEFT:
                return 5;
            case Constants.OTHER_ATTACHMENT_RIGHT:
                return 6;
            case Constants.V_CARD_LEFT:
                return 7;
            case Constants.V_CARD_RIGHT:
                return 8;
            case Constants.PROGRESS_BAR:
                return 9;
            case Constants.RETRY_BUTTON_CHAT:
                return 10;
            case Constants.TYPING_MSG_VIEW:
                return 11;
            default:
                return -1;
        }
    }

    public PrivateChatMessagesAdapter2(List<ConversationDetail> items, PrivateChatConversationActivity2 activity, DeviceInfo deviceInfo) {
        this.items = items;
        this.activity = activity;
        this.deviceInfo = deviceInfo;
        chatUtils = new ChatUtils();
    }

    public void startTypingEvent(){
        items.add(0,new ConversationDetail(Constants.TYPING_MSG_VIEW));
        notifyItemRangeInserted(0,1);

    }
    public void stopTypingEvent(){
        if(items.get(0).getTypeOfMessage().equals(Constants.TYPING_MSG_VIEW)){
            items.remove(0);
            notifyItemRangeRemoved(0,1);
        }
    }


    private void appendElement(List<ConversationDetail> newMsgs) {

        for (int i = 0; i < newMsgs.size(); i++) {
            items.add(i, newMsgs.get(i));
        }
        notifyItemRangeInserted(0, newMsgs.size());
    }

    public void setListItems(final List<ConversationDetail> newItems,RecyclerView mRecyclerViewRef){
        if(items==null || items.size() <=0){
            items.addAll(newItems);
            notifyDataSetChanged();
            return;
        }
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override
            public int getOldListSize() {
                return items.size();
            }

            @Override
            public int getNewListSize() {
                return newItems.size();
            }

            @Override
            public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                return items.get(oldItemPosition).getMid() ==
                        newItems.get(newItemPosition).getMid();
            }

            @Override
            public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                return items.get(oldItemPosition).equals(newItems.get(newItemPosition));
            }
        });
        this.items = newItems;
        result.dispatchUpdatesTo(this);
        mRecyclerViewRef.scrollToPosition(0);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_message_right, parent, false);
                TextMessageRight textMessageRight = new TextMessageRight(view);
                return textMessageRight;
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_message_left, parent, false);
                return new TextMessageLeft(view);
            case 3:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_msg_right, parent, false);
                ImageMessagRight imageMessagRight = new ImageMessagRight(view);
                setCallBacks(imageMessagRight);
                return imageMessagRight;
            case 4:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_message_left, parent, false);
                ImageMessageLeft imageMessageLeft = new ImageMessageLeft(view);
                setCallBacks(imageMessageLeft);
                return imageMessageLeft;
            case 5:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.attachment_left_item, parent, false);
                return new AttachmentLeft(view);
            case 6:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.attachment_right_item, parent, false);
                return new AttachmentRight(view);
            case 7:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_card_left_item, parent, false);
                ContactCardLeft contactCardLeft =  new ContactCardLeft(view);
                setCallBacks(contactCardLeft);
                return contactCardLeft;
            case 8:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_card_right_item, parent, false);
                ContactCardRight contactCardRight =  new ContactCardRight(view);
                setCallBacks(contactCardRight);
                return contactCardRight;
            case 9:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_loader_item, parent, false);
                return new AppListItemLoader(view);
            case 10:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.retry_button_item, parent, false);
                return new RetryButtonChat(view);
            case 11:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.typing_view_item, parent, false);
                return new TypingViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_message_left, parent, false);
                return new TextMessageLeft(view);

        }
    }


    private void setCallBacks(final RecyclerView.ViewHolder holder) {

        if (holder instanceof ImageMessagRight) {
            ImageMessagRight viewHolder = (ImageMessagRight) holder;
            viewHolder.image_right.setOnClickListener(itemView -> {
                ConversationDetail item = items.get(viewHolder.getAdapterPosition());
                showImageViewer(item.getAttachment().getFilePath() + item.getAttachment().getFileName());
            });
        } else if (holder instanceof ImageMessageLeft) {
            ImageMessageLeft viewHolder = (ImageMessageLeft) holder;
            viewHolder.image_left.setOnClickListener(itemView -> {
                showImageViewer(items.get(viewHolder.getAdapterPosition()).getAttachment().getFilePath() + items.get(viewHolder.getAdapterPosition()).getAttachment().getFileName());
            });
        } else if (holder instanceof ContactCardRight) {
            ContactCardRight viewHolder = (ContactCardRight) holder;
           // setCallBacksForContactCard(items,viewHolder.view_profile_btn,viewHolder.user_profile_img,viewHolder.company_img,viewHolder);

        } else if (holder instanceof ContactCardLeft) {
            ContactCardLeft viewHolder = (ContactCardLeft) holder;
         //   setCallBacksForContactCard(items,viewHolder.view_profile_btn,viewHolder.user_profile_img,viewHolder.company_img,viewHolder);

        }

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final ConversationDetail item = items.get(position);

        switch (item.getTypeOfMessage()) {
            case Constants.TEXT_RIGHT:
                setTypeTextRight(item, holder, position);
                break;
            case Constants.TEXT_LEFT:
                setTypeTextLeft(item, holder, position);
                break;
            case Constants.IMAGE_RIGHT:
                setTypeImageRight(item, holder);
                break;
            case Constants.IMAGE_LEFT:
                setTypeImageLeft(item, holder);
                break;
            case Constants.OTHER_ATTACHMENT_RIGHT:
                setAttachmentRight(item, holder);
                break;
            case Constants.OTHER_ATTACHMENT_LEFT:
                setAttachmentLeft(item, holder);
                break;
            case Constants.V_CARD_LEFT:
                setTypeVCardLeft(item, holder);
                break;
            case Constants.V_CARD_RIGHT:
                setTypeVCardRight(item, holder);
                break;
            case Constants.RETRY_BUTTON_CHAT:
                setRetryButton(holder, item, position);
            default:
                break;
        }
    }


    private void setRetryButton(final RecyclerView.ViewHolder holder, final ConversationDetail item, final int position) {
        RetryButtonChat retryButtonViewHolder = ((RetryButtonChat) holder);

        retryButtonViewHolder.itemView.setOnClickListener(view -> {
            items.get(position).setTypeOfMessage(Constants.PROGRESS_BAR);
            notifyItemChanged(position);
        //    activity.retryChatData();
        });
    }

    private void setTypeTextRight(ConversationDetail item, final RecyclerView.ViewHolder holder, int position) {
        TextMessageRight viewHolder = (TextMessageRight) holder;
        viewHolder.chatBoxRight.setMaxWidth((int) (deviceInfo.getDeviceWidth() * SIZE_IN_PERCENT));

        /*Listing and Emma Cooper Msg*/
        if (item.getSsb() != null) {
            viewHolder.chatBoxRight.setMovementMethod(LinkMovementMethod.getInstance());
            viewHolder.chatBoxRight.setText(item.getSsb());
        } else {
            viewHolder.chatBoxRight.setText("" + item.getReply());
        }
        /*Listing and Emma Cooper Msg*/


        viewHolder.chatBoxRight.setOnClickListener(view -> {
            Log.e("onCLick retry ", "status =>" + item.getMsgStatus());
            Log.e("onCLick retry ", "reply =>" + item.getReply());
            Log.e("onCLick retry ", "position =>" + viewHolder.getAdapterPosition());
            /*if (item.getMsgStatus() == Constants.STATUS_FAIL && activity.booleanisRetryClickAble) {
              //  activity.booleanisRetryClickAble = false;
                Toast.makeText(activity.getApplicationContext(), "Sending message...", Toast.LENGTH_SHORT).show();
              //  activity.reSendMessage(item.getReply(), "text", null, item.getMid(), viewHolder.getAdapterPosition());
                item.setMsgStatus(Constants.STATUS_PENDING);
                notifyItemChanged(position);
            }*/
        });

     //   viewHolder.date_text_view.setText(item.getSentTime());
        viewHolder.date_text_view.setText("" + item.getMsgStatus());

        if (item.getMsgStatus() == Constants.STATUS_FAIL) {
            viewHolder.not_sent_text.setVisibility(View.VISIBLE);
        } else {
            viewHolder.not_sent_text.setVisibility(View.GONE);
        }
    }

    private void setTypeVCardRight(ConversationDetail item, final RecyclerView.ViewHolder holder) {
        ContactCardRight viewHolder = (ContactCardRight) holder;

        Glide.with(activity.getApplicationContext()).load(item.getVCardData().getProfilePic()).into(viewHolder.user_profile_img);
        Glide.with(activity.getApplicationContext()).load(item.getVCardData().getCompanyProfilePic()).into(viewHolder.company_img);

        viewHolder.user_name.setText("" + item.getVCardData().getFirstName() + " " + item.getVCardData().getLastName());

        viewHolder.designation.setText(AppUtils.getCompanyAndDesignation(item.getVCardData().getCompanyName(), item.getVCardData().getDesignation()));

        if (concatenateCityCountry(item.getVCardData().getCity(), item.getVCardData().getCountry()) != null) {
            viewHolder.country_city.setVisibility(View.VISIBLE);
            viewHolder.country_city.setText(concatenateCityCountry(item.getVCardData().getCity(), item.getVCardData().getCountry()));
        } else {
            viewHolder.country_city.setVisibility(View.GONE);
        }

        viewHolder.date_text_view.setText(item.getSentTime());

        //handleViewProfileBtn(item, viewHolder.view_profile_btn);
    }

    private void setTypeVCardLeft(ConversationDetail item, final RecyclerView.ViewHolder holder) {
        ContactCardLeft viewHolder = (ContactCardLeft) holder;


        Glide.with(activity.getApplicationContext()).load(item.getVCardData().getProfilePic()).into(viewHolder.user_profile_img);
        Glide.with(activity.getApplicationContext()).load(item.getVCardData().getCompanyProfilePic()).into(viewHolder.company_img);

        viewHolder.user_name.setText("" + item.getVCardData().getFirstName() + " " + item.getVCardData().getLastName());

        viewHolder.designation.setText(AppUtils.getCompanyAndDesignation(item.getVCardData().getCompanyName(), item.getVCardData().getDesignation()));


        if (concatenateCityCountry(item.getVCardData().getCity(), item.getVCardData().getCountry()) != null) {
            viewHolder.country_city.setVisibility(View.VISIBLE);
            viewHolder.country_city.setText(concatenateCityCountry(item.getVCardData().getCity(), item.getVCardData().getCountry()));
        } else {
            viewHolder.country_city.setVisibility(View.GONE);
        }


        Glide.with(activity.getApplicationContext()).load(item.getSenderImg()).into(viewHolder.profile_img);


        viewHolder.date_text_view.setText(item.getSentTime());


       // handleViewProfileBtn(item, viewHolder.view_profile_btn);
    }


    private void handleViewProfileBtn(ConversationDetail item, Button btn) {
        if (item.getVCardData().getNetwork_status().equals(Constants.NO_NETWORK_TEXT_VALUE) && item.getVCardData().getNetwork_status().equals(Constants.NO_CONNECTION_TEXT_VALUE)) {
            // send network Request
            btn.setText("Send Network Invitation");
            // request apii
        } else if (item.getVCardData().getNetwork_status().equals(Constants.REQUEST_PENDING) && item.getVCardData().getNetwork_status().equals(Constants.NO_CONNECTION_TEXT_VALUE)) {
            btn.setText("Request Sent");
        } else if (item.getVCardData().getNetwork_status().equals(Constants.REQUEST_PENDING) && item.getVCardData().getNetwork_status().equals(Constants.REQUEST_PENDING)) {
            btn.setText("Request Sent");
        } else if (item.getVCardData().getNetwork_status().equals(Constants.CONNECTED_TEXT) && item.getVCardData().getNetwork_status().equals(Constants.NO_CONNECTION_TEXT_VALUE)) {
            btn.setText("View Profile");
        } else if (item.getVCardData().getNetwork_status().equals(Constants.CONNECTED_TEXT) && item.getVCardData().getNetwork_status().equals(Constants.REQUEST_PENDING)) {
            btn.setText("View Profile");
        } else if (item.getVCardData().getNetwork_status().equals(Constants.CONNECTED_TEXT) && item.getVCardData().getNetwork_status().equals(Constants.CONNECTED_TEXT)) {
            btn.setText("View Profile");
        }
    }

    private void setCallBacksForContactCard(List<ConversationDetail> items, Button btn,View userImg, View companyImg, RecyclerView.ViewHolder viewHolder) {
        companyImg.setOnClickListener(view -> {
            activity.appUtils.gotoCompanyProfile(activity, items.get(viewHolder.getAdapterPosition()).getVCardData().getCompanyId(), activity.preference);
        });

        btn.setOnClickListener(view -> {
            if (items.get(viewHolder.getAdapterPosition()).getVCardData().getNetwork_status().equals(Constants.NO_NETWORK_TEXT_VALUE)) {
                // send network Request
                sendNetworkRequest(btn, items.get(viewHolder.getAdapterPosition()).getVCardData().getId(), items.get(viewHolder.getAdapterPosition()), viewHolder.getAdapterPosition());
               // activity.showProgressAlert.setContentText("Sending Network Request");
             //   activity.showProgressAlert.show();
            }
            else if (items.get(viewHolder.getAdapterPosition()).getVCardData().getNetwork_status().equals(Constants.REQUEST_PENDING)) {
                // goto pending request
                Intent intent = new Intent(activity,PendingRequestActivity.class);
                activity.startActivity(intent);

            }else{
                // network connected
                activity.appUtils.gotoUserProfile(activity, items.get(viewHolder.getAdapterPosition()).getVCardData().getId(), activity.preference);
            }
        });

        userImg.setOnClickListener(view -> {
            if(items.get(viewHolder.getAdapterPosition()).getVCardData().getNetwork_status().equals(Constants.CONNECTED_TEXT)) {
                activity.appUtils.gotoUserProfile(activity, items.get(viewHolder.getAdapterPosition()).getVCardData().getId(), activity.preference);
            }
        });
    }

    private void sendNetworkRequest(Button btn, String id, ConversationDetail item, final int position) {
        btn.setEnabled(false);
        activity.getAPI().doNetworkRequest(activity.preference.getString(Constants.ACCESS_TOKEN), id).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                btn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        //  btn.setText(Constants.REQUEST_PENDING);
                        item.getVCardData().setNetwork_status(Constants.REQUEST_PENDING);
                        item.getVCardData().setConnection_status(Constants.REQUEST_PENDING);
                        notifyItemChanged(position);
                        Toast.makeText(activity, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(activity, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(activity, Constants.ERROR_SENDING_REQUEST, Toast.LENGTH_SHORT).show();

                }

              //  activity.showProgressAlert.dismiss();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                Toast.makeText(activity, Constants.ERROR_SENDING_REQUEST, Toast.LENGTH_SHORT).show();

               // activity.showProgressAlert.dismiss();
                btn.setEnabled(true);
            }
        });
    }

    private void setTypeTextLeft(ConversationDetail item, final RecyclerView.ViewHolder holder, int position) {
        TextMessageLeft viewHolder = (TextMessageLeft) holder;
        viewHolder.chat_box_left.setMaxWidth((int) (deviceInfo.getDeviceWidth() * SIZE_IN_PERCENT));

        /*Listing and Emma Cooper Msg*/
        if (item.getSsb() != null) {
            viewHolder.chat_box_left.setMovementMethod(LinkMovementMethod.getInstance());
            viewHolder.chat_box_left.setText(item.getSsb());
        } else {
            viewHolder.chat_box_left.setText("" + item.getReply());
        }
        /*Listing and Emma Cooper Msg*/


        viewHolder.date_text_view.setText(item.getSentTime());

        Glide.with(activity.getApplicationContext()).load(item.getSenderImg()).into(viewHolder.profile_img);

    }

    private void setTypeImageRight(final ConversationDetail item, final RecyclerView.ViewHolder holder) {
        ImageMessagRight viewHolder = (ImageMessagRight) holder;
        viewHolder.image_right.setImageURI(item.getThumb());
      //  viewHolder.image_right.setImageURI(item.getAttachment().getFileThumb());
        viewHolder.date_text_view.setText(item.getSentTime());

        // viewHolder.image_right.setOnClickListener(view -> showImageViewer(item.getAttachment().getFilePath() + item.getAttachment().getFileName()));
    }

    private void setTypeImageLeft(final ConversationDetail item, final RecyclerView.ViewHolder holder) {
        ImageMessageLeft viewHolder = (ImageMessageLeft) holder;
        viewHolder.image_left.setImageURI(item.getThumb());

        Glide.with(activity.getApplicationContext()).load(item.getSenderImg()).into(viewHolder.profile_img);


        viewHolder.date_text_view.setText(item.getSentTime());

        //  viewHolder.image_left.setOnClickListener(view -> showImageViewer(item.getAttachment().getFilePath() + item.getAttachment().getFileName()));
    }

    private void setAttachmentLeft(final ConversationDetail item, final RecyclerView.ViewHolder holder) {
        final AttachmentLeft viewHolder = (AttachmentLeft) holder;
        viewHolder.chat_box_left.setMaxWidth((int) (deviceInfo.getDeviceWidth() * SIZE_IN_PERCENT));
        viewHolder.chat_box_left.setText("" + item.getReply());


        Glide.with(activity.getApplicationContext()).load(item.getSenderImg()).into(viewHolder.profile_img);


        viewHolder.item.setOnClickListener(view -> {
            Uri uri = Uri.parse(item.getAttachment().getFilePath() + item.getAttachment().getFileName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.android.chrome");
            activity.startActivity(intent);
        });
        viewHolder.icon.setImageDrawable(chatUtils.getAttachmentIcon(item.getAttachment().getFileExt(),activity));


        viewHolder.date_text_view.setText(item.getSentTime());


    }

    private void setAttachmentRight(final ConversationDetail item, final RecyclerView.ViewHolder holder) {
        AttachmentRight viewHolder = (AttachmentRight) holder;
        viewHolder.chatBoxRight.setMaxWidth((int) (deviceInfo.getDeviceWidth() * SIZE_IN_PERCENT));
        viewHolder.chatBoxRight.setText("" + item.getReply());


        viewHolder.item.setOnClickListener(view -> {
            Uri uri = Uri.parse(item.getAttachment().getFilePath() + item.getAttachment().getFileName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.android.chrome");
            activity.startActivity(intent);
        });
        viewHolder.icon.setImageDrawable(chatUtils.getAttachmentIcon(item.getAttachment().getFileExt(),activity));

        viewHolder.date_text_view.setText(item.getSentTime());

    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    private void showImageViewer(String imgPath) {

        ChatImageOverlayView overlayView = new ChatImageOverlayView(activity);
        String[] imgs = new String[]{imgPath};
        ImageViewer.Builder builder = new ImageViewer.Builder<>(activity, imgs)
                .setOverlayView(overlayView)
                .setImageMargin(activity, R.dimen.overlay_margin)
                .setImageChangeListener(position -> {
                    overlayView.getSaveBtn().setOnClickListener(view -> {
                        overlayView.saveImgIntoDevice(imgPath);
                    });
                });
        builder.show();

    }



    private String concatenateCityCountry(String city, String country) {
        if (city != null && country != null) {
            return city + "," + country;
        } else if (city == null && country != null) {
            return country;
        } else if (city != null && country == null) {
            return city;
        } else {
            return null;
        }
    }
}






