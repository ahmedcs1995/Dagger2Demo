package com.mobileapp.krank.AccountSetupPages;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chaos.view.PinView;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.PhoneCodeAutoReadListener;
import com.mobileapp.krank.CustomViews.CheckView;
import com.mobileapp.krank.CustomViews.OtpTextView.OTPListener;
import com.mobileapp.krank.CustomViews.OtpTextView.OtpTextView;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.Dialogs.VerifyPopUpDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerifyPhoneNumber extends BaseFragment implements AccountSetupPage.UpdatePhoneNumberListener {


    //save instance
    public static String FINAL_OPTP_CODE_KEY = "optp_code_key";


    //view 1
    private View verify_btn;
    private TextView info_text_1;

    //view 2
    private PinView verify_view;
    private TextView error_text_view;
    private TextView timer_text_view;
    private View resend_btn;

    //check_view
    CheckView check_view;


    //phoneNumber
    TextView phone_number_text_view;

    //api
    ServiceManager serviceManager;
    SaveInSharedPreference preference;

    //get activity
    AccountSetupPage accountSetupPage;

    //timer
    CountDownTimer countDownTimer;

    //code
    String finalCode = "";

    //phone code listener
    PhoneCodeAutoReadListener phoneCodeListener;
    AccountSetupPage.PageChangeListener mPageChangeListener;


    TextView verification_label;

    //flag
    // String pageState;
    //  String code;
    public VerifyPhoneNumber() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.verify_phone_number_page, container, false);
        setFragmentView(me);


        init();


        initViews();

        getFinalSavedCode(savedInstanceState);


        verify_btn.setOnClickListener(view -> {
            showDialog();
        });

        resend_btn.setVisibility(View.GONE);
        timer_text_view.setVisibility(View.GONE);

        //phoneNum
        if (accountSetupPage.isVerified) {
            hideView_1();
            showView_2();
            verify_view.setText(finalCode);
            check_view.check();
            showTimerMessage();

            //disable
            setTouchEventOfOtp(true);
        }

        bindResendListener();

        addPinViewTextChangeListener();

        return me;
    }

    private void getFinalSavedCode(Bundle savedInstanceState) {
        if (savedInstanceState == null) return;
        finalCode = savedInstanceState.getString(FINAL_OPTP_CODE_KEY);
    }


    private void onConfirmClick() {
        //api data
        verifyCellNumber();

        accountSetupPage.bindSmsListener();

        showTimerMessage();

        //views
        hideView_1();
        showView_2();

        //disable the btns
        if (accountSetupPage != null) {
            accountSetupPage.nextBtn.setEnabled(false);
            accountSetupPage.prevBtn.setEnabled(false);
        }
        //disable the btns


        //start the timer
        setUpTimer();
    }

    private void showTimerMessage() {
        verification_label.setText("Please enter the 4 digit code which we sent on above number");

    }

    private void showInitialMessage() {
        verification_label.setText(getResources().getString(R.string.verify_phone_num_page_des));

    }

    private void onEditClick() {
        if (mPageChangeListener == null) return;
        mPageChangeListener.onPreviousPage();
    }

    private void addPinViewTextChangeListener() {

        /*verify_view.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {

            }

            @Override
            public void onOTPComplete(String otp) {
                finalCode = otp;
                onTextComplete();
                hideKeyBoard();
            }
        });*/

        verify_view.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                finalCode = editable.toString();

                if (editable.toString().length() == 4) {
                    onTextComplete();
                    hideKeyBoard();
                }
            }
        });
    }

    private void init() {
        serviceManager = ServiceManager.getInstance();


        //get Activity
        accountSetupPage = (AccountSetupPage) getActivity();

        mPageChangeListener = accountSetupPage.getListener();
        preference = accountSetupPage.preference;

        //phoneNumber
        accountSetupPage.setmUpdatePhoneNumberListener(this::update);

        //listener
        phoneCodeListener = code -> onCodeReceived(code);
        accountSetupPage.setPhoneCodeListener(phoneCodeListener);
    }

    private void onCodeReceived(String code) {
        if (verify_view != null) {
            verify_view.setText(code);
        }

    }

    private void showDialog() {
        VerifyPopUpDialog dialog = new VerifyPopUpDialog(getActivity(), new VerifyPopUpDialog.DialogClickListener() {
            @Override
            public void onConfirmClick(VerifyPopUpDialog dialog) {
                VerifyPhoneNumber.this.onConfirmClick();

            }

            @Override
            public void onEditClick(VerifyPopUpDialog dialog) {
                VerifyPhoneNumber.this.onEditClick();

            }
        });
        dialog.setPhoneNumber(phone_number_text_view.getText().toString());
        dialog.show();
    }

    private void verifyCellNumber() {


        resend_btn.setVisibility(View.GONE);


        serviceManager.getAPI().verifyCellNumberCode(preference.getString(Constants.ACCESS_TOKEN), phone_number_text_view.getText().toString(),accountSetupPage == null ? "" : accountSetupPage.getAppSignature()).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                try {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {

                        } else {
                            accountSetupPage.onResponseFailure();
                        }
                    } else {
                        accountSetupPage.onResponseFailure();
                    }
                } catch (Exception ex) {

                }

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                try {
                    accountSetupPage.onResponseFailure();
                } catch (Exception ex) {

                }
            }
        });
    }

    private void initViews() {
        //view 1
        verify_btn = findViewById(R.id.verify_btn);
        info_text_1 = (TextView) findViewById(R.id.info_text_1);

        //view 2
        verify_view = (PinView) findViewById(R.id.verify_view);
        error_text_view = (TextView) findViewById(R.id.error_text_view);
        timer_text_view = (TextView) findViewById(R.id.timer_text_view);
        resend_btn = findViewById(R.id.resend_btn);

        //checkView
        check_view = (CheckView) findViewById(R.id.check_view);

        //phoneNumber
        phone_number_text_view = (TextView) findViewById(R.id.phone_number_text_view);


        verification_label = (TextView) findViewById(R.id.verification_label);

    }

    private void showView_1() {
        view_1(View.VISIBLE);
    }

    private void hideView_1() {
        view_1(View.GONE);
    }

    private void showView_2() {
        view_2(View.VISIBLE);
    }

    private void hideView_2() {
        view_2(View.GONE);
    }

    private void view_1(int visibility) {
        verify_btn.setVisibility(visibility);
        info_text_1.setVisibility(visibility);
    }

    private void view_2(int visibility) {
        verify_view.setVisibility(visibility);
        error_text_view.setVisibility(visibility);
        check_view.setVisibility(visibility);

    }


    /*
     * Initiate the timer
     */
    private void setUpTimer() {


        timer_text_view.setVisibility(View.VISIBLE);


        countDownTimer = new CountDownTimer(Constants.TIME_LIMIT, Constants.COUNT_DOWN_INTERVAL) {

            public void onTick(long millisUntilFinished) {
                timer_text_view.setText("Resend Code in " + millisUntilFinished / 1000 + " Seconds");
            }

            public void onFinish() {
                onCountDownTimerFinish();
            }
        }.start();
    }

    /*
     * Count timer has Finished
     */
    private void onCountDownTimerFinish() {

        enableFooterBtnAndGesture();

        timer_text_view.setVisibility(View.GONE);

        resend_btn.setVisibility(View.VISIBLE);
        error_text_view.setText("");

        preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, "no");
        // check_view.check();


    }

    private void bindResendListener() {
        resend_btn.setOnClickListener(view -> {
            verify_view.setText("");
            error_text_view.setText("");
            onConfirmClick();
        });
    }

    /*
     * enable Buttons
     */
    private void enableFooterBtnAndGesture() {

        if (accountSetupPage != null) {
            accountSetupPage.nextBtn.setEnabled(true);
            accountSetupPage.prevBtn.setEnabled(true);
        }
    }

    private void onCodeVerified() {

        //resend hide
        error_text_view.setVisibility(View.GONE);
        resend_btn.setVisibility(View.GONE);

        //disable
        setTouchEventOfOtp(true);

        //animate check
        check_view.check();


        //change fragment
        new Handler().postDelayed(() -> {
            if (accountSetupPage != null) {
                //update flag
                accountSetupPage.isVerified = true;

                preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, "yes");


                //next page
                if (mPageChangeListener != null) {
                    mPageChangeListener.onNextPage();
                }

            }
        }, 1200);
    }

    /*
     * User fill the text
     */
    private void onTextComplete() {



        //code send
        sendCodeToServer();
    }


    private void onCodeNotVerified() {
        if (accountSetupPage != null) {
            //error

            error_text_view.setText("Invalid verification code");
            bindResendListener();
        }
    }

    private void sendCodeToServer() {
        accountSetupPage.getAPI().verifyCellNumber(preference.getString(Constants.ACCESS_TOKEN), finalCode).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        onCodeVerified();
                        stopTimer();
                        enableFooterBtnAndGesture();
                    } else {
                        onCodeNotVerified();
                    }
                } else {

                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });
    }

    private void stopTimer(){
        if (countDownTimer != null) {
            countDownTimer.cancel();
            timer_text_view.setText("");
        }

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(FINAL_OPTP_CODE_KEY, finalCode);
    }

    @Override
    public void update(String phoneNum, boolean isVerified) {
        phone_number_text_view.setText(phoneNum);
        if (!isVerified) {
            showView_1();
            hideView_2();

            resend_btn.setVisibility(View.GONE);
            error_text_view.setText("");


            //reset
            check_view.uncheck();
            verify_view.setText("");
            setTouchEventOfOtp(false);

            showInitialMessage();
        }
    }

    private void setTouchEventOfOtp(final boolean isEnable) {
        verify_view.setOnTouchListener((v, event) -> isEnable);
    }
}

