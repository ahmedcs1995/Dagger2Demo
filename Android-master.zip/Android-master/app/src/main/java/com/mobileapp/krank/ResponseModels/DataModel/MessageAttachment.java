package com.mobileapp.krank.ResponseModels.DataModel;


import android.arch.persistence.room.ColumnInfo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class MessageAttachment {

    @SerializedName("file_name")
    @Expose
    @ColumnInfo(name = "file_name")
    private String fileName;

    @SerializedName("file_thumb")
    @Expose
    @ColumnInfo(name = "file_thumb")
    private String fileThumb;

    @SerializedName("file_path")
    @Expose
    @ColumnInfo(name = "file_path")
    private String filePath;

    @SerializedName("file_ext")
    @Expose
    @ColumnInfo(name = "file_ext")
    private String fileExt;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileThumb() {
        return fileThumb;
    }

    public void setFileThumb(String fileThumb) {
        this.fileThumb = fileThumb;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileExt() {
        return fileExt;
    }

    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }

}

