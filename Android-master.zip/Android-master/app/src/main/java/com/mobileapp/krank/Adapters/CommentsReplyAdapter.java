package com.mobileapp.krank.Adapters;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.CommentsReplyActivity;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ChildCommentDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsDataResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentsReplyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<ChildCommentDataModel> items;
    CommentsReplyActivity context;
    CommentsDataResponse commentsDataResponse;
    public SaveInSharedPreference preference;
    Animation myAnim;


    //listeners
    CallBackWithPosTypeAndView callBackWithView;

    //listener type
    public static final int REPLY_CALLBACK = 1;
    public static final int SEND_COMMENT_LIKE = 2;
    public static final int SEND_COMMENT_REPLY_LIKE = 3;
    public static final int DELETE_COMMENT_CALLBACK = 4;
    public static final int COMMENT_USER_PROFILE = 5;
    public static final int COMMENT_REPLY_USER_PROFILE = 6;


    public class CommentViewHolder extends RecyclerView.ViewHolder {
        View item;
        CircleImageView profileImgCommentPost;
        TextView timeTextViewCommentPost;
        TextView comentName;
        TextView comentDes;
        View likeContainerCommentPost;
        View replyContainer;
        View replyCountImgContainer;
        TextView viewReplyText;
        TextView commentReplyName;
        ImageView likeImgCommentPost;
        ImageView commentReplyImg;
        TextView likeTextCommentPost;
        TextView noOfReplies;
        TextView noOfLikesCommentPost;


        public CommentViewHolder(View itemView) {
            super(itemView);
            profileImgCommentPost = itemView.findViewById(R.id.profile_img_comment_post);
            timeTextViewCommentPost = itemView.findViewById(R.id.time_text_view_comment_post);
            comentName = itemView.findViewById(R.id.commentName);
            comentDes = itemView.findViewById(R.id.comment_des);
            likeContainerCommentPost = itemView.findViewById(R.id.like_container_comment_post);
            likeImgCommentPost = itemView.findViewById(R.id.like_img_comment_post);
            likeTextCommentPost = itemView.findViewById(R.id.like_text_comment_post);
            noOfLikesCommentPost = itemView.findViewById(R.id.no_of_likes_comment_post);
            noOfReplies = itemView.findViewById(R.id.no_of_replies_comment_post);
            replyContainer = itemView.findViewById(R.id.reply_container);
            viewReplyText = itemView.findViewById(R.id.view_reply_text);
            commentReplyImg = itemView.findViewById(R.id.comment_reply_img);
            commentReplyName = itemView.findViewById(R.id.comment_reply_name);
            replyCountImgContainer = itemView.findViewById(R.id.reply_count_img_container);


            likeContainerCommentPost.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), SEND_COMMENT_LIKE, likeContainerCommentPost);
            });

            replyCountImgContainer.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), REPLY_CALLBACK, view);
            });

            comentName.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), COMMENT_USER_PROFILE, view);
            });

            profileImgCommentPost.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), COMMENT_USER_PROFILE, view);
            });
        }

    }

    public class SubComment extends RecyclerView.ViewHolder {

        View item;
        CircleImageView profileImgCommentPost;
        TextView timeTextViewCommentPost;
        TextView comentName;
        TextView comentDes;
        View likeContainerCommentPost;
        View replyContainer;
        TextView viewReplyText;
        TextView commentReplyName;
        ImageView likeImgCommentPost;
        ImageView commentReplyImg;
        TextView likeTextCommentPost;
        TextView noOfReplies;
        TextView noOfLikesCommentPost;
        View replyCountImgContainer;

        View delete_comment;

        public SubComment(View itemView) {
            super(itemView);
            item = itemView;
            profileImgCommentPost = itemView.findViewById(R.id.profile_img_comment_post);
            timeTextViewCommentPost = itemView.findViewById(R.id.time_text_view_comment_post);
            comentName = itemView.findViewById(R.id.commentName);
            comentDes = itemView.findViewById(R.id.comment_des);
            likeContainerCommentPost = itemView.findViewById(R.id.like_container_comment_post);
            likeImgCommentPost = itemView.findViewById(R.id.like_img_comment_post);
            likeTextCommentPost = itemView.findViewById(R.id.like_text_comment_post);
            noOfLikesCommentPost = itemView.findViewById(R.id.no_of_likes_comment_post);
            noOfReplies = itemView.findViewById(R.id.no_of_replies_comment_post);
            replyContainer = itemView.findViewById(R.id.reply_container);
            viewReplyText = itemView.findViewById(R.id.view_reply_text);
            commentReplyImg = itemView.findViewById(R.id.comment_reply_img);
            commentReplyName = itemView.findViewById(R.id.comment_reply_name);
            replyCountImgContainer = itemView.findViewById(R.id.reply_count_img_container);
            delete_comment = itemView.findViewById(R.id.delete_view_comment_post);


            likeContainerCommentPost.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), SEND_COMMENT_REPLY_LIKE, likeContainerCommentPost);
            });


            delete_comment.setOnClickListener(view -> {
                if(items.get(getAdapterPosition()).getCa() == 1){
                    callBackWithView.act(getAdapterPosition(),DELETE_COMMENT_CALLBACK,view);
                }
            });

            comentName.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), COMMENT_REPLY_USER_PROFILE, view);
            });
            profileImgCommentPost.setOnClickListener(view -> {
                callBackWithView.act(getAdapterPosition(), COMMENT_REPLY_USER_PROFILE, view);
            });
        }

    }


    public CommentsReplyAdapter(List<ChildCommentDataModel> items, CommentsReplyActivity context, CommentsDataResponse commentsDataResponse,  CallBackWithPosTypeAndView callBackWithView) {
        this.items = items;
        this.context = context;
        this.commentsDataResponse = commentsDataResponse;
        preference = new SaveInSharedPreference(context);
        this.callBackWithView = callBackWithView;


        myAnim = AnimationUtils.loadAnimation(context, R.anim.bounce_for_comment_click);

    }


    @Override
    public int getItemViewType(int position) {

        switch (items.get(position).getTypeOfComment()) {
            case COMMENT:
                return 1;
            case SUB_COMMENT:
                return 2;
            default:
                return -1;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_item, parent, false);
                return new CommentViewHolder(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_reply_item, parent, false);
                return new SubComment(view);
            default:
                return null;

        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final ChildCommentDataModel item = items.get(position);


        switch (item.getTypeOfComment()) {
            case COMMENT:
                setTypeComment(holder, position);
                break;
            case SUB_COMMENT:
                setTypeSubTypeComment(holder, item, position);
                break;

        }
    }

    private void setTypeComment(final RecyclerView.ViewHolder holder, final int position) {

        final CommentViewHolder commentViewHolder = (CommentViewHolder) holder;

        //  commentViewHolder.replyCountImgContainer.setVisibility(View.GONE);
        if (commentsDataResponse.getProfilePic() != null) {
            Glide.with(context).load(AppUtils.getImgUrl(commentsDataResponse.getProfilePic())).into(commentViewHolder.profileImgCommentPost);
        }
        commentViewHolder.timeTextViewCommentPost.setText(commentsDataResponse.getDate());
        commentViewHolder.comentName.setText(commentsDataResponse.getFirstName() + " " + commentsDataResponse.getLastName());
        commentViewHolder.comentDes.setText(Html.fromHtml(commentsDataResponse.getComments()));
        if (commentsDataResponse.getIsLike() == 0) {
            commentViewHolder.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            commentViewHolder.likeTextCommentPost.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            commentViewHolder.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            commentViewHolder.likeTextCommentPost.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }

        commentViewHolder.noOfReplies.setText(commentsDataResponse.getChildCount());

        commentViewHolder.noOfLikesCommentPost.setText(commentsDataResponse.getTotalLikes());


    }

    private void setTypeSubTypeComment(final RecyclerView.ViewHolder holder, final ChildCommentDataModel item, final int position) {
        final SubComment subComment = (SubComment) holder;


        if (item.getPic() != null) {
            Glide.with(context).load(AppUtils.getImgUrl(item.getProfile_pic())).into(subComment.profileImgCommentPost);
        }

        subComment.replyCountImgContainer.setVisibility(View.GONE);
        subComment.timeTextViewCommentPost.setText(item.getDate());
        subComment.comentName.setText(item.getFullName());
        subComment.comentDes.setText(Html.fromHtml(item.getReply()));
        if (item.getIsLike() == 0) {
            subComment.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));

            //  holder.likeImgForTextPost.setColorFilter(ContextCompat.getColor(context, R.color.drawerGray), android.graphics.PorterDuff.Mode.MULTIPLY);
            subComment.likeTextCommentPost.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            subComment.likeImgCommentPost.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            subComment.likeTextCommentPost.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }
        //subComment.noOfReplies.setVisibility(View.GONE);


        subComment.noOfLikesCommentPost.setText(item.getTotalLikes());


        if (item.getCa() == 1) {
            subComment.delete_comment.setVisibility(View.VISIBLE);
         //   subComment.delete_comment.setOnClickListener(view -> showDeletePopUpMenu(view, item, position));
        } else {
            subComment.delete_comment.setVisibility(View.GONE);
        }

        if (item.isFoucsComment()) {
            subComment.item.setBackgroundColor(ContextCompat.getColor(context, R.color.unread_notification));
        } else {
            subComment.item.setBackgroundColor(ContextCompat.getColor(context, R.color.AppWhiteColor));
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }


}





