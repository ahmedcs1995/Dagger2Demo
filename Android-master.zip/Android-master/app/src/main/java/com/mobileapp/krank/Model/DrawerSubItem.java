package com.mobileapp.krank.Model;

import com.mobileapp.krank.CallBacks.CustomCallBack;

/**
 * Created by Ahmed on 4/13/2018.
 */

public class DrawerSubItem {
    String name;
    CustomCallBack subItemClick;
    int icon;
    boolean focusView;


    public DrawerSubItem(String name) {
        this.name = name;
    }


    public DrawerSubItem(String name, CustomCallBack subItemClick) {
        this.name = name;
        this.subItemClick = subItemClick;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CustomCallBack getSubItemClick() {
        return subItemClick;
    }

    public void setSubItemClick(CustomCallBack subItemClick) {
        this.subItemClick = subItemClick;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public boolean isFocusView() {
        return focusView;
    }

    public void setFocusView(boolean focusView) {
        this.focusView = focusView;
    }
}
