package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.mobileapp.krank.Chat.AddPeopleInPrivateChat;
import com.mobileapp.krank.Chat.ChatMainPage;
import com.mobileapp.krank.Chat.PrivateChat.PersonalChat;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity;
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.PrivateChatUserDetail;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yaseen on 30/04/2018.
 */


public class PersonalChatAdapter extends RecyclerView.Adapter<PersonalChatAdapter.ViewHolder> {
    private List<ChatConversationListDataModel> items;
    PersonalChat personalChat;
    List<PrivateChatUserDetail> userDetail = new ArrayList<>();
    private final ViewBinderHelper binderHelper = new ViewBinderHelper();
    AppUtils appUtils;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View addPeopleBtn;
        View chatItem;
        View online_view;
        CircleImageView profile_image_view;
        TextView name;
        TextView date;
        TextView msg;
        View un_read_count;
        private SwipeRevealLayout swipeLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            addPeopleBtn=itemView.findViewById(R.id.add_people_btn);
            chatItem=itemView.findViewById(R.id.chat_item);
            profile_image_view=itemView.findViewById(R.id.profile_image_view);
            name=itemView.findViewById(R.id.name);
            date=itemView.findViewById(R.id.date);
            msg=itemView.findViewById(R.id.msg);
            online_view=itemView.findViewById(R.id.online_view);
            un_read_count=itemView.findViewById(R.id.un_read_count);
            swipeLayout = (SwipeRevealLayout) itemView.findViewById(R.id.swipe_layout);


            addPeopleBtn.setOnClickListener(view -> {
                ChatConversationListDataModel item = items.get(getAdapterPosition());
                userDetail.clear();
                userDetail.add(new PrivateChatUserDetail(item.getSecond_user().getId(),item.getSecond_user().getUser_name(),"",item.getSecond_user().getProfile_pic(),item.getSecond_user().getDesignation(),item.getSecond_user().getCompany()));
                Intent intent = new Intent(personalChat.getContext(), AddPeopleInPrivateChat.class);
                intent.putExtra("people_list_in_chat", appUtils.convertToJson(userDetail));
                intent.putExtra("isPersonalChat",true);
                personalChat.startActivity(intent);
                personalChat.getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
                //      Toast.makeText(personalChat.getContext(),"add press",Toast.LENGTH_SHORT).show();
            });
            chatItem.setOnClickListener(view -> {
                ChatConversationListDataModel item = items.get(getAdapterPosition());
                Intent intent = new Intent(personalChat.getContext(),PrivateChatConversationActivity.class);
                intent.putExtra("recipient_name","" +  item.getRecipient());
                intent.putExtra("conv_id","" +  item.getId());
                intent.putExtra("user_two_id","" +  item.getUserTwo());
            /*if(item.getFrom_local_db().equals(Constants.FROM_LOCAL_DB_TRUE)){
                intent.putExtra("start_conversation",true);
            }*/
                MyFirebaseMessagingService.CURRENT_CONV_ID ="" + item.getId();
                personalChat.startActivity(intent);
                personalChat. getActivity(). overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
            });

        }
    }

    public PersonalChatAdapter(List<ChatConversationListDataModel> items, PersonalChat personalChat) {
        this.items = items;
        this.personalChat = personalChat;
        binderHelper.setOpenOnlyOne(true);
        appUtils =  AppUtils.getInstance();

    }


    @Override
    public PersonalChatAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.personal_chat_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PersonalChatAdapter.ViewHolder holder, int position) {
        final ChatConversationListDataModel item = items.get(position);

        binderHelper.bind(holder.swipeLayout, "" + item.getId());
/*
        holder.addPeopleBtn.setOnClickListener(view -> {
            userDetail.clear();
            userDetail.add(new PrivateChatUserDetail(item.getSecond_user().getUserId(),item.getSecond_user().getUser_name(),"",item.getSecond_user().getProfile_pic(),item.getSecond_user().getDesignation(),item.getSecond_user().getCompany()));
            Intent intent = new Intent(personalChat.getContext(), AddPeopleInPrivateChat.class);
            intent.putExtra("people_list_in_chat", appUtils.convertToJson(userDetail));
            intent.putExtra("isPersonalChat",true);
            personalChat.startActivity(intent);
            personalChat.getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
      //      Toast.makeText(personalChat.getContext(),"add press",Toast.LENGTH_SHORT).show();
        });
        holder.chatItem.setOnClickListener(view -> {
            Intent intent = new Intent(personalChat.getContext(),PrivateChatConversationActivity.class);
            intent.putExtra("recipient_name","" +  item.getRecipient());
            intent.putExtra("conv_id","" +  item.getUserId());
            intent.putExtra("user_two_id","" +  item.getUserTwo());
            *//*if(item.getFrom_local_db().equals(Constants.FROM_LOCAL_DB_TRUE)){
                intent.putExtra("start_conversation",true);
            }*//*
            MyFirebaseMessagingService.CURRENT_CONV_ID ="" + item.getUserId();
            personalChat.startActivity(intent);
            personalChat. getActivity(). overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });*/

        holder.name.setText("" + item.getRecipient());
        Glide.with(personalChat.getContext()).load(item.getRecipientImg()).into(holder.profile_image_view);

        holder.date.setText("" + item.getUpdateDate());
        // holder.date.setText("" + appUtils.setTimeInChatList(item.getMsgTime()));
        if(item.getType().equals("vcard")){
            holder.msg.setText("Sent a contact card");
        }
        else if(item.getType().equals("attachment")){
            holder.msg.setText("Sent an attachment");
        }
        else{
            holder.msg.setText("" + Html.fromHtml("" + item.getConvoPreview()));
        }

        if(item.getRecipientOnline()!=null && AppUtils.checkNetworkState(personalChat.getContext())){
            if(item.getRecipientOnline().equals("0")){
                holder.online_view.setVisibility(View.GONE);
            }
            else{
                holder.online_view.setVisibility(View.VISIBLE);
            }
        }else{
            holder.online_view.setVisibility(View.GONE);
        }

        if(Integer.parseInt(item.getConversation_unread()) > 0 && !(item.getSenderId().equals(((ChatMainPage)personalChat.getActivity()).preference.getString(Constants.USER_ID)))){
            // holder.un_read_count.setText("" + item.getConversation_unread());
            holder.un_read_count.setVisibility(View.VISIBLE);
        }else{
            holder.un_read_count.setVisibility(View.GONE);
        }
    }
    @Override
    public int getItemCount() {
        return items.size();
    }


}