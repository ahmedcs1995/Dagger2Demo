package com.mobileapp.krank.Model.Enums;

public enum TypeOfSearch {
    PEOPLE_SEARCH,
    NETWORK_SEARCH,
    RENT_LISTING_SEARCH,
    SALE_LISTING_SEARCH,
    POST,
    VIEW_ALL_BUTTON,
    HEADER_ITEM
}
