package com.mobileapp.krank.CustomViews;

import android.support.v7.app.AlertDialog;
import android.view.View;

public class CustomReturn{
    public AlertDialog.Builder dialog;
    public View view;
}
