package com.mobileapp.krank.Database;

import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;

import com.mobileapp.krank.ViewModels.ChatConversationListViewModel;
import com.mobileapp.krank.ViewModels.ChatConversationListViewModel2;
import com.mobileapp.krank.ViewModels.GroupChatConversationViewModel;
import com.mobileapp.krank.ViewModels.GroupChatMemberListViewModel;

public class MyViewModelFactory extends ViewModelProvider.NewInstanceFactory {
    private Application mApplication;
    private String mParam;


    public MyViewModelFactory(Application application, String param) {
        mApplication = application;
        mParam = param;
    }


    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        if(modelClass == ChatConversationListViewModel.class){
            return (T) new ChatConversationListViewModel(mApplication, mParam);
        }
        else if(modelClass == GroupChatMemberListViewModel.class){
            return (T) new GroupChatMemberListViewModel(mApplication, mParam);
        }
        else if(modelClass == ChatConversationListViewModel2.class){
            return (T) new ChatConversationListViewModel2(mApplication, mParam);
        }
        else{
            return (T) new GroupChatConversationViewModel(mApplication, mParam);
        }
    }
}
