package com.mobileapp.krank.Functions;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.CircularProgressDrawable;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.request.RequestOptions;
import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.CompanyProfileView;
import com.mobileapp.krank.Activities.InAppWebViewCollapseActivity;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.CallBacks.DeletePopUpCallBack;
import com.mobileapp.krank.CustomViews.CustomReturn;
import com.mobileapp.krank.CustomViews.URLSpanNoUnderline;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AppUtils {
    Gson gson;
    RequestOptions options = new RequestOptions();
    private static AppUtils INSTANCE;
    Date date;
    SimpleDateFormat appDateFormat;
    SimpleDateFormat appDateFormatMilliSeconds;
    SimpleDateFormat dateConvertFormat;

    public static AppUtils getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AppUtils();
            return INSTANCE;
        }
        return INSTANCE;
    }

    private AppUtils() {

        appDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        appDateFormatMilliSeconds = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

        dateConvertFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //  appDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/London"));

        appDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        appDateFormatMilliSeconds.setTimeZone(TimeZone.getTimeZone("UTC"));

        dateConvertFormat.setTimeZone(TimeZone.getDefault());

        date = new Date();
        gson = CustomGson.getInstance();

    }




    private String getConvertedDate(String ourDate) {
        String dateToReturn;
        try {
            Date value = appDateFormat.parse(ourDate);

            dateToReturn = dateConvertFormat.format(value);

            //Log.d("ourDate", ourDate);
        } catch (Exception e) {
            dateToReturn = "00-00-0000 00:00";
        }
        return dateToReturn;
    }

    public String setTimeInChatList(String stringDate) {
        stringDate = getConvertedDate(stringDate);
        Calendar cal = Calendar.getInstance();
        int currentDate = cal.get(Calendar.DATE);
        try {
            cal.setTime(dateConvertFormat.parse(stringDate));
            if (cal.get(Calendar.DATE) == currentDate) {
                if (cal.get(Calendar.AM_PM) == 0) {

                    return String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " AM";
                } else {
                    return String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " PM";
                }
            } else {
                return "" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.DATE) + "/" + cal.get(Calendar.YEAR);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String setTimeInChatBubble(String stringDate) {
        stringDate = getConvertedDate(stringDate);
        Calendar cal = Calendar.getInstance();
        int currentDate = cal.get(Calendar.DATE);
        int currentMonth = cal.get(Calendar.MONTH);
        int yearMonth = cal.get(Calendar.YEAR);
        try {
            cal.setTime(dateConvertFormat.parse(stringDate));
            if (cal.get(Calendar.DATE) == currentDate && cal.get(Calendar.MONTH) == currentMonth && cal.get(Calendar.YEAR) == yearMonth) {
                if (cal.get(Calendar.AM_PM) == 0) {
                    return String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " AM";
                } else {
                    return String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " PM";
                }
            } else {
                if (cal.get(Calendar.AM_PM) == 0) {
                    return "" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.DATE) + "/" + cal.get(Calendar.YEAR) + " " + String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " AM";
                } else {
                    return "" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.DATE) + "/" + cal.get(Calendar.YEAR) + " " + String.format("%02d:%02d", cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE)) + " PM";
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*for sign up pages*/
    public static void addClickableText(SpannableStringBuilder ssb, int startPos, String clickableText, Context context, @ColorRes int id) {
        ssb.append(clickableText);
        ssb.setSpan(new ForegroundColorSpan(ContextCompat.getColor(context, id)), startPos, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

    }
    /*for sign up pages*/


    /*for sign up bottom pages and chat emma cooper messsage*/
    public static void addClickableTextWithClick(SpannableStringBuilder ssb, int startPos, String clickableText, CustomCallBack customCallBack, Context context) {
        ssb.append(clickableText);
        ssb.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View view) {
                customCallBack.act();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false); // get rid of underlining
                ds.setColor(ContextCompat.getColor(context, R.color.AppBlueColor));     // make links red
            }
        }, startPos, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    /*for sign up bottom pages and chat emma cooper messsage*/


    public String convertToJson(Object data) {

        String jsonString = gson.toJson(data);
        return jsonString;
    }


    public static String getImgUrl(String fileName) {
        return Constants.BASE_IMG_URL + fileName;
    }

    public static String getDeviceName() {
        String manufacturer = getManufacturer();
        String model = getModel();
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        }
        return capitalize(manufacturer) + " " + model;
    }

    public static String getManufacturer() {
        return capitalize(Build.MANUFACTURER);
    }


    public static String getDeviceVersion() {
        return "Android " + Build.VERSION.RELEASE;
    }


    public static String getModel() {
        return capitalize(Build.MODEL);
    }

    private static String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] arr = str.toCharArray();
        boolean capitalizeNext = true;

        StringBuilder phrase = new StringBuilder();
        for (char c : arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase.append(Character.toUpperCase(c));
                capitalizeNext = false;
                continue;
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            }
            phrase.append(c);
        }

        return phrase.toString();
    }

    public static void shareToExternal(String url, Context context) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "Sharing URL");
        i.putExtra(Intent.EXTRA_TEXT, url);
        context.startActivity(Intent.createChooser(i, "Share Post"));
    }

    public static void setSpannableUnderlineText(TextView mTextView, String text) {
        SpannableString content = new SpannableString(text);
        content.setSpan(new UnderlineSpan(), 0, text.length(), 0);
        mTextView.setText(content);
    }



    public static CustomReturn buildDialog(Context context, Activity activity, int layout_resource) {
        CustomReturn customReturn = new CustomReturn();
        final AlertDialog.Builder dialog = new AlertDialog.Builder(context);
// retrieve display dimensions
        Rect displayRectangle = new Rect();
        Window window = activity.getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(displayRectangle);

// inflate and adjust layout
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View layout = inflater.inflate(layout_resource, null);
        dialog.setView(layout);

        customReturn.dialog = dialog;
        customReturn.view = layout;

        return customReturn;
    }

    public static void copyToClipBoard(Context context, String url) {
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("lablel", url);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show();
    }

    public boolean checkYoutubeUrl(String youtubeUrl) {
        String video_id = "";
        if (youtubeUrl != null && youtubeUrl.trim().length() > 0 && youtubeUrl.startsWith("http")) {

            // String expression = "^.*((youtu.be"+ "\\/)" + "|(v\\/)|(\\/u\\/w\\/)|(embed\\/)|(watch\\?))\\??v?=?([^#\\&\\?]*).*"; // var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
            String expression = "^.*((youtu.be\\/)|(v\\/)|(\\/u\\/\\w\\/)|(embed\\/)|(watch\\?))\\??v?=?([^#\\&\\?]*).*"; // var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
            CharSequence input = youtubeUrl;
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(input);
            if (matcher.matches()) {
                return true;
            }
        }
        return false;
    }

    public boolean checkVimeoUrl(String youtubeUrl) {
        if (youtubeUrl != null && youtubeUrl.trim().length() > 0) {
            String expression = "^(http:\\/\\/|https:\\/\\/|)(vimeo\\.com)\\/([\\w\\/]+)([\\?].*)?$"; // var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
            CharSequence input = youtubeUrl;
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(input);
            if (matcher.matches()) {
                return true;
            }
        }
        return false;
    }

    public static void removeUnderlines(Spannable p_Text) {
        URLSpan[] spans = p_Text.getSpans(0, p_Text.length(), URLSpan.class);

        for (URLSpan span : spans) {
            int start = p_Text.getSpanStart(span);
            int end = p_Text.getSpanEnd(span);
            p_Text.removeSpan(span);
            span = new URLSpanNoUnderline(span.getURL());
            p_Text.setSpan(span, start, end, 0);
        }
    }




    public static String getCompanyAndDesignation(String company, String designation) {
        if (designation != null) {
            return designation + " @ " + company;
        }

        return "@ " + company;
    }


    public RequestOptions getRequestOptions(Context context) {

        options.fitCenter();

        CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(context);
        circularProgressDrawable.setStrokeWidth(5f);
        circularProgressDrawable.setCenterRadius(30f);
        circularProgressDrawable.start();

        options.placeholder(circularProgressDrawable);


        return options;
    }

    public String replaceScriptString(String desc) {
        // String scriptRegex = "<(/)?[ ]*script[^>]*>";
        String scriptRegex = "<(/)?[ ]*[^>]*>";
        Pattern pattern2 = Pattern.compile(scriptRegex);

        if (desc != null) {
            Matcher matcher2 = pattern2.matcher(desc);
            StringBuffer str = new StringBuffer(desc.length());
            while (matcher2.find()) {
                matcher2.appendReplacement(str, Matcher.quoteReplacement(" "));
            }
            matcher2.appendTail(str);
            desc = str.toString();
        }
        return desc;
    }

    public static void resizeImage(int width, int height, SimpleDraweeView draweeView, DeviceInfo deviceInfo) {
        draweeView.getLayoutParams().width = deviceInfo.getDeviceWidth();
        draweeView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        draweeView.setAspectRatio((float) width / height);

    }


    public static boolean validateEmail(String emailStr) {
        Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.find();
    }

    public static boolean validateWebSiteUrl(String url) {
        Pattern REGEX = Pattern.compile("^(http:\\/\\/www\\.|https:\\/\\/www\\.|http:\\/\\/|https:\\/\\/)?[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.*)?$");

        Matcher matcher = REGEX.matcher(url);
        return matcher.find();
    }

    public static boolean checkNetworkState(Context context) {
        boolean connected = false;
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            return true;
        } else {
            return false;
        }
    }


    public void gotoCompanyProfile(Context context, String companyId, SaveInSharedPreference preference) {

        Intent intent = new Intent(context, CompanyProfileView.class);
        if (String.valueOf(companyId).equals(preference.getString(Constants.MY_COMPANY_ID))) {
            intent.putExtra("IsPersonalCompanyProfile", true);
        }
        intent.putExtra("companyId", "" + companyId);
        context.startActivity(intent);
    }


    public void gotoUserProfile(Context context, String userId, SaveInSharedPreference preference) {
        Intent intent = new Intent(context, UserProfileView.class);
        if ((userId).equals(preference.getString(Constants.USER_ID))) {
            intent.putExtra("IsPersonalProfile", true);
        }
        intent.putExtra("userId", "" + userId);
        context.startActivity(intent);
    }

    public void gotoHomePage(BaseActivity baseActivity) {
        Intent intent = new Intent(baseActivity, MainPage.class);
        baseActivity.startActivity(intent);
        baseActivity.finishAffinity();
    }

    public long getCurrentTimeStamp() {
        return getTimeStampForPull(appDateFormatMilliSeconds.format(GregorianCalendar.getInstance().getTime()));
    }

    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }


    public String getcurrentUTCTime() {
        return appDateFormat.format(GregorianCalendar.getInstance().getTime());
    }

    public long getTimeStamp(String inputDate) {
        try {
            date = appDateFormat.parse(inputDate);
            return date.getTime() / 1000;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getVimeoVideoId(String url) {
        String videoId;
        String videoUrl = url;
        if (videoUrl.indexOf('?') != -1) {
            int startIndex = videoUrl.lastIndexOf('/') + 1;
            int lastIndex = videoUrl.indexOf('?');
            videoId = videoUrl.substring(startIndex, lastIndex);
        } else {
            int startIndex = videoUrl.lastIndexOf('/') + 1;
            videoId = videoUrl.substring(startIndex, videoUrl.length());
        }
        return videoId;
    }

    public static String makeThumbnailOfYoutube(String url) {
        return "http://img.youtube.com/vi/" + getYoutubeIdFromUrl(url) + "/0.jpg";
    }

    public long getTimeStampForPull(String inputDate) {
        try {
            date = appDateFormatMilliSeconds.parse(inputDate);
            return date.getTime() / 1000;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getYoutubeIdFromUrl(String youtubeUrl) {
        String pattern = "(?<=watch\\?v=|/videos/|embed\\/|youtu.be\\/|\\/v\\/|\\/e\\/|watch\\?v%3D|watch\\?feature=player_embedded&v=|%2Fvideos%2F|embed%\u200C\u200B2F|youtu.be%2F|%2Fv%2F)[^#\\&\\?\\n]*";

        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(youtubeUrl); //url is youtube url for which you want to extract the id.
        if (matcher.find()) {
            return matcher.group();
        }
        return "";
    }

    public static String getYoutubeVideoId(String youtubeUrl) {
        String video_id = "";
        if (youtubeUrl != null && youtubeUrl.trim().length() > 0 && youtubeUrl.startsWith("http")) {

            String expression = "^.*((youtu.be" + "\\/)" + "|(v\\/)|(\\/u\\/w\\/)|(embed\\/)|(watch\\?))\\??v?=?([^#\\&\\?]*).*"; // var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
            CharSequence input = youtubeUrl;
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(input);
            if (matcher.matches()) {
                String groupIndex1 = matcher.group(7);
                if (groupIndex1 != null && groupIndex1.length() == 11)
                    video_id = groupIndex1;
            }
        }
        return video_id;
    }

    public long getTimeDifference(String date) throws ParseException {
        Date d1 = appDateFormat.parse(date);
        Date d2 = appDateFormat.parse(appDateFormatMilliSeconds.format(GregorianCalendar.getInstance().getTime()));
        long diffInMillies = Math.abs(d1.getTime() - d2.getTime());

        return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);

    }

    public void gotoAppWebViewPageForLink(Context context, String url) {
        Intent intent = new Intent(context, InAppWebViewCollapseActivity.class);
        intent.putExtra("web_view_url", url.trim());
        context.startActivity(intent);
    }

    public static void requestPermissions(int code, Activity activity, String[] permissions) {
        ActivityCompat.requestPermissions(activity, permissions, code);
    }

    public static boolean isPermissionAllowed(Context context, @NonNull String permission) {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static String getSimCountryCode(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getSimCountryIso();
    }

    public static String getCountryCode(Context context)  {
        String locale;

                locale = AppUtils.getSimCountryCode(context);
        if (locale.isEmpty()) {
             if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                 locale =   context.getResources().getConfiguration().getLocales().get(0).getCountry();
            } else {
                 context.getResources().getConfiguration().locale.getCountry();
            }
        }
        return locale;
    }

    public static boolean isStringContainsHttpHttps(String url) {
        return url.matches("^(http|https|ftp)://.*$");
    }

    public String getUrlWithUid(String url, SaveInSharedPreference preference) {
        return url + "?u_id=" + preference.getString(Constants.USER_UID);
    }

    public void showExternalSharePopUp(String url, Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, url);
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    public long getFileSize(File file) {
        return file.length() / 1024;
        // return in
    }

    public static float convertDpToPixel(float dp, Context context) {
        return dp * ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }


    /**
     * Invitation
     * */
    public static void inviteCompaniesAndCoWorkerInvite(SaveInSharedPreference preference, Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL));
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    public static void invitePrivateConnections(SaveInSharedPreference preference, Context context){
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.PRIVATE_INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL) + "/p");
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    public static void dealerInvite(SaveInSharedPreference preference, Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.DEALER_INVITE_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL) + "/d");
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }
    /**
     * Invitation
     * */





    public static String autoCapitalWord(String text) {
        return text.substring(0, 1).toUpperCase() + text.substring(1).toLowerCase();
    }

    public static ConNetStatus getConNetStatus(String status) {
        if (status == null) return ConNetStatus.NONE;
        String statusLowerCase = status.toLowerCase();
        if (statusLowerCase.equals(Constants.CONNECTION_NOT_CONNECTED.toLowerCase()) || statusLowerCase.equals(Constants.NO_CONNECTION_TEXT.toLowerCase())) {
            return ConNetStatus.NOT_CONNECTED;
        } else if (statusLowerCase.equals(Constants.CONNECTED_TEXT.toLowerCase())) {
            return ConNetStatus.CONNECTED;
        } else if (statusLowerCase.equals(Constants.INVITATION_RECEIVED.toLowerCase()) || statusLowerCase.equals(Constants.ACCEPT_REQUEST.toLowerCase())) {
            return ConNetStatus.INVITATION_RECEIVED;
        } else if (statusLowerCase.equals(Constants.REQUEST_PENDING.toLowerCase())) {
            return ConNetStatus.REQUEST_PENDING;
        } else {
            return ConNetStatus.NONE;
        }
    }

    public static PopupMenu getDeletePopUpMenu(View view, Context context, DeletePopUpCallBack callBack) {
        final PopupMenu popupMenu = new PopupMenu(context, view);

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            switch (menuItem.getItemId()) {
                case R.id.delete_option:
                    callBack.act(popupMenu);
                    return true;
                default:
                    return false;
            }
        });

        popupMenu.inflate(R.menu.delete_pop_up);

        /*For delete PopUp*/
        try {
            Field[] fields = popupMenu.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popupMenu);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod(
                            "setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        /*For delete PopUp*/

        return popupMenu;
    }

    public static String getSimCardNumber(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            TelephonyManager telemamanger = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            return telemamanger.getSimSerialNumber();
        }
        return null;
    }

    public static Spanned fromHtml(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        }
        return Html.fromHtml(html);

    }

    public static boolean isValidMobileNumber(String input) {
        Pattern pattern = Pattern.compile("^\\d$");
        Matcher matcher = pattern.matcher(input);
        if (matcher.matches()) {
            return true;
        }
        return false;

    }

    public static String concatenateCountryCity(String country,String city){
        String countryCity;


        countryCity =getCountryCityText(city) + ", " + getCountryCityText(country);

        return countryCity;
    }
    private static String getCountryCityText(String text){
        if(text==null || text.isEmpty()){
            return "N/A";
        }
        return text;

    }
    public static Drawable getIcon(Context context, @DrawableRes int id){
        return ContextCompat.getDrawable(context,id);
    }

    public static Boolean isSimAvailable(Context context)  {
        TelephonyManager telMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return (telMgr.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM && telMgr.getSimState() != TelephonyManager.SIM_STATE_ABSENT);

    }

    public static void openChromeAppForDownload(Uri uri,Context context){
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.android.chrome");
        context.startActivity(intent);

    }

    public static void openFolder(Context context)
    {
        Uri selectedUri = Uri.parse(Environment.getExternalStorageDirectory() + "/Krank/");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(selectedUri, "*/*");

        context.startActivity(intent);

    }


    public static String writeFileOnInternalStorage(String sBody,SaveInSharedPreference preference){

        String sFileName = "";
        /**
         * Directory
         * */
        File filePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if(!filePath.exists()){
            filePath.mkdir();
        }

        try{

            sFileName = getExportedFileName(preference);
            String extension = ".krank";

            sFileName +=extension;

            File gpxfile = new File(filePath,sFileName);

            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.flush();
            writer.close();

        }catch (Exception e){
            e.printStackTrace();
            return null;

        }
        return sFileName;
    }

    private static String getExportedFileName(SaveInSharedPreference preference){
        return preference.getString(Constants.USER_SLUG) + "connections-" + System.currentTimeMillis();
    }



    public static void setProgressWithAnimation(ProgressBar mProgressBar,int value){
        //  ObjectAnimator.ofInt(mProgressBar, "progress", value).setDuration(500).start();

        if (android.os.Build.VERSION.SDK_INT >= 11) {
            // will update the "progress" propriety of seekbar until it reaches progress
            ObjectAnimator animation = ObjectAnimator.ofInt(mProgressBar, "progress", value);
            animation.setDuration(500); // 0.5 second
            animation.setInterpolator(new LinearInterpolator());
            animation.start();
        } else
            mProgressBar.setProgress(value); // no animation on Gingerbread or lower
    }




    /**
     *
     * Download Intent
     * */

    public static Intent openDownloads(@NonNull Context context) {
        Intent intent;
        if (isSamsung()) {
            intent = context.getPackageManager()
                    .getLaunchIntentForPackage("com.sec.android.app.myfiles");
            intent.setAction("samsung.myfiles.intent.action.LAUNCH_MY_FILES");
            intent.putExtra("samsung.myfiles.intent.extra.START_PATH",
                    getDownloadsFile().getPath());

        }

        else intent = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);

        return intent;
    }

    public static boolean isSamsung() {
        String manufacturer = Build.MANUFACTURER;
        if (manufacturer != null) return manufacturer.toLowerCase().equals("samsung");
        return false;
    }

    public static File getDownloadsFile() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    }

    public static String getFileName(Uri uri,Context context) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                cursor.close();
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }
    /**
     *
     * Download Intent
     * */


    public static void inviteCoWorkerInvite(SaveInSharedPreference preference, Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.INVITE_CO_WORKER_STRING + " " + preference.getString(Constants.INVITE_COMPANIES_URL));
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }
}
