package com.mobileapp.krank.Repository.Chat.privateChat;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.google.gson.Gson;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.PrivateChat.PersonalChat;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.Dao.PersonalChatListDao;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.ResponseModels.ChatConversationListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonalChatListRepository {

    private PersonalChatListDao mChatConversationListDataModelDao;
    private LiveData<List<ChatConversationListDataModel>> mAllChatConversationListDataModel;
    private static int SECONDS_TO_REFRESH = 3000;
    AppExecutors appExecutors;
    Handler handler;
    Runnable runnable;
    SaveInSharedPreference preference;
    ServiceManager serviceManager;
    Gson gson;


    List<ChatConversationListDataModel> tempMsgs;
    List<ChatConversationListDataModel> serverMsgs;
    List<ChatConversationListDataModel> newMsgs;
    List<ChatConversationListDataModel> oldMsgs;
    boolean idFound;
    private boolean isDbEmpty;

    // Note that in order to unit test the WordRepository, you have to remove the Application
    // dependency. This adds complexity and much more code, and this sample is not about testing.
    // See the BasicSample in the android-architecture-components repository at
    // https://github.com/googlesamples
    public PersonalChatListRepository(Application application) {

        Log.e("PersonalChatList", "Repository yes");

        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        mChatConversationListDataModelDao = db.personalChatListDao();
        mAllChatConversationListDataModel = mChatConversationListDataModelDao.getAllChatList();

        tempMsgs = new ArrayList<>();
        serverMsgs = new ArrayList<>();
        newMsgs = new ArrayList<>();
        oldMsgs = new ArrayList<>();

        appExecutors = AppExecutors.getInstance();
        handler = new Handler();
        runnable = () -> getChatConversationList(null);
        preference = new SaveInSharedPreference(application.getApplicationContext());
        serviceManager = ServiceManager.getInstance();
        gson = CustomGson.getInstance();
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    public LiveData<List<ChatConversationListDataModel>> getmAllChatConversationListDataModel() {
        return mAllChatConversationListDataModel;
    }


    public void stopTask() {
        handler.removeCallbacks(runnable);
    }

    public void startTask(CustomCallBack customCallBack) {
        getChatConversationList(customCallBack);
    }

    // You must call this on a non-UI thread or your app will crash.
    // Like this, Room ensures that you're not doing any long running operations on the main
    // thread, blocking the UI.
    public void insert(ChatConversationListDataModel msg) {
        //new insertAsyncTask(mChatConversationListDataModelDao).execute(msg);
        appExecutors.diskIO().execute(() -> {
            mChatConversationListDataModelDao.insert(msg);
        });
    }

    public void bulkInsert(List<ChatConversationListDataModel> list) {
        //  new bulkInsertAsyncTask(mChatConversationListDataModelDao).execute(list);
        appExecutors.diskIO().execute(() -> {
            mChatConversationListDataModelDao.bulkInsert(list);
        });
    }

    public void bulkUpdate(List<ChatConversationListDataModel> list) {
        appExecutors.diskIO().execute(() -> {
            mChatConversationListDataModelDao.bulkUpdate(list);
        });
    }

    private static class insertAsyncTask extends AsyncTask<ChatConversationListDataModel, Void, Void> {

        private PersonalChatListDao mAsyncTaskDao;

        insertAsyncTask(PersonalChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final ChatConversationListDataModel... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    public PersonalChatListDao getDao() {
        return mChatConversationListDataModelDao;
    }

    private static class bulkInsertAsyncTask extends AsyncTask<List<ChatConversationListDataModel>, Void, Void> {

        private PersonalChatListDao mAsyncTaskDao;

        bulkInsertAsyncTask(PersonalChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(List<ChatConversationListDataModel>... lists) {
            mAsyncTaskDao.bulkInsert(lists[0]);
            return null;
        }
    }

    public void getChatConversationList(CustomCallBack customCallBack) {

        try {
            serviceManager.getAPI().getChatConversationList(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<ChatConversationListResponse>() {
                @Override
                public void onResponse(Call<ChatConversationListResponse> call, Response<ChatConversationListResponse> response) {


                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            if (getmAllChatConversationListDataModel() !=null && getmAllChatConversationListDataModel().getValue() != null) {
                                tempMsgs.clear();
                                newMsgs.clear();
                                serverMsgs.clear();
                                oldMsgs.clear();

                                if (getmAllChatConversationListDataModel().getValue().size() <= 0) {
                                    isDbEmpty = true;
                                } else {
                                    isDbEmpty = false;
                                }

                                if (isDbEmpty) {
                                    // insert data
                                    serverMsgs.clear();
                                    serverMsgs.addAll(response.body().getData());

                                    for (ChatConversationListDataModel item : serverMsgs) {
                                        item.setFrom_local_db(Constants.FROM_LOCAL_DB_FALSE);
                                    }
                                    appExecutors.diskIO().execute(() -> {
                                        getDao().bulkInsert(serverMsgs);
                                    });


                                } else {
                                    //update data
                                    tempMsgs = getmAllChatConversationListDataModel().getValue();
                                    serverMsgs.clear();
                                    serverMsgs.addAll(response.body().getData());
                                    for (ChatConversationListDataModel item : serverMsgs) {
                                        item.setFrom_local_db(Constants.FROM_LOCAL_DB_FALSE);
                                    }

                                    for (int i = 0; i < serverMsgs.size(); i++) {
                                        idFound = false;
                                        for (int j = 0; j < tempMsgs.size(); j++) {
                                            if (serverMsgs.get(i).getId() == tempMsgs.get(j).getId()) {
                                                idFound = true;
                                            }
                                        }
                                        if (!idFound) {
                                            newMsgs.add(serverMsgs.get(i));
                                        } else {
                                            oldMsgs.add(serverMsgs.get(i));
                                        }
                                    }
                                    appExecutors.diskIO().execute(() -> {
                                        getDao().bulkUpdate(oldMsgs);
                                        getDao().bulkInsert(newMsgs);
                                    });

                                }

                                if (customCallBack != null) {
                                    customCallBack.act();
                                }
                            }
                        }
                    }


                    if (!PersonalChat.EXIT) {
                        pull();
                    }

                }




                @Override
                public void onFailure(Call<ChatConversationListResponse> call, Throwable t) {
                    if (customCallBack != null) {
                        customCallBack.act();
                    }

                    if (!PersonalChat.EXIT) {
                        pull();
                    }
                }
            });

        } catch (Exception ex) {

        }
    }

    private boolean toUpdateMsg(ChatConversationListDataModel mServerMsg, ChatConversationListDataModel mLocalMsgs) {
        if (!(mLocalMsgs.getMsgTime().equals(mServerMsg.getMsgTime())) || !(mLocalMsgs.getConversation_unread().equals(mServerMsg.getConversation_unread()))) {
            return true;
        }
        return false;
    }

    private void pull() {
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }


}

