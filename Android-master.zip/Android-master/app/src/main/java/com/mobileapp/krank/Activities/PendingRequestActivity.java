package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Adapters.PagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.PendingRequestTabs.RequestReceived;
import com.mobileapp.krank.PendingRequestTabs.RequestSent;
import com.mobileapp.krank.R;

import java.util.ArrayList;

public class PendingRequestActivity extends BaseActivity {

    ViewPager mViewPager;
    private TabLayout mCustomTabLayout;


    public static final int NETWORK = 1;
    public static final int CONNECTION = 2;
    public static final int DEALER = 3;



    public static final String CURRENT_TAB_INDEX_KEY = "current_tab_index_key";
    public static final String SHOULD_SHOW_POPUP = "should_show_popup_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_request);
        setNormalPageToolbar("Pending Requests");


        mViewPager=findViewById(R.id.view_pager);
        mCustomTabLayout = findViewById(R.id.sliding_tabs);
        ArrayList<BaseFragment> pages = new ArrayList<>();
        pages.add(new RequestReceived());
        pages.add(new RequestSent());


        setViewPagerAndTabLayout(mViewPager, mCustomTabLayout, pages, pages.size(),getInitialPage());
        mViewPager.setCurrentItem(getInitialPage());
        showPopUp();
    }

    private void showPopUp(){
        if(shouldShowPopUp()){
            NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                    .setHeading("Contacts Imported Successfully!")
                    .setDescription("Your Contacts File Has been Imported Successfully And we have sent all the connection/network request to the imported connections")
                    .setConfirmButtonText("OK")
                    .setIcon(R.drawable.contact_icon_large)
                    .setHeadingColor(R.color.AppDarkGray)
                    .setIconTint(R.color.image_icon_color)
                    .hideCancelButton()
                    .setConfirmButtonListener(dialog1 -> {
                      dialog1.dismiss();
                    });

            dialog.show();
        }
    }

    private boolean shouldShowPopUp(){
        return getIntent().getBooleanExtra(SHOULD_SHOW_POPUP,false);
    }
    @Override
    public void onBackPressed() {
        if(isTaskRoot()){
            appUtils.gotoHomePage(PendingRequestActivity.this);
            return;
        }
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private int getInitialPage() {
        return getIntent().getIntExtra(CURRENT_TAB_INDEX_KEY,0);
    }

    private boolean isInvitation(String type){
        return type != null && (type.toLowerCase().equals("invitation") || type.toLowerCase().equals("dealer invitation") || type.toLowerCase().equals("private invitation"));
    }

    public SpannableStringBuilder getSpannableStringBuilder(String type, int track_id, String trackUrl, String text,String track_name) {
        SpannableStringBuilder builder;
        if (isInvitation(type)) {
            builder = new SpannableStringBuilder(text);
        } else {
            text = text.toLowerCase();
            String replacedText = text.replace(type.toLowerCase(),"").replace(track_name.toLowerCase(),"").trim();


            replacedText =  AppUtils.autoCapitalWord(replacedText) + " ";


            builder = new SpannableStringBuilder(replacedText + type);

            builder.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View view) {
                    if (type != null && type.toLowerCase().equals("listing")) {
                        Intent intent = new Intent(PendingRequestActivity.this, ListingDetail.class);
                        intent.putExtra("listing_id", "" + track_id);
                        startActivity(intent);
                    } else if (type != null && type.toLowerCase().equals("article")) {
                        Intent intent = new Intent(PendingRequestActivity.this, ArticleDetail.class);
                        intent.putExtra("article_id", track_id);
                        startActivity(intent);
                    }

                    else {
                        Intent intent = new Intent(PendingRequestActivity.this, InAppWebViewCollapseActivity.class);
                        intent.putExtra("web_view_url", trackUrl);
                        startActivity(intent);
                    }
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    ds.setColor(ContextCompat.getColor(PendingRequestActivity.this, R.color.drawer_background));    // you can use custom color
                    ds.setUnderlineText(false);
                }
            }, replacedText.length(), replacedText.length() + type.length(), Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
        }

        return builder;
    }

}

