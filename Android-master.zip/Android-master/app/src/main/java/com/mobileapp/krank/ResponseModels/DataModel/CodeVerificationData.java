package com.mobileapp.krank.ResponseModels.DataModel;

/**
 * Created by arbaz on 5/19/2018.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CodeVerificationData {

    @SerializedName("user_data")
    @Expose
    private UserData userData;

    public UserData getUserData() {
        return userData;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

}

