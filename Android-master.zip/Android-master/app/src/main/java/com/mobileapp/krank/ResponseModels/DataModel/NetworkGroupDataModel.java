package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.CallBacks.CustomCallBack;

import java.util.List;

public class NetworkGroupDataModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("networks")
    @Expose
    private String networks;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("group_name")
    @Expose
    private String groupName;
    @SerializedName("company_data")
    @Expose
    private List<NetworkGroupCompanyDataModel> companyData = null;

    private boolean isItemChecked;







    public boolean isItemChecked() {
        return isItemChecked;
    }

    public void setItemChecked(boolean itemChecked) {
        isItemChecked = itemChecked;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNetworks() {
        return networks;
    }

    public void setNetworks(String networks) {
        this.networks = networks;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<NetworkGroupCompanyDataModel> getCompanyData() {
        return companyData;
    }

    public void setCompanyData(List<NetworkGroupCompanyDataModel> companyData) {
        this.companyData = companyData;
    }

}
