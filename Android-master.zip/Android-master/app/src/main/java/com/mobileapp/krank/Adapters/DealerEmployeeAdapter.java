package com.mobileapp.krank.Adapters;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Activities.DealerEmployeeSelect;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDealerRepDataModel;
import com.mobileapp.krank.ViewHolders.CommonViewHolder.ConnectionsListItemViewHolder;

import java.util.List;

public class DealerEmployeeAdapter extends RecyclerView.Adapter<ConnectionsListItemViewHolder> implements CallBackWithAdapterPosition {
    private List<ListingDealerRepDataModel> items;
    DealerEmployeeSelect dealerEmployeeSelect;
    public ListingDealerRepDataModel prevData;


    @Override
    public void act(int position) {
        if(prevData==null){
            dealerEmployeeSelect.selectedIndex=position;
            prevData=items.get(position);
            items.get(position).setItemSelected(true);
            notifyDataSetChanged();
            return;
        }
        dealerEmployeeSelect.selectedIndex=position;
        prevData.setItemSelected(false);
        items.get(position).setItemSelected(true);
        prevData = items.get(position);
        notifyDataSetChanged();
    }




    public DealerEmployeeAdapter(List<ListingDealerRepDataModel> items, DealerEmployeeSelect dealerEmployeeSelect) {
        this.items = items;
        this.dealerEmployeeSelect = dealerEmployeeSelect;
        prevData=null;
    }

    @Override
    public ConnectionsListItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_by_connection_dealer_item, parent, false);
        return new ConnectionsListItemViewHolder(v,this);
    }

    @Override
    public void onBindViewHolder(final ConnectionsListItemViewHolder holder, final int position) {
        final ListingDealerRepDataModel item = items.get(position);

       /* holder.item.setOnClickListener(v -> {
            if(prevData==null){
                dealerEmployeeSelect.selectedIndex=position;
                prevData=item;
                item.setItemSelected(true);
                notifyDataSetChanged();
                return;
            }
            dealerEmployeeSelect.selectedIndex=position;
            prevData.setItemSelected(false);
            item.setItemSelected(true);
            prevData = item;
            notifyDataSetChanged();
        });*/

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
       // Glide.with(dealerEmployeeSelect.getApplicationContext()).load(Constants.BASE_IMG_URL + item.getProfilePic()).into(holder.profile_image_view);

        holder.profile_image_view.setImageURI("" + item.getProfilePic());
        holder.people_name.setText( item.getFirstName()  + " " + item.getLastName());
        holder.company_name_text_view.setText(AppUtils.getCompanyAndDesignation(item.getCompanyName(),item.getDesignation()));

        holder.status_text.setVisibility(View.VISIBLE);
        holder.status_text.setText("" + item.getConnectionStatus());

        if(item.getConnectionStatus().equals(Constants.CONNECTION_NOT_CONNECTED)){
            holder.status_text.setTextColor(ContextCompat.getColor(dealerEmployeeSelect,R.color.redColor));
        }else{
            holder.status_text.setTextColor(ContextCompat.getColor(dealerEmployeeSelect,R.color.drawer_background));
        }

    }
    @Override
    public int getItemCount() {
        return items.size();
    }

}






