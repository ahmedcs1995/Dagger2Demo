package com.mobileapp.krank.ResponseModels.DataModel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DealerGroupCompanyDataModel implements Parcelable {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("company_name")
    @Expose
    private String companyName;

    protected DealerGroupCompanyDataModel(Parcel in) {
        id = in.readString();
        profilePic = in.readString();
        companyName = in.readString();
    }

    public static final Creator<DealerGroupCompanyDataModel> CREATOR = new Creator<DealerGroupCompanyDataModel>() {
        @Override
        public DealerGroupCompanyDataModel createFromParcel(Parcel in) {
            return new DealerGroupCompanyDataModel(in);
        }

        @Override
        public DealerGroupCompanyDataModel[] newArray(int size) {
            return new DealerGroupCompanyDataModel[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(profilePic);
        parcel.writeString(companyName);
    }
}
