package com.mobileapp.krank.ResponseModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedDataResponse;

import java.util.List;

public class NewsFeedListResponse {
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("data")
    @Expose
    private NewsFeedDataResponse data = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public NewsFeedDataResponse getData() {
        return data;
    }

    public void setData(NewsFeedDataResponse data) {
        this.data = data;
    }
}
