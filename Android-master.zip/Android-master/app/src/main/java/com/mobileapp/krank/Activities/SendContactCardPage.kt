package com.mobileapp.krank.Activities

import android.os.Handler
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.DataModel.SendMessagePersonalChatResponseForExistingChat
import com.mobileapp.krank.ResponseModels.SendMessagePersonalChatResponse
import com.mobileapp.krank.ResponseModels.ConnectionResponse

import java.util.ArrayList

import cn.pedant.SweetAlert.SweetAlertDialog
import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.Utils.AnimationUtils
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.ConnectionViewHolderCircle
import com.mobileapp.krank.ViewHolders.UserViewHolderCheckBox
import kotlinx.android.synthetic.main.activity_send_contact_card_page.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.shimmer_loader_layout.*
import kotlinx.android.synthetic.main.toolbar_with_search.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SendContactCardPage : BaseActivity() {


    //adapters
    lateinit var peopleRecyclerAdapter: AppGeneralAdapter<ConnectionsDataModel>
    lateinit var selectedConnectionAdapter: AppGeneralAdapter<ConnectionsDataModel>


    //list
    lateinit var connectionsItems: MutableList<ConnectionsDataModel>
    lateinit var selectedConnection: MutableList<ConnectionsDataModel>


    //loader
    private lateinit var showProgressAlert: SweetAlertDialog

    private var msgCount: Int = 0


    //callbacks
    private lateinit var listCallBack: CallBackWithAdapterPosition
    private lateinit var removeCallBack: CallBackWithAdapterPosition

    //pagination
    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false

    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //typing events
    private var onTypingTimeout: Runnable? = null

    //api
    private var call: Call<ConnectionResponse>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_contact_card_page)


        setUpTypingTimeoutRunnable()

        msgCount = 0
        showProgressAlert = showAlert("Sending contact card please wait...", SweetAlertDialog.PROGRESS_TYPE, false)

        setNormalPageToolbar( "Send Contact")


        setUpRunnable()

        initCallBack()

        bindListeners()


        //views
        shimmer_view_container.startShimmer()
        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT
        no_item_found_view.visibility = View.GONE

        setUpChipAdapter()

        setUpList()

        getData()
    }
    private fun checkForData() {
        if (connectionsItems.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }

    private fun removeShimmerLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }

    private fun setUpRunnable() {
        runnable = Runnable {
            getData()
        }
    }

    private fun initCallBack() {
        listCallBack = CallBackWithAdapterPosition {
            if (!connectionsItems[it].isItemCheck) {


                //add
                selectedConnectionAdapter.add(connectionsItems[it])

                if (selectedConnection.size <= 1) {
                    people_chip_recycler.visibility = View.VISIBLE
                    showAdapter()

                }

                //focus
                if (selectedConnection.size > 1) {
                    people_chip_recycler.smoothScrollToPosition(selectedConnection.size - 1)
                }


            } else {
                //remove

                for (i in selectedConnection.indices) {
                    if (selectedConnection[i].companyData.userId == connectionsItems[it].companyData.userId) {
                        selectedConnectionAdapter.removeAt(i)
                        break
                    }
                }

                if (selectedConnection.size <= 0 && people_chip_recycler.visibility == View.VISIBLE) {
                    hideAdapter()

                }
            }

            connectionsItems[it].isItemCheck = !connectionsItems[it].isItemCheck
            peopleRecyclerAdapter.updateListItem(it)
        }


        removeCallBack = CallBackWithAdapterPosition {
            for (j in connectionsItems.indices) {
                if (connectionsItems[j].companyData.userId == selectedConnection[it].companyData.userId) {
                    connectionsItems[j].isItemCheck = !connectionsItems[j].isItemCheck
                    peopleRecyclerAdapter.updateListItem(j)
                    break
                }
            }
            selectedConnectionAdapter.removeAt(it)

            if (selectedConnection.size <= 0 && people_chip_recycler.visibility == View.VISIBLE) {
                hideAdapter()
            }

        }
    }

    private fun showAdapter() {
        // appUtils.expand(people_chip_recycler)
    }

    private fun hideAdapter() {
        //   appUtils.collapse(people_chip_recycler)
    }

    private fun bindListeners() {

        done_btn.setOnClickListener {
            if (selectedConnection.size > 0) {
                msgCount = selectedConnection.size
                showProgressAlert.show()
            }

            for (i in selectedConnection.indices) {
                if (selectedConnection[i].companyData.user_chat.size > 0) {
                    sendMessage(intent.getStringExtra("con_id"), "vcard", null, selectedConnection[i].companyData.userId, selectedConnection[i].companyData.user_chat[0].conversation_id)
                } else {
                    sendMessage(intent.getStringExtra("con_id"), "vcard", null, selectedConnection[i].companyData.userId, null)
                }
            }

        }

        search_btn.setOnClickListener {
            showKeyboard(search_box)
            AnimationUtils.circleReveal(search_container, 1, true, true, this@SendContactCardPage)
        }


        back_btn_search.setOnClickListener {
            AnimationUtils.circleReveal(search_container, 1, true, false, this@SendContactCardPage)
            hideFocusKeyboard()
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

        })

    }

    private fun removeLoader() {
        for (i in connectionsItems.indices.reversed()) {
            if (connectionsItems[i].type == Constants.LOADER_VIEW) {
                peopleRecyclerAdapter.removeAt(i)
                break
            }
        }
    }

    private fun setUpChipAdapter() {

        selectedConnection = ArrayList()

        selectedConnectionAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(selectedConnection) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                (viewHolder as ConnectionViewHolderCircle).onBind(item)
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.people_view_with_circle, parent, false)
                return ConnectionViewHolderCircle(v, removeCallBack)
            }

        }
        people_chip_recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        people_chip_recycler.adapter = selectedConnectionAdapter
    }

    private fun setUpList() {
        connectionsItems = ArrayList()

        peopleRecyclerAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(connectionsItems) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                if (viewHolder is UserViewHolderCheckBox) {
                    viewHolder.onBindConnections(item, appUtils)
                }

            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when (i) {
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                }
            }

            override fun getItemViewType(position: Int): Int {
                return connectionsItems[position].type
            }

        }
        my_connections_recycler_view.layoutManager = LinearLayoutManager(this@SendContactCardPage)
        my_connections_recycler_view.adapter = peopleRecyclerAdapter
        peopleRecyclerAdapter.setItemAnimator(my_connections_recycler_view)
        addOnScrollEndListener()
    }

    private fun addOnScrollEndListener() {
        my_connections_recycler_view.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }


    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }


    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {
            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            connectionsItems.clear()
            connectionsItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            peopleRecyclerAdapter.notifyDataSetChanged()

            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }

            //api data
            getData()
        }
    }


    private fun filterConnections(connectionsItems: List<ConnectionsDataModel>): MutableList<ConnectionsDataModel> {
        val filteredItems = ArrayList<ConnectionsDataModel>()
        /* for (i in connectionsItems.indices) {

             if (connectionsItems[i].companyData != null && connectionsItems[i].companyData.userId == intent.getStringExtra("con_id")) {
                 continue
             }


         }*/



        for (i in connectionsItems.indices) {
            if (connectionsItems[i].companyData != null && connectionsItems[i].companyData.userId == intent.getStringExtra("con_id")) {
                continue
            }

            /*set the selected item*/
            for (j in selectedConnection.indices) {
                if (connectionsItems[i].companyData.userId == selectedConnection[j].companyData.userId) {
                    connectionsItems[i].isItemCheck = true
                }
            }
            filteredItems.add(connectionsItems[i])
        }
        /*set the selected item*/

        return filteredItems
    }

    private fun getData() {
        call = api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", search_box.text.toString(), Constants.PAGE_LIMIT)
        if (call == null) return
        call?.enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {
                removeShimmerLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        //  showToast(response.body().message)
                    }
                } else {
                    //onResponseFailure()
                }

            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                removeShimmerLoader()
                //onResponseFailure()
            }
        })
    }

    private fun onSuccess(response: Response<ConnectionResponse>) {

        val tempList = filterConnections(response.body().data.connectionsData)

        removeLoader()

        /*for pagination*/
        if (response.body().data.connectionsData.size >= Constants.PAGE_LIMIT) {
            tempList.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /*for pagination*/

        peopleRecyclerAdapter.addAll(tempList)

        checkForData()
    }

    private fun sendMessage(msg: String, type: String, filePath: String?, conId: String, conv_id: String?) {
        val filePaths = ArrayList<String>()
        if (filePath != null) {
            filePaths.add(filePath)
        }
        if (conv_id == null) {
            api.chatStartConversation(preference.getString(Constants.ACCESS_TOKEN), conId, msg, type, filePaths, "").enqueue(object : Callback<SendMessagePersonalChatResponse> {
                override fun onResponse(call: Call<SendMessagePersonalChatResponse>, response: Response<SendMessagePersonalChatResponse>) {
                    if (response.isSuccessful) {

                        checkIsMessageIsDeliveredToAllConnections()
                    }
                }

                override fun onFailure(call: Call<SendMessagePersonalChatResponse>, t: Throwable) {

                }
            })
        } else {
            api.sendChatMsg(preference.getString(Constants.ACCESS_TOKEN), conv_id, msg, type, filePaths, "").enqueue(object : Callback<SendMessagePersonalChatResponseForExistingChat> {
                override fun onResponse(call: Call<SendMessagePersonalChatResponseForExistingChat>, response: Response<SendMessagePersonalChatResponseForExistingChat>) {
                    if (response.isSuccessful) {

                        checkIsMessageIsDeliveredToAllConnections()

                    }
                }

                override fun onFailure(call: Call<SendMessagePersonalChatResponseForExistingChat>, t: Throwable) {

                }
            })
        }
    }

    private fun checkIsMessageIsDeliveredToAllConnections() {
        msgCount--
        if (msgCount <= 0) {
            showToast("Contact card successfully sent")
            showProgressAlert.dismiss()
            finish()
            return
        }
    }


}
