package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.UploadImageResponse;
import com.steelkiwi.cropiwa.AspectRatio;
import com.steelkiwi.cropiwa.CropIwaView;
import com.steelkiwi.cropiwa.config.CropIwaSaveConfig;
import com.steelkiwi.cropiwa.shape.CropIwaOvalShape;
import com.steelkiwi.cropiwa.shape.CropIwaRectShape;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PictureAdjustmentActivity extends BaseActivity {


    Button saveBtn, cancel_btn;
    CropIwaView cropView;
    private String mediaPath;
    String cropImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture_adjustment);
        cropView = (CropIwaView) findViewById(R.id.crop_view);
        saveBtn = findViewById(R.id.save_btn);
        cancel_btn = findViewById(R.id.cancel_btn);


        String imgType = getIntent().getExtras().getString(Constants.IMAGE_TYPE);
        cropView.setImageUri(Uri.parse(getIntent().getExtras().getString("image")));
        switch (imgType) {
            case "UserImg":
                setUserImgVisualization();
                break;
            case "UserCoverImg":
                setCoverImgVisualization();
                break;
            case "CompanyImg":
                setCompanyImgVisualization();
                break;
            case "CompanyCoverImg":
                setCoverImgVisualization();
                break;

        }


        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cropImage();
            }
        });
        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
       cropView.setCropSaveCompleteListener(new CropIwaView.CropSaveCompleteListener() {
           @Override
           public void onCroppedRegionSaved(Uri bitmapUri) {
               cropImg = bitmapUri.toString();
               uploadImage(bitmapUri);
           }
       });
    }

    private void cropImage() {
        cropView.crop(new CropIwaSaveConfig.Builder(createNewEmptyFile())
                .setCompressFormat(Bitmap.CompressFormat.JPEG)
                .setQuality(100)
                .build());
    }
    public Uri createNewEmptyFile() {
        return Uri.fromFile(new File(
                this.getFilesDir(),
                System.currentTimeMillis() + ".jpg"));
    }

    private void setUserImgVisualization() {

        cropView.configureOverlay()
                .setCropShape(new CropIwaOvalShape(cropView.configureOverlay()))
                .setAspectRatio(new AspectRatio(1, 1))
                .apply();
    }

    private void setCoverImgVisualization() {
        cropView.configureOverlay()
                .setCropShape(new CropIwaRectShape(cropView.configureOverlay()))
                .setAspectRatio(new AspectRatio(5, 3))
                .apply();
    }

    private void setCompanyImgVisualization() {
        cropView.configureOverlay()
                .setCropShape(new CropIwaRectShape(cropView.configureOverlay()))
                .setAspectRatio(new AspectRatio(1, 1))
                .apply();
    }
    public void uploadImage(Uri bitmapUri) {
        String imgType = getIntent().getExtras().getString(Constants.IMAGE_TYPE);
        mediaPath = bitmapUri.toString();

        switch (imgType) {
            case "UserImg":
                uploadImageToServer("user-profile");
                break;
            case "UserCoverImg":
                uploadImageToServer("user-cover");
                break;
            case "CompanyImg":
                uploadImageToServer("company-profile");
                break;
            case "CompanyCoverImg":
                uploadImageToServer("company-cover");
                break;

        }
    }
    public void uploadImageToServer(final String userType) {
        File file = null;
        try {
            file = new File(new URI(mediaPath));
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }


        RequestBody requestBodyid = RequestBody.create(MediaType.parse("image/jpeg"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("upload_file", file.getName(), requestBodyid);

        getAPI().uploadProfileImage(preference.getString(Constants.ACCESS_TOKEN), userType, body).enqueue(new Callback<UploadImageResponse>() {
            @Override
            public void onResponse(Call<UploadImageResponse> call, Response<UploadImageResponse> response) {
                if (response.isSuccessful()) {
                    Log.e("pic upload","" + appUtils.convertToJson(response.body()));
                    Log.e("getappcont", "posts loaded from API");
                    Log.e("getappcont", response.body().getMessage());
                    Log.e("getappcont", response.body().getStatus());
                    Log.e("getappcont", response.body().getData().getFileName());


                    if (response.body().getStatus().equals("success")) {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        if (userType.equals("user-profile")) {
                            preference.setString(Constants.TEMP_USER_PROFILE_PICTURE, response.body().getData().getFileName());
                            preference.setString(Constants.PROFILE_PICTURE,response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                        }
                       else  if (userType.equals("user-cover")) {
                            preference.setString(Constants.COVER_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());

                        }
                       else  if (userType.equals("company-profile")) {
                            preference.setString(Constants.COMPANY_PROFILE_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                        }
                       else if (userType.equals("company-cover")) {
                            Log.e("company cover pic","" + response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                            preference.setString(Constants.COMPANY_COVER_PICTURE, response.body().getData().getFilePath().trim() +  response.body().getData().getFileName().trim());
                        }
                        Intent intent = new Intent();
                        intent.putExtra("crop_img",cropImg);
                        setResult(RESULT_OK, intent);
                        finish();
                    }

                } else {
                    int statusCode = response.code();
                    Log.e("getappcont", "posts loaded from API " + statusCode);

                    // handle request errors depending on status code
                }
            }

            @Override
            public void onFailure(Call<UploadImageResponse> call, Throwable t) {
                Log.e("getappcont", "error loading from API");
                Log.e("getappcont", t.getLocalizedMessage());

            }
        });
    }
}
