package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 6/1/2018.
 */

public class ProfileMenuUserData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("cover_pic")
    @Expose
    private String coverPic;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("company_name")
    @Expose
    private String companyName;

    @SerializedName("country_name")
    @Expose
    private String countryName;

    @SerializedName("country_code")
    @Expose
    private String country_code;

    @SerializedName("country_dial_code")
    @Expose
    private String country_dial_code;

    @SerializedName("city_name")
    @Expose
    private String cityName;

    @SerializedName("city_id")
    @Expose
    private String city_id;

    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    @SerializedName("company_size_name")
    @Expose
    private String companySizeName;
    @SerializedName("business")
    @Expose
    private String business;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("company_cover_pic")
    @Expose
    private String companyCoverPic;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("department")
    @Expose
    private String department;
    @SerializedName("department_name")
    @Expose
    private String departmentName;
    @SerializedName("job_title")
    @Expose
    private String jobTitle;
    @SerializedName("mobile_number")
    @Expose
    private String mobileNumber;

    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("verify_status")
    @Expose
    private String verify_status;

    @SerializedName("user_slug")
    @Expose
    private String user_slug;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoverPic() {
        return coverPic;
    }

    public void setCoverPic(String coverPic) {
        this.coverPic = coverPic;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public String getCompanySizeName() {
        return companySizeName;
    }

    public void setCompanySizeName(String companySizeName) {
        this.companySizeName = companySizeName;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCompany_profile_pic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getCompany_cover_pic() {
        return companyCoverPic;
    }

    public void setCompanyCoverPic(String companyCoverPic) {
        this.companyCoverPic = companyCoverPic;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getVerify_status() {
        return verify_status;
    }

    public void setVerify_status(String verify_status) {
        this.verify_status = verify_status;
    }

    public String getCity_id() {
        return city_id;
    }

    public void setCity_id(String city_id) {
        this.city_id = city_id;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCountry_dial_code() {
        return country_dial_code;
    }

    public void setCountry_dial_code(String country_dial_code) {
        this.country_dial_code = country_dial_code;
    }

    public String getUser_slug() {
        return user_slug;
    }

    public void setUser_slug(String user_slug) {
        this.user_slug = user_slug;
    }
}
