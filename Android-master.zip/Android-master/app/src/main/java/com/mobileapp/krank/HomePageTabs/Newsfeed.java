package com.mobileapp.krank.HomePageTabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.mobileapp.krank.Activities.ArticleDetail;
import com.mobileapp.krank.Activities.CommentsActivity;
import com.mobileapp.krank.Activities.CompanyProfileView;
import com.mobileapp.krank.Activities.CreatePost;
import com.mobileapp.krank.Activities.DiscoverPeople;
import com.mobileapp.krank.Activities.InAppWebViewCollapseActivity;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Activities.PersonalProfileSettings;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.Adapters.NewsFeedAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CallBacks.PhoneCodeAutoReadListener;
import com.mobileapp.krank.CallBacks.ResponseCallBacks;
import com.mobileapp.krank.CustomViews.FeedImageOverlayView;
import com.mobileapp.krank.Scroll.EndlessRecyclerViewScrollListener;
import com.mobileapp.krank.Scroll.HidingPageScrollListener;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.Dialogs.VerifyPopUpDialog;
import com.mobileapp.krank.Model.HomePageDataFlagContainer;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.NewsFeedListResponse;
import com.mobileapp.krank.Utils.FeedBottomSheet;
import com.mobileapp.krank.Utils.NewsFeed.NewsFeedUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ShareBottomSheet;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VerifyPhoneNumberViewHolder;
import com.mobileapp.krank.ViewModels.NewsFeedViewModel;
import com.stfalcon.frescoimageviewer.ImageViewer;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Ahmed on 4/13/2018.
 */

public class Newsfeed extends BaseFragment {


    private static final int SHOULD_APPEND_HORIZONTAL_LIST = 5;

    //for list items
    private RecyclerView newsFeedRecyclerView;
    private NewsFeedAdapter mFeedAdapter;
    public List<NewsFeedArray> feedList;
    public List<GetNetworkEmployeeData> suggestedPeoples;
    public List<NewsFeedArray> localDbFeedItems;
    LinearLayoutManager layoutManager;


    //pagination
    EndlessRecyclerViewScrollListener scrollListener;

    //for delay
    Handler handler;
    Runnable runnable;

    List<NewsFeedArray> tempItems;


    NewsFeedArray retryFeed;
    NewsFeedArray loaderFeed;
    NewsFeedArray suggestedConnections;

    //other
    public int clickIndex;
    String last_num;

    //for insert data in localDb
    boolean shouldUpdateData;


    //scroll flags
    boolean isItemAddedOnScroll;
    boolean isSwipeRefreshCall;
    boolean isScrollCall;

    //like comment Anim
    Animation myAnim;
    Animation commentShareAnim;


    //activity codes
    public static int CREATE_POST_ACTIVITY_CODE = 1;
    public static int COMMENT_ACTIVITY_CODE = 15;
    public static final int PRIVACY_ACTIVITY_CODE = 200;


    //view model
    public NewsFeedViewModel newsFeedViewModel;


    //views
    SwipeRefreshLayout swipeRefreshLayout;

    //utils
    SaveInSharedPreference preference;
    NewsFeedUtils newsFeedUtils;
    AppUtils appUtils;

    //flag container
    HomePageDataFlagContainer homePageDataFlagContainer;

    //savedInstanceState keys
    private static final String KEY_1 = "key_1";
    private static final String KEY_2 = "key_2";
    private static final String KEY_3 = "key_3";
    private static final String KEY_4 = "key_4";


    //bottom sheets
    FeedBottomSheet bottomSheetFragment;
    ShareBottomSheet shareBottomSheet;

    //code update Listener
    PhoneCodeAutoReadListener codeAutoReadListener;
    MainPage.PhoneNumberUpdateListener mPhoneNumberUpdateListener;

    //activity ref
    MainPage activityRef;



    public Newsfeed() {
        setTitle("Newsfeed");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.news_feed_page, container, false);
        setFragmentView(me);


        //data from activity
        initDataFromActivity();


        init(savedInstanceState);


        //view
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);

        //adapter
        setUpNewsFeedAdapter();


        if (!homePageDataFlagContainer.isDataLoaded()) {
            getNewsFeedData();
        }


        addOnSwipeRefreshListener();


        addOnScrollListener();


        return me;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void addOnSwipeRefreshListener() {
        swipeRefreshLayout.setOnRefreshListener(() -> {

            //reset scroll
            scrollListener.resetState();

            isSwipeRefreshCall = true;
            last_num = null;
            swipeRefreshLayout.setRefreshing(true);

            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
        });
    }

    private void addOnScrollListener() {


        scrollListener =  new EndlessRecyclerViewScrollListener(layoutManager) {
            @Override
            public void onLoadMore(int totalItemsCount, RecyclerView view) {
                if(isSwipeRefreshCall || last_num == null){
                    scrollListener.resetState();
                    return;
                }
                onScrollEnd();
            }

            @Override
            public void onHide() {
                activityRef.quick_access_fab.hideMenuButton(true);
            }
            @Override
            public void onShow() {
                activityRef.quick_access_fab.showMenuButton(true);
            }
        };

        newsFeedRecyclerView.addOnScrollListener(scrollListener);


    }

    private void onScrollEnd() {
        /*if (last_num != null && !isSwipeRefreshCall && !isScrollCall) {
            isScrollCall = true;
            if (!isItemAddedOnScroll) {
               // feedList.add(loaderFeed);
              //  mFeedAdapter.notifyItemInserted(feedList.size());
                isItemAddedOnScroll = true;
            }
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
        }*/
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    public void retryNewsFeedData() {
        last_num = feedList.get(feedList.size() - 2).getLast_num();
        isScrollCall = true;
        getNewsFeedData();
    }

    private void init(Bundle savedInstanceState) {

        //loader and retry
        retryFeed = new NewsFeedArray(Constants.RETRY_ITEM);
        loaderFeed = new NewsFeedArray(Constants.LOADER);
        suggestedConnections = new NewsFeedArray(Constants.SUGGESTED_CONNECTIONS);


        appUtils = AppUtils.getInstance();


        /*init data*/
        if (savedInstanceState == null || !homePageDataFlagContainer.isDataLoaded()) {
            isSwipeRefreshCall = false;
            isScrollCall = true;
            last_num = null;
            isItemAddedOnScroll = false;
            shouldUpdateData = true;
        } else {
            isSwipeRefreshCall = savedInstanceState.getBoolean(KEY_1, false);
            isScrollCall = savedInstanceState.getBoolean(KEY_2, false);
            last_num = savedInstanceState.getString(KEY_3);
            isItemAddedOnScroll = savedInstanceState.getBoolean(KEY_4, false);
            shouldUpdateData = false;
        }
        /*init data*/


        //for delay
        handler = new Handler();
        runnable = () -> getNewsFeedData();

        tempItems = new ArrayList<>();


        setLikeCommentAnimation();

        //share pop up
        shareBottomSheet = new ShareBottomSheet
                .Builder(Newsfeed.this, preference)
                .setListeners(getShareCallBack())
                .create();


        newsFeedUtils = NewsFeedUtils.getInstance();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);


        outState.putBoolean(KEY_1, isSwipeRefreshCall);
        outState.putBoolean(KEY_2, isScrollCall);
        outState.putString(KEY_3, last_num);
        outState.putBoolean(KEY_4, isItemAddedOnScroll);

    }

    private void setLikeCommentAnimation() {
        /*like comment button*/
        myAnim = AnimationUtils.loadAnimation(getContext(), R.anim.bounce);
        commentShareAnim = AnimationUtils.loadAnimation(getContext(), R.anim.bounce_for_comment_click);
        /*like comment button*/
    }

    /**
     * Spannable String data
     */
    public void setDataInModel(NewsFeedArray feed) {

        /*other than auto post*/
        if (feed.getPostType() == Constants.NETWORK_POST || feed.getPostType() == Constants.DEALER_POST || feed.getPostType() == Constants.KRANK_POST) {
            if (feed.getPostType() == Constants.KRANK_POST) {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, true, getContext()));
            } else {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, false, getContext()));
            }
        } else {
            feed.setHeaderSpannableString(newsFeedUtils.getSpannablePostHeader(feed, getContext(), preference));
        }
        if (feed.getPostType() == Constants.CHECK_IN) {
            feed.setCheckInAddress(newsFeedUtils.getSpannableCheckInAddress(feed.getTitle(), feed.getDescription(), feed.getTime_difference(), getContext()));
        }
        /*other than auto post*/


        /*setting dealer spannable*/
        feed.setDealerPostString(newsFeedUtils.getDealerPostSpannableString(feed, getContext(), preference));
        /*setting dealer spannable*/


    }

    /**
     * Horizontal Suggested Connections bottom Sheet
     */
    private void openBottomSheetFragment(int pos) {

        if (bottomSheetFragment == null) {
            bottomSheetFragment = new FeedBottomSheet();
        }
        bottomSheetFragment.show(getChildFragmentManager(), bottomSheetFragment.getTag());

        bottomSheetFragment.setManageViewClickListener(() -> {
            bottomSheetFragment.dismiss();
            Intent intent = new Intent(getContext(), DiscoverPeople.class);
            startActivity(intent);
        }, () -> {
            bottomSheetFragment.dismiss();
            if (feedList.get(pos).getPostType() == Constants.SUGGESTED_CONNECTIONS) {
                feedList.remove(pos);
                mFeedAdapter.notifyItemRemoved(pos);
            }

        });
    }


    /*
     * Adapter List items Add
     */
    private void insertIntoList(List<NewsFeedArray> data) {
        int lastListSize = feedList.size();
        feedList.addAll(data);


        if (!homePageDataFlagContainer.isDataLoaded() && data.size() >= SHOULD_APPEND_HORIZONTAL_LIST && suggestedPeoples.size() > 0) {
            feedList.add(3 + 4, suggestedConnections);
        }

        mFeedAdapter.notifyItemRangeInserted(lastListSize, feedList.size());

    }


    /*
     * Initialize Adapter
     */
    private void setUpNewsFeedAdapter() {
        newsFeedRecyclerView = (RecyclerView) findViewById(R.id.news_feed_recycler_view);
        //  newsFeedItems = new ArrayList<>();
        layoutManager = new LinearLayoutManager(getActivity());

        //init adapter
        mFeedAdapter = new NewsFeedAdapter(feedList, ((MainPage) getActivity()).getDeviceResolution(), this, preference, suggestedPeoples);

        //adapter Listeners
        mFeedAdapter.setListener((position, type, view) -> {
            switch (type) {
                case Constants.SHARE_CALLBACK:
                    newsFeedUtils.openDialog(feedList.get(position), feedList.get(position).getPostType() == Constants.LISTING_POST ? Constants.LISTING_SHARE : Constants.POST_SHARE, view, shareBottomSheet, commentShareAnim);
                    break;
                case Constants.LIKE_CALLBACK:
                    newsFeedUtils.sendLike(feedList.get(position), position, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(getContext(), R.anim.bounce),null);
                    break;
                case Constants.DELETE_CALLBACK:
                    newsFeedUtils.showDeletePopUpMenu(view, feedList.get(position), position, getContext(), preference);
                    break;
                case Constants.COMMENT_CALLBACK:
                    gotoCommentActivity(view, position);
                    break;
                case Constants.POST_CALLBACK:
                    NewsFeedArray feed = feedList.get(position);
                    if (feed.getPostType() == Constants.ARTICLE_POST) {
                        Intent articleIntent = new Intent(getContext(), ArticleDetail.class);
                        articleIntent.putExtra("article_id", feed.getPost_track_id());
                        startActivity(articleIntent);
                    } else if (feed.getPostType() == Constants.AUCTION_POST) {
                        Intent inAppWebViewIntent = new Intent(getContext(), InAppWebViewCollapseActivity.class);
                        inAppWebViewIntent.putExtra("feed_type", "auction");
                        inAppWebViewIntent.putExtra("web_view_url", appUtils.getUrlWithUid(feed.getShareUrl(), preference));
                        startActivity(inAppWebViewIntent);

                    } else if (feed.getPostType() == Constants.LINKED_POST) {
                        Intent linkWebViewIntent = new Intent(getContext(), InAppWebViewCollapseActivity.class);
                        linkWebViewIntent.putExtra("web_view_url", feed.getShareUrl());
                        startActivity(linkWebViewIntent);

                    } else if (feed.getPostType() == Constants.LISTING_POST) {
                        Intent listingDetailIntent = new Intent(getContext(), ListingDetail.class);
                        listingDetailIntent.putExtra("listing_id", "" + feed.getPost_track_id());
                        listingDetailIntent.putExtra("listing_pg_name", "" + feed.getHtmlParse().getTitle());
                        startActivity(listingDetailIntent);
                    }
                    break;
                case Constants.CREATE_POST_CALLBACK:
                    gotoCreatePost();
                    break;
                case Constants.INVITE_COMPANIES_CALLBACK:
                    if (preference.getString(Constants.INVITE_COMPANIES_URL).isEmpty()) {
                        return;
                    }
                    sendInvitationUrl();
                    break;
                case Constants.INVITE_CO_WORKER_CALLBACK:
                    if (preference.getString(Constants.INVITE_COMPANIES_URL).isEmpty()) {
                        return;
                    }
                    AppUtils.inviteCoWorkerInvite(preference, getContext());
                    break;
                case Constants.USER_PROFILE:
                    gotoUserProfile("" + feedList.get(position).getUser_id());
                    break;
                case Constants.REMOVE_SUGGESTED_CONNECTION_VIEW:
                    openBottomSheetFragment(position);
                    break;
                case Constants.COMPANY_PROFILE:
                    gotoCompanyProfile("" + feedList.get(position).getCompany_id());
                    break;
                case Constants.MY_COMPANY_PROFILE:
                    gotoCompanyProfile("" + preference.getString(Constants.MY_COMPANY_ID));
                    break;
                case Constants.CONNECT_COMPANY_PROFILE:
                    gotoCompanyProfile("" + feedList.get(position).getAutoPostHtml().getConnect_company_id());
                    break;
                case Constants.OWNER_USER_PROFILE:
                    gotoUserProfile("" + feedList.get(position).getOwner().getUser_id());
                    break;
                case Constants.POST_IMAGE_CALLBACK:
                    animateImage(feedList.get(position).getAsset(), feedList.get(position).getDescription(), feedList.get(position), position);
                    break;
            }

        });

        mFeedAdapter.setPhoneNumberListeners(new VerifyPhoneNumberViewHolder.PhoneNumberCallBack() {
            @Override
            public void act(int position, int type, @Nullable CustomCallBack callBack) {
                switch (type) {
                    case Constants.EDIT_PROFILE_CALL_BACK:
                        gotoEditProfile();
                        break;
                    case Constants.PHONE_VERIFY_CODE_CALLBACK:
                        if (feedList.get(position).getPhoneNumberVerificationState() == NewsFeedArray.ALREADY_IN_USE) {
                            gotoEditProfile();
                            return;
                        }
                        showVerifyPopUpDialog(position, callBack);
                        break;

                }
            }

            @Override
            public void verify(int position, int type, String code, @Nullable VerifyPhoneNumberViewHolder.OnCodeVerified callBack) {

                switch (type) {
                    case Constants.SEND_CODE_CALL_BACK:
                        onCodeVerify(position, code, callBack);
                        break;

                }

            }
        });

        newsFeedRecyclerView.setLayoutManager(layoutManager);
        newsFeedRecyclerView.setAdapter(mFeedAdapter);
        ((SimpleItemAnimator) newsFeedRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        if (!homePageDataFlagContainer.isDataLoaded()) {
            feedList.add(new NewsFeedArray(Constants.LOADER));
            mFeedAdapter.notifyItemInserted(feedList.size() - 1);
        }
    }

    private void gotoUserProfile(String userId) {
        Intent intent = new Intent(getContext(), UserProfileView.class);
        intent.putExtra(UserProfileView.INTENT_USER_ID, userId);
        startActivity(intent);
    }

    private void gotoCompanyProfile(String companyId) {
        Intent intent = new Intent(getContext(), CompanyProfileView.class);
        intent.putExtra(CompanyProfileView.INTENT_COMPANY_ID, companyId);
        startActivity(intent);
    }

    private void onCodeVerify(int position, String code, VerifyPhoneNumberViewHolder.OnCodeVerified callBack) {
        //api call
        verifyCellNumber(code, callBack, position);


        feedList.get(position).setPhoneCodeReceived(code);


        //keyboard
        if (activityRef != null) {
            activityRef.hideKeyBoard();
        }

    }

    /*
     * Personal Profile Settings
     */
    private void gotoEditProfile() {
        Intent profileSettingIntent = new Intent(getContext(), PersonalProfileSettings.class);
        profileSettingIntent.putExtra("user_id", preference.getString(Constants.USER_ID));
        getActivity().startActivityForResult(profileSettingIntent, MainPage.EDIT_PROFILE_CODE);
    }


    /*
     * show Phone Number Pop up
     */
    private void showVerifyPopUpDialog(final int position, CustomCallBack callBack) {

        VerifyPopUpDialog dialog = new VerifyPopUpDialog(getActivity(), new VerifyPopUpDialog.DialogClickListener() {
            @Override
            public void onConfirmClick(VerifyPopUpDialog dialog) {
                if (callBack == null) return;

                if (activityRef != null) {
                    activityRef.bindSmsListener();
                }

                //clears the old code
                feedList.get(position).setPhoneCodeReceived("");

                //api call
                verifyCellNumberCode(position, callBack);

            }

            @Override
            public void onEditClick(VerifyPopUpDialog dialog) {
                gotoEditProfile();

            }
        });

        //mobile number
        dialog.setPhoneNumber(preference.getString(Constants.MOBILE_NUMBER));
        dialog.show();

    }

    /*
     * Bottom Sheet Share CallBack
     */
    private CustomShareCallBack getShareCallBack() {
        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(getContext(), SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", appUtils.convertToJson(selectedPrivacy));
            intent.putExtra("selected_network_group", appUtils.convertToJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", appUtils.convertToJson(tempDealerGroup));
            startActivityForResult(intent, PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }


    /*
     * Updating Data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == CREATE_POST_ACTIVITY_CODE) {
                isSwipeRefreshCall = true;
                last_num = null;
                shouldUpdateData = true;
                swipeRefreshLayout.setRefreshing(true);
                handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
            } else if (requestCode == COMMENT_ACTIVITY_CODE) {
                feedList.get(clickIndex).setLike_count(data.getIntExtra("likeCount", 0));
                feedList.get(clickIndex).setIs_like(data.getIntExtra("isLike", 0));
                feedList.get(clickIndex).setComment_count(data.getIntExtra("commentCount", 0));
                newsFeedViewModel.updateLikeComment(feedList.get(clickIndex).getId(), feedList.get(clickIndex).getIs_like(), feedList.get(clickIndex).getLike_count(), feedList.get(clickIndex).getComment_count());

                if (feedList.get(clickIndex).getUpdateCommentCountForImageOverlay() != null) {
                    feedList.get(clickIndex).getUpdateCommentCountForImageOverlay().act();
                }
                mFeedAdapter.notifyItemChanged(clickIndex);
            } else if (requestCode == PRIVACY_ACTIVITY_CODE) {
                shareBottomSheet.updateDialogOnActivityResult(data);
            }
        }
    }

    private void updateOrAddPhoneNumberView() {
        if (feedList.size() > 1) {
            //if already present.. update

            activityRef.notRemovedThread = true;
            if (feedList.get(1).getPostType() == Constants.VERIFY_PHONE_NUMBER_VIEW) {
                //reset
                feedList.get(1).setPhoneNumber(preference.getString(Constants.MOBILE_NUMBER));
                feedList.get(1).setPhoneNumberVerificationState(NewsFeedArray.NOT_VERIFIED);


                //adapter
                mFeedAdapter.notifyItemChanged(1);

                //update cache
                updateVerifyPhoneNumberStatus("no");

            } else {
                //add phoneNumberView
                NewsFeedArray feedArray = new NewsFeedArray(Constants.VERIFY_PHONE_NUMBER_VIEW);
                feedArray.setPhoneNumber(preference.getString(Constants.MOBILE_NUMBER));

                feedList.add(1, feedArray);
                mFeedAdapter.notifyDataSetChanged();
            }
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        resetPhoneVerificationState();
    }

    private void resetPhoneVerificationState() {
        if (feedList.size() > 1) {
            if (feedList.get(1).getPostType() == Constants.VERIFY_PHONE_NUMBER_VIEW && feedList.get(1).getPhoneNumberVerificationState() == NewsFeedArray.UNDER_VERIFICATION) {
                feedList.get(1).setPhoneNumberVerificationState(NewsFeedArray.NOT_VERIFIED);
                feedList.get(1).setPhoneCodeReceived("");
                mFeedAdapter.notifyItemChanged(1);
            }
        }
    }

    private void updateVerifyPhoneNumberStatus(String status) {
        preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, status);
    }


    /**
     *
     * News Feed Response
     *
     *
     */
    private void onFeedResponse(Response<NewsFeedListResponse> response){

        /**
         * Scroll Listener
         * */
        scrollListener.resetState();




        tempItems.clear();
        tempItems.addAll(response.body().getData().getFeeds());



        /**
         *
         * horizontal suggested connections
         *
         * */
        if (!homePageDataFlagContainer.isDataLoaded() || isSwipeRefreshCall) {

            /*horizontal recycler*/
            suggestedPeoples.clear();
            suggestedPeoples.addAll(response.body().getData().getPumk());
            if (suggestedPeoples.size() > 0) {
                suggestedPeoples.add(new GetNetworkEmployeeData(GetNetworkEmployeeData.MANAGE_VIEW));
            }
            for (GetNetworkEmployeeData item : suggestedPeoples) {
                item.setStatus(Constants.CONNECTION_NOT_CONNECTED);
            }
            /*horizontal recycler*/


            //update nested adapter
            if (isSwipeRefreshCall) {
                mFeedAdapter.setUpdateInnerAdapter(true);
            }
        }
        /*horizontal suggested connections*/


        //pagination
        last_num = response.body().getData().getLast_num();

        setTypeFeed(last_num);


        /**
         *
         * local cache
         *
         * */
        if (shouldUpdateData) {
            newsFeedViewModel.deleteAll();
            newsFeedViewModel.bulkInsert(tempItems);
            //observeNewsFeed();
            shouldUpdateData = false;
        }
        /*local cache*/


        /**
         * Footer Loader
         * */
        if(tempItems.size() >= Constants.PAGE_LIMIT_1){
            tempItems.add(loaderFeed);
        }


        /**
         *
         * swipe refresh
         * */
        if (isSwipeRefreshCall) {

            //remove loader
            mFeedAdapter.removeLoader(false);

            /*clears the data*/

            //business email
            if (activityRef.isBussinessEmail()) {
                if (activityRef.isPhoneNumberVerified() && !activityRef.notRemovedThread) {
                    clearList(3);
                } else {
                    clearList(4);
                }
            }

            //free user
            else {
                if (activityRef.isPhoneNumberVerified()) {
                    clearList(2);
                } else {
                    clearList(3);
                }
            }
            /*clears the data*/


            feedList.addAll(tempItems);

            if (tempItems.size() >= SHOULD_APPEND_HORIZONTAL_LIST && suggestedPeoples.size() > 0) {
                feedList.add(3 + 4, suggestedConnections);
            }


            mFeedAdapter.notifyDataSetChanged();


            isScrollCall = false;
            isItemAddedOnScroll = false;
            isSwipeRefreshCall = false;
        }
        /*swipe refresh*/


        else {
            mFeedAdapter.removeLoader(false);
            insertIntoList(tempItems);
            isScrollCall = false;
            isItemAddedOnScroll = false;
        }
        swipeRefreshLayout.setRefreshing(false);

        homePageDataFlagContainer.setDataLoaded(true);
    }

    /*
     * Api Call From Repository
     */
    private void getNewsFeedData() {
        newsFeedViewModel.getmRepository().getNewsFeedData(((MainPage) getActivity()).preference.getString(Constants.ACCESS_TOKEN), last_num, new ResponseCallBacks<NewsFeedListResponse>() {

            @Override
            public void failure(@NotNull Call<NewsFeedListResponse> call, @NotNull Throwable t) {
                try {
                    onResponseFailure();
                } catch (Exception ex) {

                }
            }

            @Override
            public void failure(@NotNull Call<NewsFeedListResponse> call, @NotNull Response<NewsFeedListResponse> response) {
                try {
                    onResponseFailure();
                } catch (Exception ex) {

                }
            }

            @Override
            public void success(@NotNull Call<NewsFeedListResponse> call, @NotNull Response<NewsFeedListResponse> response) {

                try {
                    onFeedResponse(response);

                } catch (Exception ex) {
                    homePageDataFlagContainer.setDataLoaded(true);
                }
            }
        });

    }

    /*
     * Clear data
     */
    private void clearList(int initialIndex) {
        feedList.subList(initialIndex, feedList.size()).clear();
    }


    /*
     * Newsfeed Api data failure
     */
    private void onResponseFailure() {
        swipeRefreshLayout.setRefreshing(false);
        isSwipeRefreshCall = false;

        shouldUpdateData = false;


        if (!homePageDataFlagContainer.isDataLoaded()) {
            mFeedAdapter.removeLoader(false);

            int oldSize = feedList.size();
            feedList.addAll(localDbFeedItems);
            feedList.add(new NewsFeedArray(Constants.RETRY_ITEM));
            mFeedAdapter.notifyItemRangeInserted(oldSize, feedList.size());
        } else {
            mFeedAdapter.removeLoader(true);
        }


        homePageDataFlagContainer.setDataLoaded(true);
    }

    /**
     * Feed View Types
     */
    private void setTypeFeed(String last_num) {
        for (int i = 0; i < tempItems.size(); i++) {
            tempItems.get(i).setLast_num(last_num);
            tempItems.get(i).getNewsFeedType();
            //  newsFeedUtils.getNewsFeedType(tempItems.get(i));
            setDataInModel(tempItems.get(i));
        }
    }

    public void sendInvitationUrl() {
        AppUtils.inviteCompaniesAndCoWorkerInvite(preference, getContext());
    }


    public void gotoCreatePost() {
        Intent intent = new Intent(getContext(), CreatePost.class);
        startActivityForResult(intent, CREATE_POST_ACTIVITY_CODE);
        getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    public void focusToTop(CustomCallBack customCallBack) {

        if (layoutManager.findFirstCompletelyVisibleItemPosition() == 0) {
            customCallBack.act();
        } else {
            newsFeedRecyclerView.smoothScrollToPosition(0);
        }
    }

    public void scrollToTop() {
        newsFeedRecyclerView.smoothScrollToPosition(0);
    }

    /*
     * Data from Activity
     */
    private void initDataFromActivity() {
        activityRef = (MainPage) getActivity();

        //feed
        feedList = activityRef.newsFeedItems;

        //suggested
        suggestedPeoples = activityRef.suggestedPeoples;
        //data container
        homePageDataFlagContainer = activityRef.feedTabData;

        //local Db
        newsFeedViewModel = activityRef.newsFeedViewModel;
        localDbFeedItems = activityRef.localDbFeedItems;

        //preferences
        preference = activityRef.preference;

        //listener
        codeAutoReadListener = (code) -> {
            onCodeReceived(code);
        };
        mPhoneNumberUpdateListener = () -> {
            //update the phone Number
            updateOrAddPhoneNumberView();
        };


        activityRef.phoneCodeListener = codeAutoReadListener;
        activityRef.mPhoneNumberUpdateListener = mPhoneNumberUpdateListener;
    }


    private void onCodeReceived(String code) {
        if (mFeedAdapter == null || feedList == null || feedList.size() < 1)
            return;
        feedList.get(1).setPhoneCodeReceived(code);
        // feedList.get(1).setPhoneNumberVerificationState(NewsFeedArray.VERIFIED);
        mFeedAdapter.notifyItemChanged(1);

    }

    /*
     *Cell Number Code Api
     */
    private void verifyCellNumberCode(int position, CustomCallBack callBack) {
        newsFeedViewModel.getmRepository().verifyCellNumberCode(preference.getString(Constants.ACCESS_TOKEN), activityRef == null ? "" : activityRef.getAppSignature(), new ResponseCallBacks<GeneralResponse>() {
            @Override
            public void success(@NotNull Call<GeneralResponse> call, @NotNull Response<GeneralResponse> response) {

                //update adapter
                feedList.get(position).setPhoneNumberVerificationState(NewsFeedArray.UNDER_VERIFICATION);
                mFeedAdapter.notifyItemChanged(position);

                callBack.act();
            }

            @Override
            public void failure(@NotNull Call<GeneralResponse> call, @NotNull Response<GeneralResponse> response) {
                if (activityRef != null) {
                    activityRef.showToast(response.body().getMessage());
                }

            }

            @Override
            public void failure(@NotNull Call<GeneralResponse> call, @NotNull Throwable t) {
                if (activityRef != null) {
                    activityRef.onResponseFailure();
                }
            }
        });
    }

    /*
     * Send Cell Number Code
     */
    private void verifyCellNumber(String codeToSend, VerifyPhoneNumberViewHolder.OnCodeVerified callBack, int position) {
        newsFeedViewModel.getmRepository().sendCodeToServer(preference.getString(Constants.ACCESS_TOKEN), codeToSend, new ResponseCallBacks<GeneralResponse>() {

            @Override
            public void failure(@NotNull Call<GeneralResponse> call, @NotNull Throwable t) {
                callBack.onFailure();
                //  feedList.get(position).setPhoneNumberVerificationState(NewsFeedArray.VERIFICATION_FAILED);
                //  mFeedAdapter.notifyItemChanged(position);
            }

            @Override
            public void failure(@NotNull Call<GeneralResponse> call, @NotNull Response<GeneralResponse> response) {
                callBack.onFailure();
                //feedList.get(position).setPhoneNumberVerificationState(NewsFeedArray.VERIFICATION_FAILED);
                //mFeedAdapter.notifyItemChanged(position);
            }

            @Override
            public void success(@NotNull Call<GeneralResponse> call, @NotNull Response<GeneralResponse> response) {
                callBack.onSuccess();
                feedList.get(position).setPhoneNumberVerificationState(NewsFeedArray.VERIFIED);
                mFeedAdapter.notifyItemChanged(position);
                //update cache
                updateVerifyPhoneNumberStatus("yes");
            }
        });
    }

    private void animateImage(String imgPath, String description, NewsFeedArray item, final int position) {
        FeedImageOverlayView overlayView = new FeedImageOverlayView(getContext());
        String[] posters = new String[]{imgPath};
        new ImageViewer.Builder<>(getContext(), posters)
                .setOverlayView(overlayView)
                .setImageChangeListener(getImageChangeListener(description, item, position, overlayView))
                .show();
    }

    private ImageViewer.OnImageChangeListener getImageChangeListener(final String description, NewsFeedArray item, final int adapterPos, FeedImageOverlayView overlayView) {
        return position -> {
            // CustomImage image = images.get(position);
            overlayView.setDescription(description);
            overlayView.setNo_of_like("" + item.getLike_count());
            overlayView.setNo_of_comments("" + item.getComment_count());

            overlayView.setLikeEffect(item.getIs_like(), getContext());

            item.setUpdateCommentCountForImageOverlay(() -> {
                overlayView.setNo_of_comments("" + item.getComment_count());
                overlayView.setNo_of_like("" + item.getLike_count());
                overlayView.setLikeEffect(item.getIs_like(), getContext());
            });


            /**
             *
             *
             * Feed Like
             *
             * */
            overlayView.getLike_container().setOnClickListener(view -> {
                newsFeedUtils.sendLike(item, adapterPos, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(getContext(), R.anim.bounce),(isLike) -> {
                    overlayView.setLikeEffect(isLike, getContext());
                    overlayView.setNo_of_like("" + item.getLike_count());

                });

            });

            /**
             * Comments
             * */
            overlayView.getComment_container().setOnClickListener(view -> {
                gotoCommentActivity(overlayView.getComment_container(), adapterPos);
            });
        };
    }
    /**
     * Comments Page
     */
    private void gotoCommentActivity(View view, int position) {
        view.startAnimation(commentShareAnim);
        clickIndex = position;
        Intent intent = new Intent(getContext(), CommentsActivity.class);
        intent.putExtra("CommentDataObj", feedList.get(position));
        startActivityForResult(intent, COMMENT_ACTIVITY_CODE);
        getActivity().overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
    }

}
