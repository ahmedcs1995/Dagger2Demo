package com.mobileapp.krank.AccountSetupPages;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Activities.CustomDropDown.CityListActivity;
import com.mobileapp.krank.Activities.CustomDropDown.CountryListActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomViews.CustomViewPager.SwipeableViewPager;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.UpdateProfileRespose;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by Yaseen on 10/04/2018.
 */


public class AccountSetUpUserInfo extends BaseFragment implements AccountSetupPage.ProceedButtonListener {


    //fields
    private EditText job_edit_text, mobile_edit_text;

    //country city
    CountyListData selectedCountryData;
    CityListData selectedCityData;
    EditText city_text;
    EditText country_text;


    //text_view
    TextView error;
    TextView text_view_name;
    TextView mobile_code_edit_text;

    //activity code
    private static int COUNTRY_LIST_ACTIVITY_CODE = 100;
    private static int CITY_LIST_ACTIVITY_CODE = 200;


    //utils
    Gson gson;

    //activity ref
    AccountSetupPage accountSetupPage;


    public AccountSetUpUserInfo() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_four, container, false);
        setFragmentView(me);

        init();

        initViews();


        bindListeners();


        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));

        if (!(preference.getString(Constants.USER_COUNTRY_DATA).isEmpty())) {
            selectedCountryData = gson.fromJson(preference.getString(Constants.USER_COUNTRY_DATA), CountyListData.class);
            country_text.setText("" + selectedCountryData.getName());
            mobile_code_edit_text.setText("" + selectedCountryData.getPhoneCode());
        }
        if (!(preference.getString(Constants.USER_CITY_DATA).isEmpty())) {
            selectedCityData = gson.fromJson(preference.getString(Constants.USER_CITY_DATA), CityListData.class);
            city_text.setText("" + selectedCityData.getCityName());
        }

        return me;
    }


    private void bindListeners() {
        country_text.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), CountryListActivity.class);

            if (selectedCountryData != null) {
                intent.putExtra("countryData", gson.toJson(selectedCountryData));
            }
            startActivityForResult(intent, COUNTRY_LIST_ACTIVITY_CODE);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        city_text.setOnClickListener(view -> {
            if (selectedCountryData != null) {
                Intent intent = new Intent(getContext(), CityListActivity.class);
                intent.putExtra("countryData", gson.toJson(selectedCountryData));
                startActivityForResult(intent, CITY_LIST_ACTIVITY_CODE);
                getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            } else {
                Toast.makeText(getContext(), "Please Select Country", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String removeZero(String str) {
        // Count leading zeros
        int i = 0;
        while (str.charAt(i) == '0')
            i++;

        // Convert str into StringBuffer as Strings
        // are immutable.
        StringBuffer sb = new StringBuffer(str);

        // The  StringBuffer replace function removes
        // i characters from given index (0 here)
        sb.replace(0, i, "");

        return sb.toString();  // return in String
    }

    private void initViews() {
        text_view_name = (TextView) findViewById(R.id.text_view_name);
        city_text = (EditText) findViewById(R.id.city_text);
        job_edit_text = (EditText) findViewById(R.id.job_edit_text);
        mobile_edit_text = (EditText) findViewById(R.id.mobile_edit_text);
        mobile_code_edit_text = (TextView) findViewById(R.id.mobile_code_edit_text);
        error = (TextView) findViewById(R.id.error_view);
        country_text = (EditText) findViewById(R.id.country_text);

    }

    private void init() {
        selectedCountryData = null;
        selectedCityData = null;
        gson = CustomGson.getInstance();


        // get the activity
        accountSetupPage = ((AccountSetupPage) getActivity());


        preference = accountSetupPage.preference;

        accountSetupPage.setmUsernfoInfoProceedListener(this::onProceed);

    }


    private boolean isError() {
        final String job = job_edit_text.getText().toString().trim();
        String mobile = mobile_edit_text.getText().toString().trim();

        boolean isError = false;
        String errorMessage = "";
        if (job.isEmpty()) {
            errorMessage = Constants.ENTER_JOB_TITLE;
            isError = true;
        } else if (selectedCountryData == null) {
            errorMessage = Constants.SELECT_COUNTRY;
            isError = true;
        } else if (selectedCityData == null) {
            errorMessage = Constants.SELECT_CITY;
            isError = true;
        } else if (mobile.isEmpty()) {
            errorMessage = Constants.ENTER_MOBILE_NUM;
            isError = true;
        } else if (mobile.length() < Constants.NUMBER_OF_CHARACTERS_OF_PH_NUM  && !AppUtils.isValidMobileNumber(mobile)) {
            errorMessage = Constants.ENTER_VALID_MOBILE_NUM;
            isError = true;
        }
        error.setText(errorMessage);
        return isError;
    }


    private String getMobileNumber() {
        return selectedCountryData.getPhoneCode() + "-" + removeZero(mobile_edit_text.getText().toString().trim());
    }

    private void updateApiCall(ImageView nextBtn,int forceVerify) {


        if (isError()) return;
        nextBtn.setEnabled(false);
        accountSetupPage.getAPI().updateWizardProfile(preference.getString(Constants.ACCESS_TOKEN), job_edit_text.getText().toString().trim(), getMobileNumber(), selectedCountryData.getCode(), selectedCityData.getCityId(),forceVerify).enqueue(new Callback<UpdateProfileRespose>() {
            @Override
            public void onResponse(Call<UpdateProfileRespose> call, Response<UpdateProfileRespose> response) {
                nextBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        onSuccess();
                    }
                    else if(response.body().getStatus().toLowerCase().equals("warning")){
                        //show pop up
                        showWarningDialog(response.body().getTitle(),response.body().getMessage(),nextBtn);
                    }
                    else {
                        error.setText(response.body().getMessage());
                    }
                } else {
                    error.setText(Constants.ERROR_MSG_TOAST_1);
                }
            }

            @Override
            public void onFailure(Call<UpdateProfileRespose> call, Throwable t) {
                nextBtn.setEnabled(true);
                error.setText(Constants.ERROR_MSG_TOAST_1);

            }
        });

    }

    private void showWarningDialog(String title,String description,ImageView nextBtn){
        NormalAppDialog dialog = ((NormalAppDialog)DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG,getContext())).setHeading(title).setDescription(description).setConfirmButtonListener(dialog1 -> {
            updateApiCall(nextBtn,1);
        });
        dialog.show();
    }

    private void onSuccess() {
        updateCache();


        accountSetupPage.setPhoneNumber(getMobileNumber());


        if (accountSetupPage != null) {
            accountSetupPage.getListener().onNextPage();
        }
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void updateCache() {
        //clear the text
        error.setText("");

        //cache
        //city
        preference.setString(Constants.CITY, selectedCityData.getCityName());
        preference.setString(Constants.CITY_ID_KEY, selectedCityData.getCityId());

        //country
        preference.setString(Constants.COUNTRY, selectedCountryData.getName());
        preference.setString(Constants.COUNTRY_CODE, selectedCountryData.getCode());
        preference.setString(Constants.COUNTRY_DIAL_CODE, selectedCountryData.getPhoneCode());

        preference.setString(Constants.USER_COUNTRY_DATA, gson.toJson(selectedCountryData));
        preference.setString(Constants.USER_CITY_DATA, gson.toJson(selectedCityData));

        //other
        preference.setString(Constants.JOB_TITLE, job_edit_text.getText().toString().trim());

        //set flag for splash and wizard close
        preference.setString(Constants.MOBILE_NUMBER, getMobileNumber());
        preference.setString(Constants.IS_PHONE_NUMBER_ON_WIZARD_ENTERED,"yes");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COUNTRY_LIST_ACTIVITY_CODE) {
                selectedCountryData = gson.fromJson(data.getStringExtra("selectedCountry"), CountyListData.class);
                mobile_code_edit_text.setText(selectedCountryData.getPhoneCode());
                city_text.setText("");
                selectedCityData = null;
                country_text.setText("" + selectedCountryData.getName());
            } else if (requestCode == CITY_LIST_ACTIVITY_CODE) {
                selectedCityData = gson.fromJson(data.getStringExtra("cityData"), CityListData.class);
                city_text.setText("" + selectedCityData.getCityName());
            }

        }
    }

    @Override
    public void onProceed(SwipeableViewPager mViewPager, ImageView nextBtn) {
        updateApiCall(nextBtn,0);
    }



}