package com.mobileapp.krank.Chat;

import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Adapters.PagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChat;
import com.mobileapp.krank.Chat.PrivateChat.PersonalChat;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.NotificationMsgBadgeResponse;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatMainPage extends BaseActivity {

    private static int PAGE_OFF_SCREEN_LIMIT = 2;
    private Typeface mTypefaceBold;
    private Typeface mTypefaceNormal;
    TabLayout mCustomTabLayout;
    ViewPager mViewPager;
    private static int TAB_TEXT_SIZE = 15;
    Handler handler;
    Runnable runnable;
    TextView [] tabBadgeRef;
    TextView [] tabNameRef;
    private boolean isMsgCountShown;
    private boolean isGroupChatCountShown;
    private boolean exit;
    private static int SECONDS_TO_REFRESH = 2000;


    // fragments
    PersonalChat personalChat;
    GroupChat groupChat;

    PersonalChat.SendList sendList;

    private static final String TAG = ChatMainPage.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_main_page);
        isMsgCountShown = false;
        isGroupChatCountShown = false;
        exit = false;
        mTypefaceBold = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_BOLD);
        mTypefaceNormal = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_NORMAL);
        tabBadgeRef = new TextView[2];
        tabNameRef = new TextView[2];
        handler = new Handler();
        runnable = () -> updateTabBadgeCount();

        setNormalPageToolbar("Messaging");
        setSendListCallBack();
        setViewPagerAndTabLayout();

    }


    private void setSendListCallBack(){
        sendList = items -> {
            groupChat.personalChatConvoList(items);
        };
    }
    private void setViewPagerAndTabLayout() {
        mViewPager = findViewById(R.id.viewpager);
        mCustomTabLayout = findViewById(R.id.sliding_tabs);
        ArrayList<BaseFragment> pages = new ArrayList<>();




        personalChat = new PersonalChat();
        groupChat = new GroupChat();


        pages.add(personalChat);
        pages.add(groupChat);


        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));

        mCustomTabLayout.setupWithViewPager(mViewPager);

        mViewPager.setOffscreenPageLimit(pages.size());
        setInitialTabLayoutConfig();
        mCustomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
                tabNameRef[tab.getPosition()].setTypeface(mTypefaceBold);
                tabNameRef[tab.getPosition()].setTextColor(getResources().getColor(R.color.AppDarkGray));
                tabNameRef[tab.getPosition()].setTextSize(TAB_TEXT_SIZE);
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                tabNameRef[tab.getPosition()].setTypeface(mTypefaceNormal);
                tabNameRef[tab.getPosition()].setTextColor(getResources().getColor(R.color.drawerGray));
                tabNameRef[tab.getPosition()].setTextSize(TAB_TEXT_SIZE);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });
        updateTabBadgeCount();
    }
    private void setInitialTabLayoutConfig() {
        for (int i = 0; i < mCustomTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mCustomTabLayout.getTabAt(i);
            if (tab != null) {
                tab.setCustomView(R.layout.custom_tab_with_badge);

                tabBadgeRef[i] = tab.getCustomView().findViewById(R.id.badge);

                tabBadgeRef[i].setScaleX(0);
                tabBadgeRef[i].setScaleY(0);

                tabNameRef[i] = tab.getCustomView().findViewById(R.id.tab_name);

             //   TextView tabTextView = tab.getCustomView().findViewById(R.id.tab_name);
          /*      TextView tabTextView = new TextView(this);
                tab.setCustomView(tabTextView);*/

                tabNameRef[i].getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
                tabNameRef[i].getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;

                tabNameRef[i].setTypeface(mTypefaceNormal);
                tabNameRef[i].setTextSize(TAB_TEXT_SIZE);

                tabNameRef[i].setTextColor(getResources().getColor(R.color.drawerGray));
                tabNameRef[i].setText(tab.getText());

                // First tab is the selected tab, so if i==0 then set BOLD typeface
                if (i == 0) {
                    tabNameRef[i].setTypeface(mTypefaceBold);
                    tabNameRef[i].setTextColor(getResources().getColor(R.color.AppDarkGray));
                }

            }

        }
    }

    private void updateTabBadgeCount(){
        getAPI().notification_msg_badge(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<NotificationMsgBadgeResponse>() {
            @Override
            public void onResponse(Call<NotificationMsgBadgeResponse> call, Response<NotificationMsgBadgeResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getData().getChat_count().equals("0")) {
                        if (isMsgCountShown) {
                            isMsgCountShown = false;
                            tabBadgeRef[0].animate()
                                    .scaleY(0).scaleX(0)
                                    .setDuration(200)
                                    .start();
                        }
                    } else {
                        if (!isMsgCountShown) {
                            isMsgCountShown = true;
                            tabBadgeRef[0].animate()
                                    .scaleY(1).scaleX(1)
                                    .setDuration(200)
                                    .start();
                        }
                    }
                    if (response.body().getData().getGroup_count().equals("0")) {
                        if (isGroupChatCountShown) {
                            isGroupChatCountShown = false;
                            tabBadgeRef[1].animate()
                                    .scaleY(0).scaleX(0)
                                    .setDuration(200)
                                    .start();
                        }
                    } else {
                        if (!isGroupChatCountShown) {
                            isGroupChatCountShown = true;
                            tabBadgeRef[1].animate()
                                    .scaleY(1).scaleX(1)
                                    .setDuration(200)
                                    .start();
                        }
                    }
                    tabBadgeRef[0].setText("" + response.body().getData().getChat_count());
                    tabBadgeRef[1].setText("" + response.body().getData().getGroup_count());

                }
                if(!exit){
                    pull();
                }
            }

            @Override
            public void onFailure(Call<NotificationMsgBadgeResponse> call, Throwable t) {

                if(!exit){
                    pull();
                }
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        exit = false;
        updateTabBadgeCount();
    }

    private void pull(){
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }

    @Override
    public void onStop() {
        super.onStop();
        exit = true;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        exit = true;
    }

    public PersonalChat.SendList getSendList(){
        return sendList;
    }
}
