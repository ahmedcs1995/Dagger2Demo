package com.mobileapp.krank.Chat.GroupChatPakage;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.GroupChatMessagesAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Chat.AddPeopleInPrivateChat;
import com.mobileapp.krank.Chat.ChatUtils.ChatUtils;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.CustomViews.CustomFaView;
import com.mobileapp.krank.CustomViews.CustomReturn;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.Dao.GroupChatConversationDao;
import com.mobileapp.krank.Database.Dao.GroupChatListDao;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.MyViewModelFactory;
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.ChatImageUploadResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMessageModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMsgModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMessagesDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupConversationSendResponse;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.GroupChatMessagesResponse;
import com.mobileapp.krank.Utils.AnimationUtils;
import com.mobileapp.krank.ViewModels.GroupChatConversationViewModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GroupChatConversationActivity extends BaseActivity {
    private RecyclerView chatMessagesRecyclerView;
    private GroupChatMessagesAdapter chatMessagesRecyclerAdapter;
    List<GroupChatConversationMessageModel> chatMessagesItems;
    LinearLayoutManager layoutManager;
    View moreOptions;
    View collapseAbleHeader;
    View deleteClick;
    View addPeopleClick;
    View add_people_footer_btn;
    View loader;
    boolean iscollapseAbleHeaderVisible;

    private static int SECONDS_TO_REFRESH = 1000;
    public long lastMsgId;
    public long firstId;
    public long oldFirstId;


    View send_btn;
    View attachment_btn;
    View image_btn;
    View v_card_btn;
    EditText msg_box;

    private static int MAX_FILE_COUNT = 6;
    List<String> imagesPath;
    List<String> filesPath;

    private static final int V_CARD_PAGE_CODE = 500;

    private boolean exit;


    private int filesCount;
    private int conversationResponseCount;

    int firstVisibleItem, visibleItemCount, totalItemCount;
    private int visibleThreshold = 5;
    private int previousTotal = 0;
    private boolean loading = true;
    ArrayList<String> limit;
    private boolean isScrollCalled;
    //  private boolean isScrollCalled;

    private static String ASEC = "1";
    private static String DESC = "0";

    Handler handler;
    Runnable runnable;
    public SweetAlertDialog showProgressAlert;
    int lastMsgsSize;
    long lastMsgMIdForAppendMsgs;
    private GroupChatConversationViewModel groupChatConversationViewModel;

    boolean isFirstTimeInit;
    AppExecutors executors;

    long lastMsgTime;
    List<GroupChatConversationMessageModel> tempMsgs;


    boolean onFailureCall;


    private static String TEXT_MSG = "text";
    private static String CONTACT_CARD_MSG = "vcard";
    private static String ATTACHEMENT_MSG = "attachment";

    public boolean booleanisRetryClickAble;


    View leave_group_btn;
    View mute_chat_btn;
    View view_people_btn;
    private String member_notifications;
    private TextView mute_unmute_text;
    private CustomFaView mute_unmute_icon;

    View leave_group_text_view;
    View send_msg_view;

    boolean sendClick;
    boolean isFirstTimeInitRequest;
    String memberId;
    String groupId;
    String member_leave_on;
    boolean isGroupAdmin;




    List<GroupChatConversationMessageModel> newMsgs;


    GroupChatConversationMessageModel sendMsgInstance;
    GroupChatConversationGroupModel groupChatConversationGroupModel;

    public static String UN_MUTE_NOTIFICATIONS = "1";
    public static String MUTE_NOTIFICATIONS = "0";

    public static String MEMBER_EXISTS_TIME = "0000-00-00 00:00:00";
    public static String MEMBER_STATUS = "1";


    private static String MUTE_ICON = "&#xf0f3;";
    private static String UN_MUTE_ICON = "&#xf1f6;";

    boolean idInsertInParent;

    ChatUtils chatUtils;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat_conversation);

        if (getIntent().getStringExtra("recipient_name") != null) {
            setNormalPageToolbar( getIntent().getStringExtra("recipient_name"));
        }
        memberId = getIntent().getStringExtra("member_id");
        MyFirebaseMessagingService.CURRENT_MEMBER_ID = memberId;

        init();


        initViews();


        handleIntent();



        setUpChatMessages();



        chatMessagesRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                handleScroll();
            }
        });
    }

    private void handleIntent(){
        if(getIntent().getBooleanExtra("from_adapter",false)){
            member_notifications = getIntent().getStringExtra("member_notifications");
            member_leave_on = getIntent().getStringExtra("member_leave_on");
            member_notifications = getIntent().getStringExtra("member_notifications");
            groupId = getIntent().getStringExtra("group_id");
            isGroupAdmin = getIntent().getBooleanExtra("isGroupAdmin",false);

            muteUnMuteNotificationLabel();

            checkGroupLeave();

            setClickListener();

            checkCondition();

            isFirstTimeInitRequest = false;

        }
    }

    private void handleScroll() {
        visibleItemCount = chatMessagesRecyclerView.getChildCount();
        totalItemCount = layoutManager.getItemCount();
        firstVisibleItem = layoutManager.findFirstVisibleItemPosition();
        if (loading) {
            if (totalItemCount > previousTotal) {
                loading = false;
                previousTotal = totalItemCount;
            }
        }
        if (!loading && !isScrollCalled && (totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)) {
            isScrollCalled = true;
            limit.clear();
            //  limit.add(String.valueOf(chatMessagesItems.size()));
            //  limit.add("20");
            chatMessagesItems.add(new GroupChatConversationMessageModel(Constants.PROGRESS_BAR));
            chatMessagesRecyclerAdapter.notifyItemInserted(chatMessagesItems.size() - 1);
            Log.e("calling from scroll", "yes");
            getMessages("0", String.valueOf(firstId), limit, true, false);
            loading = true;
        }
    }

    private void initViews() {
        moreOptions = findViewById(R.id.more_options);
        collapseAbleHeader = findViewById(R.id.collpaseable_header);
        deleteClick = findViewById(R.id.delete_click);
        addPeopleClick = findViewById(R.id.add_people_click);
        send_btn = findViewById(R.id.send_btn);
        msg_box = findViewById(R.id.msg_box);
        attachment_btn = findViewById(R.id.attachment_btn);
        image_btn = findViewById(R.id.image_btn);
        v_card_btn = findViewById(R.id.v_card_btn);
        add_people_footer_btn = findViewById(R.id.add_people_footer_btn);
        leave_group_btn = findViewById(R.id.leave_group_btn);
        mute_chat_btn = findViewById(R.id.mute_chat_btn);
        view_people_btn = findViewById(R.id.view_people_btn);
        mute_unmute_text = findViewById(R.id.mute_unmute_text);
        leave_group_text_view = findViewById(R.id.leave_group_text_view);
        send_msg_view = findViewById(R.id.send_msg_view);
        loader = findViewById(R.id.loader);
        mute_unmute_icon = findViewById(R.id.mute_unmute_icon);
    }

    private void init() {
        chatUtils = new ChatUtils();
        imagesPath = new ArrayList<>();
        filesPath = new ArrayList<>();
        tempMsgs = new ArrayList<>();
        newMsgs = new ArrayList<>();
        newMsgs = new ArrayList<>();
        limit = new ArrayList<>();
        exit = false;
        booleanisRetryClickAble = true;
        sendClick = false;
        isGroupAdmin = false;
        onFailureCall = false;
        isFirstTimeInit = true;
        isFirstTimeInitRequest = true;
        member_notifications = null;
        filesCount = 0;
        showProgressAlert = showAlert(Constants.UPLOAD_FILES_MESSAGE, SweetAlertDialog.PROGRESS_TYPE, false);

        isScrollCalled = true;
        handler = new Handler();
        runnable = () -> getMessages(String.valueOf(lastMsgId), "0", limit, false, true);



        iscollapseAbleHeaderVisible = false;
        lastMsgId = -1;
        oldFirstId = 0;
        firstId = 0;

        groupChatConversationViewModel = ViewModelProviders.of(GroupChatConversationActivity.this, new MyViewModelFactory(this.getApplication(), memberId)).get(GroupChatConversationViewModel.class);


        executors = AppExecutors.getInstance();


    }

    private void setClickListener() {
        moreOptions.setOnClickListener(view -> {
            if (iscollapseAbleHeaderVisible) {
                AnimationUtils.collapse(collapseAbleHeader);
                chatMessagesRecyclerView.setAlpha(1);
                iscollapseAbleHeaderVisible = false;
                return;
            }
            AnimationUtils.expand(collapseAbleHeader);
            chatMessagesRecyclerView.setAlpha((float) 0.2);
            iscollapseAbleHeaderVisible = true;
        });
        deleteClick.setOnClickListener(view -> showDeleteDialogBox());
        addPeopleClick.setOnClickListener(view -> {
            Intent intent = new Intent(GroupChatConversationActivity.this, AddPeopleInPrivateChat.class);
            intent.putExtra("group_id", "" + groupId);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        add_people_footer_btn.setOnClickListener(view -> {
            Intent intent = new Intent(GroupChatConversationActivity.this, AddPeopleInPrivateChat.class);
            intent.putExtra("group_id", "" + groupId);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        send_btn.setOnClickListener(view -> {

            String msg = appUtils.replaceScriptString(msg_box.getText().toString());

            if (!(msg.trim().isEmpty()) && !(msg.equals(Constants.NBSP))) {
                sendClick = true;

                /*updating object*/
                sendMsgInstance.setReply(msg);
                sendMsgInstance.setTimeStamp(appUtils.getCurrentTimeStamp());
                sendMsgInstance.setVCardData(null);
                sendMsgInstance.setMsgAdded(appUtils.getcurrentUTCTime());
                sendMsgInstance.setSentTime("Just Now");
                sendMsgInstance.setMsgGroupId(Integer.parseInt(groupId));
                /*updating object*/


                executors.diskIO().execute(() -> {
                    long lastMsgMId = groupChatConversationViewModel.getDao().insert(sendMsgInstance);
                    sendMessage(msg, TEXT_MSG, null, lastMsgMId);
                });
                msg_box.setText("");
            }else{
                if(msg_box.getText().toString().length() > 0 && msg.trim().isEmpty()){
                    //means <script></script> entered
                    Toast.makeText(GroupChatConversationActivity.this,Constants.INVALID_INPUT,Toast.LENGTH_SHORT).show();
                    msg_box.setText("");
                }
            }
        });
        attachment_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickFile(GroupChatConversationActivity.this));

        image_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickPhoto(GroupChatConversationActivity.this));
        v_card_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), PrivateNewMessage.class);
            intent.putExtra("type", "visiting_card");
            intent.putExtra("page_title", "Send Card");
            startActivityForResult(intent, V_CARD_PAGE_CODE);
        });
        leave_group_btn.setOnClickListener(view -> {
            Log.e("leave group", "btn");
            leaveGroup();
        });
        mute_chat_btn.setOnClickListener(view -> muteNotification());
        view_people_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), PeopleListInGroupChat.class);
            intent.putExtra("member_id", "" + memberId);

            intent.putExtra("is_group_admin", isGroupAdmin);
            intent.putExtra("group_id", groupId);
            startActivity(intent);
        });

    }


    private void setUpChatMessages() {
        chatMessagesRecyclerView = (RecyclerView) findViewById(R.id.chat_messages_recycler_view);
        chatMessagesItems = new ArrayList<>();

        layoutManager = new LinearLayoutManager(GroupChatConversationActivity.this);

        layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        DeviceInfo deviceInfo = getDeviceResolution();
        chatMessagesRecyclerAdapter = new GroupChatMessagesAdapter(chatMessagesItems, this, deviceInfo);
        chatMessagesRecyclerView.setLayoutManager(layoutManager);
        chatMessagesRecyclerView.setAdapter(chatMessagesRecyclerAdapter);
        ((SimpleItemAnimator) chatMessagesRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

        handleChatMsgs();
    }


    private void observeMsgs() {
        groupChatConversationViewModel.getAllMsgs().observe(this, msgs -> {
            loader.setVisibility(View.GONE);
            if (isFirstTimeInit && msgs.size() > 0) {
                lastMsgsSize = chatMessagesItems.size();
                chatMessagesItems.addAll(msgs);
                if (onFailureCall) {
                    chatMessagesItems.add(new GroupChatConversationMessageModel(Constants.RETRY_BUTTON_CHAT));
                }
                chatMessagesRecyclerAdapter.notifyItemRangeInserted(lastMsgsSize, chatMessagesItems.size());


                lastMsgTime = msgs.get(0).getTimeStamp();
                lastMsgMIdForAppendMsgs = msgs.get(0).getMid();
                Log.e("lastMsgMIdForAppendMsgs", "=> " + lastMsgMIdForAppendMsgs);
                Log.e("lastMsgTime", "=> " + lastMsgTime);
                isFirstTimeInit = false;


              /*  try {
                    firstId = Long.parseLong(msgs.get(msgs.size() - 1).getUserId());
                } catch (NumberFormatException ex) {
                }*/

            } else {
                int index = -1;
                for (int i = 0; i < msgs.size(); i++) {
                    if (msgs.get(i).getTimeStamp() <= lastMsgTime) {
                        break;
                    }
                    index = i;
                }
                if (index != -1) {
                    appendElement(msgs.subList(0, index + 1));
                    lastMsgTime = msgs.get(0).getTimeStamp();
                    lastMsgMIdForAppendMsgs = msgs.get(0).getMid();
                    if (msgs.subList(0, index + 1).size() > 0) {
                        chatMessagesRecyclerView.scrollToPosition(0);
                    }
                }

                //status copy in UI
                int j = 0;
                while (j < msgs.size()) {
                    int k = 0;
                    boolean shouldIterate = true;
                    while (k < chatMessagesItems.size() && shouldIterate) {
                        if (chatMessagesItems.get(k).getMid() == msgs.get(j).getMid()) {
                            if (msgs.get(j).getMsgStatus() == Constants.STATUS_FAIL) {
                                chatMessagesItems.get(k).setMsgStatus(Constants.STATUS_FAIL);
                                chatMessagesRecyclerAdapter.notifyItemChanged(k);
                            }
                            shouldIterate = false;
                        }
                        k++;
                    }
                    j++;
                }
            }
        });
    }

    private void handleChatMsgs() {

        initSendMsgInstance();

        if (getIntent().getBooleanExtra("from_notification", false)) {
            groupChatConversationGroupModel = new GroupChatConversationGroupModel(Integer.parseInt(memberId));
            Log.e("memberId","in group Chat => " + memberId);
            new GetIdFromParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).groupchatConversationListDao()).execute(memberId);

        } else {
            limit.clear();
            getMessages("0", "0", limit, false, false);
        }
    }

    private void initSendMsgInstance(){
        sendMsgInstance = new GroupChatConversationMessageModel("",Constants.TEXT_RIGHT,Constants.STATUS_PENDING,memberId);
    }

    public void retryChatData() {
        isScrollCalled = true;
        getMessages("0", String.valueOf(firstId), limit, true, false);
    }

    private void showDeleteDialogBox() {
        CustomReturn customReturn = AppUtils.buildDialog(this, this, R.layout.delete_dialog_box);

        AlertDialog.Builder builder = customReturn.dialog;
        View v = customReturn.view;
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getMessages(String latest_id, String first_id, final ArrayList<String> limit, final boolean isScrollCalled, final boolean pullRequest) {
        getAPI().getGroupMsgs(preference.getString(Constants.ACCESS_TOKEN), memberId,first_id,latest_id, limit, DESC).enqueue(new Callback<GroupChatMessagesResponse>() {
            @Override
            public void onResponse(Call<GroupChatMessagesResponse> call, Response<GroupChatMessagesResponse> response) {

                // Log.e("call", "=> " + appUtils.convertToJson(call.request()));
                // Log.e("res", "=> " + appUtils.convertToJson(response.body().getData().getConvoMsgs()));

                if (response.isSuccessful()) {
                    if(response.body().getStatus().equals("success")){

                        /*updating the data for notifications and member Leave*/
                        if (member_notifications != null && !(member_notifications.equals(response.body().getData().getMemberData().getMemberNotifications()))) {
                            member_notifications = response.body().getData().getMemberData().getMemberNotifications();
                            muteUnMuteNotificationLabel();
                        }

                        if (member_leave_on != null && !(member_leave_on.equals(response.body().getData().getMemberData().getMemberLeaveOn()))) {
                            member_leave_on = response.body().getData().getMemberData().getMemberLeaveOn();
                            checkGroupLeave();
                        }
                        /*updating the data for notifications and member Leave*/

                        /*clear the old data and inset new Data*/
                        tempMsgs.clear();
                        tempMsgs.addAll(response.body().getData().getConvoMsgs());
                        /*clear the old data*/


                        /*block for updating msgs continuously*/
                        if (pullRequest) {
                            if (tempMsgs.size() > 0) {
                                // lastMsgId =Long.parseLong(tempMsgs.get(0).getMsgId());
                                // lastMsgId =Long.parseLong(tempMsgs.get(tempMsgs.size() - 1).getMsgId());
                                lastMsgId =tempMsgs.get(tempMsgs.size() - 1).getMsgId();
                                //  setMemberId();
                                //  Log.e("call", "" + appUtils.convertToJson(call.request()));
                                //   Log.e("temp Msgs", "" + appUtils.convertToJson(response.body()));
                                chatUtils.setGroupMessagesType(tempMsgs, true,memberId);
                                checkMsgAlreadyExists();
                            }
                        }
                        /*block for updating msgs continuously*/

                        else {

                            /*setting the toolbar*/
                            if (isFirstTimeInitRequest) {
                                if (getIntent().getStringExtra("recipient_name") == null) {
                                    setNormalPageToolbar(response.body().getData().getGroupData().getGroupName());
                                }
                                /*setting the toolbar*/

                                /*check if the person is group Admin*/
                                if (preference.getString(Constants.USER_ID).equals(response.body().getData().getUserDetail().getId())) {
                                    isGroupAdmin = true;
                                }
                                /*check if the person is group Admin*/

                                /*getting the group Data*/
                                groupId = response.body().getData().getGroupId();
                                member_notifications = response.body().getData().getMemberData().getMemberNotifications();
                                member_leave_on = response.body().getData().getMemberData().getMemberLeaveOn();
                                /*getting the group Data*/


                                /*bind listeners*/
                                setClickListener();
                                /*bind listeners*/

                                // checking conditions for group admin,member notifications...
                                checkCondition();

                                isFirstTimeInitRequest = false;
                            }

                            if (isScrollCalled) {
                                if (tempMsgs.size() <= 0) {
                                    GroupChatConversationActivity.this.isScrollCalled = true;
                                }
                            }

                            // block for Scroll Pagination and first time init Request
                            if (tempMsgs.size() > 0) {


                                // setting msgs type
                                chatUtils.setGroupMessagesType(tempMsgs, false,memberId);

                                //get the first id for pagination
                                //   firstId =  Long.parseLong(tempMsgs.get(tempMsgs.size() - 1).getMsgId());
                                firstId =  tempMsgs.get(tempMsgs.size() - 1).getMsgId();


                                /*block for first time init*/
                                if (isFirstTimeInit) {
                                    // get the last Msg Id for pulling
                                    //   lastMsgId =Long.parseLong(tempMsgs.get(0).getMsgId());
                                    lastMsgId =tempMsgs.get(0).getMsgId();

                                    performDbOperations(response.body().getData());


                                }
                                /*block for first time init*/

                                /*block for scroll pagination*/
                                else {
                                    // for scroll pagination
                                    lastMsgsSize = chatMessagesItems.size();
                                    chatMessagesItems.addAll(tempMsgs);
                                    removeProgressBar(false);
                                    chatMessagesRecyclerAdapter.notifyItemRangeInserted(lastMsgsSize, chatMessagesItems.size());
                                }
                                /*block for scroll pagination*/


                                if (tempMsgs.size() >= 20) {
                                    loading = false;
                                    GroupChatConversationActivity.this.isScrollCalled = false;
                                }
                            } else {
                                removeProgressBar(false);
                            }
                        }
                    }else{
                        Toast.makeText(GroupChatConversationActivity.this,response.body().getMessage(),Toast.LENGTH_SHORT).show();
                    }


                    if (!exit && !isScrollCalled) {
                        pull();
                    }
                }else{
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GroupChatMessagesResponse> call, Throwable t) {
                if (isFirstTimeInit) {
                    new getLastMsgId(groupChatConversationViewModel.getDao()).execute(memberId);
                    //   onFailureCall = true;
                    // observeMsgs();
                    return;
                }
                removeProgressBar(true);
                if (!exit && !isScrollCalled) {
                    pull();
                }
            }
        });
    }

    private void performDbOperations(GroupChatMessagesDataModel data){
        executors.diskIO().execute(() -> {
            if(idInsertInParent){
                groupChatConversationGroupModel.setGroupName(data.getGroupData().getGroupName());
                groupChatConversationGroupModel.setGroupId(Integer.parseInt(data.getGroupData().getGroupId()));
                groupChatConversationGroupModel.setMemberNotifications(data.getMemberData().getMemberNotifications());
                groupChatConversationGroupModel.setMemberLeaveOn(data.getMemberData().getMemberLeaveOn());
                groupChatConversationGroupModel.setMemberAddedBy(Integer.parseInt(data.getMemberData().getMemberAddedBy()));
                groupChatConversationGroupModel.setUnread_count("0");
                GroupChatConversationMsgModel groupChatConversationMsgModel = new GroupChatConversationMsgModel();
                //  GroupChatConversationMessageModel Lastmsg = data.getConvoMsgs().get(data.getConvoMsgs().size() - 1);
                //groupChatConversationMsgModel.setMsgType();
                groupChatConversationMsgModel.setMsgUpdated("");
                groupChatConversationGroupModel.setMsg(groupChatConversationMsgModel);
                //groupChatConversationGroupModel.setMsg(new GroupChatConversationMsgModel(data.getConvoMsgs().get(data.getConvoMsgs().size() -1).getReply()));
                KrankRoomDataBase.getDatabase(getApplicationContext()).groupchatConversationListDao().insert(groupChatConversationGroupModel);
                idInsertInParent = false;
            }

            groupChatConversationViewModel.getDao().deleteByMemberId(Integer.parseInt(memberId));
            groupChatConversationViewModel.getDao().bulkInsert(tempMsgs);
            observeMsgs();
        });
    }

    private void setMemberId(){
        for(int i=0;i<tempMsgs.size();i++){
            tempMsgs.get(i).setMember_id(memberId);
        }
    }
    private void muteUnMuteNotificationLabel() {
        if (member_notifications.equals(UN_MUTE_NOTIFICATIONS)) {
            mute_unmute_text.setText("Mute");
            mute_unmute_icon.setText(Html.fromHtml(MUTE_ICON));
        } else {
            mute_unmute_text.setText("UnMute");
            mute_unmute_icon.setText(Html.fromHtml(UN_MUTE_ICON));
        }
    }

    private void checkCondition() {


        checkGroupLeave();

        if (isGroupAdmin) {
            addPeopleClick.setVisibility(View.VISIBLE);
            add_people_footer_btn.setVisibility(View.VISIBLE);
            leave_group_btn.setVisibility(View.GONE);
        } else {
            addPeopleClick.setVisibility(View.GONE);
            add_people_footer_btn.setVisibility(View.GONE);
            if (!isMemberLeave()) {
                leave_group_btn.setVisibility(View.VISIBLE);
            }
        }
    }
    private boolean isMemberLeave() {
        if (member_leave_on.equals(MEMBER_EXISTS_TIME)) {
            return false;
        }
        return true;
    }

    private void checkGroupLeave() {
        if (isMemberLeave()) {
            leave_group_btn.setVisibility(View.GONE);

            leave_group_text_view.setVisibility(View.VISIBLE);
            send_msg_view.setVisibility(View.GONE);
            moreOptions.setVisibility(View.GONE);

        } else {
            leave_group_btn.setVisibility(View.VISIBLE);
            leave_group_text_view.setVisibility(View.GONE);
            send_msg_view.setVisibility(View.VISIBLE);
        }
    }


    private void checkMsgAlreadyExists() {
        List<GroupChatConversationMessageModel> newMsgs = new ArrayList<>();
        for (int i = 0; i < tempMsgs.size(); i++) {
            if (!(tempMsgs.get(i).getTypeOfMessage().equals(Constants.TEXT_RIGHT))) {
                newMsgs.add(tempMsgs.get(i));
            }
        }
        NewMsgBulkInsert(newMsgs);
    }

    private void setMsgsType(List<GroupChatConversationMessageModel> tempMsgs, boolean newMsgs) {
        for (GroupChatConversationMessageModel item : tempMsgs) {
            item.setMsgStatus(Constants.STATUS_SEND);
            if (newMsgs) {
                item.setTimeStamp(appUtils.getCurrentTimeStamp());
                //   Log.e("setting time_Stamp", "=> " + appUtils.getCurrentTimeStamp());
            } else {
                item.setTimeStamp(appUtils.getTimeStamp(item.getSentTime()));
                // Log.e("setting time_Stamp", "=> " + appUtils.getTimeStamp(item.getTime()));
            }

            if (item.getType().equals("text")) {
                if (item.getSentByme() == 1) {
                    item.setTypeOfMessage(Constants.TEXT_RIGHT);
                } else {
                    item.setTypeOfMessage(Constants.TEXT_LEFT);
                }
            } else if (item.getType().equals("attachment")) {
                if (item.getAttachment().getFileExt().equals("jpg") || item.getAttachment().getFileExt().equals("jpeg") || item.getAttachment().getFileExt().equals("png")) {
                    if (item.getSentByme() == 1) {
                        item.setTypeOfMessage(Constants.IMAGE_RIGHT);
                    } else {
                        item.setTypeOfMessage(Constants.IMAGE_LEFT);
                    }
                } else {
                    if (item.getSentByme() == 1) {
                        item.setTypeOfMessage(Constants.OTHER_ATTACHMENT_RIGHT);
                    } else {
                        item.setTypeOfMessage(Constants.OTHER_ATTACHMENT_LEFT);
                    }
                }
            } else if (item.getType().equals("vcard")) {
                if (item.getSentByme() == 1) {
                    item.setTypeOfMessage(Constants.V_CARD_RIGHT);
                } else {
                    item.setTypeOfMessage(Constants.V_CARD_LEFT);
                }
            } else if (item.getType().equals("system")) {
                item.setTypeOfMessage(Constants.SYSTEM_MESSAGE);
            } else {
                item.setTypeOfMessage(Constants.OTHER);
            }
        }
    }


    public void removeProgressBar(boolean retryIcon) {
        for (int i = (chatMessagesItems.size() - 1); i >= 0; i--) {

            if (chatMessagesItems.get(i).getTypeOfMessage().equals(Constants.PROGRESS_BAR)) {
                if (retryIcon) {
                    chatMessagesItems.get(i).setTypeOfMessage(Constants.RETRY_BUTTON_CHAT);
                    chatMessagesRecyclerAdapter.notifyItemChanged(i);
                } else {
                    chatMessagesItems.remove(i);
                    chatMessagesRecyclerAdapter.notifyItemRemoved(i);
                }
                break;
            }
        }
    }

    public void NewMsgBulkInsert(final List<GroupChatConversationMessageModel> msgs) {

        //   new NewMsgBulkInsertAsyncTask(groupChatConversationViewModel.getDao()).execute(msgs);
        groupChatConversationViewModel.newMsgBulkInsert(msgs);

    }




    private void appendElement(List<GroupChatConversationMessageModel> newMsgs) {

        for (int i = 0; i < newMsgs.size(); i++) {
            //  if (!(newMsgs.get(i).getTypeOfMessage() == TypeOfMessage.TEXT_RIGHT)) {
            chatMessagesItems.add(i, newMsgs.get(i));
            //   }
        }
        chatMessagesRecyclerAdapter.notifyItemRangeInserted(0, newMsgs.size());
        // chatMessagesRecyclerAdapter.notifyDataSetChanged();
    }


    private void pull() {
        exit = false;
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }

    @Override
    protected void onStop() {
        super.onStop();
        exit = true;
       /* if(memberId != null && fromLocalDb){
            executors.diskIO().execute(() -> {
                if (!isRecordUpdatedInParentTable) {
                    KrankRoomDataBase.getDatabase(getApplicationContext()).personalChatListDao().updateConvId(Integer.parseInt(memberId), Integer.parseInt(tempmemberId),Constants.FROM_LOCAL_DB_FALSE);
                    isRecordUpdatedInParentTable = true;
                }
            });
        }*/


        MyFirebaseMessagingService.CURRENT_MEMBER_ID = "-1";

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exit = true;
        MyFirebaseMessagingService.CURRENT_MEMBER_ID = "-1";
    }

    private void leaveGroup() {


        AnimationUtils.collapse(collapseAbleHeader);

        send_msg_view.setVisibility(View.GONE);
        leave_group_btn.setVisibility(View.GONE);
        leave_group_text_view.setVisibility(View.VISIBLE);

        send_msg_view.setVisibility(View.GONE);
        moreOptions.setVisibility(View.GONE);
        chatMessagesRecyclerView.setAlpha(1);
        iscollapseAbleHeaderVisible = false;



        getAPI().leaveGroup(preference.getString(Constants.ACCESS_TOKEN), memberId).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                    }
                }else{
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void muteNotification() {
        getAPI().muteNotificationGroupChat(preference.getString(Constants.ACCESS_TOKEN), memberId, member_notifications).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (member_notifications.equals("0")) {
                            member_notifications = "1";
                            mute_unmute_text.setText("Mute");
                            mute_unmute_icon.setText(Html.fromHtml(MUTE_ICON));
                            return;
                        }
                        member_notifications = "0";
                        mute_unmute_text.setText("UnMute");
                        mute_unmute_icon.setText(Html.fromHtml(UN_MUTE_ICON));
                    }
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });
    }

    private void sendMessage(String msg, String type, String filePath,final long lastMsgMid) {
        Log.e("into the", "send Msg");
        ArrayList<String> filePaths = new ArrayList<>();
        if (filePath != null) {
            filePaths.add(filePath);
        }
        getAPI().sendGroupChatMsg(preference.getString(Constants.ACCESS_TOKEN), groupId, memberId, msg, type, filePaths).enqueue(new Callback<GroupConversationSendResponse>() {
            @Override
            public void onResponse(Call<GroupConversationSendResponse> call, Response<GroupConversationSendResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (type.equals(TEXT_MSG)) {
                            response.body().getData().getMessage().setMsgStatus(Constants.STATUS_SEND);

                            Log.e("updateting_msg", "=> " + gson.toJson(response.body().getData()));

                            if (type.equals(TEXT_MSG)) {
                                groupChatConversationViewModel.updateMsgByMid(memberId, lastMsgMid, response.body().getData().getMessage());
                            }
                        }
                        if(type.equals(ATTACHEMENT_MSG)){
                            conversationResponseCount++;
                        }

                        if (conversationResponseCount == filesCount) {
                            conversationResponseCount = 0;
                            filesCount = 0;
                            hideLoader();
                        }
                    }
                    // PrivateChatConversationActivity.this.attachments.clear();
                }
            }

            @Override
            public void onFailure(Call<GroupConversationSendResponse> call, Throwable t) {

                if (type.equals(TEXT_MSG)) {
                    //  handler.postDelayed(() -> chatConversationListViewModel.updateMsgStatusByMid(conv_id, lastMsgMid, Constants.STATUS_FAIL), 1500);

                    groupChatConversationViewModel.updateMsgStatusByMid(memberId, lastMsgMid, Constants.STATUS_FAIL);
                }

            }
        });

    }

    public void reSendMessage(String msg, String type, String filePath,final long msgMid,int position) {
        Log.e("into the", "send Msg");
        ArrayList<String> filePaths = new ArrayList<>();
        if (filePath != null) {
            filePaths.add(filePath);
        }
        getAPI().sendGroupChatMsg(preference.getString(Constants.ACCESS_TOKEN), groupId, memberId, msg, type, filePaths).enqueue(new Callback<GroupConversationSendResponse>() {
            @Override
            public void onResponse(Call<GroupConversationSendResponse> call, Response<GroupConversationSendResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (type.equals(TEXT_MSG)) {
                            response.body().getData().getMessage().setMsgStatus(Constants.STATUS_SEND);
                            response.body().getData().getMessage().setTypeOfMessage(Constants.TEXT_RIGHT);
                            response.body().getData().getMessage().setMember_id(memberId);

                            groupChatConversationViewModel.deleteByMid(msgMid);
                            chatMessagesItems.remove(position);
                            chatMessagesRecyclerAdapter.notifyItemRemoved(position);
                            response.body().getData().getMessage().setTimeStamp(appUtils.getCurrentTimeStamp());

                            groupChatConversationViewModel.insert(response.body().getData().getMessage());

                            booleanisRetryClickAble = true;
                        }
                    }
                    // PrivateChatConversationActivity.this.attachments.clear();
                }
            }

            @Override
            public void onFailure(Call<GroupConversationSendResponse> call, Throwable t) {
                handler.postDelayed(() -> {
                    Toast.makeText(getApplicationContext(), "Message not sent...", Toast.LENGTH_SHORT).show();
                    chatMessagesItems.get(position).setMsgStatus(Constants.STATUS_FAIL);
                    chatMessagesRecyclerAdapter.notifyItemChanged(position);
                    booleanisRetryClickAble = true;
                }, 2000);

            }
        });

    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FilePickerConst.REQUEST_CODE_PHOTO:
                if (resultCode == RESULT_OK && data != null) {

                    imagesPath.clear();
                    imagesPath.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));
                    // Log.e("file paths", "" + appUtils.convertToJson(imagesPath));
                    //  filesCount = imagesPath.size();

                    for (String item : imagesPath) {
                        uploadFiles(item);
                    }
                    //uploadFiles(imagesPath);
                }
                break;
            case FilePickerConst.REQUEST_CODE_DOC:
                if (resultCode == RESULT_OK && data != null) {

                    filesPath.clear();
                    filesPath.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));


                    for (String item : filesPath) {
                        uploadFiles(item);
                    }
                    //  uploadFiles(filesPath);
                }
                break;
            case V_CARD_PAGE_CODE:
                if (data.getStringExtra("selected_data") != null && resultCode == RESULT_OK) {

                    ConnectionsDataModel connectionsDataModel = gson.fromJson(data.getStringExtra("selected_data"), ConnectionsDataModel.class);

                    /*sendMsgInstance.setReply(connectionsDataModel.getCompanyData().getUserId());
                    sendMsgVCard.setUserPic(connectionsDataModel.getCompanyData().getUserProfilePic());
                    sendMsgVCard.setCompanyProfilePic(connectionsDataModel.getCompanyData().getCompanyProfilePic());
                    sendMsgVCard.setFirstName(connectionsDataModel.getCompanyData().getFirstName());
                    sendMsgVCard.setLastName(connectionsDataModel.getCompanyData().getLastName());
                    sendMsgVCard.setCompanyId(connectionsDataModel.getCompanyData().getCompanyName());
                    sendMsgVCard.setDesignation(connectionsDataModel.getCompanyData().getJobTitle());
                    sendMsgVCard.setCity(connectionsDataModel.getCompanyData().getUserCityName());
                    sendMsgVCard.setCountry(connectionsDataModel.getCompanyData().getUserCountryName());
                    sendMsgInstance.setVCardData(sendMsgVCard);
                    executors.diskIO().execute(()->{
                        sendMsgInstance.setTimeStamp(getCurrentTimeStamp());
                        lastMsgMId = groupChatConversationViewModel.getDao().insert(sendMsgInstance);
                        sendMessage(connectionsDataModel.getCompanyData().getUserId(), "vcard", null,lastMsgMId);
                        executors.mainThread().execute(()-> msg_box.setText(""));
                    });*/
                    sendMessage(connectionsDataModel.getCompanyData().getUserId(), CONTACT_CARD_MSG, null, 0);
                }
                break;
        }
    }


    private void uploadFiles(String attachmentsToSend) {
        ArrayList<String> filePaths = new ArrayList<>();
        boolean isDataAdded=false;

        filePaths.add(attachmentsToSend);

        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);


        for (int i = 0; i < filePaths.size(); i++) {
            File file = new File(filePaths.get(i));
            Log.e("file.getName()","" + file.getName());
            // Log.e(TAG,"=> file size " + appUtils.getFileSize(file));
            if(appUtils.getFileSize(file) < Constants.MAX_FILE_SIZE && appUtils.getFileSize(file) > 0){
                isDataAdded = true;
                filesCount+=1;
                builder.addFormDataPart("upload_file[]", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
            }else{
                Toast.makeText(GroupChatConversationActivity.this,"Could Not upload file " + file.getName(),Toast.LENGTH_SHORT).show();
            }

        }

        if(!isDataAdded){
            return;
        }
        showLoader();

        MultipartBody requestBody = builder.build();


        getAPI().uploadChatImages(preference.getString(Constants.ACCESS_TOKEN), "chat-attachment", requestBody).enqueue(new Callback<ChatImageUploadResponse>() {
            @Override
            public void onResponse(Call<ChatImageUploadResponse> call, Response<ChatImageUploadResponse> response) {
                //  Log.e("on Success file", "attachment " + appUtils.convertToJson(response.body()));
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        //  attachments.clear();


                        //   Log.e("files count", "" + filesCount);
                        for (int i = 0; i < response.body().getData().getSuccess().size(); i++) {
                            //   attachments.add(response.body().getData().getSuccess().get(i).getFileName());
                            sendMessage("", ATTACHEMENT_MSG, response.body().getData().getSuccess().get(i).getFileName(), 0);
                        }
                    } else {
                        Toast.makeText(GroupChatConversationActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(GroupChatConversationActivity.this, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChatImageUploadResponse> call, Throwable t) {
                hideLoader();
                Toast.makeText(GroupChatConversationActivity.this, "Error while uploading files", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (isTaskRoot()) {
            appUtils.gotoHomePage(GroupChatConversationActivity.this);
            return;
        }
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
        overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
    }

    private void showLoader() {
        chatMessagesRecyclerView.setAlpha(0.2f);
        showProgressAlert.setContentText(Constants.UPLOAD_FILES_MESSAGE);
        showProgressAlert.show();
        msg_box.setEnabled(false);
    }

    private void hideLoader() {
        chatMessagesRecyclerView.setAlpha(1f);
        showProgressAlert.dismiss();
        msg_box.setEnabled(true);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //  Log.e("into", "onRestart");
        MyFirebaseMessagingService.CURRENT_MEMBER_ID = memberId;
        pull();
    }


    private class getLastMsgId extends AsyncTask<String, Integer, Integer> {

        private GroupChatConversationDao mAsyncTaskDao;

        getLastMsgId(GroupChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Integer doInBackground(final String... params) {
            return mAsyncTaskDao.getLatestMsgId(Integer.parseInt(params[0]));

        }

        @Override
        protected void onPostExecute(Integer longVal) {
            try {
                lastMsgId = longVal;
            }
            catch (NumberFormatException ex){

            }

            new getFirstMsgId(groupChatConversationViewModel.getDao()).execute(memberId);
        }
    }

    private class getFirstMsgId extends AsyncTask<String, Integer, Integer> {

        private GroupChatConversationDao mAsyncTaskDao;

        getFirstMsgId(GroupChatConversationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Integer doInBackground(final String... params) {
            return mAsyncTaskDao.getFirstMsgId(Integer.parseInt(params[0]));

        }

        @Override
        protected void onPostExecute(Integer longVal) {
            try {
                firstId = longVal;
            }
            catch (NumberFormatException ex){

            }

            onFailureCall = true;
            observeMsgs();
            removeProgressBar(true);
            if (!exit) {
                pull();
            }
        }
    }



    private class GetIdFromParentTable extends AsyncTask<String, Void, Integer> {

        private GroupChatListDao mAsyncTaskDao;

        GetIdFromParentTable(GroupChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Integer doInBackground(final String... params) {
            return mAsyncTaskDao.getIdOfParentTable(params[0]);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            if (integer == 0) {
                // record does not exists
                Log.e("parentId","=> "+ integer);
                // new InsertMemberIdInParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).groupchatConversationListDao()).execute();
                idInsertInParent = true;
            } /*else {
                getMessages("0", "0", limit, false, false);
            }*/
            getMessages("0", "0", limit, false, false);
        }
    }

    private class InsertMemberIdInParentTable extends AsyncTask<Void, Void, Void> {

        private GroupChatListDao mAsyncTaskDao;

        InsertMemberIdInParentTable(GroupChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Void... params) {
            //groupChatConversationGroupModel.(appUtils.getcurrentUTCTime());
            mAsyncTaskDao.insert(groupChatConversationGroupModel);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            getMessages("0", "0", limit, false, false);
        }
    }

}