package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Adapters.PagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.FirstPageFragments.PageOne;
import com.mobileapp.krank.FirstPageFragments.PageTwo;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;

import java.util.ArrayList;

public class FirstPage extends BaseActivity {

    Button iHaveAnAccountBtn;
    Button getStartedBtn;
    ViewPager mViewPager;
    TabLayout mTabLayout;

    //  ImageView krankLogo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mTabLayout = (TabLayout) findViewById(R.id.tab_dots);
        iHaveAnAccountBtn = (Button) findViewById(R.id.i_have_an_account_btn);
        getStartedBtn = (Button) findViewById(R.id.get_started_btn);
        // krankLogo =findViewById(R.id.krank_logo);
      //  setImageIntermsOfDeviceResolution();
        setKrankLogoForUserProfiling();

        DeviceInfo deviceInfo = getDeviceResolution();
        int heightOfImg = (int) ((deviceInfo.getDeviceHeight() / 2) / 4.8);
        //  krankLogo.getLayoutParams().height=heightOfImg;


        ArrayList<BaseFragment> pages = new ArrayList<>();
        pages.add(new PageOne());
        pages.add(new PageTwo());
        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.e("onPageScrolled", "" + position);
            }

            @Override
            public void onPageSelected(int position) {
                Log.e("onPageSelected", "" + position);
                //  setBackgroundImg(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        mTabLayout.setupWithViewPager(mViewPager);

        iHaveAnAccountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FirstPage.this, SignIn.class);
                startActivity(intent);
                // overridePendingTransition(R.anim.activity_open_translate,R.anim.activity_close_scale);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            }
        });
        getStartedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FirstPage.this, SignUp.class);
                startActivity(intent);
                //overridePendingTransition(R.anim.activity_open_translate,R.anim.activity_close_scale);
                //overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            }
        });
    }

 /*   @Override
    public void setImageIntermsOfDeviceResolution() {
        footerImg = findViewById(R.id.footer_img);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        if (height == 800) {
            footerImg.getLayoutParams().height = (int) (height * 0.12);
        } else {
            footerImg.getLayoutParams().height = (int) (height * 0.22);
        }
        footerImg.requestLayout();
        // return new DeviceInfo(width,height);
    }*/
}
