package com.mobileapp.krank.ResponseModels

import com.google.gson.annotations.SerializedName
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Model.Enums.ConNetStatus

data class ArticleDetailResponseModel (

        @SerializedName("status") val status : String,
        @SerializedName("message") val message : String,
        @SerializedName("data") val data : ArticleDetailDataModel
)

data class ArticleDetailDataModel (

        @SerializedName("page_title") val page_title : String,
        @SerializedName("page_meta_desc") val page_meta_desc : String,
        @SerializedName("og_image") val og_image : String,
        @SerializedName("isReported") val isReported : Boolean,
        @SerializedName("articleData") val articleData : ArticleData,
        @SerializedName("act") val act : Int
)

data class ArticleData (

        @SerializedName ("article_id") val article_id : Int,
        @SerializedName("article_name") val article_name : String,
        @SerializedName("article_slug") val article_slug : String,
        @SerializedName("article_text") var article_text : String,
        @SerializedName("article_added") val article_added : String,
        @SerializedName("article_updated") val article_updated : String,
        @SerializedName("article_image") val article_image : String,
        @SerializedName("article_user_id") val article_user_id : Int,
        @SerializedName("article_company_id") val article_company_id : Int,
        @SerializedName("article_privacy") val article_privacy : Int,
        @SerializedName("article_status") val article_status : Int,
        @SerializedName("article_views") val article_views : Int,
        @SerializedName("article_category_id") val article_category_id : Int,
        @SerializedName("is_blocked") val is_blocked : Int,
        @SerializedName("review_request") val review_request : Int,
        @SerializedName("user_id") val user_id : Int,
        @SerializedName("first_name") val first_name : String,
        @SerializedName("last_name") val last_name : String,
        @SerializedName("designation") val designation : String,
        @SerializedName("user_slug") val user_slug : String,
        @SerializedName("user_pic") val user_pic : String,
        @SerializedName("company_id") val company_id : Int,
        @SerializedName("company_name") val company_name : String,
        @SerializedName("company_slug") val company_slug : String,
        @SerializedName("company_pic") val company_pic : String,
        @SerializedName("categoryName") val categoryName : String,
        @SerializedName("country") val country : String,
        @SerializedName("city") val city : String,
        @SerializedName("user_url") val user_url : String,
        @SerializedName("company_url") val company_url : String,
        @SerializedName("networkStatus") val networkStatus : String,
        @SerializedName("conStatus") var conStatus : String,
        @SerializedName("likes") var likes : Int,
        @SerializedName("isLike") var isLike : Int,
        @SerializedName("article_url") var article_url : String

){
    var formattedDate: String? = null

    fun isLiked() : Boolean{
        return isLike == 1
    }


    fun isPublic() : Boolean{
        return article_privacy == 1
    }

    fun isConnectionConnected() : Boolean{
        return AppUtils.getConNetStatus(conStatus) == ConNetStatus.CONNECTED
    }
}






