package com.mobileapp.krank.ResponseModels.DataModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ConnectionDataModel {

    @SerializedName("connections_ids")
    @Expose
    private String connectionsIds;

    @SerializedName("reminderCount")
    @Expose
    private int reminderCount;

    @SerializedName("connections_data")
    @Expose
    private List<ConnectionsDataModel> connectionsData = null;

    public String getConnectionsIds() {
        return connectionsIds;
    }

    public void setConnectionsIds(String connectionsIds) {
        this.connectionsIds = connectionsIds;
    }

    public List<ConnectionsDataModel> getConnectionsData() {
        return connectionsData;
    }

    public void setConnectionsData(List<ConnectionsDataModel> connectionsData) {
        this.connectionsData = connectionsData;
    }

    public int getReminderCount() {
        return reminderCount;
    }

    public void setReminderCount(int reminderCount) {
        this.reminderCount = reminderCount;
    }
}
