package com.mobileapp.krank.Activities

import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ResponseModels.DealerListFromGroup
import com.mobileapp.krank.ResponseModels.NetworkListFromGroup
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.NetworkDealersInGroupViewHolder
import kotlinx.android.synthetic.main.activity_network_and_dealer_list_in_group.*
import kotlinx.android.synthetic.main.app_progress_bar.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
class NetworkAndDealerListInGroup : BaseActivity() {


    private lateinit var networkList: MutableList<NetworkList>
    private lateinit var dealerList: MutableList<NetworkDealersData>


    //adapters
    private lateinit var networkAdapter : AppGeneralAdapter<NetworkList>
    private lateinit var dealerAdapter : AppGeneralAdapter<NetworkDealersData>

    //pagination
    private var offset: Int = 0
    private var shouldScrollCall: Boolean = false

    //list callback
    private lateinit var listCallBack : CallBackWithAdapterPosition
    //delay
    private lateinit var handler: Handler
    private lateinit var runnable: Runnable


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network_and_dealer_list_in_group)


        setUpRunnable()


        setUpListCallBack()

        setNormalPageToolbar(intent.getStringExtra(PAGE_TITLE))
        if(getType() == NETWORK_LIST){
            setUpNetworkAdapter()
        }else{
            setUpDealerAdapter()
        }
    }
    private fun setUpRunnable() {
        handler = Handler()

        runnable = Runnable {
            if(getType() == NETWORK_LIST){
                getNetworkData()
            }else{
                getDealersData()
            }
        }
    }
    private fun getType() : Int{
        return intent.getIntExtra(PAGE_KEY,0)
    }

    private fun setUpListCallBack(){
        listCallBack = CallBackWithAdapterPosition{

            if(getType() == NETWORK_LIST){
                appUtils.gotoCompanyProfile(this@NetworkAndDealerListInGroup,networkList[it].companyId,preference)
            }else {
                appUtils.gotoCompanyProfile(this@NetworkAndDealerListInGroup,dealerList[it].companyId,preference)
            }
        }
    }


    private fun setUpNetworkAdapter(){
        networkList = ArrayList()

        networkAdapter = object : AppGeneralAdapter<NetworkList>(networkList){
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: NetworkList, position: Int) {
                if(viewHolder is NetworkDealersInGroupViewHolder){
                    viewHolder.onBind(item)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when(i){
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.network_dealer_list_in_group, parent, false)
                        NetworkDealersInGroupViewHolder(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.network_dealer_list_in_group, parent, false)
                        AppListItemLoader(v)
                    }

                }

            }

            override fun getItemViewType(position: Int): Int {
                return networkList[position].type
            }
        }
        group_list_recycler.layoutManager = LinearLayoutManager(this@NetworkAndDealerListInGroup)
        group_list_recycler.adapter = networkAdapter


        getNetworkData()

        addOnScrollEndListener()
    }
    private fun setUpDealerAdapter(){
        dealerList = ArrayList()

        dealerAdapter = object : AppGeneralAdapter<NetworkDealersData>(dealerList){
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: NetworkDealersData, position: Int) {
                if(viewHolder is NetworkDealersInGroupViewHolder){
                    viewHolder.onBind(item)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when(i){
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.network_dealer_list_in_group, parent, false)
                        NetworkDealersInGroupViewHolder(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }

                }

            }
            override fun getItemViewType(position: Int): Int {
                return dealerList[position].viewType
            }

        }
        group_list_recycler.layoutManager = LinearLayoutManager(this@NetworkAndDealerListInGroup)
        group_list_recycler.adapter = dealerAdapter

        getDealersData()
        addOnScrollEndListener()
    }

    private fun addOnScrollEndListener() {
        group_list_recycler.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCall) {
            shouldScrollCall = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }


    private fun getNetworkData(){
        api.getNetworkListFromGroup(preference.getString(Constants.ACCESS_TOKEN),intent.getStringExtra("id"), offset, Constants.PAGE_LIMIT).enqueue(object : Callback<NetworkListFromGroup> {
            override fun onResponse(call: Call<NetworkListFromGroup>, response: Response<NetworkListFromGroup>) {
                hideLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        var tempList = response.body().data

                        //remove loader
                        networkAdapter.removeLoader()


                        /*for pagination*/
                        if (tempList.size >= Constants.PAGE_LIMIT) {
                            tempList.add(NetworkList(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }
                        /*for pagination*/


                        networkAdapter.addAll(tempList)

                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }

            }

            override fun onFailure(call: Call<NetworkListFromGroup>, t: Throwable) {
                hideLoader()
                onResponseFailure()
            }
        })
    }
    private fun getDealersData(){
        api.getDealerListFromGroup(preference.getString(Constants.ACCESS_TOKEN), intent.getStringExtra("id"), offset, Constants.PAGE_LIMIT).enqueue(object : Callback<DealerListFromGroup> {
            override fun onResponse(call: Call<DealerListFromGroup>, response: Response<DealerListFromGroup>) {
                hideLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                        var tempList = response.body().data
                        dealerAdapter.removeLoader()
                        dealerAdapter.removeDealerListLoader(dealerList)


                        /*for pagination*/
                        if (tempList.size >= Constants.PAGE_LIMIT) {
                            tempList.add(NetworkDealersData(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }
                        /*for pagination*/


                        dealerAdapter.addAll(tempList)
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }

            }

            override fun onFailure(call: Call<DealerListFromGroup>, t: Throwable) {
                hideLoader()
                onResponseFailure()
            }
        })
    }


    private fun hideLoader(){
        loader.visibility = View.GONE
    }

    companion object {
        const val NETWORK_LIST = 1
        const val DEALER_LIST = 2
        const val PAGE_KEY = "page_key"
        const val PAGE_TITLE = "page_title"
    }
}
