package com.mobileapp.krank.Model;

public class SearchTabsDataModel {
    //start for pagination
    private int stP;

    private boolean isDataLoaded;
    private boolean isFirstTimeInit;
    private boolean scrollShouldCall;


    private String listingType;


    public SearchTabsDataModel(boolean isFirstTimeInit) {
        this.isFirstTimeInit = isFirstTimeInit;
    }

    public SearchTabsDataModel(int stP, boolean isDataLoaded, boolean isFirstTimeInit, boolean scrollShouldCall) {
        this.stP = stP;
        this.isDataLoaded = isDataLoaded;
        this.isFirstTimeInit = isFirstTimeInit;
        this.scrollShouldCall = scrollShouldCall;
    }

    public SearchTabsDataModel(int stP, boolean isDataLoaded, boolean isFirstTimeInit, boolean scrollShouldCall,String listingType) {
        this.stP = stP;
        this.isDataLoaded = isDataLoaded;
        this.isFirstTimeInit = isFirstTimeInit;
        this.scrollShouldCall = scrollShouldCall;
        this.listingType = listingType;
    }

    public int getStP() {
        return stP;
    }

    public void setStP(int stP) {
        this.stP = stP;
    }

    public boolean isDataLoaded() {
        return isDataLoaded;
    }

    public void setDataLoaded(boolean dataLoaded) {
        isDataLoaded = dataLoaded;
    }

    public boolean isFirstTimeInit() {
        return isFirstTimeInit;
    }

    public void setFirstTimeInit(boolean firstTimeInit) {
        isFirstTimeInit = firstTimeInit;
    }

    public boolean isScrollShouldCall() {
        return scrollShouldCall;
    }

    public void setScrollShouldCall(boolean scrollShouldCall) {
        this.scrollShouldCall = scrollShouldCall;
    }

    public String getListingType() {
        return listingType;
    }

    public void setListingType(String listingType) {
        this.listingType = listingType;
    }
}
