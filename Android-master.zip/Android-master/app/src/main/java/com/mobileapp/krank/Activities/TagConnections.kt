package com.mobileapp.krank.Activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition

import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.TagConnectionsNewsFeedPostDataModel
import com.mobileapp.krank.ResponseModels.TagConnectionNewsFeedPost
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.UserViewHolderCheckBox
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.tag_connection_drawer_main.*
import java.util.ArrayList
import java.util.Arrays
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TagConnections : BaseActivity() {
    private lateinit var tagConnectionsRecyclerAdapter: AppGeneralAdapter<TagConnectionsNewsFeedPostDataModel>
    internal lateinit var tagConnectionsItems: MutableList<TagConnectionsNewsFeedPostDataModel>
    internal lateinit var layoutManager: LinearLayoutManager



    private var privacyId: Int = 0
    private lateinit var callBack : CallBackWithAdapterPosition

    private val selectedTagConnections: List<TagConnectionsNewsFeedPostDataModel>

        get() {

            val tagged_connections = ArrayList<TagConnectionsNewsFeedPostDataModel>()
            for (item in tagConnectionsItems) {
                if (item.isItemChecked) {
                    tagged_connections.add(item)
                }
            }
            return tagged_connections
        }

    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //typing events
    private var onTypingTimeout: Runnable? = null


    var offset: Int = 0


    private var shouldScrollCalled: Boolean = false


    //groups ids
    var ngids = ArrayList<String>()
    var dgids = ArrayList<String>()
    var tagDataReceived : MutableList<TagConnectionsNewsFeedPostDataModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tag_connection_drawer_main)

        //loader
        shimmer_view_container.startShimmer()
        shimmer_view_container.visibility = View.VISIBLE

        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT

        setUpTypingTimeoutRunnable()

        getNetworkAndDealerGroupids()


        getSelectedConnections()


        runnable = Runnable {
            getTagConnections()
        }

        privacyId = intent.getIntExtra("privacyId", 1)


        setNormalPageToolbar( "Tag Connections")

        setUpCallBack()

        setUpTagConnectionsAdapter()

        getTagConnections()

        setUpListeners()
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {


            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            tagConnectionsItems.clear()
            tagConnectionsItems.add(TagConnectionsNewsFeedPostDataModel(Constants.LOADER_VIEW))
            tagConnectionsRecyclerAdapter.notifyDataSetChanged()


            //api data
            getTagConnections()

        }
    }

    private fun setUpCallBack(){
        callBack = CallBackWithAdapterPosition {
            tagConnectionsItems[it].isItemChecked = !tagConnectionsItems[it].isItemChecked
            tagConnectionsRecyclerAdapter.notifyItemChanged(it)

        }
    }

    private fun getNetworkAndDealerGroupids(){

        ngids.addAll(Arrays.asList(*gson.fromJson(intent.getStringExtra("Network_ids").toString(), Array<String>::class.java)))
        dgids.addAll(Arrays.asList(*gson.fromJson(intent.getStringExtra("Dealer_ids").toString(), Array<String>::class.java)))
    }

    private fun getSelectedConnections(){
        val dataReceived = intent.getStringExtra("selectedArray").toString()

        //back screen data
        tagDataReceived= Arrays.asList(*gson.fromJson(dataReceived, Array<TagConnectionsNewsFeedPostDataModel>::class.java))
    }

    private fun setUpListeners(){
        done_tagging_btn.setOnClickListener {
            val selectedTagConnections = selectedTagConnections

            if (selectedTagConnections.isNotEmpty()) {
                val intent = Intent()
                Log.e("tagged id", "" + appUtils.convertToJson(selectedTagConnections))
                intent.putExtra("taggedIds", "" + appUtils.convertToJson(selectedTagConnections))
                setResult(Activity.RESULT_OK, intent)
                finish()
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
            } else {
                Toast.makeText(this@TagConnections, "Please select Tag connections", Toast.LENGTH_SHORT).show()
            }
        }

        search_edit_text.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

            override fun afterTextChanged(editable: Editable) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }
        })
    }

    private fun setUpTagConnectionsAdapter() {
        tagConnectionsItems = ArrayList()
        layoutManager = LinearLayoutManager(this)

        tagConnectionsRecyclerAdapter = object : AppGeneralAdapter<TagConnectionsNewsFeedPostDataModel>(tagConnectionsItems){
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: TagConnectionsNewsFeedPostDataModel, position: Int) {
                if(item.viewType == Constants.ITEM_VIEW){
                    (viewHolder as UserViewHolderCheckBox).onBindTagConnections(item,appUtils)
                }

            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {

                var v : View
                return when (i){
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v,callBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v,callBack)
                    }
                }


            }

            override fun getItemViewType(position: Int): Int {
                return tagConnectionsItems[position].viewType
            }

        }

        tag_connections_recycler_view.layoutManager = layoutManager
        tag_connections_recycler_view.adapter = tagConnectionsRecyclerAdapter
        tagConnectionsRecyclerAdapter.setItemAnimator(tag_connections_recycler_view)
        addOnScrollEndListener()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    private fun getTagConnections() {
        api.getTagConnectionsNewsFeed(preference.getString(Constants.ACCESS_TOKEN), privacyId.toString(), ngids, dgids,offset,Constants.PAGE_LIMIT,search_edit_text.text.toString()).enqueue(object : Callback<TagConnectionNewsFeedPost> {
            override fun onResponse(call: Call<TagConnectionNewsFeedPost>, response: Response<TagConnectionNewsFeedPost>) {

                hideLoader()
                if(response.isSuccessful){
                    if(response.body().status == Constants.SUCCESS_STATUS){
                        onSuccess(response)
                    }else{
                       showToast(response.body().message)
                    }
                }else{
                   onResponseFailure()
                }
            }
            override fun onFailure(call: Call<TagConnectionNewsFeedPost>, t: Throwable) {
                hideLoader()
                onResponseFailure()
            }
        })
    }

    private fun addOnScrollEndListener() {
        tag_connections_recycler_view.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun removeLoader() {
        for (i in tagConnectionsItems.indices.reversed()) {
            if (tagConnectionsItems[i].viewType == Constants.LOADER_VIEW) {
                tagConnectionsItems.removeAt(i)
                tagConnectionsRecyclerAdapter.notifyItemRemoved(i)
                break
            }
        }
    }

    private fun onSuccess(response: Response<TagConnectionNewsFeedPost>){

        val tempList = response.body().data

        removeLoader()


        //for check mark
        for (i in tempList.indices) {
            for (j in tagDataReceived.indices) {
                if (tagDataReceived[j].userId == tempList[i].userId) {
                    tempList[i].isItemChecked = tagDataReceived[j].isItemChecked
                }
            }
        }
        tagConnectionsItems.addAll(tempList)


        /*for pagination*/
        if (response.body().data.size >= Constants.PAGE_LIMIT) {
            tagConnectionsItems.add(TagConnectionsNewsFeedPostDataModel(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /*for pagination*/


        tagConnectionsRecyclerAdapter.notifyItemRangeInserted(tagConnectionsItems.size - tempList.size,tagConnectionsItems.size)


        checkForData()
    }

    private fun hideLoader(){
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }
    private fun checkForData(){
        if (tagConnectionsItems.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
        }else{
            no_item_found_view.visibility = View.GONE
        }
    }
}
