package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;

public class InAppWebViewCollapseActivity extends BaseActivity {


    WebView webView;
    ProgressBar toolbar_loader;
    View share_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_web_view);

        webView = findViewById(R.id.webview);
        share_btn = findViewById(R.id.share_btn);
        toolbar_loader = findViewById(R.id.toolbar_loader);


        // webView.loadUrl(getIntent().getStringExtra("web_view_url"));


        String url = getIntent().getStringExtra("web_view_url");

        Log.e("url", url);
        setNormalPageToolbar( url);




        webView.getSettings().setAppCacheEnabled(false);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        if(fromExternalApp()){
            webView.loadUrl(getQueryStringUrl(url));
        }else{
            webView.loadUrl(url);
        }
        webView.getSettings().setJavaScriptEnabled(true);



        webView.setDownloadListener((url1, userAgent, contentDisposition, mimetype, contentLength) -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url1));
            startActivity(i);
        });

        // Set WebView client
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {

            public void onProgressChanged(WebView view, int progress) {
                    toolbar_loader.setProgress(progress);
                    if(progress == 100){
                        toolbar_loader.setVisibility(View.GONE);
                    }
                super.onProgressChanged(view, progress);

            }
        });

        share_btn.setOnClickListener(view -> {
            AppUtils.getInstance().showExternalSharePopUp(getIntent().getStringExtra("web_view_url"), InAppWebViewCollapseActivity.this);
        });
    }
    private boolean fromExternalApp(){
        return getIntent().getBooleanExtra("from_external_app",false);
    }
}
