package com.mobileapp.krank.Functions.Dialogs

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.Window

import com.mobileapp.krank.R

class FollowPeopleDialog(context: Context) : Dialog(context), View.OnClickListener {

    //listener
    internal var listener: DialogClickListener? = null
    var dialog: Dialog? = null


    //views
    private lateinit var get_started_btn: View
    private lateinit var close_btn: View


    private lateinit var dont_ask_me_btn: View
    private lateinit var view3: View

    //interface
    interface DialogClickListener {
        fun onGetStartedClick(dialog: Dialog)
        fun onDontAskMeClick(dialog: Dialog)
        fun onCloseClick(dialog: Dialog)
    }

    fun setListener(listener: DialogClickListener) {
        this.listener = listener
    }

    private var showDontAskButton : Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.follow_people_pop_up)

        setCancelable(false)
        //init views
        get_started_btn = findViewById(R.id.get_started_btn)
        // learn_more_btn = findViewById(R.id.learn_more_btn);
        close_btn = findViewById(R.id.close_btn)

        dont_ask_me_btn = findViewById(R.id.dont_ask_me_btn)
        view3 = findViewById(R.id.view3)




        //listeners
        get_started_btn.setOnClickListener(this)
        //  learn_more_btn.setOnClickListener(this);
        close_btn.setOnClickListener(this)
        dont_ask_me_btn.setOnClickListener(this)


         if(!showDontAskButton){
             hideDontAskMeView()
         }

    }

    private fun hideDontAskMeView() {
        viewVisibility(View.GONE,dont_ask_me_btn)
        viewVisibility(View.GONE,view3)
    }

    fun setShowDontAskButton(enable : Boolean): FollowPeopleDialog {
        showDontAskButton = enable
        return this
    }

    private fun viewVisibility(visibility: Int, view: View) {
        view.visibility = visibility
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.get_started_btn -> if (listener != null) {
                listener?.onGetStartedClick(this@FollowPeopleDialog)
            }
            R.id.close_btn -> if (listener != null) {
                listener?.onCloseClick(this@FollowPeopleDialog)
            }
            R.id.dont_ask_me_btn -> if (listener != null) {
                listener?.onDontAskMeClick(this@FollowPeopleDialog)
            }
            else -> {
            }
        }
        dismiss()
    }

}
