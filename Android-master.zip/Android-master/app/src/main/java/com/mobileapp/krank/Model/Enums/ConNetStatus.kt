package com.mobileapp.krank.Model.Enums

enum class ConNetStatus{
    CONNECTED,
    NOT_CONNECTED,
    REQUEST_PENDING,
    INVITATION_RECEIVED,
    SEND_INVITE_MESSAGE,
    NONE
}