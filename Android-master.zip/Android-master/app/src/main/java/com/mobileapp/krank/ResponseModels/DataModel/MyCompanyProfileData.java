package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 6/8/2018.
 */

public class MyCompanyProfileData {


    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("company_hash")
    @Expose
    private String companyHash;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("business")
    @Expose
    private String business;
    @SerializedName("currency_id")
    @Expose
    private String currencyId;
    @SerializedName("currency_name")
    @Expose
    private String currencyName;
    @SerializedName("zip_code")
    @Expose
    private String zipCode;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("package_id")
    @Expose
    private String packageId;
    @SerializedName("payment_status")
    @Expose
    private Object paymentStatus;
    @SerializedName("is_public")
    @Expose
    private String isPublic;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("cover_pic")
    @Expose
    private String coverPic;
    @SerializedName("cover_setting")
    @Expose
    private String coverSetting;
    @SerializedName("telephone_number")
    @Expose
    private String telephoneNumber;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    @SerializedName("company_size_name")
    @Expose
    private String companySizeName;
    @SerializedName("company_bio")
    @Expose
    private String companyBio;
    @SerializedName("company_latlng")
    @Expose
    private Object companyLatlng;
    @SerializedName("city_id")
    @Expose
    private String cityId;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("country_code")
    @Expose
    private String countryCode;
    @SerializedName("country_name")
    @Expose
    private Object countryName;
    @SerializedName("user")
    @Expose
    private Object user;

    @SerializedName("dialing_code")
    @Expose
    private String dialing_code;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyHash() {
        return companyHash;
    }

    public void setCompanyHash(String companyHash) {
        this.companyHash = companyHash;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public Object getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(Object paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getIsPublic() {
        return isPublic;
    }

    public void setIsPublic(String isPublic) {
        this.isPublic = isPublic;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getCoverPic() {
        return coverPic;
    }

    public void setCoverPic(String coverPic) {
        this.coverPic = coverPic;
    }

    public String getCoverSetting() {
        return coverSetting;
    }

    public void setCoverSetting(String coverSetting) {
        this.coverSetting = coverSetting;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public String getCompanySizeName() {
        return companySizeName;
    }

    public void setCompanySizeName(String companySizeName) {
        this.companySizeName = companySizeName;
    }

    public String getCompanyBio() {
        return companyBio;
    }

    public void setCompanyBio(String companyBio) {
        this.companyBio = companyBio;
    }

    public Object getCompanyLatlng() {
        return companyLatlng;
    }

    public void setCompanyLatlng(Object companyLatlng) {
        this.companyLatlng = companyLatlng;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Object getCountryName() {
        return countryName;
    }

    public void setCountryName(Object countryName) {
        this.countryName = countryName;
    }

    public Object getUser() {
        return user;
    }

    public void setUser(Object user) {
        this.user = user;
    }

    public String getDialing_code() {
        return dialing_code;
    }

    public void setDialing_code(String dialing_code) {
        this.dialing_code = dialing_code;
    }
}
