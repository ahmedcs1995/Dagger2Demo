package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CompanyInvitationDataModel {
    @SerializedName("text")
    @Expose
    private String text;

    @SerializedName("user_name")
    @Expose
    private String user_name;

    @SerializedName("company_name")
    @Expose
    private String company_name;

    @SerializedName("code")
    @Expose
    private String code;

    @SerializedName("user_id")
    @Expose
    private int user_id;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getCod() {
        return code;
    }

    public void setCod(String cod) {
        this.code = cod;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
