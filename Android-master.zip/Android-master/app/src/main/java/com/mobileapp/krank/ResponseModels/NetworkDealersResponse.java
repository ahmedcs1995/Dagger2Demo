package com.mobileapp.krank.ResponseModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersDataModelResponse;

import java.util.List;

/**
 * Created by arbaz on 6/12/2018.
 */

public class NetworkDealersResponse {

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private NetworkDealersDataModelResponse data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }



    public NetworkDealersDataModelResponse getData() {
        return data;
    }

    public void setData(NetworkDealersDataModelResponse data) {
        this.data = data;
    }
}
