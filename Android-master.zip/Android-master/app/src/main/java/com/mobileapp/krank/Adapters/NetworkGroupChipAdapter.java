package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkGroupDataModel;

import java.util.ArrayList;
import java.util.List;

public class NetworkGroupChipAdapter extends RecyclerView.Adapter<NetworkGroupChipAdapter.ViewHolder>  {
    private List<NetworkGroupDataModel> items;
    private ArrayList<NetworkGroupDataModel> tempItems;
    Context context;
    TextView label;
    View container;

    CustomCallBack customCallBack;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View cancelBtn;
        TextView name;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            cancelBtn=itemView.findViewById(R.id.cancel_btn);
            name=itemView.findViewById(R.id.name);
        }
    }

    public NetworkGroupChipAdapter(List<NetworkGroupDataModel> items, Context context, TextView label, View container) {
        this.items = items;
        this.context = context;
        this.label = label;
        this.container = container;
    }
    public NetworkGroupChipAdapter(List<NetworkGroupDataModel> items,ArrayList<NetworkGroupDataModel> tempItems, Context context, TextView label, View container) {
        this.items = items;
        this.tempItems = tempItems;
        this.context = context;
        this.label = label;
        this.container = container;
    }

    public NetworkGroupChipAdapter(List<NetworkGroupDataModel> items,ArrayList<NetworkGroupDataModel> tempItems, Context context, TextView label, View container,CustomCallBack customCallBack) {
        this.items = items;
        this.tempItems = tempItems;
        this.context = context;
        this.label = label;
        this.container = container;
        this.customCallBack=customCallBack;
    }





    @Override
    public NetworkGroupChipAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chip_view_item, parent, false);
        return new NetworkGroupChipAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final NetworkGroupChipAdapter.ViewHolder holder, final int position) {
        final NetworkGroupDataModel item = items.get(position);

        holder.name.setText("" + item.getGroupName());



        holder.cancelBtn.setOnClickListener(view -> {

            removeAt(position);


            tempItems.remove(position);
            checkContainerVisibility();
            if(customCallBack!=null){
                customCallBack.act();
            }
        });

    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,items.size());

    }

    private void checkContainerVisibility(){
        if(items.size() <=0){
            container.setVisibility(View.GONE);
            return;
        }
        label.setText("You have selected " + items.size() + " network Group");
        container.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}
