package com.mobileapp.krank.CallBacks;

import android.view.View;

import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;

public interface ListingFavCallBack {
    void act(final ListingDataArray item, final View fav_btn, final int position);
}
