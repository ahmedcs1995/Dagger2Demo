package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.TypeConverters;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Functions.StringListTypeConverter;
import com.mobileapp.krank.Utils.Converters.HtmlParseLinksConverter;

import java.util.List;

public class ChatHtmlParse {

    @SerializedName("message_type")
    @Expose
    @ColumnInfo(name = "html_parse_message_type")
    private String message_type;

    @SerializedName("listing_id")
    @Expose
    @ColumnInfo(name = "html_parse_listing_id")
    private String listing_id;

    @SerializedName("html_message")
    @Expose
    @ColumnInfo(name = "html_message")
    @TypeConverters(StringListTypeConverter.class)
    private List<String> html_message;


    @SerializedName("links")
    @Expose
    @ColumnInfo(name = "chat_html_parse_links")
    @TypeConverters(HtmlParseLinksConverter.class)
    private List<ChatHtmlParseLinks> links;

    public String getMessage_type() {
        return message_type;
    }

    public void setMessage_type(String message_type) {
        this.message_type = message_type;
    }

    public List<String> getHtml_message() {
        return html_message;
    }

    public void setHtml_message(List<String> html_message) {
        this.html_message = html_message;
    }

    public String getListing_id() {
        return listing_id;
    }

    public void setListing_id(String listing_id) {
        this.listing_id = listing_id;
    }

    public List<ChatHtmlParseLinks> getLinks() {
        return links;
    }

    public void setLinks(List<ChatHtmlParseLinks> links) {
        this.links = links;
    }

    public class ChatHtmlParseLinks{
        @SerializedName("text")
        @Expose
        @ColumnInfo(name = "chat_html_parse_links_text")
        private String text;

        @SerializedName("link")
        @Expose
        @ColumnInfo(name = "chat_html_parse_links_link")
        private String link;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getLink() {
            return link;
        }

        public void setLink(String link) {
            this.link = link;
        }
    }
}