package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PostSearch {
    @SerializedName("feeds")
    @Expose
    private List<NewsFeedArray> newsFeedArrays = null;

    public List<NewsFeedArray> getNewsFeedArrays() {
        return newsFeedArrays;
    }

    public void setNewsFeedArrays(List<NewsFeedArray> newsFeedArrays) {
        this.newsFeedArrays = newsFeedArrays;
    }
}
