package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.FilterMarketPlaceList;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingFilterDataModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterMarketPlaceListAdapter extends RecyclerView.Adapter<FilterMarketPlaceListAdapter.ViewHolder> {
    private List<ListingFilterDataModel> items = new ArrayList<>();
    FilterMarketPlaceList filterMarketPlaceList;


    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView category_name;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            category_name = item.findViewById(R.id.name);

        }
    }

    public FilterMarketPlaceListAdapter(List<ListingFilterDataModel> items, FilterMarketPlaceList filterMarketPlaceList) {
        this.items = items;
        this.filterMarketPlaceList = filterMarketPlaceList;
    }

    public FilterMarketPlaceListAdapter(ListingFilterDataModel[] items, FilterMarketPlaceList filterMarketPlaceList) {

        this.items.addAll(Arrays.asList(items));
        this.filterMarketPlaceList = filterMarketPlaceList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.drop_adapter_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ListingFilterDataModel item = items.get(position);


        item.setItemClick(() -> {
            if(filterMarketPlaceList.getIntent().getIntExtra("selected_item",-1) != -1){
                items.get(filterMarketPlaceList.getIntent().getIntExtra("selected_item",0)).setItemCheck(false);
            }
            item.setItemCheck(true);
            notifyDataSetChanged();
            Intent intent = new Intent();
            intent.putExtra("category_id", "" + item.getCategoryId());
            intent.putExtra("selected_index", position);
            intent.putExtra("selected_name", "" + item.getTitle());
            filterMarketPlaceList.setResult(filterMarketPlaceList.RESULT_OK, intent);
            filterMarketPlaceList.finish();

        });

        if (item.isItemCheck()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }

        holder.item.setOnClickListener(view -> {
            if (item.getItemClick() != null) {
                item.getItemClick().act();
            }
        });

        holder.category_name.setText("" + item.getTitle());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}








