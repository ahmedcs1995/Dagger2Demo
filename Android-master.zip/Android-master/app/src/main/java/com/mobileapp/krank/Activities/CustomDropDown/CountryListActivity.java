package com.mobileapp.krank.Activities.CustomDropDown;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.CountryListAdapter;
import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CountryListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CountryListActivity extends BaseActivity {

    List<CountyListData> countyListData;
    CountyListData countryDataReceived;
    LinearLayoutManager layoutManager;
    private RecyclerView countryRecyclerView;
    private CountryListAdapter countryRecyclerAdapter;
    EditText search_box;
    View done_btn;

    public int selectedIndex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drop_down);
        search_box=findViewById(R.id.search_box);
        done_btn=findViewById(R.id.done_btn);

        selectedIndex= -1;
        countryDataReceived =null;
        setNormalPageToolbar("Country List");
        search_box.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                countryRecyclerAdapter.getFilter().filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        done_btn.setOnClickListener(view -> {

            try {
                if(selectedIndex !=-1){
                    hideKeyBoard();
                    Intent intent = new Intent();
                    intent.putExtra("selectedCountry","" + appUtils.convertToJson(countryRecyclerAdapter.filteredItems.get(selectedIndex)));
                    setResult(RESULT_OK, intent);
                    finish();

                    overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
                }
                else if(countryDataReceived !=null){
                    hideKeyBoard();
                    Intent intent = new Intent();
                    intent.putExtra("selectedCountry","" + appUtils.convertToJson(countryDataReceived));
                    setResult(RESULT_OK, intent);
                    finish();
                    overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
                }
                else{
                    Toast.makeText(CountryListActivity.this,"Please select Country",Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e){
                Toast.makeText(this,"An unknown Error Occurred",Toast.LENGTH_SHORT).show();
            }

        });
        setUpAdapter();
    }

    private void getCountries() {
        getAPI().countryList().enqueue(new Callback<CountryListResponse>() {
            @Override
            public void onResponse(Call<CountryListResponse> call, Response<CountryListResponse> response) {

                if(response.isSuccessful()){
                    countyListData.addAll(response.body().getData());

                    String dataReceived=null;
                    if(getIntent().getStringExtra("countryData") !=null ){
                        dataReceived = getIntent().getStringExtra("countryData");
                    }

                    if(dataReceived != null){
                        countryDataReceived =(gson.fromJson(dataReceived,CountyListData.class));
                        for(int i=0;i<countyListData.size();i++){
                            if(countryDataReceived.getCode().equals(countyListData.get(i).getCode())){
                                countyListData.get(i).setItemSelected(true);
                                break;
                            }
                        }
                    }
                    countryRecyclerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<CountryListResponse> call, Throwable t) {

            }
        });
    }
    private void setUpAdapter() {
        countryRecyclerView = (RecyclerView) findViewById(R.id.country_recycler_view);

        countyListData = new ArrayList<>();

        layoutManager=new LinearLayoutManager(this);
        countryRecyclerAdapter = new CountryListAdapter(countyListData, this);
        countryRecyclerView.setLayoutManager(layoutManager);
        countryRecyclerView.setAdapter(countryRecyclerAdapter);
        getCountries();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
}
