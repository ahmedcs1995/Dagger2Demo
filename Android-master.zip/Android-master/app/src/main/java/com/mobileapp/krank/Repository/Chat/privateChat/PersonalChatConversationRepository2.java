package com.mobileapp.krank.Repository.Chat.privateChat;

import android.app.Activity;
import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mobileapp.krank.Chat.ChatUtils.ChatUtils;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity2;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.Dao.PersonalChatConversationDao;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.ResponseModels.ChatImageUploadResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.DataModel.MessageAttachment;
import com.mobileapp.krank.ResponseModels.DataModel.MessageVCardData;
import com.mobileapp.krank.ResponseModels.PrivateChatMessagesResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.socket.client.Ack;
import io.socket.emitter.Emitter;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import io.socket.client.Socket;


public class PersonalChatConversationRepository2 {

    private PersonalChatConversationDao mConversationDetailDao;

    //for DB operations
    AppExecutors executors;

    //for rest api
    ServiceManager serviceManager;

    // utils for chat
    ChatUtils chatUtils;

    SaveInSharedPreference preference;

    String conv_id;


    //order by
    private static String ASEC = "1";
    private static String DESC = "0";


    // for pagination
    long firstId;

    //flag for first Time init
    boolean isFirstTimeInit;

    AppUtils appUtils;

    Socket mSocket;

    Activity activity;


    ArrayList limit;

    Gson gson;

    //files count
    int filesCount;

    //send Message Object
    ConversationDetail msgObject;
    MessageVCardData sendMsgVCard;
    MessageAttachment messageAttachment;

    //retrieve Message Instance
    ConversationDetail retrieveMsgObj;
    MessageAttachment retreivemessageAttachment;


    private static String TAG = PersonalChatConversationRepository2.class.getSimpleName();

    public PersonalChatConversationRepository2(Application application, String conv_id) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        mConversationDetailDao = db.chatConversationListDao();

        // local preferences data
        preference = new SaveInSharedPreference(application.getApplicationContext());

        //for retrieve Messages
        this.conv_id = conv_id;


        initialize();

    }


    private void initialize() {
        isFirstTimeInit = true;

        limit = new ArrayList();

        //for DB operations
        executors = AppExecutors.getInstance();

        //for rest api
        serviceManager = ServiceManager.getInstance();

        // utils
        chatUtils = new ChatUtils();
        appUtils = AppUtils.getInstance();

        gson = CustomGson.getInstance();

    }

    public LiveData<List<ConversationDetail>> getmAllMsgs(String id) {
        return mConversationDetailDao.getAllRecords(id);
    }

    public PersonalChatConversationDao getConversationDao() {
        return mConversationDetailDao;
    }


    public void getMessages(Activity activity, PrivateChatConversationActivity2.onScrollCall callBack) {
        serviceManager.getAPI().getPrivateChatMessages(preference.getString(Constants.ACCESS_TOKEN), conv_id, "0", String.valueOf(firstId), limit, DESC).enqueue(new Callback<PrivateChatMessagesResponse>() {
            @Override
            public void onResponse(Call<PrivateChatMessagesResponse> call, Response<PrivateChatMessagesResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {

                        //store the data
                        List<ConversationDetail> tempMsgs = response.body().getData().getConversation_detail();

                        if (tempMsgs.size() > 0) {

                            /*setting values in chat msgs object*/
                            chatUtils.setPersonalChatMsgsType(tempMsgs, false, activity, preference);
                            /*setting values in chat msgs object*/

                            //get the first id for pagination
                            firstId = Long.parseLong(tempMsgs.get(0).getId());

                            /*block for first time init data*/
                            if (isFirstTimeInit) {

                                //perform DB operation in Background
                                executors.diskIO().execute(() -> {
                                    mConversationDetailDao.deleteByConvId(conv_id);
                                    mConversationDetailDao.bulkInsert(tempMsgs);

                                });
                                isFirstTimeInit = false;
                                callBack.act(tempMsgs);

                            }
                            /*block for first time init data*/

                            /*block for scroll Pagination*/
                            else {
                                Collections.reverse(tempMsgs);
                                if (callBack != null) {
                                    callBack.act(tempMsgs);
                                }
                            }
                            /*block for scroll Pagination*/
                        }
                    } else {
                        Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PrivateChatMessagesResponse> call, Throwable t) {

            }
        });
    }


    public void getMessages2(Activity activity,PrivateChatConversationActivity2.onSuccessCallBack successCallBack) {



        serviceManager.getAPI().getPrivateChatMessages(preference.getString(Constants.ACCESS_TOKEN), conv_id, "0", String.valueOf(firstId), limit, DESC).enqueue(new Callback<PrivateChatMessagesResponse>() {
            @Override
            public void onResponse(Call<PrivateChatMessagesResponse> call, Response<PrivateChatMessagesResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {

                        //store the data
                        List<ConversationDetail> tempMsgs = response.body().getData().getConversation_detail();

                        /*setting values in chat msgs object*/
                        chatUtils.setPersonalChatMsgsType(tempMsgs, false, activity, preference);
                        /*setting values in chat msgs object*/



                        //get the first id for pagination
                        firstId = Long.parseLong(tempMsgs.get(0).getId());


                        // dao.updatePersons(it.data.persons, page == 0, it.hasLoadedAllItems);
                        executors.diskIO().execute(()->{
                           // mConversationDetailDao.deleteByConvId(conv_id);
                            mConversationDetailDao.bulkInsert(tempMsgs);
                        });


                        successCallBack.act(tempMsgs);

                    } else {
                        Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PrivateChatMessagesResponse> call, Throwable t) {

            }
        });
    }


    public void setSocket(Socket mSocket, Activity activity) {
        this.mSocket = mSocket;
        this.activity = activity;
        bindSocketEmitterListeners();
    }

    private void bindSocketEmitterListeners() {
        mSocket.on(PrivateChatConversationActivity2.EVENT_MESSAGE + "-" + conv_id, onNewMessage);
        //   mSocket.on("is deleted-" + CONV_ID,onMsgDelete);
        //    mSocket.on("is read-" + CONV_ID, isRead);
        //    mSocket.on("update-msg-" + USER_D, updateConvo);
        mSocket.connect();
    }

    public void disconnectSocket() {
        mSocket.off("msg-" + conv_id, onNewMessage);
    }


    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                Log.e("onNewMsg", "Emitter Listener => " + data.toString());

                try {
                    //   String convId = data.get("convoId").toString();
                    String msgText = data.get("msgText").toString();
                    String msgType = data.get("msgType").toString();
                    String userId = data.get("userID").toString();
                    // String localMsgID = data.get("localMsgID").toString();
                    //  String convoUserID = data.get("convoUserID").toString();
                    String time = data.get("time").toString();
                    // String formatted_time = data.get("formatted_time").toString();
                    String id = data.get("id").toString();
                    String attachmentThumb = null;
                    MessageVCardData messageVCardData = null;
                    MessageAttachment messageAttachment = null;

                    if (msgType.equals("vcard")) {
                        //Vcard
                        try {
                            Object vCardData = data.get("vCardData");
                            messageVCardData = gson.fromJson(vCardData.toString(), MessageVCardData.class);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        msgText = "";
                    } else if (msgType.equals("attachment")) {
                        //attachment
                        attachmentThumb = data.get("thumb").toString();
                        messageAttachment = getRetrieveMessageAttachment(data.get("fExt").toString(), data.get("thumb").toString(), data.get("msgText").toString());
                        msgText = "";
                    }


                    //    ConversationDetail conversationDetail = new ConversationDetail(id,msgText, ChatUtils.getTypeOfMessage(msgType,preference.getString(Constants.USER_ID),userId,messageAttachment==null ? "" : messageAttachment.getFileExt()), Constants.STATUS_SEND, convId, appUtils.getCurrentTimeStamp(), time, "2 hours Ago",messageVCardData,messageAttachment);
                    ConversationDetail conversationDetail = getRetrieveMessageInstance(id, msgText, msgType, userId, time, messageVCardData, messageAttachment, attachmentThumb);
                    //insert in to the database
                    executors.diskIO().execute(() -> {
                        mConversationDetailDao.insert(conversationDetail);
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
        }
    };

    private MessageAttachment getRetrieveMessageAttachment(String fileExt, String thumb, String msgText) {
        if (retreivemessageAttachment == null) {
            retreivemessageAttachment = new MessageAttachment();
        }

        retreivemessageAttachment.setFileExt(fileExt);
        retreivemessageAttachment.setFileThumb(thumb);
        retreivemessageAttachment.setFileName(msgText);
        retreivemessageAttachment.setFilePath("");
        return retreivemessageAttachment;
    }

    private ConversationDetail getRetrieveMessageInstance(String id, String msgText, String msgType, String msgUserId, String time, MessageVCardData messageVCardData, MessageAttachment messageAttachment, String attachmentThumb) {
        if (retrieveMsgObj == null) {
            retrieveMsgObj = new ConversationDetail();
        }
        retrieveMsgObj.setId(id);
        retrieveMsgObj.setTypeOfMessage(ChatUtils.getTypeOfMessage(msgType, preference.getString(Constants.USER_ID), msgUserId, messageAttachment == null ? "" : messageAttachment.getFileExt()));
        retrieveMsgObj.setMsgStatus(Constants.STATUS_SEND);
        retrieveMsgObj.setConversationId(conv_id);
        retrieveMsgObj.setTimeStamp(appUtils.getCurrentTimeStamp());
        retrieveMsgObj.setTime(time);
        retrieveMsgObj.setSentTime("Just Now");
        retrieveMsgObj.setVCardData(messageVCardData);
        retrieveMsgObj.setThumb(attachmentThumb);
        if (retrieveMsgObj.getTypeOfMessage().equals(Constants.OTHER_ATTACHMENT_RIGHT) || retrieveMsgObj.getTypeOfMessage().equals(Constants.OTHER_ATTACHMENT_RIGHT)) {
            retrieveMsgObj.setReply(messageAttachment.getFileName().substring(messageAttachment.getFileName().indexOf('/') + 1, messageAttachment.getFileName().length()));

        } else {
            retrieveMsgObj.setReply(msgText);
        }

        retrieveMsgObj.setAttachment(messageAttachment);


        return retrieveMsgObj;
    }

    public void sendTextMessage(String msgText) {
        if (msgText.isEmpty()) {
            return;
        }
        performSend(msgText, Constants.TEXT_RIGHT, null);
    }

    public void sendContactCardMessage(String connectionId, ConnectionsDataModel connectionsDataModel) {
        performSend(connectionId, Constants.V_CARD_RIGHT, connectionsDataModel);
    }

    public void sendAttachmentMessage(String filePath) {
        performAttachmentSend(filePath);
    }

    private void performSend(String msgText, String type, ConnectionsDataModel connectionsDataModel) {


        ConversationDetail msg = getMessageObject(type, msgText, connectionsDataModel);


        //add the msg in local Db
        executors.diskIO().execute(() -> {
            long local_id = mConversationDetailDao.insert(msg);


            //send the message to server
            JSONObject jsonObj;
            try {
                jsonObj = makeJsonObject(msgText, type, local_id);

                Log.e(TAG, "sending Json" + jsonObj.toString());


                mSocket.emit("msg", jsonObj, (Ack) args -> {
                    JSONObject object = (JSONObject) args[0];
                    Log.e(TAG, "Msg Send Resp => " + object.toString());

                    //update the msg in local Db
                    try {
                        if (object.get("status").toString().toLowerCase().trim().equals(Constants.SUCCESS_STATUS)) {
                            mConversationDetailDao.updateMsg(conv_id, local_id, object.get("msg_id").toString(), Constants.STATUS_SEND);
                        } else {
                            mConversationDetailDao.updateMsg(conv_id, local_id, Constants.STATUS_FAIL);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    private void performAttachmentSend(String filePath) {


        // ConversationDetail msg = getMessageObject(Constants.OTHER_ATTACHMENT_RIGHT,filePath,null);


        //send the message to server
        JSONObject jsonObj;
        try {
            jsonObj = makeJsonObject(filePath, Constants.OTHER_ATTACHMENT_RIGHT, -1);

            Log.e(TAG, "sending Json" + jsonObj.toString());


            mSocket.emit("msg", jsonObj, (Ack) args -> {
                JSONObject object = (JSONObject) args[0];
                Log.e(TAG, "Msg attachment Resp => " + object.toString());

                //update the msg in local Db


                try {
                    if (object.get("status").toString().toLowerCase().trim().equals(Constants.SUCCESS_STATUS)) {

                        //   mConversationDetailDao.insert(getMessageAttachmentObject())
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }



                    /*try {
                        if(object.get("status").toString().toLowerCase().trim().equals(Constants.SUCCESS_STATUS)){
                            mConversationDetailDao.updateMsg(conv_id, local_id,object.get("msg_id").toString(),Constants.STATUS_SEND);
                        }else{
                            mConversationDetailDao.updateMsg(conv_id, local_id,Constants.STATUS_FAIL);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }*/
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private JSONObject makeJsonObject(String msg, String type, long localMsgId) throws JSONException {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("convoId", conv_id);
        jsonObj.put("msgText", msg);

        if (type.equals(Constants.TEXT_RIGHT)) {
            jsonObj.put("msgType", Constants.TEXT_MSG_TYPE);
        } else if (type.equals(Constants.V_CARD_RIGHT)) {
            jsonObj.put("msgType", Constants.V_CARD_TYPE);
        } else if (type.equals(Constants.OTHER_ATTACHMENT_RIGHT)) {
            jsonObj.put("msgType", Constants.ATTACHMENT_TYPE);
        }

        jsonObj.put("userID", preference.getString(Constants.USER_ID_ENCRYPTED));


        if (localMsgId != -1) {
            jsonObj.put("localMsgID", localMsgId);
        }

        jsonObj.put("convoUserID", "");

        return jsonObj;
    }

    //for contact card and text message
    private ConversationDetail getMessageObject(String type, String msgText, ConnectionsDataModel connectionsDataModel) {
        if (msgObject == null) {
            msgObject = new ConversationDetail();
        }
        //updating object
        msgObject.setReply(msgText);
        msgObject.setTypeOfMessage(type);
        msgObject.setMsgStatus(Constants.STATUS_PENDING);
        msgObject.setConversationId(conv_id);
        msgObject.setTimeStamp(appUtils.getCurrentTimeStamp());
        msgObject.setTime(appUtils.getcurrentUTCTime());
        msgObject.setSentTime("Just Now");

        //insert VCard Data
        if (type.equals(Constants.V_CARD_RIGHT)) {
            msgObject.setVCardData(getVCardObject(connectionsDataModel));
            msgObject.setAttachment(null);
        } else {
            msgObject.setVCardData(null);
            msgObject.setAttachment(null);
        }

        return msgObject;
        //  return new ConversationDetail(msgText, Constants.TEXT_RIGHT, Constants.STATUS_PENDING, conv_id, appUtils.getCurrentTimeStamp(), appUtils.getcurrentUTCTime(), "Just Now");
    }


    private ConversationDetail getMessageAttachmentObject(String id, String filePath, String fileExt) {
        if (msgObject == null) {
            msgObject = new ConversationDetail();
        }
        //updating object
        msgObject.setReply("");
        msgObject.setTypeOfMessage(Constants.OTHER_ATTACHMENT_RIGHT);
        msgObject.setMsgStatus(Constants.STATUS_SEND);
        msgObject.setConversationId(conv_id);
        msgObject.setTimeStamp(appUtils.getCurrentTimeStamp());
        msgObject.setTime(appUtils.getcurrentUTCTime());
        msgObject.setSentTime("Just Now");
        msgObject.setId(id);


        msgObject.setAttachment(null);
        msgObject.setAttachment(getAttachmentObject(filePath, fileExt));


        return msgObject;
        //  return new ConversationDetail(msgText, Constants.TEXT_RIGHT, Constants.STATUS_PENDING, conv_id, appUtils.getCurrentTimeStamp(), appUtils.getcurrentUTCTime(), "Just Now");
    }


    private MessageVCardData getVCardObject(ConnectionsDataModel connectionsDataModel) {
        if (sendMsgVCard == null) {
            sendMsgVCard = new MessageVCardData();
        }

        sendMsgVCard.setProfilePic(connectionsDataModel.getCompanyData().getUserProfilePic());
        sendMsgVCard.setCompanyProfilePic(connectionsDataModel.getCompanyData().getCompanyProfilePic());
        sendMsgVCard.setFirstName(connectionsDataModel.getCompanyData().getFirstName());
        sendMsgVCard.setLastName(connectionsDataModel.getCompanyData().getLastName());
        sendMsgVCard.setCompanyId(connectionsDataModel.getCompanyData().getCompanyName());
        sendMsgVCard.setDesignation(connectionsDataModel.getCompanyData().getJobTitle());
        sendMsgVCard.setCity(connectionsDataModel.getCompanyData().getUserCityName());
        sendMsgVCard.setCountry(connectionsDataModel.getCompanyData().getUserCountryName());
        //sendMsgInstance.setVCardData(sendMsgVCard);

        return sendMsgVCard;

    }

    private MessageAttachment getAttachmentObject(String filePath, String fileExt) {
        if (messageAttachment == null) {
            messageAttachment = new MessageAttachment();
        }

        messageAttachment.setFilePath(filePath);
        messageAttachment.setFileExt(fileExt);
        //sendMsgInstance.setVCardData(sendMsgVCard);

        return messageAttachment;

    }


    public void uploadFiles(String attachmentsToSend) {
        ArrayList<String> filePaths = new ArrayList<>();

        boolean isDataAdded = false;

        filePaths.add(attachmentsToSend);

        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);


        for (int i = 0; i < filePaths.size(); i++) {
            File file = new File(filePaths.get(i));
            Log.e("file.getName()", "" + file.getName());
            if (appUtils.getFileSize(file) < Constants.MAX_FILE_SIZE && appUtils.getFileSize(file) > 0) {
                isDataAdded = true;
                filesCount += 1;
                builder.addFormDataPart("upload_file[]", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
            } else {
                Toast.makeText(activity, "Could Not upload file " + file.getName(), Toast.LENGTH_SHORT).show();
            }

        }

        if (!isDataAdded) {
            return;
        }
        //showLoader();
        MultipartBody requestBody = builder.build();

        serviceManager.getAPI().uploadChatImages(preference.getString(Constants.ACCESS_TOKEN), "chat-attachment", requestBody).enqueue(new Callback<ChatImageUploadResponse>() {
            @Override
            public void onResponse(Call<ChatImageUploadResponse> call, Response<ChatImageUploadResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        for (int i = 0; i < response.body().getData().getSuccess().size(); i++) {
                            sendAttachmentMessage(response.body().getData().getSuccess().get(i).getFileName());
                        }
                    } else {
                        Toast.makeText(activity, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChatImageUploadResponse> call, Throwable t) {

                Toast.makeText(activity, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
            }
        });
    }
}


