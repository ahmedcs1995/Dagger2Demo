package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CallBacks.ListingFavCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.MarketPlaceFunctions;
import com.mobileapp.krank.ViewHolders.MarketPlaceViewHolder.MarketPlaceViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.AddRemoveFavResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;
import com.mobileapp.krank.Utils.ShareBottomSheet;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MarketPlaceAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    ListingFavCallBack getFavCallBack;
    private List<ListingDataArray> items;

    MarketPlaceFunctions marketPlaceFunctions;
    Fragment fragment;
    ShareBottomSheet shareBottomSheet;
    AppUtils appUtils = AppUtils.getInstance();
    SaveInSharedPreference preference;
    public class Loader extends RecyclerView.ViewHolder {
        View item;
        public Loader(View itemView) {
            super(itemView);
            item = itemView;
        }
    }

    public MarketPlaceAdapter(List<ListingDataArray> items, String type, String sub_type, Fragment fragment, SaveInSharedPreference preference) {
        this.items = items;
        this.fragment=fragment;
        this.preference=preference;
        initDialog(preference);
        getFavCallBack = getFavCallBack();
        marketPlaceFunctions = new MarketPlaceFunctions(type,sub_type,fragment,this);
    }

    public MarketPlaceAdapter(List<ListingDataArray> items, Fragment fragment, SaveInSharedPreference preference) {
        this.items = items;
        this.fragment=fragment;
        this.preference=preference;
        initDialog(preference);
        getFavCallBack = getFavCallBack();
        marketPlaceFunctions = new MarketPlaceFunctions(fragment,this);
    }
    private void initDialog(SaveInSharedPreference preference){
        shareBottomSheet = new ShareBottomSheet
                .Builder(fragment, preference)
                .setListeners(getShareCallBack())
                .create();
    }
    private CustomShareCallBack getShareCallBack() {
        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(fragment.getContext(), SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", appUtils.convertToJson(selectedPrivacy));
            intent.putExtra("selected_network_group", appUtils.convertToJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", appUtils.convertToJson(tempDealerGroup));
            fragment.startActivityForResult(intent, Constants.PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }

    private ListingFavCallBack getFavCallBack(){
        return (item, fav_btn, position) -> {
            addToFavUnFav(item,fav_btn,position);
        };
    }

    public ShareBottomSheet getShareBottomSheet() {
        return shareBottomSheet;
    }

    @Override
    public int getItemViewType(int position) {

        switch (items.get(position).getTypeOfListing()) {
            case LOADER:
                return 1;
            case POST:
                return 2;
            default:
                return -1;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sale_listing_searched_item, parent, false);
                return new MarketPlaceViewHolder(view).setListingCallBacks(items,fragment,shareBottomSheet,getFavCallBack);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);

        }
    }

    private void addToFavUnFav(final ListingDataArray item, final View fav_btn, final int position) {
        final String isFav = item.getIsFav();
        final int action;
        if (isFav != null) {
            action = 2;
        } else {
            action = 1;
        }
        ServiceManager.getInstance().getAPI().listingFavUnFav(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(item.getId()), String.valueOf(item.getIsFav()), String.valueOf(action)).enqueue(new Callback<AddRemoveFavResponse>() {
            @Override
            public void onResponse(Call<AddRemoveFavResponse> call, Response<AddRemoveFavResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (isFav == null) {
                            item.setIsFav(response.body().getData().getFav_id());

                        } else {
                            item.setIsFav(null);
                        }
                    }
                    notifyItemChanged(position);
                    fav_btn.setEnabled(true);
                }
            }

            @Override
            public void onFailure(Call<AddRemoveFavResponse> call, Throwable t) {
                fav_btn.setEnabled(true);

            }
        });
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final ListingDataArray item = items.get(position);
        switch (item.getTypeOfListing()) {
            case POST:
                marketPlaceFunctions.setPostView(holder, position, item);
                break;
            case LOADER:
                break;
        }
    }
    @Override
    public int getItemCount() {
        return items.size();
    }
}










