package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CodeVerificationResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.SignupResendVerificationResponse;


import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpPage4 extends BaseActivity {

    private Button continueBtn;
    private ImageView sideImg;
    private TextView detailTextView, resend_code,change_email_btn;
    private String finalCode = "";
    PinView pinView;
    private SweetAlertDialog  showProgressAlert;

    CompanyInvitationDataModel companyInvitationDataModel;

    TextView info_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page4);

        initViews();

        gotoLinkPage();

        if (!(isInviteLinkDataExists())) {
            info_text.setVisibility(View.GONE);
        } else {
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }

        addPinViewTextChangeListener();

        setScreenHeader("Sign Up");
        setKrankLogoForUserProfiling();
        setSpannableString();
        DeviceInfo deviceInfo = getDeviceResolution();
        sideImg.getLayoutParams().height = (int) (deviceInfo.getDeviceHeight() / 6.5);
        sideImg.requestLayout();

        showProgressAlert = showAlert("Checking please wait...", SweetAlertDialog.PROGRESS_TYPE, false);


        setResendCodeCallBack();


        continueBtn.setOnClickListener(view -> confirmVerification());

        change_email_btn.setOnClickListener(v -> {
            Intent intent;
            if(isInviteLinkDataExists()){
                intent = new Intent(this, InvitationRecievePage.class);
            }else{
                intent = new Intent(this, FirstPage.class);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            this.finish();
        });
    }

    private void addPinViewTextChangeListener() {
        pinView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


                if (charSequence.toString().length() == 4) {
                    hideKeyBoard();
                }
                finalCode = charSequence.toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    private void showDialog() {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Code Not Received")
                .setDescription("Didn't receive the code?")
                .setConfirmButtonText("Yes")
                .setCancelButtonText("No")
                .setConfirmButtonListener(dialog1 -> {
                    dialog1.dismiss();
                })
                .setCancelButtonListener(dialog1 -> {
                    resendCodeApi();
                    dialog1.dismiss();
                });

        dialog.show();
    }

    private void resendCodeApi(){
        showProgressAlert.setContentText("Resending Code");
        showProgressAlert.show();

        Log.e("email resend", "" + preference.getString(Constants.USER_EMAIL));

        getAPI().signupResendVerification(preference.getString(Constants.USER_EMAIL)).enqueue(new Callback<SignupResendVerificationResponse>() {
            @Override
            public void onResponse(Call<SignupResendVerificationResponse> call, Response<SignupResendVerificationResponse> response) {

                showProgressAlert.dismiss();
                if (response.isSuccessful()) {
                    showToast(response.body().getMessage());
                }else{
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<SignupResendVerificationResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                onResponseFailure();
            }
        });
    }



    private void setResendCodeCallBack() {
        resend_code.setOnClickListener(v -> {
            showDialog();
        });

    }


    private void initViews() {
        detailTextView = findViewById(R.id.detail_text_view);
        pinView = findViewById(R.id.pinView);

        info_text = findViewById(R.id.info_text);

        resend_code = findViewById(R.id.resend_code);
        continueBtn = findViewById(R.id.continue_btn);
        sideImg = findViewById(R.id.side_img);
        change_email_btn = findViewById(R.id.change_email_btn);
    }

    private void confirmVerification() {
        if (finalCode.length() != 4) {
            showToast("Please enter code correctly");

        } else {
            showProgressAlert.setContentText("Checking please wait...");
            showProgressAlert.show();

            getAPI().codeVerification(preference.getString(Constants.USER_EMAIL), finalCode).enqueue(new Callback<CodeVerificationResponse>() {
                @Override
                public void onResponse(Call<CodeVerificationResponse> call, Response<CodeVerificationResponse> response) {
                    CodeVerificationResponse codeVerificationResponse = response.body();

                    showProgressAlert.dismiss();

                    if (response.isSuccessful()) {
                        if (codeVerificationResponse.getStatus().equals("success")) {


                            Intent intent = new Intent(SignUpPage4.this, SignUpPage5.class);


                            //for redirect to verification screen
                            preference.setBoolean(Constants.GOTO_VERIFICATION_SCREEN,false);


                            preference.setString(Constants.TEMP_USER_ID, codeVerificationResponse.getData().getUserData().getTmpUserId());
                            preference.setString(Constants.VERIFY_CODE, codeVerificationResponse.getData().getUserData().getVerifyCode());
                            preference.setString(Constants.OLD_COMPANY, codeVerificationResponse.getData().getUserData().getOldCompanyName());



                            if (codeVerificationResponse.getData().getUserData().getCompanyInfo() != null) {
                                CountyListData countyListData = new CountyListData(codeVerificationResponse.getData().getUserData().getCompanyInfo().getCountryCode(), codeVerificationResponse.getData().getUserData().getCompanyInfo().getCountryName(), codeVerificationResponse.getData().getUserData().getCompanyInfo().getCountryDialCode());
                                CityListData cityListData = new CityListData(codeVerificationResponse.getData().getUserData().getCompanyInfo().getCityName(), codeVerificationResponse.getData().getUserData().getCompanyInfo().getCityId());
                                preference.setString(Constants.COMPANY_COUNTRY_DATA, appUtils.convertToJson(countyListData));
                                preference.setString(Constants.COMPANY_CITY_DATA, appUtils.convertToJson(cityListData));
                            }
                            startActivity(intent);
                            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                        } else {
                            showToast(codeVerificationResponse.getMessage());
                        }
                    } else {
                        showProgressAlert.dismiss();
                        onResponseFailure();
                    }
                }

                @Override
                public void onFailure(Call<CodeVerificationResponse> call, Throwable t) {
                    showProgressAlert.dismiss();
                    onResponseFailure();
                }
            });

        }
    }


    private void setSpannableString() {
        SpannableStringBuilder ssb = new SpannableStringBuilder("");

        AppUtils.addClickableText(ssb, ssb.length(), "Please check your inbox of ", this, R.color.AppDarkGray);
        AppUtils.addClickableText(ssb, ssb.length(), preference.getString(Constants.USER_EMAIL), this, R.color.drawer_background);
        AppUtils.addClickableText(ssb, ssb.length(), " to verify code. Be sure to check your spam folder too and enter the code here to confirm your email address", this, R.color.AppDarkGray);
        detailTextView.setMovementMethod(LinkMovementMethod.getInstance());   // make our spans selectable
        detailTextView.setText(ssb);
    }


}
