package com.mobileapp.krank.MarketPlaceTabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.MarketPlacePage;
import com.mobileapp.krank.Adapters.MarketPlaceAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Model.Enums.TypeOfListing;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;
import com.mobileapp.krank.ResponseModels.PublicMarketPlaceResponse;
import com.mobileapp.krank.Scroll.EndlessRecyclerViewScrollListener;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class MarketPlaceSaleRent extends BaseFragment {

    //list items
    private RecyclerView mMarketPlaceRecyclerView;
    private MarketPlaceAdapter mMarketPlaceAdapter;
    List<ListingDataArray> items;

    //for pagination
    int offset;
    EndlessRecyclerViewScrollListener scrollListener;


    // for delay the api
    Handler handler;
    Runnable runnable;


    //flag for scroll pagination
    boolean firstTimeInit;
    boolean triggerScroll;
    SwipeRefreshLayout swipeRefreshLayout;
    boolean isSwipeRefreshCall;


    //sort,search and filter var
    String keyword;
    String search_type;
    String category_id;
    String sub_category_id;
    String type_id;

    String sort_by;
    String sort_by_network;
    String sort_by_connection;

    public static final int LISTING_DETAIL_CODE = 300;
    String type;
    String userId;

    Gson gson;
    boolean isSortByNetworkExecute;
    public int clickIndex;

    TextView no_item_found_view;

    ServiceManager serviceManager;



    //shimmer loader
    ShimmerFrameLayout shimmerFrameLayout;


    private String code;
    private MarketPlacePage mMarketPlacePage;

    public MarketPlaceSaleRent() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.listing_page, container, false);
        setFragmentView(me);


        getDataFromActivity();

        initViews();


        handler = new Handler();
        runnable = () -> getData();


        gson = CustomGson.getInstance();


        init();


        initValues();


        setUpAdapter();
        //getPublicMarketPlace();

        // start the loader
        startShimmer();

        //request the api
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);


        return me;
    }

    private void initViews() {
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);
        no_item_found_view = (TextView) findViewById(R.id.no_item_found_view);
        shimmerFrameLayout = (ShimmerFrameLayout) findViewById(R.id.shimmer_layout);
        no_item_found_view.setText(Constants.NO_LISTING_FOUND_TEXT);
        no_item_found_view.setVisibility(View.GONE);

    }

    private void startShimmer() {
        shimmerFrameLayout.startShimmer();
    }

    private void stopShimmer() {
        shimmerFrameLayout.stopShimmer();
        shimmerFrameLayout.setVisibility(View.GONE);
    }

    private void setUpAdapter() {
        mMarketPlaceRecyclerView = (RecyclerView) findViewById(R.id.sale_listing_result_recycler);
        items = new ArrayList<>();

        //items.add(new ListingDataArray(TypeOfListing.LOADER));


        mMarketPlaceAdapter = new MarketPlaceAdapter(items, type, "SALE", MarketPlaceSaleRent.this, ((MarketPlacePage) getActivity()).preference);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        mMarketPlaceRecyclerView.setLayoutManager(layoutManager);
        mMarketPlaceRecyclerView.setAdapter(mMarketPlaceAdapter);

        ((SimpleItemAnimator) mMarketPlaceRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

        /*mMarketPlaceRecyclerView.addOnScrollListener(new EndlessOnScrollListener(layoutManager) {
            @Override
            public void onScrolledToEnd() {
                if (!firstTimeInit && !isSwipeRefreshCall && isItemsAdded) {
                    isItemsAdded = false;
                    offset += Constants.PAGE_LIMIT_1;
                    handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
                }
            }
        });*/


        addOnScrollListener(layoutManager);

        addOnSwipeRefresh();

    }

    private void addOnScrollListener(LinearLayoutManager layoutManager) {
        scrollListener = new EndlessRecyclerViewScrollListener(layoutManager) {
            @Override
            public void onLoadMore(int totalItemsCount, RecyclerView view) {
                if(isSwipeRefreshCall || !triggerScroll){
                    scrollListener.resetState();
                    return;
                }
                offset += Constants.PAGE_LIMIT_1;
                handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
            }

            @Override
            public void onHide() {

            }

            @Override
            public void onShow() {

            }
        };


        mMarketPlaceRecyclerView.addOnScrollListener(scrollListener);
    }

    private void addOnSwipeRefresh() {

        swipeRefreshLayout.setOnRefreshListener(() -> {
            isSwipeRefreshCall = true;
            items.clear();
            offset = 0;
            mMarketPlaceRecyclerView.getRecycledViewPool().clear();
            mMarketPlaceAdapter.notifyDataSetChanged();
            swipeRefreshLayout.setRefreshing(true);
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
        });
    }


    private void onSuccess(List<ListingDataArray> tempData) {

        /**
         * Scroll listener
         * */
        scrollListener.resetState();


        if (firstTimeInit) {
            stopShimmer();
        } else {
            removeLoader();
        }

        for (ListingDataArray item : tempData) {
            item.setTypeOfListing(TypeOfListing.POST);
        }

        firstTimeInit = false;
        isSwipeRefreshCall = false;
        swipeRefreshLayout.setRefreshing(false);

        if (tempData.size() <= 0) {
            triggerScroll = false;
        } else if (tempData.size() < Constants.PAGE_LIMIT_1) {
            triggerScroll = false;
            insertIntoList(tempData);
        } else {
            triggerScroll = true;
            tempData.add(new ListingDataArray(TypeOfListing.LOADER));
            insertIntoList(tempData);
        }

        if (items.size() <= 0) {
            no_item_found_view.setVisibility(View.VISIBLE);
        } else {
            no_item_found_view.setVisibility(View.GONE);
        }
    }


    private void insertIntoList(List<ListingDataArray> data) {
        int lastListSize = items.size();
        items.addAll(data);
        mMarketPlaceAdapter.notifyItemRangeInserted(lastListSize, items.size());
        // newsFeedRecyclerAdapter.notifyDataSetChanged();

    }

    private void removeLoader() {
        for (int i = (items.size() - 1); i >= 0; i--) {
            if (items.get(i).getTypeOfListing() == TypeOfListing.LOADER) {
                removeAt(i);
                break;
            }
        }
    }

    public void removeAt(int position) {
        items.remove(position);
        mMarketPlaceAdapter.notifyItemRemoved(position);
        mMarketPlaceAdapter.notifyItemRangeChanged(position, items.size());
    }

    private void onResponseFailure() {
        if (firstTimeInit) {
            stopShimmer();
        } else {
            removeLoader();
        }

        swipeRefreshLayout.setRefreshing(false);

        firstTimeInit = false;
        // Toast.makeText(getContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
        if (mMarketPlacePage != null) {
            mMarketPlacePage.onResponseFailure();
        }

    }

    private void getData() {
        Call<PublicMarketPlaceResponse> request;
        if (type.equals(Constants.PUBLIC_MARKET_PLACE)) {
            request = serviceManager.getAPI().getPublicMarketPlaceData(((MarketPlacePage) getActivity()).preference.getString(Constants.ACCESS_TOKEN), code, category_id, sub_category_id, type_id, keyword, search_type, sort_by, sort_by_network, sort_by_connection, offset, Constants.PAGE_LIMIT_1);
        } else {
            //network market place
            request = serviceManager.getAPI().getNetworkMarketPlaceData(((MarketPlacePage) getActivity()).preference.getString(Constants.ACCESS_TOKEN), code, category_id, sub_category_id, type_id, keyword, search_type, sort_by, sort_by_network, sort_by_connection, offset, Constants.PAGE_LIMIT_1);
        }

        request.enqueue(new Callback<PublicMarketPlaceResponse>() {
            @Override
            public void onResponse(Call<PublicMarketPlaceResponse> call, Response<PublicMarketPlaceResponse> response) {
                try {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                            onSuccess(response.body().getData().getListing());
                        } else {
                            if (mMarketPlacePage != null) {
                                mMarketPlacePage.showToast(response.body().getMessage());
                            }
                        }
                    } else {
                        onResponseFailure();
                    }
                } catch (Exception ex) {

                }

            }

            @Override
            public void onFailure(Call<PublicMarketPlaceResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }

    private void init() {
        keyword = "";
        category_id = "0";
        sub_category_id = "0";
        type_id = "0";
        sort_by = "0";
        if (!isSortByNetworkExecute) {
            sort_by_network = "0";
            sort_by_connection = "0";
        }

        serviceManager = ServiceManager.getInstance();


    }

    private void initValues() {

        offset = 0;
        firstTimeInit = true;
        isSwipeRefreshCall = false;
    }

    public void performSearchFilterization(String keyword, String search_type) {
        this.keyword = keyword;
        this.search_type = search_type;
        initValues();
        items.clear();
        mMarketPlaceRecyclerView.getRecycledViewPool().clear();
        mMarketPlaceAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(true);
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    public void performCategoryFilterization(String category_id, String sub_category_id, String type_id) {
        this.category_id = category_id;
        this.sub_category_id = sub_category_id;
        this.type_id = type_id;
        initValues();
        items.clear();
        mMarketPlaceRecyclerView.getRecycledViewPool().clear();
        mMarketPlaceAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(true);
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    public void performSortFilterization(String sort_by, String sort_by_network, String sort_by_connection) {
        this.sort_by = sort_by;
        this.sort_by_network = sort_by_network;
        this.sort_by_connection = sort_by_connection;
        initValues();
        items.clear();
        mMarketPlaceRecyclerView.getRecycledViewPool().clear();
        mMarketPlaceAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(true);
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void sortByNetwork(String sort_by, String sort_by_network, String sort_by_connection) {
        isSortByNetworkExecute = true;
        this.sort_by = sort_by;
        this.sort_by_network = sort_by_network;
        this.sort_by_connection = sort_by_connection;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {

            switch (requestCode) {

                case LISTING_DETAIL_CODE:
                    // items.get(clickIndex).setIsFav();
                    items.get(clickIndex).setIsFav(data.getStringExtra("isFavValue"));
                    mMarketPlaceAdapter.notifyItemChanged(clickIndex);
                    break;

                case Constants.PRIVACY_ACTIVITY_CODE:
                    mMarketPlaceAdapter.getShareBottomSheet().updateDialogOnActivityResult(data);
                    break;

                case Constants.ENQUIRY_ACTIVITY_CODE:
                    if (data.getStringExtra("dealer_data_listing") != null) {
                        items.get(data.getIntExtra("item_index", 0)).setDealers(Arrays.asList(gson.fromJson(data.getStringExtra("dealer_data_listing"), DealerDataListing[].class)));
                        mMarketPlaceAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                    }
                    if (data.getStringExtra("co_worker_assignments") != null) {
                        items.get(data.getIntExtra("item_index", 0)).setAssignments(Arrays.asList(gson.fromJson(data.getStringExtra("co_worker_assignments"), PublicMarketPlaceAssignment[].class)));
                        mMarketPlaceAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                    } else if (data.getStringExtra("updated_network_status") != null && data.getStringExtra("updated_connection_status") != null) {
                        items.get(data.getIntExtra("item_index", 0)).setNetStatus(data.getStringExtra("updated_network_status"));
                        items.get(data.getIntExtra("item_index", 0)).setConStatus(data.getStringExtra("updated_connection_status"));
                        mMarketPlaceAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                    }
                    break;
                default:
                    break;

            }
        }
    }

    private void getDataFromActivity() {
        mMarketPlacePage = (MarketPlacePage) getActivity();

        String pageTitle = getTitle();

        code = pageTitle.equals("Sale") ? MarketPlacePage.SALE_LISTING_CODE : MarketPlacePage.RENT_LISTING_CODE;

        type = mMarketPlacePage.typeOfMarketPlace;


    }
}