package com.mobileapp.krank.CustomImagePicker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.mobileapp.krank.CallBacks.CustomCallBack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CustomImagePicker {


    private static int REQUEST_IMAGE = 100;
    private static int REQUEST_GALLERY = 300;
    private String imageFilePath;

    private static final int MIN_WIDTH_QUALITY = 400;        // min pixels
    private static final int MIN_HEIGHT_QUALITY = 400;

    private static String TAG = CustomImagePicker.class.getSimpleName();


    public CustomImagePicker(){
        //Empty constructor
    }

    public void pickImage(Activity activity){
        //showPictureDialog(activity);
        showPictureDialog(activity,()->{
           openGalleryIntent(activity);
        },()->{
          openCameraIntent(activity);
        });
    }


    public void pickImage(Fragment fragment){
        //showPictureDialog(fragment.getActivity());
        showPictureDialog(fragment.getContext(),()->{
            openGalleryIntent(fragment);
        },()->{
            openCameraIntent(fragment);
        });
    }

    public Bitmap handleImagePick(int requestCode,Activity activity,Intent data){
        if (requestCode == REQUEST_IMAGE) {
            try {
                Uri selectedImage = Uri.fromFile(new File(imageFilePath));
                Bitmap bm  = decodeBitmap(activity, selectedImage);
                return modifyOrientationForCamera(bm,imageFilePath);
            } catch (Exception ex) {
              //  Log.e(TAG,ex.getMessage());
                Log.e(TAG,"handleImagePick() Exception");
                return null;
            }
        } else if (requestCode == REQUEST_GALLERY) {
            Uri selectedImage = data.getData();
            Bitmap bm = decodeBitmap(activity, selectedImage);
            int rotation = getRotationFromGallery(activity, selectedImage);
            return rotate(bm,rotation);
        }
        return null;
    }

    public Bitmap rotate(Bitmap bitmap, int degrees) {
        if (bitmap != null && degrees != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(degrees);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        }
        return bitmap;
    }


    private int getRotationFromGallery(Context context, Uri imageUri) {
        int result = 0;
        String[] columns = {MediaStore.Images.Media.ORIENTATION};
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(imageUri, columns, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int orientationColumnIndex = cursor.getColumnIndex(columns[0]);
                result = cursor.getInt(orientationColumnIndex);
            }
        } catch (Exception e) {
            //Do nothing
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        } //End of try-catch block
        return result;
    }

    private static Bitmap decodeBitmap(Context context, Uri theUri) {
        Bitmap outputBitmap = null;
        AssetFileDescriptor fileDescriptor = null;

        try {
            fileDescriptor = context.getContentResolver().openAssetFileDescriptor(theUri, "r");

            // Get size of bitmap file
            BitmapFactory.Options boundsOptions = new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeFileDescriptor(fileDescriptor.getFileDescriptor(), null, boundsOptions);

            // Get desired sample size. Note that these must be powers-of-two.
            int[] sampleSizes = new int[]{8, 4, 2, 1};
            int selectedSampleSize = 1; // 1 by default (original image)

            for (int sampleSize : sampleSizes) {
                selectedSampleSize = sampleSize;
                int targetWidth = boundsOptions.outWidth / sampleSize;
                int targetHeight = boundsOptions.outHeight / sampleSize;
                if (targetWidth >= MIN_WIDTH_QUALITY && targetHeight >= MIN_HEIGHT_QUALITY) {
                    break;
                }
            }

            // Decode bitmap at desired size
            BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
            decodeOptions.inSampleSize = selectedSampleSize;
            outputBitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor.getFileDescriptor(), null, decodeOptions);
            if (outputBitmap != null) {
                Log.i(TAG, "Loaded image with sample size " + decodeOptions.inSampleSize + "\t\t"
                        + "Bitmap width: " + outputBitmap.getWidth()
                        + "\theight: " + outputBitmap.getHeight());
            }
            fileDescriptor.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return outputBitmap;
    }


    private String getImagePath(Uri uri,Activity activity){
        Cursor cursor = activity.getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        String document_id = cursor.getString(0);
        document_id = document_id.substring(document_id.lastIndexOf(":")+1);
        cursor.close();

        cursor = activity.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                null, MediaStore.Images.Media._ID + " = ? ", new String[]{document_id}, null);
        cursor.moveToFirst();
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
        cursor.close();

        return path;
    }

    private void showPictureDialog(final Activity activity){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(activity);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                (dialog, which) -> {
                    switch (which) {
                        case 0:
                            openGalleryIntent(activity);
                            break;
                        case 1:
                            openCameraIntent(activity);
                            break;
                    }
                });
        pictureDialog.show();
    }

    private void showPictureDialog(Context context, CustomCallBack openGallery,CustomCallBack openCamera){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(context);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                (dialog, which) -> {
                    switch (which) {
                        case 0:
                            openGallery.act();
                            break;
                        case 1:
                            openCamera.act();
                            break;
                    }
                });
        pictureDialog.show();
    }



    private boolean checkPermissionForReadExternalStorage(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = context.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return false;
    }

    private boolean checkPermissionForWriteExternalStorage(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return false;
    }

    private boolean hasCameraAccess(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = context.checkSelfPermission(Manifest.permission.CAMERA);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return false;
    }


    private File createImageFile(Context context) throws IOException {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        imageFilePath = image.getAbsolutePath();

        Log.e(TAG,"create image file " + image);
        Log.e(TAG,"create image file with absolute path " + imageFilePath);
        return image;
    }

   /* private Intent getGalleryIntent(Context context){
        if(checkPermissionForReadExternalStorage(context)){
            return new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        }
        return null;
    }*/

    private Intent getGalleryIntent(Context context){
        if(checkPermissionForReadExternalStorage(context)){
            return new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        }
        return null;
    }

    private void openGalleryIntent(Activity activity) {
        Intent intent =getGalleryIntent(activity);
        if (intent!= null) {
            activity.startActivityForResult(intent, REQUEST_GALLERY);
        }
    }

    private void openGalleryIntent(Fragment fragment){
        Intent intent =getGalleryIntent(fragment.getContext());
        if (intent!= null) {
            fragment.startActivityForResult(intent, REQUEST_GALLERY);
        }
    }

    private void openCameraIntent(Activity activity){
        Intent intent =getCameraIntent(activity);
        if (intent!= null) {
            activity.startActivityForResult(intent, REQUEST_IMAGE);
        }
    }

    private void openCameraIntent(Fragment fragment){
        Intent intent =getCameraIntent(fragment.getContext());
        if (intent!= null) {
            fragment.startActivityForResult(intent, REQUEST_IMAGE);
        }

    }

    private Intent getCameraIntent(Context context) {
        if(hasCameraAccess(context) && checkPermissionForReadExternalStorage(context) && checkPermissionForWriteExternalStorage(context)){
            Intent pictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (pictureIntent.resolveActivity(context.getPackageManager()) != null) {

                File photoFile = null;
                try {
                    photoFile = createImageFile(context);
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG,"getCameraIntent() Exception");
                    return null;
                }
                Uri photoUri = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", photoFile);
                pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                return pictureIntent;
            }
        }
        return null;
    }

    public void pickImageFromCameraOnly(Activity activity){
        openCameraIntent(activity);
    }

    public void pickImageFromCameraOnly(Activity activity,int requestcode){
        REQUEST_IMAGE = requestcode;
        openCameraIntent(activity);
    }
    public void pickImageFromGalleryOnly(Activity activity,int requestcode){
        REQUEST_GALLERY = requestcode;
        openGalleryIntent(activity);
    }
    public void pickImageFromGalleryOnly(Activity activity){
        openGalleryIntent(activity);
    }

    private Bitmap modifyOrientationForCamera(Bitmap bitmap, String image_absolute_path) throws IOException {
        ExifInterface ei = new ExifInterface(image_absolute_path);
        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        Log.e("orientation", "" + orientation);
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotate(bitmap, 90);

            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotate(bitmap, 180);

            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotate(bitmap, 270);

            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
                return flip(bitmap, true, false);

            case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                return flip(bitmap, false, true);

            default:
                return bitmap;
        }
    }

    private Bitmap rotate(Bitmap bitmap, float degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical) {
        Matrix matrix = new Matrix();
        matrix.preScale(horizontal ? -1 : 1, vertical ? -1 : 1);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
}
