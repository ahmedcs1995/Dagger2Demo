package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList

class SortByNetworkAdapter(private val items: List<NetworkList>?, internal var context: Context, internal var callBack: CallBackWithAdapterPosition) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    inner class NetworkSortViewHolder(internal var item: View) : RecyclerView.ViewHolder(item) {
        internal var unCheckView: View = item.findViewById(R.id.uncheck_view)
        internal var checkedView: View = item.findViewById(R.id.check_view)
        internal var checkb: View = item.findViewById(R.id.checkb)
        internal var company_image_view: SimpleDraweeView = item.findViewById(R.id.company_image_view)
        internal var company_name_text_view: TextView = item.findViewById(R.id.company_name_text_view)
        internal var country_and_city_text_view: TextView = item.findViewById(R.id.country_and_city_text_view)

        init {
            item.setOnClickListener { view -> callBack.act(adapterPosition) }
        }
    }

    override fun getItemViewType(position: Int): Int {
        when (items!![position].type) {
            Constants.LOADER_VIEW -> return 1
            Constants.ITEM_VIEW -> return 2
            else -> return 1
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View
        when (viewType) {
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                return AppListItemLoader(v)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.network_sort_item, parent, false)
                return NetworkSortViewHolder(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                return AppListItemLoader(v)
            }
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items!![position]


        if (items[position].type == Constants.ITEM_VIEW) {
            setItemView(holder as NetworkSortViewHolder, item)
        }

    }

    private fun setItemView(holder: NetworkSortViewHolder, item: NetworkList) {
        if (item.isItemCheck) {
            holder.unCheckView.visibility = View.GONE
            holder.checkedView.visibility = View.VISIBLE
        } else {
            holder.unCheckView.visibility = View.VISIBLE
            holder.checkedView.visibility = View.GONE
        }



        if (item.profilePic != null) {
            holder.company_image_view.setImageURI("" + item.profilePic)
        } else {
            holder.company_image_view.visibility = View.GONE
            holder.country_and_city_text_view.visibility = View.GONE
        }


        val country = if (item.countryName != null) item.countryName else "N/A"
        val city = if (item.cityName != null) item.cityName else "N/A"

        holder.company_name_text_view.text = item.companyName
        holder.country_and_city_text_view.text = "$city, $country"
    }


    override fun getItemCount(): Int {
        return items?.size ?: 0
    }

}







