package com.mobileapp.krank.CallBacks;

import android.view.View;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

public interface ShareButtonCallBack {
    void act(NewsFeedArray item,View viewToAnim,int type);
}
