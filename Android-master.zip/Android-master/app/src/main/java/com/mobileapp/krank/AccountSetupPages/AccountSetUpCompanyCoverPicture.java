package com.mobileapp.krank.AccountSetupPages;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.ApiUtils;
import com.yalantis.ucrop.UCrop;

import java.io.File;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Yaseen on 17/04/2018.
 */

public class AccountSetUpCompanyCoverPicture extends BaseFragment implements AccountSetupPage.PictureChangeListener{

    //views
    ImageView coverImg;
    ImageView imgPlaceHolder;
    ImageView company_image_view;
    View imgSelect;
    TextView coverPicText;
    TextView text_view_name;


    CustomImagePicker imagePicker;
    public AccountSetUpCompanyCoverPicture() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_page_six, container, false);
        setFragmentView(me);


        init();

        initViews();
        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));


        coverImg.setVisibility(View.GONE);

        imgSelect.setOnClickListener(view -> {
            imagePicker.pickImage(AccountSetUpCompanyCoverPicture.this);
        });
        setCoverPictureOfCompany();
        return me;
    }

    private void initViews(){
        coverPicText = (TextView) findViewById(R.id.cover_pic_text);
        coverImg = (ImageView) findViewById(R.id.cover_img);
        imgSelect = findViewById(R.id.img_select);
        imgPlaceHolder = (ImageView) findViewById(R.id.img_place_holder);
        text_view_name = (TextView) findViewById(R.id.text_view_name);
        company_image_view = (ImageView) findViewById(R.id.company_image_view);

    }

    private void init(){

        AccountSetupPage accountSetupPage = (AccountSetupPage) getActivity();
        preference = accountSetupPage.preference;
        accountSetupPage.setmCompanyPicChangeListener(this::onPictureChange);

        imagePicker = new CustomImagePicker();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {


        if(resultCode == RESULT_OK){
            if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);
                ApiUtils.uploadImage(resultUri, Constants.COMPANY_COVER_IMAGE, preference, getContext());
                setImage(resultUri);
            }
            else{
                Bitmap bitmap = imagePicker.handleImagePick(requestCode,getActivity(),  intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(getContext(), bitmap), Uri.fromFile(new File(getActivity().getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, getContext(), Constants.COMPANY_COVER_IMAGE);
                    uCrop.start(getContext(), AccountSetUpCompanyCoverPicture.this);
                }
            }
        }
    }

    private void setImage(Uri uri) {
        Constants.COMPANY_COVER_IMG = true;
        ((AccountSetupPage)getActivity()).hideSkipNowView();
        coverImg.setVisibility(View.VISIBLE);
        imgPlaceHolder.setVisibility(View.GONE);
        Glide.with(getContext()).load(uri).apply(new RequestOptions().centerCrop()).into(coverImg);
        coverPicText.setText(Constants.COMPANY_COVER_IMG_UPLOAD_MESSAGE);
    }

    private void setCoverPictureOfCompany(){
        if (!(preference.getString(Constants.COMPANY_COVER_PICTURE).isEmpty())) {
            Glide.with(getActivity()).load(Constants.BASE_IMG_URL + preference.getString(Constants.COMPANY_COVER_PICTURE)).into(coverImg);
            coverImg.setVisibility(View.VISIBLE);
            imgPlaceHolder.setVisibility(View.GONE);
        }
    }
    public void update() {

        if (!(preference.getString(Constants.TEMP_COMPANY_PROFILE_PICTURE).isEmpty())) {
            Glide.with(getActivity()).load(Uri.parse(preference.getString(Constants.TEMP_COMPANY_PROFILE_PICTURE))).apply(new RequestOptions().centerCrop()).into(company_image_view);
        }
        else if (!(preference.getString(Constants.COMPANY_PROFILE_PICTURE).isEmpty())) {
            Glide.with(getActivity()).load(Constants.BASE_IMG_URL + preference.getString(Constants.COMPANY_PROFILE_PICTURE)).into(company_image_view);
        }

    }

    @Override
    public void onPictureChange() {
        update();
    }
}
