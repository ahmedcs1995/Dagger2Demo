package com.mobileapp.krank.Model;

public class FilterMarketPlaceModel {
    private String categoryId;
    private String subCategoryId;
    private String type;
    private int selected_category;
    private int selected_sub_category;
    private int selected_type;
    private String selectedCategoryTitle;
    private String selectedSubCategoryTitle;
    private String selectedTypeCategoryTitle;


    public FilterMarketPlaceModel(String categoryId, String subCategoryId, String type, int selected_category, int selected_sub_category, int selected_type,String selectedCategoryTitle,String selectedSubCategoryTitle,String selectedTypeCategoryTitle) {
        this.categoryId = categoryId;
        this.subCategoryId = subCategoryId;
        this.type = type;
        this.selected_category = selected_category;
        this.selected_sub_category = selected_sub_category;
        this.selected_type = selected_type;
        this.selectedCategoryTitle = selectedCategoryTitle;
        this.selectedSubCategoryTitle = selectedSubCategoryTitle;
        this.selectedTypeCategoryTitle = selectedTypeCategoryTitle;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getSubCategoryId() {
        return subCategoryId;
    }

    public void setSubCategoryId(String subCategoryId) {
        this.subCategoryId = subCategoryId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSelected_category() {
        return selected_category;
    }

    public void setSelected_category(int selected_category) {
        this.selected_category = selected_category;
    }

    public int getSelected_sub_category() {
        return selected_sub_category;
    }

    public void setSelected_sub_category(int selected_sub_category) {
        this.selected_sub_category = selected_sub_category;
    }

    public int getSelected_type() {
        return selected_type;
    }

    public void setSelected_type(int selected_type) {
        this.selected_type = selected_type;
    }


    public String getSelectedCategoryTitle() {
        return selectedCategoryTitle;
    }

    public void setSelectedCategoryTitle(String selectedCategoryTitle) {
        this.selectedCategoryTitle = selectedCategoryTitle;
    }

    public String getSelectedSubCategoryTitle() {
        return selectedSubCategoryTitle;
    }

    public void setSelectedSubCategoryTitle(String selectedSubCategoryTitle) {
        this.selectedSubCategoryTitle = selectedSubCategoryTitle;
    }

    public String getSelectedTypeCategoryTitle() {
        return selectedTypeCategoryTitle;
    }

    public void setSelectedTypeCategoryTitle(String selectedTypeCategoryTitle) {
        this.selectedTypeCategoryTitle = selectedTypeCategoryTitle;
    }
}
