package com.mobileapp.krank.CallBacks

interface CallBackWithAdapterPosAndType {
    fun act(position: Int,type : Int)
}
