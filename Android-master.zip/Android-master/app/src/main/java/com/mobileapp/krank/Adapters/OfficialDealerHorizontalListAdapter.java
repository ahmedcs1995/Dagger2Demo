package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.CompanyProfileView;
import com.mobileapp.krank.Functions.AppUtils;

import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealersDataForCompanyProfileViewPage;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.List;

public class OfficialDealerHorizontalListAdapter  extends RecyclerView.Adapter<OfficialDealerHorizontalListAdapter.ViewHolder>  {
    private List<DealersDataForCompanyProfileViewPage> items;
    Context context;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        SimpleDraweeView network_dealers_profile_image_view;
        TextView name;
        TextView country;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            network_dealers_profile_image_view=itemView.findViewById(R.id.network_dealers_profile_image_view);
            name=itemView.findViewById(R.id.name);
            country=itemView.findViewById(R.id.country);

            item.setOnClickListener(view -> {
                Intent intent = new Intent(context, CompanyProfileView.class);
                intent.putExtra("companyId", "" + items.get(getAdapterPosition()).getId());
                context.startActivity(intent);

            });
        }
    }

    public OfficialDealerHorizontalListAdapter(List<DealersDataForCompanyProfileViewPage> items, Context context) {
        this.items = items;
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.official_dealer_horizontal_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final DealersDataForCompanyProfileViewPage item = items.get(position);
        holder.network_dealers_profile_image_view.setImageURI("" + item.getImage());
        holder.name.setText("" + item.getCompanyName());
        holder.country.setText(AppUtils.concatenateCountryCity(item.getCountryName(),item.getCityName()));
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }


}



