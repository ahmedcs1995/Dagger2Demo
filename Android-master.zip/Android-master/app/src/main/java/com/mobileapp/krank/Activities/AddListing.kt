package com.mobileapp.krank.Activities

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast

import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.ListingWebviewResponse

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddListing : BaseActivity() {

    private var loginUrl: String? = null
    internal lateinit var progressBar: ProgressBar
    internal lateinit var webView: WebView

   // private var mUploadMessage: ValueCallback<Array<Uri>>? = null
    private var mUploadMessage: ValueCallback<Uri>? = null
    private var uploadMessage: ValueCallback<Array<Uri>>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_listing)
        setNormalPageToolbar( "Add Listing")
        webView = findViewById<View>(R.id.webview) as WebView
        webView.visibility = View.GONE
        progressBar = findViewById(R.id.loader)
        progressBar.visibility = View.VISIBLE

        listingLogin()


    }

    private fun listingLogin() {
        api.ListingLogin(preference.getString(Constants.ACCESS_TOKEN)).enqueue(object : Callback<ListingWebviewResponse> {
            override fun onResponse(call: Call<ListingWebviewResponse>, response: Response<ListingWebviewResponse>) {
                Log.e("login res->", "" + appUtils.convertToJson(response.body()))
                Log.e("login params->", "" + appUtils.convertToJson(call.request()))
                if (response.isSuccessful) {
                    Log.e("login url", Constants.BASE_LOGIN_URL + response.body().data.encoded_url)

                    /*if(response.body().getData().getLogin_url().contains(" ")){
                        listingLogin();
                        return;
                    }*/

                    loginUrl = Constants.BASE_LOGIN_URL + response.body().data.encoded_url

                    webView.loadUrl(loginUrl)
                    webView.settings.javaScriptEnabled = true
                    webView.settings.allowFileAccess = true
                    webView.webViewClient = object : WebViewClient() {

                        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                            Log.e("shouldOverride", "UrlLoading => $url")

                            if (url.substring(url.indexOf('#') + 1, url.length) == "sale") {
                                val intent = Intent(applicationContext, MyListingPage::class.java)
                                intent.putExtra("currentItem", 0)
                                startActivity(intent)
                                finish()
                            } else if (url.substring(url.indexOf('#') + 1, url.length) == "rent") {
                                val intent = Intent(applicationContext, MyListingPage::class.java)
                                intent.putExtra("currentItem", 1)
                                startActivity(intent)
                                finish()
                            } else {
                                Log.e("url ->", "" + url)
                                Log.e("OverrideUrlLoading", "yes")
                                view.loadUrl(url)
                            }
                            return true

                        }

                        override fun onLoadResource(view: WebView, url: String) {
                            //  Log.e("onLoadResource","yes");
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            Log.e("onPageFinished", "yes=> $url")
                            //  progressBar.setVisibility(View.GONE);
                            webView.loadUrl("javascript:(function() { " +
                                    "document.getElementsByClassName('header-navigation')[0].style.display = 'none';" +
                                    "document.getElementsByClassName('header')[0].style.display = 'none';" +
                                    "document.getElementsByClassName('content')[0].style.paddingTop = '15px';" +
                                    "document.getElementsByClassName('container-fixed-lg')[0].style.display ='none'" +
                                    "})()")
                            if (url == Constants.SITE_BASE_URL + "/add-listing") {
                                progressBar.visibility = View.GONE
                                webView.visibility = View.VISIBLE
                            }
                        }

                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            Toast.makeText(applicationContext, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show()
                        }

                    }

                    webView.webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: WebChromeClient.FileChooserParams): Boolean {
                            uploadMessage?.onReceiveValue(null)
                            uploadMessage = null

                            uploadMessage = filePathCallback

                            val intent = fileChooserParams.createIntent()

                            try {
                                startActivityForResult(intent, REQUEST_SELECT_FILE)
                            } catch (e: ActivityNotFoundException) {
                                uploadMessage = null
                                Toast.makeText(applicationContext, "Cannot Open File Chooser", Toast.LENGTH_LONG).show()
                                return false
                            }
                            return true
                        }
                        override fun onPermissionRequest(request: PermissionRequest?) {
                            Log.d("ChatMessagesPage", "onPermissionRequest")

                        }
                        // For Android 3.0+
                        fun openFileChooser(uploadMsg: ValueCallback<*>, acceptType: String) {
                            mUploadMessage = uploadMsg as ValueCallback<Uri>
                            val i = Intent(Intent.ACTION_GET_CONTENT)
                            i.addCategory(Intent.CATEGORY_OPENABLE)
                            i.type = "*/*"
                            this@AddListing.startActivityForResult(
                                    Intent.createChooser(i, "File Browser"),
                                    FILE_CHOOSER_RESULTCODE)
                        }
                        //For Android 4.1
                        fun openFileChooser(uploadMsg: ValueCallback<Uri>, acceptType: String, capture: String) {
                            mUploadMessage = uploadMsg
                            val i = Intent(Intent.ACTION_GET_CONTENT)
                            i.addCategory(Intent.CATEGORY_OPENABLE)
                            i.type = "image/*"
                            this@AddListing.startActivityForResult(Intent.createChooser(i, "File Chooser"), FILE_CHOOSER_RESULTCODE)

                        }

                        protected fun openFileChooser(uploadMsg: ValueCallback<Uri>) {
                            mUploadMessage = uploadMsg
                            val intent = Intent(Intent.ACTION_GET_CONTENT)
                            intent.addCategory(Intent.CATEGORY_OPENABLE)
                            intent.type = "*/*"
                            startActivityForResult(Intent.createChooser(intent, "File Chooser"), FILE_CHOOSER_RESULTCODE)
                        }


                    }


                }
            }

            override fun onFailure(call: Call<ListingWebviewResponse>, t: Throwable) {
               // Toast.makeText(applicationContext, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT)
            }
        })
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (requestCode === REQUEST_SELECT_FILE) {
                if (uploadMessage == null)
                    return
                print("result code = $resultCode")
                var results: Array<Uri>? = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                uploadMessage?.onReceiveValue(results)
                uploadMessage = null
            }
        } else if (requestCode == FILE_CHOOSER_RESULTCODE) {
            if (null == mUploadMessage)
                return
            // Use ChatMessagesPage.RESULT_OK if you're implementing WebView inside Fragment
            // Use RESULT_OK only if you're implementing WebView inside an Activity
            val result = if (intent == null || resultCode !== RESULT_OK) null else intent.data
            mUploadMessage?.onReceiveValue(result)
            mUploadMessage = null
        } else
            Toast.makeText(applicationContext, "Failed to Upload Image", Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val FILE_CHOOSER_RESULTCODE = 1
        private const val REQUEST_SELECT_FILE  = 100
    }
}
