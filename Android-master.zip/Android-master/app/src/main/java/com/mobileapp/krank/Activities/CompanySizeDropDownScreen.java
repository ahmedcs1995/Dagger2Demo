package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.CompanySizeAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CompanySizeResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CompanySizeData;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CompanySizeDropDownScreen extends BaseActivity {

    List<CompanySizeData> companySizeData;
    CompanySizeData companySizeDataReceived;
    LinearLayoutManager layoutManager;
    private RecyclerView countryRecyclerView;
    private CompanySizeAdapter countryRecyclerAdapter;
    View done_btn;
    public int selectedIndex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_size_drop_down_screen);
        done_btn=findViewById(R.id.done_btn);
        selectedIndex= -1;
        setNormalPageToolbar("Company Size");

        done_btn.setOnClickListener(view -> {
            if(selectedIndex != -1){
                Log.e("selected_company","-> " + appUtils.convertToJson(companySizeData.get(selectedIndex)));
                Intent intent = new Intent();
                intent.putExtra("selectedCompanySize","" + appUtils.convertToJson(companySizeData.get(selectedIndex)));
                setResult(RESULT_OK, intent);
                finish();
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
            }
            else{
                Toast.makeText(CompanySizeDropDownScreen.this,"Please select an option",Toast.LENGTH_SHORT).show();
            }
        });
        setUpAdapter();
    }

    private void getCountries() {
        getAPI().getCompanySize(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<CompanySizeResponse>() {
            @Override
            public void onResponse(Call<CompanySizeResponse> call, Response<CompanySizeResponse> response) {



                if(response.isSuccessful()){
                    companySizeData.addAll(response.body().getData());
                    String dataReceived=null;
                    if(getIntent().getStringExtra("selectedCompanySize") !=null ){
                        dataReceived = getIntent().getStringExtra("selectedCompanySize");

                    }
                    if(dataReceived != null){
                        companySizeDataReceived =(gson.fromJson(dataReceived,CompanySizeData.class));
                        for(int i=0;i<companySizeData.size();i++){
                            if(companySizeDataReceived.getId().equals(companySizeData.get(i).getId())){
                                companySizeData.get(i).setItemSelected(true);
                                selectedIndex = i;
                                break;
                            }
                        }
                    }
                    countryRecyclerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<CompanySizeResponse> call, Throwable t) {

            }
        });
    }

    private void setUpAdapter() {
        countryRecyclerView = (RecyclerView) findViewById(R.id.country_recycler_view);

        companySizeData = new ArrayList<>();

        layoutManager=new LinearLayoutManager(this);
        countryRecyclerAdapter = new CompanySizeAdapter(companySizeData, CompanySizeDropDownScreen.this);
        countryRecyclerView.setLayoutManager(layoutManager);
        countryRecyclerView.setAdapter(countryRecyclerAdapter);
        getCountries();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
}
