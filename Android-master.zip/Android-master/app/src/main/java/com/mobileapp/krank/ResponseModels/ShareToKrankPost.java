package com.mobileapp.krank.ResponseModels;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ShareToKrankPost {
    @SerializedName("track_id")
    @Expose
    private String trackId;
    @SerializedName("post_from")
    @Expose
    private String postFrom;
    @SerializedName("privacy_id")
    @Expose
    private String privacyId;
    @SerializedName("post_title")
    @Expose
    private String postTitle;
    @SerializedName("group_ids")
    @Expose
    private List<String> groupIds = null;

    public ShareToKrankPost(String trackId, String postFrom, String privacyId, String postTitle, List<String> groupIds) {
        this.trackId = trackId;
        this.postFrom = postFrom;
        this.privacyId = privacyId;
        this.postTitle = postTitle;
        this.groupIds = groupIds;
    }

    public String getTrackId() {
        return trackId;
    }

    public void setTrackId(String trackId) {
        this.trackId = trackId;
    }

    public String getPostFrom() {
        return postFrom;
    }

    public void setPostFrom(String postFrom) {
        this.postFrom = postFrom;
    }

    public String getPrivacyId() {
        return privacyId;
    }

    public void setPrivacyId(String privacyId) {
        this.privacyId = privacyId;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }

    public List<String> getGroupIds() {
        return groupIds;
    }

    public void setGroupIds(List<String> groupIds) {
        this.groupIds = groupIds;
    }

}
