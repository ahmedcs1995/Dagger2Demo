package com.mobileapp.krank.AccountSetupPages;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Base.BaseFragment;

import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Yaseen on 18/04/2018.
 */

public class AccountSetUpPageNine extends BaseFragment {
    Button gotoBtn;

    SaveInSharedPreference preference;

    public AccountSetUpPageNine() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_nine, container, false);
        setFragmentView(me);


        init();

        gotoBtn = (Button) findViewById(R.id.goto_btn);

        gotoBtn.setOnClickListener(v -> {
            //update the flag
          //  profileWizardClose();

            ApiUtils.profileWizardClose(preference.getString(Constants.ACCESS_TOKEN), ((AccountSetupPage)getActivity()).getAPI());




            Constants.USER_IMG = false;
            Constants.COVER_IMG = false;
            Constants.COMPANY_COVER_IMG = false;
            Constants.COMPANY_IMG = false;

            CustomApplication app = (CustomApplication)getActivity().getApplicationContext();

            Intent intent =((AccountSetupPage)getActivity()).getIntentToRedirectNextPage(getActivity(),app.listingUrl,app.pageToRedirect);
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
            getActivity().finishAffinity();


        });
        return me;
    }

    private void init(){
       preference = ((AccountSetupPage)getActivity()).preference;
    }

}