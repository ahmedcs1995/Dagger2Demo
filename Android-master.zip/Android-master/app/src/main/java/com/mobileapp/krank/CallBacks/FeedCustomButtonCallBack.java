package com.mobileapp.krank.CallBacks;

import android.view.View;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

public interface FeedCustomButtonCallBack {
    void act(int position, NewsFeedArray item,View view);
}
