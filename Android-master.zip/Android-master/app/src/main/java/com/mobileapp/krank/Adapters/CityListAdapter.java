package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.CustomDropDown.CityListActivity;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;

import java.util.List;

public class CityListAdapter extends RecyclerView.Adapter<CityListAdapter.ViewHolder>{
    public List<CityListData> items;
    CityListActivity cityListActivity;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView name;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            name = item.findViewById(R.id.name);
        }
    }

    public CityListAdapter(List<CityListData> items, CityListActivity cityListActivity) {
        this.items = items;
        this.cityListActivity = cityListActivity;
    }



    @Override
    public CityListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.drop_adapter_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CityListAdapter.ViewHolder holder, final int position) {
        final CityListData item = items.get(position);

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cityListActivity.hideKeyBoard();
                item.setItemSelected(true);
                notifyDataSetChanged();
                Intent intent = new Intent();
                intent.putExtra("cityData", cityListActivity.appUtils.convertToJson(item));
                cityListActivity.setResult(cityListActivity.RESULT_OK, intent);
                cityListActivity.finish();
                cityListActivity.overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);

            }
        });
        holder.name.setText("" + item.getCityName());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}







