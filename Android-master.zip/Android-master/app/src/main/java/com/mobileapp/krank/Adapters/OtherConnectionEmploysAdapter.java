package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsForCompanyProfileViewDataModel;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.ArrayList;
import java.util.List;

public class OtherConnectionEmploysAdapter extends RecyclerView.Adapter<OtherConnectionEmploysAdapter.ViewHolder>  {
    private List<ConnectionsForCompanyProfileViewDataModel> items;
    Context context;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        SimpleDraweeView image;
        TextView name;
        TextView company_name;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            image=itemView.findViewById(R.id.profile_img);
            name=itemView.findViewById(R.id.name);
            company_name=itemView.findViewById(R.id.company_name);

            item.setOnClickListener(view -> {
                Intent intent = new Intent(context, UserProfileView.class);
                intent.putExtra(UserProfileView.INTENT_USER_ID, "" + items.get(getAdapterPosition()).getUserId());
                context.startActivity(intent);
            });
        }
    }

    public OtherConnectionEmploysAdapter(List<ConnectionsForCompanyProfileViewDataModel> items, Context context) {
        this.items = items;
        this.context = context;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.other_connection_employs_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final ConnectionsForCompanyProfileViewDataModel item = items.get(position);


        holder.company_name.setText("" + item.getDesignation());
        holder.name.setText("" + item.getFirstName() + " " + item.getLastName());

        holder.image.setImageURI("" + item.getUserPic());

    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}








