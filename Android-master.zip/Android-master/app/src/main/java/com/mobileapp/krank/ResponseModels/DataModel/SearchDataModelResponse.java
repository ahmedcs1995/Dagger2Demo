package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchDataModelResponse {

    @SerializedName("networkEmp")
    @Expose
    private List<NetworkEmpSearch> networkEmp = null;


    @SerializedName("network")
    @Expose
    private List<NetworkSearch> network = null;

    @SerializedName("listing")
    @Expose
    private List<ListingDataArray> listing = null;

    @SerializedName("listingSale")
    @Expose
    private List<ListingDataArray> listingSale = null;

    @SerializedName("networkEmpCount")
    @Expose
    private int networkEmpCount;


    @SerializedName("networkCount")
    @Expose
    private int networkCount;

    @SerializedName("rentListingCount")
    @Expose
    private int rentListingCount;

    @SerializedName("saleListingCount")
    @Expose
    private int saleListingCount;



 /*   @SerializedName("post")
    @Expose
    PostSearch postSearch;*/

    public List<NetworkEmpSearch> getNetworkEmp() {
        return networkEmp;
    }

    public void setNetworkEmp(List<NetworkEmpSearch> networkEmp) {
        this.networkEmp = networkEmp;
    }

    public List<NetworkSearch> getNetwork() {
        return network;
    }

    public void setNetwork(List<NetworkSearch> network) {
        this.network = network;
    }

    public List<ListingDataArray> getListing() {
        return listing;
    }

    public void setListing(List<ListingDataArray> listing) {
        this.listing = listing;
    }

    public List<ListingDataArray> getListingSale() {
        return listingSale;
    }

    public void setListingSale(List<ListingDataArray> listingSale) {
        this.listingSale = listingSale;
    }

  /*  public PostSearch getPostSearch() {
        return postSearch;
    }

    public void setPostSearch(PostSearch postSearch) {
        this.postSearch = postSearch;
    }*/

    public int getNetworkEmpCount() {
        return networkEmpCount;
    }

    public void setNetworkEmpCount(int networkEmpCount) {
        this.networkEmpCount = networkEmpCount;
    }

    public int getNetworkCount() {
        return networkCount;
    }

    public void setNetworkCount(int networkCount) {
        this.networkCount = networkCount;
    }

    public int getRentListingCount() {
        return rentListingCount;
    }

    public void setRentListingCount(int rentListingCount) {
        this.rentListingCount = rentListingCount;
    }

    public int getSaleListingCount() {
        return saleListingCount;
    }

    public void setSaleListingCount(int saleListingCount) {
        this.saleListingCount = saleListingCount;
    }
}
