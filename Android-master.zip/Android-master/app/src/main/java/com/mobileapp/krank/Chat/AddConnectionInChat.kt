package com.mobileapp.krank.Chat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.ConnectionResponse
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.Utils.AnimationUtils
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.ViewHolders.UserViewHolderCheckBox
import kotlinx.android.synthetic.main.activity_add_connection_in_chat.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.toolbar_with_search.*

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class AddConnectionInChat : BaseActivity() {


    private lateinit var connectionsRecyclerAdapter: AppGeneralAdapter<ConnectionsDataModel>
    internal lateinit var connectionsItems: MutableList<ConnectionsDataModel>


    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null

    //pagination
    var offset: Int = 0
    private var shouldScrollCalled: Boolean = false

    //typing events
    private var onTypingTimeout: Runnable? = null

    private lateinit var selectedConnections: MutableList<ConnectionsDataModel>

    //api
    private var call: Call<ConnectionResponse>? = null

    //list call back
    private lateinit var listCallBack: CallBackWithAdapterPosition


    var tagDataReceived: MutableList<ConnectionsDataModel>? = null

    var alreadyAddedPeopleList: MutableList<GroupChatMembersDataModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_connection_in_chat)

        selectedConnections = ArrayList();

        setNormalPageToolbar( "Select People")


        setUpTypingTimeoutRunnable()


        setUpRunnable()


        setUpListCallBack()


        getIntentData()

        showLoader()


        no_item_found_view.text = Constants.NO_CONNECTION_FOUND_TEXT
        no_item_found_view.visibility = View.GONE




        setUpAdapter()

        getMyConnectionData()


        bindListeners()

    }

    private fun showLoader() {
        shimmer_view_container.startShimmer()
        shimmer_view_container.visibility = View.VISIBLE
    }

    private fun setUpListCallBack() {


        listCallBack = CallBackWithAdapterPosition {
            if (!connectionsItems[it].isItemCheck) {
                selectedConnections.add(connectionsItems[it])
            } else {
                for (i in selectedConnections.indices) {
                    if (selectedConnections[i].companyData.userId == connectionsItems[it].companyData.userId) {
                        selectedConnections.removeAt(i)
                        break
                    }
                }
            }
            connectionsItems[it].isItemCheck = !connectionsItems[it].isItemCheck
            connectionsRecyclerAdapter.updateListItem(it)
        }
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {
            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            connectionsItems.clear()
            connectionsItems.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            connectionsRecyclerAdapter.notifyDataSetChanged()

            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }

            //api data
            getMyConnectionData()
        }
    }

    private fun setUpRunnable() {
        runnable = Runnable {
            getMyConnectionData()
        }
    }

    private fun checkForData() {
        if (connectionsItems.size <= 0) no_item_found_view.visibility = View.VISIBLE else no_item_found_view.visibility = View.GONE
    }


    private fun onSuccess(response: Response<ConnectionResponse>) {

        val responseList = response.body().data.connectionsData

        var tempList: MutableList<ConnectionsDataModel> = ArrayList()

        removeListLoader()


        var idFound: Boolean
        for (i in responseList.indices) {
            idFound = false

            //already added people
            var j = 0
            while (j < alreadyAddedPeopleList!!.size && !idFound) {
                if (responseList[i].companyData.userId == alreadyAddedPeopleList!![j].id) {
                    idFound = true
                }
                j++
            }
            if (!idFound) {
                //check mark
                for (k in selectedConnections.indices) {
                    if (responseList[i].companyData.userId == selectedConnections[k].companyData.userId) {
                        responseList[i].isItemCheck = true
                    }
                }
                //adding
                tempList.add(responseList[i])
            }
        }


        for (i in tempList.indices) {
            for (j in tagDataReceived!!.indices) {
                if (tagDataReceived!![j].companyData.userId == tempList[i].companyData.userId) {
                    tempList[i].isItemCheck = true
                }
            }
        }

        /*for pagination*/
        if (responseList.size >= Constants.PAGE_LIMIT) {
            tempList.add(ConnectionsDataModel(Constants.LOADER_VIEW))
            shouldScrollCalled = true
        }
        /* for pagination*/


        connectionsRecyclerAdapter.addAll(tempList)

        checkForData()

    }


    private fun bindListeners() {
        done_btn.setOnClickListener {
            val selectedTagConnections = selectedConnections

            if (selectedTagConnections.isNotEmpty()) {
                val intent = Intent()
                intent.putExtra("selected_connections", "" + appUtils.convertToJson(selectedTagConnections))
                setResult(Activity.RESULT_OK, intent)
                finish()
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
            } else {
                showToast("Please select connections")
            }
        }

        search_btn.setOnClickListener {
            showKeyboard(search_box)
            AnimationUtils.circleReveal(search_container, 1, true, true, this@AddConnectionInChat)
        }


        back_btn_search.setOnClickListener {
            AnimationUtils.circleReveal(search_container, 1, true, false, this@AddConnectionInChat)
            hideFocusKeyboard()
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")
        }

        search_box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

        })
    }


    private fun setUpAdapter() {
        connectionsItems = ArrayList()
        connectionsRecyclerAdapter = object : AppGeneralAdapter<ConnectionsDataModel>(connectionsItems) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: ConnectionsDataModel, position: Int) {
                if (viewHolder is UserViewHolderCheckBox) {
                    viewHolder.onBindConnections(item, appUtils)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                var v: View
                return when (i) {
                    Constants.ITEM_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                    Constants.LOADER_VIEW -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                        AppListItemLoader(v)
                    }
                    else -> {
                        v = LayoutInflater.from(parent.context).inflate(R.layout.tag_connections_item, parent, false)
                        UserViewHolderCheckBox(v, listCallBack)
                    }
                }
            }

            override fun getItemViewType(position: Int): Int {
                return connectionsItems[position].type
            }


        }

        connections_recycler_view.layoutManager = LinearLayoutManager(this)
        connections_recycler_view.adapter = connectionsRecyclerAdapter
        connectionsRecyclerAdapter.setItemAnimator(connections_recycler_view)
        addOnScrollEndListener()

    }

    private fun addOnScrollEndListener() {
        connections_recycler_view.addOnScrollListener(object : EndlessOnScrollListener() {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun removeListLoader() {
        for (i in connectionsItems.indices.reversed()) {
            if (connectionsItems[i].type == Constants.LOADER_VIEW) {
                connectionsRecyclerAdapter.removeAt(i)
                break
            }
        }
    }

    private fun getIntentData() {
        val dataReceived = intent.getStringExtra("selectedArray").toString()
        val alreadyAddedPeople = intent.getStringExtra("already_added_people").toString()

        tagDataReceived = Arrays.asList(*gson.fromJson(dataReceived, Array<ConnectionsDataModel>::class.java))

        alreadyAddedPeopleList = Arrays.asList(*gson.fromJson(alreadyAddedPeople, Array<GroupChatMembersDataModel>::class.java))
    }

    private fun getMyConnectionData() {
        call = api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", search_box.text.toString(), Constants.PAGE_LIMIT)
        if (call == null) return
        call?.enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {

                removeLoader()
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        // showToast(response.body().message)
                    }
                } else {
                    // onResponseFailure()
                }
            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                //  Toast.makeText(applicationContext, Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show()


            }
        })
    }

    private fun removeLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }


}
