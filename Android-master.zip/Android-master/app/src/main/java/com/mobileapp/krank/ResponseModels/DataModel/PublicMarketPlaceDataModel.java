package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PublicMarketPlaceDataModel {
    @SerializedName("listing")
    @Expose
    private List<ListingDataArray> listing = null;

    @SerializedName("user_data")
    @Expose
    private List<PublicMarketPlaceUserDataModel> userData = null;


    public List<ListingDataArray> getListing() {
        return listing;
    }

    public void setListing(List<ListingDataArray> listing) {
        this.listing = listing;
    }

    public List<PublicMarketPlaceUserDataModel> getUserData() {
        return userData;
    }

    public void setUserData(List<PublicMarketPlaceUserDataModel> userData) {
        this.userData = userData;
    }
}
