package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 6/8/2018.
 */

public class CompanySizeData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    private boolean isItemSelected;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public boolean isItemSelected() {
        return isItemSelected;
    }

    public void setItemSelected(boolean itemSelected) {
        isItemSelected = itemSelected;
    }

    public CompanySizeData(String id, String companySize) {
        this.id = id;
        this.companySize = companySize;
    }
}
