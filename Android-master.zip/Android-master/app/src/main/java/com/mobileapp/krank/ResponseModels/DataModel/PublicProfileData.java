package com.mobileapp.krank.ResponseModels.DataModel;

/**
 * Created by arbaz on 5/29/2018.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PublicProfileData {


    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("cover_pic")
    @Expose
    private String coverPic;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("country_code")
    @Expose
    private String country_code;
    @SerializedName("country_dial_code")
    @Expose
    private String country_dial_code;
    @SerializedName("city_name")
    @Expose
    private String cityName;
    @SerializedName("city_id")
    @Expose
    private String city_id;
    @SerializedName("website_url")
    @Expose
    private String websiteUrl;
    @SerializedName("industry_id")
    @Expose
    private String industryId;
    @SerializedName("company_size")
    @Expose
    private String companySize;
    @SerializedName("company_size_name")
    @Expose
    private String companySizeName;
    @SerializedName("business")
    @Expose
    private String business;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("company_cover_pic")
    @Expose
    private String companyCoverPic;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("department")
    @Expose
    private String department;
    @SerializedName("department_name")
    @Expose
    private String departmentName;
    @SerializedName("job_title")
    @Expose
    private String jobTitle;
    @SerializedName("mobile_number")
    @Expose
    private String mobileNumber;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;

    @SerializedName("connection_info")
    @Expose
    private String connection_info;

    @SerializedName("network_info")
    @Expose
    private String network_info;


    @SerializedName("private_connection_info")
    @Expose
    private boolean private_connection_info;


    @SerializedName("con_type")
    @Expose
    private String con_type;

    @SerializedName("con_id")
    @Expose
    private String con_id;

    private String conStatus = "";

    @SerializedName("my_connections")
    @Expose
    List<ConnectionsForCompanyProfileViewDataModel> myConnections;

    @SerializedName("conversation_id")
    @Expose
    private String conversation_id;



    public String getConnection_info() {
        return connection_info;
    }

    public void setConnection_info(String connection_info) {
        this.connection_info = connection_info;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoverPic() {
        return coverPic;
    }

    public void setCoverPic(String coverPic) {
        this.coverPic = coverPic;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getCompanySize() {
        return companySize;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public String getCompanySizeName() {
        return companySizeName;
    }

    public void setCompanySizeName(String companySizeName) {
        this.companySizeName = companySizeName;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getCompanyCoverPic() {
        return companyCoverPic;
    }

    public void setCompanyCoverPic(String companyCoverPic) {
        this.companyCoverPic = companyCoverPic;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getCon_id() {
        return con_id;
    }

    public void setCon_id(String con_id) {
        this.con_id = con_id;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCountry_dial_code() {
        return country_dial_code;
    }

    public void setCountry_dial_code(String country_dial_code) {
        this.country_dial_code = country_dial_code;
    }

    public String getCity_id() {
        return city_id;
    }

    public void setCity_id(String city_id) {
        this.city_id = city_id;
    }

    public List<ConnectionsForCompanyProfileViewDataModel> getMyConnections() {
        return myConnections;
    }

    public void setMyConnections(List<ConnectionsForCompanyProfileViewDataModel> myConnections) {
        this.myConnections = myConnections;
    }

    public String getNetwork_info() {
        return network_info;
    }

    public void setNetwork_info(String network_info) {
        this.network_info = network_info;
    }

    public String getConversation_id() {
        return conversation_id;
    }

    public void setConversation_id(String conversation_id) {
        this.conversation_id = conversation_id;
    }

    public boolean isPrivate_connection_info() {
        return private_connection_info;
    }

    public void setPrivate_connection_info(boolean private_connection_info) {
        this.private_connection_info = private_connection_info;
    }

    public boolean showPrivateLabel(){
        if(getCon_type() == null) return false;
        return getCon_type().toLowerCase().equals(ConnectionsDataModel.PRIVATE_CONNECTION);
    }

    public String getCon_type() {
        return con_type;
    }

    public void setCon_type(String con_type) {
        this.con_type = con_type;
    }
}
