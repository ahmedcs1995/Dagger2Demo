package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SizeForPublicCompanyProfileData {
    @SerializedName("size_id")
    @Expose
    private String sizeId;
    @SerializedName("size_name")
    @Expose
    private String sizeName;

    public String getSizeId() {
        return sizeId;
    }

    public void setSizeId(String sizeId) {
        this.sizeId = sizeId;
    }

    public String getSizeName() {
        return sizeName;
    }

    public void setSizeName(String sizeName) {
        this.sizeName = sizeName;
    }

    public SizeForPublicCompanyProfileData(String sizeId, String sizeName) {
        this.sizeId = sizeId;
        this.sizeName = sizeName;
    }
}
