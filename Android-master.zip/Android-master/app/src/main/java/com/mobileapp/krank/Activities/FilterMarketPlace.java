package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Model.FilterMarketPlaceModel;
import com.mobileapp.krank.R;


public class FilterMarketPlace extends BaseActivity {

    View sort_by_category;
    View sort_by_sub_category;
    View select_type;

    //activity codes
    private static int SORT_BY_CATEGORY_CODE = 20;
    private static int SORT_BY_SUB_CATEGORY_CODE = 25;
    private static int SORT_BY_TYPE_CODE = 30;


    String category_id;
    String sub_category_id;
    String type_id;

    int  selected_category;
    int  selected_sub_category;
    int  selected_type;

    TextView selected_category_text;
    TextView selected_sub_category_text;
    TextView selected_type_text;

    View apply_btn;

    View reset_btn;


    FilterMarketPlaceModel filterMarketPlaceModel;

    String selected_category_title;
    String selected_sub_category_title;
    String selected_type_title;

    View selected_header;

    private static final String CATEGORY_TEXT = "<b>Category :- </b>";
    private static final String SUB_CATEGORY_TEXT = "<b>Sub Category :- </b>";
    private static final String TYPE_TEXT = "<b>Type :- </b>";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter_market_place);

        setNormalPageToolbar("Filter Marketplace");

        sort_by_category = findViewById(R.id.sort_by_category);
        sort_by_sub_category = findViewById(R.id.sort_by_sub_category);
        select_type = findViewById(R.id.select_type);


        selected_header = findViewById(R.id.selected_header);

        selected_category_text = findViewById(R.id.selected_category_text);
        selected_sub_category_text = findViewById(R.id.selected_sub_category_text);
        selected_type_text = findViewById(R.id.selected_type_text);


        apply_btn = findViewById(R.id.apply_btn);
        reset_btn = findViewById(R.id.reset_btn);


        filterMarketPlaceModel = gson.fromJson(getIntent().getStringExtra("filtered_data"),FilterMarketPlaceModel.class);


        category_id = filterMarketPlaceModel.getCategoryId();
        sub_category_id = filterMarketPlaceModel.getSubCategoryId();
        type_id = filterMarketPlaceModel.getType();


        selected_category=filterMarketPlaceModel.getSelected_category();
        selected_sub_category=filterMarketPlaceModel.getSelected_sub_category();
        selected_type=filterMarketPlaceModel.getSelected_type();


        selected_category_title=filterMarketPlaceModel.getSelectedCategoryTitle();
        selected_sub_category_title=filterMarketPlaceModel.getSelectedSubCategoryTitle();
        selected_type_title=filterMarketPlaceModel.getSelectedTypeCategoryTitle();



        setLabels(CATEGORY_TEXT,selected_category_title,selected_category_text);
        setLabels(SUB_CATEGORY_TEXT,selected_sub_category_title,selected_sub_category_text);
        setLabels(TYPE_TEXT,selected_type_title,selected_type_text);

      //  selected_category_text.setText("" + selected_category_title);
      //  selected_sub_category_text.setText("" + selected_sub_category_title);
       // selected_type_text.setText("" + selected_type_title);

        sort_by_category.setOnClickListener(view -> {
            // category selection
            Intent intent = new Intent(FilterMarketPlace.this,FilterMarketPlaceList.class);
            intent.putExtra("category_id","0");
            intent.putExtra("sub_category_id","0");
            intent.putExtra("selected_item",selected_category);
            startActivityForResult(intent,SORT_BY_CATEGORY_CODE);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        sort_by_sub_category.setOnClickListener(view -> {
            // sub category selection
            if(!(category_id.equals("0"))){
                Intent intent = new Intent(FilterMarketPlace.this,FilterMarketPlaceList.class);
                intent.putExtra("category_id","" + category_id);
                intent.putExtra("sub_category_id","0");
                intent.putExtra("selected_item",selected_sub_category);
                startActivityForResult(intent,SORT_BY_SUB_CATEGORY_CODE);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            }
        });

        select_type.setOnClickListener(view -> {
            // currentType selection
            if(!(category_id.equals("0")) && !(sub_category_id.equals("0"))){
                Intent intent = new Intent(FilterMarketPlace.this,FilterMarketPlaceList.class);
                intent.putExtra("category_id","" + category_id);
                intent.putExtra("sub_category_id","" + sub_category_id);
                intent.putExtra("selected_item",selected_type);
                startActivityForResult(intent,SORT_BY_TYPE_CODE);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            }
        });
        apply_btn.setOnClickListener(view -> {
            if(!(category_id.equals("0"))){
                FilterMarketPlaceModel filterMarketPlaceModel = new FilterMarketPlaceModel(category_id,sub_category_id,type_id,selected_category,selected_sub_category,selected_type,selected_category_title,selected_sub_category_title,selected_type_title);
                Intent intent = new Intent();
                intent.putExtra("filtered_data", appUtils.convertToJson(filterMarketPlaceModel));
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        reset_btn.setOnClickListener(view -> {
            resetCategoryData();
            FilterMarketPlaceModel filterMarketPlaceModel = new FilterMarketPlaceModel(category_id,sub_category_id,type_id,selected_category,selected_sub_category,selected_type,selected_category_title,selected_sub_category_title,selected_type_title);
            Intent intent = new Intent();
            intent.putExtra("filtered_data", appUtils.convertToJson(filterMarketPlaceModel));
            setResult(RESULT_OK, intent);
            finish();

        });
    }

    private void setLabels(String initialText,String text,TextView textView){
        if(text.isEmpty()){
            return;
        }
        selected_header.setVisibility(View.VISIBLE);
        textView.setText(Html.fromHtml(initialText + text));

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            selected_header.setVisibility(View.VISIBLE);
            if(requestCode==SORT_BY_CATEGORY_CODE){
                resetSubCategoryData();
                category_id=data.getStringExtra("category_id");
                selected_category=data.getIntExtra("selected_index",0);
                selected_category_title= data.getStringExtra("selected_name");
                selected_category_text.setText(Html.fromHtml(CATEGORY_TEXT + selected_category_title));
            }
            else if(requestCode==SORT_BY_SUB_CATEGORY_CODE){
                resetTypeData();
                sub_category_id=data.getStringExtra("category_id");
                selected_sub_category=data.getIntExtra("selected_index",0);
                selected_sub_category_title = data.getStringExtra("selected_name");
                selected_sub_category_text.setText(Html.fromHtml(SUB_CATEGORY_TEXT + selected_sub_category_title));
            }
            else if(requestCode==SORT_BY_TYPE_CODE){
                type_id=data.getStringExtra("category_id");
                selected_type_title =data.getStringExtra("selected_name");
                selected_type_text.setText(Html.fromHtml(TYPE_TEXT + selected_type_title));

                selected_type=data.getIntExtra("selected_index",0);
            }
        }
    }
    private void resetCategoryData(){
        selected_header.setVisibility(View.GONE);
        selected_category=-1;
        selected_category_title="";
        selected_category_text.setText("");
        category_id="0";
        resetSubCategoryData();
        resetTypeData();
    }
    private void resetSubCategoryData(){
        selected_sub_category=-1;
        selected_sub_category_title="";
        selected_sub_category_text.setText("");
        sub_category_id="0";
        resetTypeData();
    }
    private void resetTypeData(){
        selected_type=-1;
        selected_type_title="";
        selected_type_text.setText("");
        type_id="0";
    }
}
