package com.mobileapp.krank.ResponseModels.DataModel;

import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Model.Enums.TypeOfSearch;


public class AllSearchResult  {
    TypeOfSearch typeOfSearch;


    NetworkEmpSearch networkEmp;

    NetworkSearch network;

    ListingDataArray listing;

    ListingDataArray listingSale;

    CustomCallBack viewAllClick;

    String headerText;


    public TypeOfSearch getTypeOfSearch() {
        return typeOfSearch;
    }

    public void setTypeOfSearch(TypeOfSearch typeOfSearch) {
        this.typeOfSearch = typeOfSearch;
    }

    public NetworkEmpSearch getNetworkEmp() {
        return networkEmp;
    }

    public void setNetworkEmp(NetworkEmpSearch networkEmp) {
        this.networkEmp = networkEmp;
    }

    public NetworkSearch getNetwork() {
        return network;
    }

    public void setNetwork(NetworkSearch network) {
        this.network = network;
    }

    public ListingDataArray getListing() {
        return listing;
    }

    public void setListing(ListingDataArray listing) {
        this.listing = listing;
    }

    public ListingDataArray getListingSale() {
        return listingSale;
    }

    public void setListingSale(ListingDataArray listingSale) {
        this.listingSale = listingSale;
    }


    public AllSearchResult(TypeOfSearch typeOfSearch) {
        this.typeOfSearch = typeOfSearch;
    }

    public CustomCallBack getViewAllClick() {
        return viewAllClick;
    }

    public void setViewAllClick(CustomCallBack viewAllClick) {
        this.viewAllClick = viewAllClick;
    }

    public AllSearchResult(TypeOfSearch typeOfSearch, CustomCallBack viewAllClick) {
        this.typeOfSearch = typeOfSearch;
        this.viewAllClick = viewAllClick;
    }

    public AllSearchResult(TypeOfSearch typeOfSearch, String headerText) {
        this.typeOfSearch = typeOfSearch;
        this.headerText = headerText;
    }

    public String getHeaderText() {
        return headerText;
    }

    public void setHeaderText(String headerText) {
        this.headerText = headerText;
    }
}
