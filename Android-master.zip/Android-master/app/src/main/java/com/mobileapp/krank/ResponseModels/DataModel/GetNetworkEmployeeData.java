package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


@Entity(tableName = "contact_import_table")
public class GetNetworkEmployeeData {


    //phone book
    @Ignore
    public static final int CONNECTED_CONTACTS_VIEW = 1;

    @Ignore
    public static final int NOT_CONNECTED_CONTACTS_VIEW = 2;

    @Ignore
    public static final int INVITE_CONTACTS_VIEW = 3;
    //phone book

    @Ignore
    public static int TOP_HEADER_VIEW = 6;


    // horizontal scroll
    @Ignore
    public static int MANAGE_VIEW = 4;

    //loader
    @Ignore
    public static int LOADER_VIEW = 5;

    //for list item
    @Ignore
    public static int NORMAL_VIEW = 0;

    //phone connect view
    @Ignore
    public static int CONNECT_PHONE_BOOK_VIEW = 7;


    @SerializedName("contact_id")
    @Expose
    @ColumnInfo(name = "contact_id")
    @PrimaryKey
    @NonNull
    int contact_id;


    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    private String id;


    @SerializedName("first_name")
    @Expose
    @ColumnInfo(name = "first_name")
    private String firstName;


    @SerializedName("last_name")
    @Expose
    @ColumnInfo(name = "last_name")
    private String lastName;


    @SerializedName("profile_pic")
    @Expose
    @ColumnInfo(name = "profile_pic")
    private String profilePic;


    @SerializedName("designation")
    @Expose
    @ColumnInfo(name = "designation")
    private String designation;


    @SerializedName("email_address")
    @Expose
    @ColumnInfo(name = "email_address")
    private String emailAddress;


    @SerializedName("online")
    @Expose
    @ColumnInfo(name = "online")
    private String online;


    @SerializedName("company_name")
    @Expose
    @ColumnInfo(name = "company_name")
    private String companyName;


    @SerializedName("con_id")
    @Expose
    @ColumnInfo(name = "con_id")
    private Integer conId;


    @SerializedName("isDelete")
    @Expose
    @ColumnInfo(name = "isDelete")
    private Integer isDelete;


    @SerializedName("conStatus")
    @Expose
    @ColumnInfo(name = "conStatus")
    private String conStatus;

    @SerializedName("connected_users_count")
    @Expose
    @ColumnInfo(name = "connected_users_count")
    private int connected_users_count;

    @SerializedName("company_pic")
    @Expose
    @ColumnInfo(name = "company_pic")
    private String company_pic;


    @SerializedName("company_id")
    @Expose
    @ColumnInfo(name = "company_id")
    private String company_id;


    @SerializedName("location")
    @Expose
    @ColumnInfo(name = "location")
    private String location;

    @SerializedName("number")
    @Expose
    @ColumnInfo(name = "number")
    private String number;


    @SerializedName("country_code")
    @Expose
    @ColumnInfo(name = "country_code")
    private String country_code;


    @Ignore
    private String status;


    @ColumnInfo(name = "view_type")
    private int viewType;

    @ColumnInfo(name = "totalUsersCount")
    private int totalUsersCount;

    @SerializedName("sim_id")
    @Expose
    @ColumnInfo(name = "device_id")
    private String device_id;

    @Ignore
    private boolean isItemSelected;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getConId() {
        return conId;
    }

    public void setConId(Integer conId) {
        this.conId = conId;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public boolean isItemSelected() {
        return isItemSelected;
    }

    public void setItemSelected(boolean itemSelected) {
        isItemSelected = itemSelected;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof GetNetworkEmployeeData)) {
            return false;
        }


        GetNetworkEmployeeData obj = (GetNetworkEmployeeData) o;

        if (obj.id == null) return false;

        return id.equals(obj.id);

    }

    public int getConnected_users_count() {
        return connected_users_count;
    }

    public void setConnected_users_count(int connected_users_count) {
        this.connected_users_count = connected_users_count;
    }

    public String getCompany_pic() {
        return company_pic;
    }

    public void setCompany_pic(String company_pic) {
        this.company_pic = company_pic;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Ignore
    public GetNetworkEmployeeData(int viewType) {
        this.viewType = viewType;
    }


    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }


    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }


    public int getContact_id() {
        return contact_id;
    }

    public void setContact_id(int contact_id) {
        this.contact_id = contact_id;
    }

    public GetNetworkEmployeeData() {
        // for room persistence
    }


    public boolean isSameViewType(GetNetworkEmployeeData obj) {
        if (obj == null) return false;
        return obj.viewType == viewType;
    }

    public String getSectionHeaderTitle() {
        switch (viewType) {
            case NOT_CONNECTED_CONTACTS_VIEW:
                return "Not Connected";
            case CONNECTED_CONTACTS_VIEW:
                return "Connected";
            case INVITE_CONTACTS_VIEW:
                return "Not on Krank";
            default:
                return null;
        }
    }

    public int getTotalUsersCount() {
        return totalUsersCount;
    }

    public void setTotalUsersCount(int totalUsersCount) {
        this.totalUsersCount = totalUsersCount;
    }

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

}
