package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.mobileapp.krank.Adapters.ImageAdapter;
import com.mobileapp.krank.Adapters.ListingDetailAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DetailItem;
import com.mobileapp.krank.Model.ListingDetailListItem;
import com.mobileapp.krank.Model.Enums.TypeOfDetailInListing;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailPartsItemDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailSpecUrlDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDetailVideoDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ListingInnerDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;
import com.mobileapp.krank.ResponseModels.ListingDetailResponseModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListingDetail extends BaseActivity {

    public static final int PRIVACY_ACTIVITY_CODE = 500;
    TabLayout mTabLayout;
    private ViewPager imgViewPager;
    ImageAdapter imgAdapter;
    ListingDetailDataModel listingDetailDataModel;

    List<ListingDetailListItem> listingDetailListItems;


    private RecyclerView listing_detail_recycler_view;
    private ListingDetailAdapter mListingDetailAdapter;

    ProgressBar loader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listing_detail_new);


        Log.e("item_index","=> " +getIntent().getIntExtra("item_index",0));
        initViews();
        init();

        getListingDetail();
    }
    private void initViews(){
        mTabLayout = findViewById(R.id.tab_dots);
        listing_detail_recycler_view =  findViewById(R.id.listing_detail_recycler_view);
        imgViewPager = findViewById(R.id.viewpager_cards);
        loader = findViewById(R.id.loader);
    }

    private void init(){
        listingDetailListItems = new ArrayList<>();
    }
    private void getListingDetail() {
        String slug = "";
        String id = "";


        if (getIntent().getStringExtra("listingName") != null) {
            slug = getIntent().getStringExtra("listingName").trim();
        } else {
            id = getIntent().getStringExtra("listing_id");
        }
        getAPI().getListingDetail(preference.getString(Constants.ACCESS_TOKEN), slug, id).enqueue(new Callback<ListingDetailResponseModel>() {
            @Override
            public void onResponse(Call<ListingDetailResponseModel> call, Response<ListingDetailResponseModel> response) {

                Log.e("listing success ->", "" + appUtils.convertToJson(call.request()));
                Log.e("listing success ->", "" + appUtils.convertToJson(response.body()));

                loader.setVisibility(View.GONE);


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        setNormalPageToolbar(response.body().getData().getListingName());
                        listingDetailDataModel = response.body().getData();

                        setUpImageAdapter();

                        listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.TOP_HEADER));

                        listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.HEADING,"Details"));

                        ListingInnerDataModel listingInnerDataModel = listingDetailDataModel.getListingData();


                        /*adding detail items*/
                        setDetailItem("Category",listingInnerDataModel.getCategoryName());
                        setDetailItem("Sub Category",listingInnerDataModel.getSubCategoryName());
                        setDetailItem("Type",listingInnerDataModel.getCat_type_name());
                        setDetailItem("Manufacturer",listingInnerDataModel.getManufacturer());
                        setDetailItem("Model",listingInnerDataModel.getModel());
                        setDetailItem("Equipment Number",listingInnerDataModel.getEquipmentNumber());
                        setDetailItem("Year Of Manufacture",listingInnerDataModel.getYearOfManf());
                        setDetailItem("Total Time(in Hours)",listingInnerDataModel.getTotalTime());
                        setDetailItem("Flow Rate",listingInnerDataModel.getFlowRate());
                        setDetailItem("Maximum Lifting Height",listingInnerDataModel.getMaxLifting());
                        setDetailItem("Condition",listingInnerDataModel.getCondition());
                        setDetailItem("Flight Rules",listingInnerDataModel.getListingFlightRules());
                        setDetailItem("Number of Seats",listingInnerDataModel.getNumberOfSeats());
                        setDetailItem("Registration Number",listingInnerDataModel.getRegistrationNumber());
                        setDetailItem("Gross Weight",listingInnerDataModel.getWeight());
                        setDetailItem("Transmission",listingInnerDataModel.getTransmission());
                        setDetailItem("Power",listingInnerDataModel.getPower());
                        setDetailItem("Power Fuel",listingInnerDataModel.getPowerFuel());
                        setDetailItem("Energy",listingInnerDataModel.getEnergy());
                        setDetailItem("Maximum Ampere",listingInnerDataModel.getMaxAmp());
                        setDetailItem("Minimum Ampere",listingInnerDataModel.getMinAmp());
                        setDetailItem("Drive (Select Drive)",listingInnerDataModel.getDrive());
                        setDetailItem("Capacity",listingInnerDataModel.getCapacity());
                        setDetailItem("Cylinders",listingInnerDataModel.getCylinders());
                        setDetailItem("Length (In Meters)",listingInnerDataModel.getLengths());
                        /*adding detail items*/
                       // setDetailItem("Serial Number",listingInnerDataModel.numb());

                        if(listingDetailDataModel.getSpecUrl().size()> 0){
                            listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.HEADING,"Specification URL(s)"));


                            for(ListingDetailSpecUrlDataModel item : listingDetailDataModel.getSpecUrl()){
                                listingDetailListItems.add(new ListingDetailListItem(item.getId(),item.getTitle(),item.getUrl(),item.getCreated_date(),item.getStatus(),item.getListing_id(),TypeOfDetailInListing.SPECIFICATION_URL));
                            }

                        }

                        if(listingDetailDataModel.getVideo().size()> 0){
                            listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.HEADING,"Video"));
                            for(ListingDetailVideoDataModel item : listingDetailDataModel.getVideo()){
                                listingDetailListItems.add(new ListingDetailListItem(item.getId(),item.getTitle(),item.getUrl(),item.getCreatedDate(),item.getStatus(),item.getListingId(),item.getVimeo_thumbnail(),TypeOfDetailInListing.VIDEO_VIEW));
                            }

                        }

                        if(listingDetailDataModel.getPartItems().size()> 0){
                            listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.HEADING," Parts Item"));

                            listingDetailListItems.add(new ListingDetailListItem(null,"QUANTITY","DESCRIPTION","TYPE",null,null,null,null,"NUMBER",TypeOfDetailInListing.PARTS_ITEM));


                            for(ListingDetailPartsItemDataModel item : listingDetailDataModel.getPartItems()){
                                listingDetailListItems.add(new ListingDetailListItem(item.getId(),item.getQuantity(),item.getDescription(),item.getPartItemType(),item.getCreatedDate(),item.getStatus(),item.getListingId(),item.getRfqId(),item.getNumber(),TypeOfDetailInListing.PARTS_ITEM));
                            }
                        }

                        listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.HEADING,"Location"));

                        // listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.VIDEO_VIEW));


                       if (listingDetailDataModel.getListingData().getLatlng() != null){
                            String address = getAddress();
                            if(address!=null){
                                String latLngToSend[] = listingDetailDataModel.getListingData().getLatlng().split(",");

                                ListingDetailListItem listingDetailListItem = new ListingDetailListItem(TypeOfDetailInListing.LOCATION);
                                listingDetailListItem.setLatitude(latLngToSend[0]);
                                listingDetailListItem.setLongitude(latLngToSend[1]);
                                listingDetailListItem.setAddress(address);
                                listingDetailListItems.add(listingDetailListItem);
                            }
                        }
                        listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.BOTTOM_BUTTONS));
                        mListingDetailAdapter = new ListingDetailAdapter(listingDetailListItems,ListingDetail.this,listingDetailDataModel);
                        listing_detail_recycler_view.setLayoutManager(new LinearLayoutManager(ListingDetail.this));
                        listing_detail_recycler_view.setAdapter(mListingDetailAdapter);
                        ((SimpleItemAnimator) listing_detail_recycler_view.getItemAnimator()).setSupportsChangeAnimations(false);

                    }else{
                       // Toast.makeText(ListingDetail.this,response.body().getMessage(),Toast.LENGTH_SHORT).show();


                        setNormalPageToolbar( "");

                        ListingDetailListItem listingDetailListItem = new ListingDetailListItem(TypeOfDetailInListing.ERROR_VIEW);

                        listingDetailListItem.setErrorText(response.body().getMessage());

                        listingDetailListItems.add(listingDetailListItem);

                        mListingDetailAdapter = new ListingDetailAdapter(listingDetailListItems,ListingDetail.this,listingDetailDataModel);
                        listing_detail_recycler_view.setLayoutManager(new LinearLayoutManager(ListingDetail.this));
                        listing_detail_recycler_view.setAdapter(mListingDetailAdapter);
                        ((SimpleItemAnimator) listing_detail_recycler_view.getItemAnimator()).setSupportsChangeAnimations(false);
                    }
                }else{
                    setNormalPageToolbar( "");
                }
            }
            @Override
            public void onFailure(Call<ListingDetailResponseModel> call, Throwable t) {
                loader.setVisibility(View.GONE);

                setNormalPageToolbar("");

                Log.e("listing failure ->", "" + appUtils.convertToJson(call.request()));
                Log.e("listing failure ->", "" + t.getMessage());
                onResponseFailure();
            }
        });
    }


    private void setDetailItem(String title,String itemName){
        if(checkForData(itemName)){
            listingDetailListItems.add(new ListingDetailListItem(TypeOfDetailInListing.DETAIL_ITEM,new DetailItem(title,itemName)));
        }
    }

    private String getAddress(){
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(ListingDetail.this, Locale.getDefault());

        String[] latLng = listingDetailDataModel.getListingData().getLatlng().split(",");
        String address = "";

        try {
            addresses = geocoder.getFromLocation(Double.parseDouble(latLng[0]), Double.parseDouble(latLng[1]), 1);
        } catch (IOException e) {
            return null;
        }

        if (addresses.size() > 0) {
            address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                      /*  String city = addresses.get(0).getLocality();
                        String state = addresses.get(0).getAdminArea();
                        String country = addresses.get(0).getCountryName();
                        String postalCode = addresses.get(0).getPostalCode();
                        String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL*/
        }
        return address;
    }

    private void setUpImageAdapter() {
        // hide dot when only 1 img
        if (listingDetailDataModel.getImages().size() <= 1) {
            mTabLayout.setVisibility(View.GONE);
        }


        imgAdapter = new ImageAdapter(listingDetailDataModel.getImages(), getDeviceResolution(), this);
        imgViewPager.setAdapter(imgAdapter);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        imgViewPager.setOffscreenPageLimit(listingDetailDataModel.getImages().size());
        mTabLayout.setupWithViewPager(imgViewPager);

       /* nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void act(View view) {
                imgViewPager.setCurrentItem(imgViewPager.getCurrentItem() + 1);
            }
        });
        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void act(View view) {
                imgViewPager.setCurrentItem(imgViewPager.getCurrentItem() - 1);

            }
        });*/


    }

    @Override
    public void onBackPressed() {
        if (listingDetailDataModel != null) {
            Intent intent = new Intent();
            intent.putExtra("isFavValue", listingDetailDataModel.getListingData().getIs_fav());
            intent.putExtra("item_index", getIntent().getIntExtra("item_index",0));

            setResult(RESULT_OK, intent);
            finish();
        } else {
            super.onBackPressed();
        }
    }

    private boolean checkForData(String data) {
        if (data == null || (data !=null && data.length() <= 0 || data.equals("0"))) {
            return false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == PRIVACY_ACTIVITY_CODE) {
                mListingDetailAdapter.getShareBottomSheet().updateDialogOnActivityResult(data);
            }
            else if(requestCode == Constants.ENQUIRY_ACTIVITY_CODE){
                if(data.getStringExtra("dealer_data_listing") !=null){
                    listingDetailDataModel.setDealers(Arrays.asList(gson.fromJson(data.getStringExtra("dealer_data_listing"), DealerDataListing[].class)));
                    mListingDetailAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                }
                if (data.getStringExtra("co_worker_assignments") != null) {
                    listingDetailDataModel.setAssignedUsers(Arrays.asList(gson.fromJson(data.getStringExtra("co_worker_assignments"), PublicMarketPlaceAssignment[].class)));
                    mListingDetailAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                }else if(data.getStringExtra("updated_network_status") !=null && data.getStringExtra("updated_connection_status") !=null){
                    listingDetailDataModel.setNetworkStatus(data.getStringExtra("updated_network_status"));
                    listingDetailDataModel.setConnectionStatus(data.getStringExtra("updated_connection_status"));
                    mListingDetailAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
                }
            }
        }
    }

}
