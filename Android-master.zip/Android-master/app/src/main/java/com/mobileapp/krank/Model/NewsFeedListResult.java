package com.mobileapp.krank.Model;

import android.arch.lifecycle.LiveData;
import android.arch.paging.PagedList;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

public class NewsFeedListResult {

    private LiveData<PagedList<NewsFeedArray>> data;
    private LiveData<String> networkErrors;

    public NewsFeedListResult(LiveData<PagedList<NewsFeedArray>> data, LiveData<String> networkErrors) {
        this.data = data;
        this.networkErrors = networkErrors;
    }
}
