package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkSearch;
import com.mobileapp.krank.ViewHolders.SearchViewHolders.NetworkViewHolder;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NetworkSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<NetworkSearch> items = new ArrayList<>();
    Context context;
    public SaveInSharedPreference preference;
    AppUtils appUtils;


    public NetworkSearchAdapter(List<NetworkSearch> items, Context context,SaveInSharedPreference preference) {
        this.items = items;
        this.context = context;
        this.preference = preference;
        appUtils = AppUtils.getInstance();

    }

    public NetworkSearchAdapter(NetworkSearch[] items, Context context) {

        this.items.addAll(Arrays.asList(items));
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        if (viewType == 1) {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_loader_item, parent, false);
            return new AppListItemLoader(v);
        } else if (viewType == 2) {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_view, parent, false);
            return new NetworkViewHolder(v);
        } else {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_loader_item, parent, false);
            return new AppListItemLoader(v);
        }

    }

    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getItemType()) {
            case NetworkSearch.PROGRESS_BAR:
                return 1;
            case NetworkSearch.ITEM_VIEW:
                return 2;
            default:
                return 2;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final NetworkSearch item = items.get(position);

        switch (item.getItemType()) {
            case NetworkSearch.ITEM_VIEW:
                ((NetworkViewHolder) holder).onBind(item, context, preference);

                break;
            case NetworkSearch.PROGRESS_BAR:
                break;
        }

    }


    @Override
    public int getItemCount() {
        return items.size();
    }

}







