package com.mobileapp.krank.Chat.GroupChatPakage;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.mobileapp.krank.Adapters.PeopleListInGroupChatAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Database.MyViewModelFactory;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.ViewModels.GroupChatMemberListViewModel;

import java.util.ArrayList;
import java.util.List;

public class PeopleListInGroupChat extends BaseActivity {

    private RecyclerView peopleListRecyclerView;
    private RecyclerView.Adapter peopleListRecyclerAdapter;
    List<GroupChatMembersDataModel> peopleListItems;
    LinearLayoutManager layoutManager;
    boolean isGroupAdmin;
    GroupChatMemberListViewModel groupChatMemberListViewModel;
    CustomCallBack customCallBack;
    View loader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people_list_in_group_chat);
        loader = findViewById(R.id.loader);
        peopleListRecyclerView = (RecyclerView) findViewById(R.id.people_list_recycler);
        setNormalPageToolbar("People");
        isGroupAdmin = getIntent().getBooleanExtra("is_group_admin",false);
        peopleListRecyclerView.setVisibility(View.GONE);

        groupChatMemberListViewModel = ViewModelProviders.of(PeopleListInGroupChat.this, new MyViewModelFactory(this.getApplication(),getIntent().getStringExtra("group_id"))).get(GroupChatMemberListViewModel.class);


        customCallBack = () -> {
            peopleListRecyclerView.setVisibility(View.VISIBLE);
            loader.setVisibility(View.GONE);
            observeList();
        };

        setUpList();
    }
    private void observeList(){
        groupChatMemberListViewModel.getmPeopleList().observe(this,peopleListItems -> {
            Log.e("observer","onChnage => " + peopleListItems.size());
            this.peopleListItems.clear();
            this.peopleListItems.addAll(peopleListItems);
            peopleListRecyclerAdapter.notifyDataSetChanged();
        });
    }

    private void setUpList() {

        peopleListItems = new ArrayList<>();
        layoutManager = new LinearLayoutManager(PeopleListInGroupChat.this);
        peopleListRecyclerAdapter =new PeopleListInGroupChatAdapter(peopleListItems,PeopleListInGroupChat.this,isGroupAdmin);
        peopleListRecyclerView.setLayoutManager(layoutManager);
        peopleListRecyclerView.setAdapter(peopleListRecyclerAdapter);

        groupChatMemberListViewModel.getmRepository().requestFromSever(customCallBack);
    }

    public GroupChatMemberListViewModel getGroupChatMemberListViewModel() {
        return groupChatMemberListViewModel;
    }
}
