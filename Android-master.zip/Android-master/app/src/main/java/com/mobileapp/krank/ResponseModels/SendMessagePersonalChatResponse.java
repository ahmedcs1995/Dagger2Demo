package com.mobileapp.krank.ResponseModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationStartDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.PrivateChatMessagesDataModel;

import java.util.List;

public class SendMessagePersonalChatResponse {
    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("data")
    @Expose
    private ConversationStartDataModel data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ConversationStartDataModel getData() {
        return data;
    }

    public void setData(ConversationStartDataModel data) {
        this.data = data;
    }
}
