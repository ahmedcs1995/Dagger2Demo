package com.mobileapp.krank.Adapters;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.mobileapp.krank.Activities.SearchKrank;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CallBacks.ListingFavCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.MarketPlaceFunctions;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.ViewHolders.MarketPlaceViewHolder.MarketPlaceViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.KrankPostViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.AddRemoveFavResponse;
import com.mobileapp.krank.ResponseModels.DataModel.AllSearchResult;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkEmpSearch;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkSearch;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.SearchTabs.All;
import com.mobileapp.krank.ViewHolders.SearchViewHolders.NetworkEmployeeViewHolder;
import com.mobileapp.krank.ViewHolders.SearchViewHolders.NetworkViewHolder;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;
import com.mobileapp.krank.Utils.ShareBottomSheet;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AllSearchResultAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<AllSearchResult> items;
    ListingFavCallBack getFavCallBack;
    ShareBottomSheet mListingSharePopUp;
    SaveInSharedPreference preference;
    All all;
    MarketPlaceFunctions marketPlaceFunctions;
    NewsFeedFunctions newsFeedFunctions;


    Gson gson = CustomGson.getInstance();

    private final static int PEOPLE_SEARCH = 1;
    private final static int NETWORK_SEARCH = 2;
    private final static int RENT_LISTING_SEARCH = 3;
    private final static int SALE_LISTING_SEARCH = 4;
    private final static int VIEW_ALL_BUTTON = 5;

    private final static int HEADER_ITEM = 17;



    private class ViewAllBtnViewHolder extends RecyclerView.ViewHolder {
        View view_all_btn;

        ViewAllBtnViewHolder(View itemView) {
            super(itemView);
            view_all_btn = itemView.findViewById(R.id.view_all_btn);
        }
    }

    private class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView header_text;

        HeaderViewHolder(View itemView) {
            super(itemView);
            header_text = itemView.findViewById(R.id.header_text);
        }
    }

    public AllSearchResultAdapter(List<AllSearchResult> items, All all, SaveInSharedPreference preference) {
        this.items = items;
        this.all = all;
        this.preference = preference;
        this.preference = preference;
        initDialog(preference);
        getFavCallBack = getFavCallBack();
        marketPlaceFunctions = new MarketPlaceFunctions(all, this);

        newsFeedFunctions = new NewsFeedFunctions(all, ((SearchKrank) all.getActivity()).getDeviceResolution(), true);
    }

    private void initDialog(SaveInSharedPreference preference) {
        mListingSharePopUp = new ShareBottomSheet
                .Builder(this.all, preference)
                .setListeners(getShareCallBack())
                .create();
    }

    private CustomShareCallBack getShareCallBack() {
        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(all.getContext(), SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", gson.toJson(selectedPrivacy));
            intent.putExtra("selected_network_group", gson.toJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", gson.toJson(tempDealerGroup));
            all.startActivityForResult(intent, Constants.PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }

    private ListingFavCallBack getFavCallBack() {
        return (item, fav_btn, position) -> {
            addToFavUnFav(item, fav_btn, position);
        };
    }

    private void addToFavUnFav(final ListingDataArray item, final View fav_btn, final int position) {
        final String isFav = item.getIsFav();
        final int action;
        if (isFav != null) {
            action = 2;
        } else {
            action = 1;
        }
        ServiceManager.getInstance().getAPI().listingFavUnFav(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(item.getId()), String.valueOf(item.getIsFav()), String.valueOf(action)).enqueue(new Callback<AddRemoveFavResponse>() {
            @Override
            public void onResponse(Call<AddRemoveFavResponse> call, Response<AddRemoveFavResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (isFav == null) {
                            item.setIsFav(response.body().getData().getFav_id());

                        } else {
                            item.setIsFav(null);
                        }
                    }
                    notifyItemChanged(position);
                    fav_btn.setEnabled(true);
                }
            }

            @Override
            public void onFailure(Call<AddRemoveFavResponse> call, Throwable t) {
                fav_btn.setEnabled(true);

            }
        });
    }

    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getTypeOfSearch()) {
            case PEOPLE_SEARCH:
                return PEOPLE_SEARCH;
            case NETWORK_SEARCH:
                return NETWORK_SEARCH;
            case RENT_LISTING_SEARCH:
                return RENT_LISTING_SEARCH;
            case SALE_LISTING_SEARCH:
                return SALE_LISTING_SEARCH;
            case VIEW_ALL_BUTTON:
                return VIEW_ALL_BUTTON;
            case HEADER_ITEM:
                return HEADER_ITEM;
            default:
                return -1;
        }
    }


    @Override
    public int getItemCount() {
        return items.size();
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case PEOPLE_SEARCH:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.connection_view, parent, false);
                return new NetworkEmployeeViewHolder(view);
            case NETWORK_SEARCH:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_view, parent, false);
                return new NetworkViewHolder(view);
            case RENT_LISTING_SEARCH:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sale_listing_searched_item, parent, false);
                return new MarketPlaceViewHolder(view).setSearchCallBacks(items, all, mListingSharePopUp, getFavCallBack);
            case SALE_LISTING_SEARCH:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sale_listing_searched_item, parent, false);
                return new MarketPlaceViewHolder(view).setSaleListingSearchCallBacks(items, all, mListingSharePopUp, getFavCallBack);
            case VIEW_ALL_BUTTON:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_view_all_btn, parent, false);
                return new ViewAllBtnViewHolder(view);
            case HEADER_ITEM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.header_item, parent, false);
                return new HeaderViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_view_all_btn, parent, false);
                return new ViewAllBtnViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final AllSearchResult item = items.get(position);
        switch (item.getTypeOfSearch()) {
            case HEADER_ITEM:
                ((HeaderViewHolder) holder).header_text.setText(item.getHeaderText());
                break;
            case VIEW_ALL_BUTTON:
                ((ViewAllBtnViewHolder) holder).view_all_btn.setOnClickListener(view -> {
                    if (item.getViewAllClick() != null) {
                        item.getViewAllClick().act();
                    }
                });
                break;
            case NETWORK_SEARCH:
                setNetworkView(holder, item.getNetwork());
                break;
            case PEOPLE_SEARCH:
                setNetworkEmployeeView(holder, item.getNetworkEmp());
                break;
            case RENT_LISTING_SEARCH:
                marketPlaceFunctions.setPostView(holder, position, item.getListing());
                break;
            case SALE_LISTING_SEARCH:
                marketPlaceFunctions.setPostView(holder, position, item.getListingSale());
                break;
            default:
                break;
        }
    }




    private void setNetworkEmployeeView(RecyclerView.ViewHolder holder, NetworkEmpSearch item) {
        NetworkEmployeeViewHolder viewHolder = (NetworkEmployeeViewHolder) holder;
        viewHolder.onBind(item, all.getContext(),preference);
    }

    private void setNetworkView(RecyclerView.ViewHolder holder, NetworkSearch item) {
        NetworkViewHolder viewHolder = (NetworkViewHolder) holder;
        viewHolder.onBind(item, all.getContext(), preference);
    }

    public ShareBottomSheet getmListingSharePopUp() {
        return mListingSharePopUp;
    }

    public void setMarketPlaceFunctions(MarketPlaceFunctions marketPlaceFunctions) {
        this.marketPlaceFunctions = marketPlaceFunctions;
    }

    public NewsFeedFunctions getNewsFeedFunctions() {
        return newsFeedFunctions;
    }

    public void setNewsFeedFunctions(NewsFeedFunctions newsFeedFunctions) {
        this.newsFeedFunctions = newsFeedFunctions;
    }
}







