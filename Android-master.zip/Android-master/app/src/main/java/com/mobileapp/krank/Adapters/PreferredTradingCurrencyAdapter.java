package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.CustomDropDown.PreferredTradingCurrencyDropDown;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CurrenciesListData;

import java.util.ArrayList;
import java.util.List;

public class PreferredTradingCurrencyAdapter extends RecyclerView.Adapter<PreferredTradingCurrencyAdapter.ViewHolder> {
    public List<CurrenciesListData> items = new ArrayList<>();
    PreferredTradingCurrencyDropDown preferredTradingCurrencyDropDown;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView name;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            name = item.findViewById(R.id.name);
        }
    }

    public PreferredTradingCurrencyAdapter(List<CurrenciesListData> items,  PreferredTradingCurrencyDropDown preferredTradingCurrencyDropDown) {
        this.items = items;
        this.preferredTradingCurrencyDropDown = preferredTradingCurrencyDropDown;
    }
    @Override
    public PreferredTradingCurrencyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.drop_adapter_item, parent, false);
        return new PreferredTradingCurrencyAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PreferredTradingCurrencyAdapter.ViewHolder holder, final int position) {
        final CurrenciesListData item = items.get(position);

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setItemSelected(true);
                preferredTradingCurrencyDropDown.selectedIndex = position;
                uncheckAllItems(item);
                notifyDataSetChanged();
            }
        });
        holder.name.setText("" + item.getCurrencyValue());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void uncheckAllItems(CurrenciesListData item){
        for(int i=0; i < items.size();i++){
            if(items.get(i).getCurrencyValue().equals(item.getCurrencyValue())){
                continue;
            }
            items.get(i).setItemSelected(false);
        }
    }
}








