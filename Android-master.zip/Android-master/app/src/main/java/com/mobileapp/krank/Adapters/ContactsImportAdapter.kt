package com.mobileapp.krank.Adapters

import android.arch.paging.PagedListAdapter
import android.content.Context
import android.support.v4.content.ContextCompat
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CallBacks.CallBackWithData
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Model.Enums.ConNetStatus
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.BaseViewHolder
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.ListItemViewHolder

class ContactsImportAdapter(val context: Context, private val callBack: CallBackWithData<GetNetworkEmployeeData>?, private val userJoinedId: String?) : PagedListAdapter<GetNetworkEmployeeData, RecyclerView.ViewHolder>(ContactsDiffCallback()), CallBackWithPosTypeAndView, CallBackWithAdapterPosAndType {

    override fun act(position: Int, type: Int) {
        if (callBack == null) return
        callBack.act(getItem(position), type, null)
    }





    var contactsImportMessage: String = ""

    var NotOnKrankUsersCount : Int = 0
    var connectedUsersCount : Int = 0
    var notConnectedUsersCount : Int = 0
    var NotConnectedRequestPendingCounts : Int = 0



    override fun act(position: Int, type: Int, view: View) {
        if (type == BaseViewHolder.CONNECT_ALL) {
            if (callBack == null) return

            callBack.act(getItem(position), BaseViewHolder.CONNECT_ALL, view)
            return
        }
        onConnectionButtonPressed(position, view)
    }


    private fun onConnectionButtonPressed(position: Int, view: View) {
        if (callBack == null) return

        //connection and network request
        when (AppUtils.getConNetStatus(getItem(position)?.conStatus)) {
            ConNetStatus.REQUEST_PENDING -> {

            }
            ConNetStatus.CONNECTED -> {
                if (Integer.parseInt(getItem(position)?.id) != Constants.EMMA_COOPER_ID) {
                    callBack.act(getItem(position), BaseViewHolder.REMOVE_CONNECTION, view)

                }
            }
            ConNetStatus.INVITATION_RECEIVED -> {
                callBack.act(getItem(position), BaseViewHolder.ACCEPT_INVITE, view)
            }
            ConNetStatus.NOT_CONNECTED -> {
                callBack.act(getItem(position), BaseViewHolder.SEND_CONNECTION_REQUEST, view)

            }
            ConNetStatus.NONE -> {
                callBack.act(getItem(position), BaseViewHolder.SEND_INVITE, view)
            }
        }
    }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        val listHolder = holder as BaseViewHolder


        //for highLight View
        if (userJoinedId != null && userJoinedId == getItem(position)?.id) {
            listHolder.root_view.setBackgroundColor(ContextCompat.getColor(context, R.color.unread_notification))
        } else {
            listHolder.root_view.setBackgroundColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
        }

        //header
        (holder as TopHeaderViewHolder).onBindHeader(getItem(position), position, context)



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return TopHeaderViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.top_header_contacts_view_item, parent, false), this, this)

    }



    inner class TopHeaderViewHolder(item: View, callBack: CallBackWithAdapterPosAndType?, connectionRequestCallBack: CallBackWithPosTypeAndView?) : ListItemViewHolder(item, callBack, connectionRequestCallBack) {
        private var header_heading_text_view: TextView = item.findViewById(R.id.header_heading_text_view)
        private var des: TextView = item.findViewById(R.id.des)
        private var follow_btn: View = item.findViewById(R.id.follow_btn)
        private var header_container: View = item.findViewById(R.id.header_container)

        init {
            follow_btn.setOnClickListener {
                if (adapterPosition < 0 || connectionRequestCallBack == null) return@setOnClickListener
                connectionRequestCallBack.act(adapterPosition, CONNECT_ALL, follow_btn)

            }
        }

        fun onBindHeader(item: GetNetworkEmployeeData?, position: Int, context: Context) {
            if(item == null) return
           // if(item.show_section_type == GetNetworkEmployeeData.SHOW_HEADER_AND_SECTION){
            if(position == 0){
                header_container.visibility = View.VISIBLE

               // header_heading_text_view.text = item?.totalUsersCount.toString() + " of Your Contact are on Krank"

               val totalUsersCount = connectedUsersCount + notConnectedUsersCount


                /**
                 * Follow Button
                 */
                if(NotConnectedRequestPendingCounts <=0){
                    follow_btn.visibility=View.GONE
                }else{
                    follow_btn.visibility=View.VISIBLE
                }


                /**
                 * Heading
                 */
                if(totalUsersCount <= 1){
                    header_heading_text_view.text =  "$totalUsersCount of Your Contact are on Krank"
                }else{
                    header_heading_text_view.text =  "$totalUsersCount of Your Contacts are on Krank"
                }

                des.text = contactsImportMessage
              //  des.text = "Connect them to see their listing and article"

            }else{
                header_container.visibility = View.GONE
            }

           // onBindContactsView(getItem(position), context)

            onBindContactsView(getItem(position), if (position == 0) null else getItem(position - 1),context)
        }
    }

    class ContactsDiffCallback : DiffUtil.ItemCallback<GetNetworkEmployeeData>() {


        override fun areItemsTheSame(oldItem: GetNetworkEmployeeData, newItem: GetNetworkEmployeeData): Boolean {
            return (oldItem.contact_id == newItem.contact_id)
        }

        override fun areContentsTheSame(oldItem: GetNetworkEmployeeData, newItem: GetNetworkEmployeeData): Boolean {
            return (oldItem.conStatus == newItem.conStatus)
        }
    }
}