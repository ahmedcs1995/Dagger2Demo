package com.mobileapp.krank.Functions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spannable;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Activities.PlayerActivity;
import com.mobileapp.krank.Activities.ListOfEmployeesAndConnections;
import com.mobileapp.krank.Activities.YoutubePlayer;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.KrankPostViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.AutoPostHtml;
import com.mobileapp.krank.ResponseModels.DataModel.HtmlParse;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

public class NewsFeedFunctions {

    public SaveInSharedPreference preference;
    Context context;

    DeviceInfo deviceInfo;


    private boolean hideDeleteView;


    public NewsFeedFunctions(Activity activity, DeviceInfo deviceInfo, boolean hideDeleteView) {
        init(activity, deviceInfo, hideDeleteView);
    }

    public NewsFeedFunctions(Fragment fragment, DeviceInfo deviceInfo, boolean hideDeleteView) {
        init(fragment.getContext(), deviceInfo, hideDeleteView);
    }

    private void init(Context context, DeviceInfo deviceInfo, boolean hideDeleteView) {
        preference = new SaveInSharedPreference(context);
        this.context = context;
        this.deviceInfo = deviceInfo;
        this.hideDeleteView = hideDeleteView;
    }





    public void setTypeImgPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) { //image based post


        final ImageViewHolder viewHolder = ((ImageViewHolder) holder);



        /**
        * header
        * */
        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);
        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());
        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());


        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }



        /**
        * footer
        * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }




        /**
         *
         * content
         *
         * */
        AppUtils.resizeImage(item.getImage_width(), item.getImage_height(), viewHolder.postImg, deviceInfo);

        if (item.getAsset().length() > 0) {
            viewHolder.postImg.setVisibility(View.VISIBLE);

            viewHolder.postImg.setImageURI(Uri.parse(item.getAsset()));

        } else {
            viewHolder.postImg.setVisibility(View.GONE);
        }

        viewHolder.post_des.setText("" + item.getDescription());



    }

    public void setTypeTextPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {

        final TextPostHolder viewHolder = ((TextPostHolder) holder);



        /**
         * Header
         * */
        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);

        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }
        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());

        viewHolder.time_text_view.setText(item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());


        /**
         * Content
         * */
        viewHolder.post_des_text.setText(item.getDescription());



        /**
         *
         *Footer
         *
         **/
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }


        if (item.getPrivacy_id() == 1) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }


    }

    public void setCheckInTypePost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {
        final CheckInHolder viewHolder = ((CheckInHolder) holder);



        /**
         * Header
         * */
        viewHolder.name_with_action.setText(item.getHeaderSpannableString());
        viewHolder.name_with_action.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.check_in_text.setText(item.getCheckInAddress());
        viewHolder.check_in_text.setMovementMethod(LinkMovementMethod.getInstance());

        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);

        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);

        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.company_text_view.setText(AppUtils.getCompanyAndDesignation(item.getCompany_name(), item.getDesignation()));




       /**
        * Content
        * */

        long width = deviceInfo.getDeviceWidth();
        String zoom = "13";
        final String url = "https://maps.googleapis.com/maps/api/staticmap?markers=" + item.getDescription() + "&zoom=" + zoom + "&size=" + width + "x600&sensor=false&key=" + Constants.GOOGLE_API_KEY;

        viewHolder.check_in_map.getLayoutParams().width = (int) width;
        viewHolder.check_in_map.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        viewHolder.check_in_map.setAspectRatio((float) deviceInfo.getDeviceWidth() / 600);
        viewHolder.check_in_map.setImageURI(Uri.parse(url));


        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }
    }

    public void setTypeLinkedPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {
        final LinkViewHolder viewHolder = ((LinkViewHolder) holder);


        final HtmlParse htmlParse = item.getHtmlParse();

        //   viewHolder.like_container.setOnClickListener(view -> sendLike(item, position, viewHolder.like_container));

        /**
         * Header
         * */

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);

        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);

        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }


        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());


        /**
         * Content
         * */
        viewHolder.heading_for_link_post.setText("" + htmlParse.getTitle());

        htmlParse.setDescription(htmlParse.getDescription().replace("... Read more", ""));

        if (htmlParse.getDescription() != null && !(htmlParse.getDescription().isEmpty())) {
            viewHolder.description_for_link_post.setText("" + htmlParse.getDescription());
        } else {
            viewHolder.description_for_link_post.setText("" + item.getShareUrl());
        }

        if (htmlParse.getTitle().length() > 0) {
            viewHolder.heading_for_link_post.setVisibility(View.VISIBLE);
        } else {
            viewHolder.heading_for_link_post.setVisibility(View.GONE);
        }


        if (htmlParse.getImage().length() > 0) {
            viewHolder.link_img.setVisibility(View.VISIBLE);

           // AppUtils.resizeImage(item.getHtmlParse().getImage_width(), item.getHtmlParse().getImage_height(), viewHolder.link_img, deviceInfo);

            viewHolder.link_img.setImageURI(Uri.parse(htmlParse.getImage()));

        } else {
            viewHolder.link_img.setVisibility(View.GONE);
        }


        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);

        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }
        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }


    }


    public void setNetworkPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {

        final NetworkPost viewHolder = ((NetworkPost) holder);


        final AutoPostHtml autoPostHtml = item.getAutoPostHtml();

        viewHolder.company_one_text.setText("" + autoPostHtml.getMyCompanyName());
        viewHolder.company_two_text.setText("" + autoPostHtml.getConnectCompanyName());


        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);
        Glide.with(context).load(autoPostHtml.getMyCompanyLogo()).into(viewHolder.company_one);
        Glide.with(context).load(autoPostHtml.getConnectCompanyLogo()).into(viewHolder.company_two);

        // viewHolder.name.setText(setPostHeaderForCompanyFeed(item, false));
        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());

        if (autoPostHtml.getDescription().size() > 0) {
            viewHolder.heading.setText("" + autoPostHtml.getDescription().get(0));
        }

        if (autoPostHtml.getDescription().size() > 1) {
            viewHolder.descritpion.setText("" + autoPostHtml.getDescription().get(1));
        }
        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());

        //  viewHolder.company_text_view.setText(AppUtils.getCompanyAndDesignation(item.getCompany_name(), item.getDesignation()));


        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());

        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        viewHolder.comment_container.setVisibility(View.GONE);


        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }


        viewHolder.addConnectionsBtn.setOnClickListener(view -> {
            Intent intent = new Intent(context, ListOfEmployeesAndConnections.class);
            intent.putExtra(ListOfEmployeesAndConnections.NAME_KEY, autoPostHtml.getConnectCompanyName());
            intent.putExtra(ListOfEmployeesAndConnections.COMPANY_ID, autoPostHtml.getConnect_company_id());
            context.startActivity(intent);
            //newsfeed.getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        viewHolder.delete_view_post.setVisibility(View.GONE);

    }

    /**
     * Show the owner name (in case of share listing/Article)
     * */

    /**
     * Owner of Listing Article
     */
    private void setPostActionForListingAndArticle(NewsFeedArray item, TextView actionView, TextView ownerName) {

        if (item.isPostOwner()) {
            item.setPostShareText(item.getPostShareText().replace(item.getOwner().getName(), ""));
            actionView.setText("" + item.getPostShareText());
            ownerName.setText("" + item.getOwner().getName());
            ownerName.setVisibility(View.VISIBLE);
        } else {
            actionView.setText("" + item.getPostShareText());
            ownerName.setVisibility(View.GONE);
        }
    }

    public void setDealerPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {

        final DealerPost viewHolder = ((DealerPost) holder);

        AutoPostHtml autoPostHtml = item.getAutoPostHtml();



        /**
         * Header
         * */

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);
        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());

        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());

        viewHolder.delete_view_post.setVisibility(View.GONE);


        /**
         * Content
         * */
        viewHolder.company_one_text.setText("" + autoPostHtml.getMyCompanyName());
        viewHolder.company_two_text.setText("" + autoPostHtml.getConnectCompanyName());



        Glide.with(context).load(autoPostHtml.getMyCompanyLogo()).into(viewHolder.company_one);
        Glide.with(context).load(autoPostHtml.getConnectCompanyLogo()).into(viewHolder.company_two);


        /**
         * Types of Dealer Post
         * */
        if (autoPostHtml.getDealer_post_type() == Constants.DEALER_POST_TYPE_THREE) {
            viewHolder.view_profile_btn.setVisibility(View.GONE);
            viewHolder.add_connections_btn.setVisibility(View.GONE);
            viewHolder.btn_container.setVisibility(View.GONE);
            if (autoPostHtml.getDescription().size() > 0) {
                viewHolder.heading.setText(item.getDealerPostString());
                viewHolder.heading.setMovementMethod(LinkMovementMethod.getInstance());
                if (autoPostHtml.getDescription().size() > 1) {
                    viewHolder.descritpion.setText("" + autoPostHtml.getDescription().get(1));
                }
            }
        } else if (autoPostHtml.getDealer_post_type() == Constants.DEALER_POST_TYPE_TWO) {
            viewHolder.view_profile_btn.setVisibility(View.VISIBLE);
            viewHolder.add_connections_btn.setVisibility(View.VISIBLE);
            viewHolder.btn_container.setVisibility(View.VISIBLE);


            viewHolder.heading.setText(item.getDealerPostString());
            viewHolder.heading.setMovementMethod(LinkMovementMethod.getInstance());

            if (autoPostHtml.getDescription().size() > 1) {
                viewHolder.descritpion.setText("" + autoPostHtml.getDescription().get(1));
            }


            viewHolder.add_connections_btn.setOnClickListener(view -> {
                Intent intent = new Intent(context, ListOfEmployeesAndConnections.class);
                intent.putExtra(ListOfEmployeesAndConnections.NAME_KEY, autoPostHtml.getConnectCompanyName());
                intent.putExtra(ListOfEmployeesAndConnections.COMPANY_ID, autoPostHtml.getConnect_company_id());
                context.startActivity(intent);
            });

        } else {
            //type one post
            viewHolder.view_profile_btn.setVisibility(View.VISIBLE);
            viewHolder.add_connections_btn.setVisibility(View.VISIBLE);
            viewHolder.btn_container.setVisibility(View.VISIBLE);


            if (autoPostHtml.getDescription().size() > 0) {
                viewHolder.heading.setText(autoPostHtml.getDescription().get(0));
            }

            if (autoPostHtml.getDescription().size() > 1) {
                viewHolder.descritpion.setText("" + autoPostHtml.getDescription().get(1));
            }


            viewHolder.add_connections_btn.setOnClickListener(view -> {
                Intent intent = new Intent(context, ListOfEmployeesAndConnections.class);
                intent.putExtra(ListOfEmployeesAndConnections.NAME_KEY, autoPostHtml.getConnectCompanyName());
                intent.putExtra(ListOfEmployeesAndConnections.COMPANY_ID, autoPostHtml.getConnect_company_id());
                context.startActivity(intent);
            });
        }

        /**
         * Types of Dealer Post
         * */





        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        viewHolder.comment_container.setVisibility(View.GONE);


        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }

    }

    public void setTypeListingPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {


        final ListingArticleViewHolder viewHolder = ((ListingArticleViewHolder) holder);





        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);

        /**
         * Header
         * */
        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
            // viewHolder.delete_view_post.setOnClickListener(view -> showDeletePopUpMenu(view, item, position));
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }


        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.time_text_view.setText("" + item.getCreated_date());

        setPostActionForListingAndArticle(item, viewHolder.action, viewHolder.owner_name);


        /**
         * Content
         * */

        viewHolder.post_title_text_view.setText("Listing");

        final HtmlParse htmlParse = item.getHtmlParse();


        htmlParse.setDescription(htmlParse.getDescription().replace("Read more", "<font color='#1578FC'><b>Read more</b></font>"));

        if (htmlParse.getImage() != null && htmlParse.getImage().length() > 0 && htmlParse.getImage_width() > 0 && htmlParse.getImage_height() > 0) {
            AppUtils.resizeImage(item.getHtmlParse().getImage_width(), item.getHtmlParse().getImage_height(), viewHolder.post_img, deviceInfo);


            viewHolder.post_img.setImageURI(Uri.parse(htmlParse.getImage()));


            viewHolder.post_img.setVisibility(View.VISIBLE);
        } else {
            viewHolder.post_img.setVisibility(View.GONE);
            viewHolder.post_title_text_view.setVisibility(View.GONE);
        }
        viewHolder.heading.setText("" + htmlParse.getTitle());
        viewHolder.description.setText(Html.fromHtml(htmlParse.getDescription()), TextView.BufferType.SPANNABLE);




        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        viewHolder.share_container.setVisibility(View.GONE);
        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }



    }

    public void setTypeYoutubeVideoPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {


        final VideoPostViewHolder viewHolder = ((VideoPostViewHolder) holder);


        /**
         * Header
         * */

        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
            //  viewHolder.delete_view_post.setOnClickListener(view -> showDeletePopUpMenu(view, item, position));
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);

        //  viewHolder.name.setText(setPostHeaderDetail(item));
        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());




        /**
         * Content
         * */
        Glide.with(context).load(R.drawable.youtube_thumbnail_img).into(viewHolder.btnYoutube_player);


        String videoUrl = item.getHtmlParse().getVideoUrl();
        final String videoId = AppUtils.getYoutubeIdFromUrl(videoUrl);


        // Glide.with(context).load().apply(options).into(youtubeViewHolder.youTubeThumbnailView);
        Glide.with(context).load("http://img.youtube.com/vi/" + videoId + "/0.jpg").into(viewHolder.youtube_thumbnail);

        viewHolder.video_click.setOnClickListener(view -> {
            Intent intent = new Intent(context, YoutubePlayer.class);
            intent.putExtra("videoId", "" + videoId);
            context.startActivity(intent);
        });





        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }
    }

    public void setTypeArticleAuctionPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item, String title) {


        final ListingArticleViewHolder viewHolder = ((ListingArticleViewHolder) holder);


        final HtmlParse htmlParse = item.getHtmlParse();





        /**
         * Header
         * */

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);


        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.time_text_view.setText("" + item.getCreated_date());


        setPostActionForListingAndArticle(item, viewHolder.action, viewHolder.owner_name);

        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }


        /**
         * Content
         * */
        viewHolder.heading.setText("" + htmlParse.getTitle());

        viewHolder.description.setText(Html.fromHtml(htmlParse.getDescription()), TextView.BufferType.SPANNABLE);


        if (htmlParse.getImage() != null && htmlParse.getImage().length() > 0 && htmlParse.getImage_height() > 0 && htmlParse.getImage_height() > 0) {
            AppUtils.resizeImage(item.getHtmlParse().getImage_width(), item.getHtmlParse().getImage_height(), viewHolder.post_img, deviceInfo);
            viewHolder.post_img.setImageURI(Uri.parse(item.getHtmlParse().getImage()));
            viewHolder.post_img.setVisibility(View.VISIBLE);
        } else {
            viewHolder.post_img.setVisibility(View.GONE);
            viewHolder.post_title_text_view.setVisibility(View.GONE);
        }



        htmlParse.setDescription(htmlParse.getDescription().replace("Read more", "<font color='#1578FC'><b>Read more</b></font>"));
        if (title.equals("Auction")) {
            viewHolder.post_title_text_view.setBackgroundColor(ContextCompat.getColor(context, R.color.auction_color));
        } else {
            viewHolder.post_title_text_view.setBackgroundColor(ContextCompat.getColor(context, R.color.article_color));
        }

        viewHolder.post_title_text_view.setText(title);


        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());


        viewHolder.share_container.setVisibility(View.GONE);
        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }

    }


    public void setTypeVimeoVideoPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {
        final VideoPostViewHolder viewHolder = ((VideoPostViewHolder) holder);


        /**
         * Header
         * */

        Glide.with(context).load(item.getProfile_pic()).into(viewHolder.profileImg);


        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());


        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("" + item.getPostShareText());



        if (String.valueOf(item.getUser_id()).equals(preference.getString(Constants.USER_ID)) && !hideDeleteView) {
            viewHolder.delete_view_post.setVisibility(View.VISIBLE);
            // viewHolder.delete_view_post.setOnClickListener(view -> showDeletePopUpMenu(view, item, position));
        } else {
            viewHolder.delete_view_post.setVisibility(View.GONE);
        }


        /**
         * Content
         * */
        Glide.with(context).load(R.drawable.youtube_thumbnail_img).into(viewHolder.btnYoutube_player);


        String videoId;
        String videoUrl = item.getHtmlParse().getVideoUrl();
        if (videoUrl.indexOf('?') != -1) {
            int startIndex = videoUrl.lastIndexOf('/') + 1;
            int lastIndex = videoUrl.indexOf('?');
            videoId = videoUrl.substring(startIndex, lastIndex);
        } else {
            int startIndex = videoUrl.lastIndexOf('/') + 1;
            videoId = videoUrl.substring(startIndex);
        }


        Glide.with(context).load(item.getHtmlParse().getImage()).into(viewHolder.youtube_thumbnail);

        final String videoIdToSend = videoId;



        viewHolder.video_click.setOnClickListener(view -> {
            Intent intent = new Intent(context, PlayerActivity.class);
            intent.putExtra("videoId", videoIdToSend);
            context.startActivity(intent);
        });







        /**
         * Footer
         * */
        viewHolder.no_of_like.setText("" + item.getLike_count());
        viewHolder.no_of_comments.setText("" + item.getComment_count());

        if (item.getShareUrl() != null && item.getPrivacy_id() == 1 && Patterns.WEB_URL.matcher(item.getShareUrl().toLowerCase()).matches()) {
            viewHolder.share_container.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_container.setVisibility(View.GONE);
        }

        if (item.getIs_like() == 0) {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray));
        } else {
            viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));
        }
    }


    /**
     * Default Krank Post
     */
    public void setTypeKrankPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {
        final KrankPostViewHolder viewHolder = ((KrankPostViewHolder) holder);




        /**
         * Header
         * */

        viewHolder.name.setText(item.getHeaderSpannableString());
        viewHolder.name.setMovementMethod(LinkMovementMethod.getInstance());
        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.action.setText("share this post");
        viewHolder.company_text_view.setText("@ krank");
        Glide.with(context).load(R.drawable.krank_post_img).into(viewHolder.profileImg);

        viewHolder.delete_view_post.setVisibility(View.GONE);
        viewHolder.time_text_view.setText("" + item.getCreated_date());
        viewHolder.delete_view_post.setVisibility(View.GONE);




        /**
         * Content
         * */
        AutoPostHtml autoPostHtml = item.getAutoPostHtml();
        viewHolder.heading.setText("" + autoPostHtml.getHeading());

        for (int i = 0; i < autoPostHtml.getList().size(); i++) {
            if (i == 0) {
                viewHolder.line_1.setText("" + autoPostHtml.getList().get(i));
            } else if (i == 1) {
                viewHolder.line_2.setText("" + autoPostHtml.getList().get(i));
            } else if (i == 2) {
                viewHolder.line_3.setText("" + autoPostHtml.getList().get(i));
            } else if (i == 3) {
                viewHolder.line_4.setText("" + autoPostHtml.getList().get(i));
            } else if (i == 4) {
                viewHolder.line_4.setText("" + autoPostHtml.getList().get(i));
            }
        }
        viewHolder.para_1.setText(autoPostHtml.getPera().get0());
        if (autoPostHtml.getPera().getEmail().size() > 0) {
            viewHolder.para_2.setText(autoPostHtml.getPera().get1() + autoPostHtml.getPera().getEmail().get(0));
            AppUtils.removeUnderlines((Spannable) viewHolder.para_2.getText());

        }

        viewHolder.para_3.setText(autoPostHtml.getPera().get2());

    }
}
