package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Chat.AddPeopleInPrivateChat;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yaseen on 02/05/2018.
 */
public class PeopleListAdapter extends RecyclerView.Adapter<PeopleListAdapter.ViewHolder> {
    private List<GroupChatMembersDataModel> items;
    Context context;
    AppUtils appUtils;
    SaveInSharedPreference preference;


    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        TextView employee_name_text_view;
        TextView company_name_text_view;
        CircleImageView profile_image_view;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            employee_name_text_view = item.findViewById(R.id.employee_name_text_view);
            company_name_text_view = item.findViewById(R.id.company_name_text_view);
            profile_image_view = item.findViewById(R.id.profile_image_view);


            employee_name_text_view.setOnClickListener(view -> {
                appUtils.gotoUserProfile(context,items.get(getAdapterPosition()).getId(),preference);
            });

            company_name_text_view.setOnClickListener(view -> {
               // appUtils.gotoCompanyProfile(context,items.get(getAdapterPosition()).getCompanyId(),preference);
            });

            profile_image_view.setOnClickListener(view -> {
                appUtils.gotoUserProfile(context,items.get(getAdapterPosition()).getId(),preference);
            });
        }
    }

    public PeopleListAdapter(List<GroupChatMembersDataModel> items, Context context,SaveInSharedPreference preference) {
        this.items = items;
        this.context = context;
        this.preference=preference;
        appUtils = AppUtils.getInstance();
    }


    @Override
    public PeopleListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.people_list_recycler_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PeopleListAdapter.ViewHolder holder, int position) {
        final GroupChatMembersDataModel item = items.get(position);

        holder.employee_name_text_view.setText("" + item.getFirstName() + " " + item.getLastName());
        holder.company_name_text_view.setText("" + AppUtils.getCompanyAndDesignation(item.getCompanyName(),item.getDesignation()));
        Glide.with(context).load(item.getProfilePic()).into(holder.profile_image_view);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}





