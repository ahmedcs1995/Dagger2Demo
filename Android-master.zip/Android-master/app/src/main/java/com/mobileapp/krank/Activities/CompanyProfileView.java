package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.support.design.widget.AppBarLayout;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Adapters.CarousalCardsAdapter;
import com.mobileapp.krank.Adapters.CompanyProfileViewAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.CustomViews.FeedImageOverlayView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.Model.Enums.ConNetStatus;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CompanyNewsFeedResponse;
import com.mobileapp.krank.ResponseModels.CompanyProfileDetailResponseModel;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyProfileDetailDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.DataModel.PublicCompanyProfileData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Scroll.EndlessOnScrollListener;
import com.mobileapp.krank.Scroll.EndlessRecyclerViewScrollListener;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.NewsFeed.NewsFeedUtils;
import com.mobileapp.krank.Utils.ShareBottomSheet;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CompanyProfileFeed.CompanyProfileMessageView;
import com.stfalcon.frescoimageviewer.ImageViewer;
import com.yalantis.ucrop.UCrop;


import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CompanyProfileView extends BaseActivity {

    //intent constant
    public static String INTENT_COMPANY_ID = "companyId";

    //list item
    private RecyclerView mRecyclerView;
    private CompanyProfileViewAdapter mFeedAdapter;
    List<NewsFeedArray> mFeedList;
    LinearLayoutManager mLayoutManager;

    //scroll
    //pagination
    EndlessRecyclerViewScrollListener scrollListener;

    //animate
    private static final int PERCENTAGE_TO_ANIMATE_IMAGE = 70;
    private boolean mIsImageShown = true;


    private View mCompanyProfileImg;
    private int mMaxScrollSize;
    private boolean isPersonalCompanyProfile;
    CompanyProfileDetailDataModel myCompanyProfileData;

    //img
    SimpleDraweeView coverPic;
    SimpleDraweeView company_profile_img;


    View companyPicTakePicture;
    String currentCompanyId;
    private String currentPictureType = null;
    boolean isSwipeRefreshCall;
    boolean isScrollCall;
    String last_num;


    //delay
    Runnable runnable;
    Handler handler;

    public int clickIndex;
    View cover_camera_btn;


    //activity codes
    private static int EDIT_PROFILE_SETTING = 500;
    public static int COMMENT_ACTIVITY_CODE = 15;
    public static final int PRIVACY_ACTIVITY_CODE = 200;

    AppBarLayout appbarLayout;

    //image picker
    CustomImagePicker imagePicker;

    //newsfeed
    NewsFeedUtils newsFeedUtils;

    //share pop up
    private ShareBottomSheet shareBottomSheet;


    /*like comment Anim*/
    Animation myAnim;
    Animation commentShareAnim;
    /*like comment Anim*/

    //swipe refresh
    SwipeRefreshLayout swipe_refresh;


    //api
    Call<CompanyNewsFeedResponse> feedServiceCall;
    Call<CompanyProfileDetailResponseModel> companyInfoServiceCall;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_profile_view);

        init();

        initViews();

        setNormalPageToolbar(this);

        addAppBarOffSetChangeListener();

        checkForPersonalAndOtherProfile();

        setUpProfileViewAdapter();

        addOnSwipeRefreshListener();
    }


    private void addOnSwipeRefreshListener(){
        swipe_refresh.setOnRefreshListener(() -> {


            //reset scroll
            scrollListener.resetState();

            isSwipeRefreshCall = true;

            mFeedList.clear();

            addProfileLoader();


            mFeedAdapter.notifyDataSetChanged();


            /**
             * Abort the request
             * */
            if(feedServiceCall != null){
                feedServiceCall.cancel();
            }

            if(companyInfoServiceCall!=null){
                companyInfoServiceCall.cancel();
            }


            /**
             * Reset Param
             * */
            last_num = null;


            /**
             * Api
             * */
            new Handler().postDelayed(() -> {
                getCompanyInfo();
            }, Constants.SECONDS_TO_LOAD);
        });
    }

    private void setLikeCommentAnimation() {
        /*like comment button*/
        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        commentShareAnim = AnimationUtils.loadAnimation(this, R.anim.bounce_for_comment_click);
        /*like comment button*/
    }

    private void checkForPersonalAndOtherProfile() {
        if (!isPersonalCompanyProfile) {
            companyPicTakePicture.setVisibility(View.GONE);
            cover_camera_btn.setVisibility(View.GONE);
        } else {
            companyPicTakePicture.setVisibility(View.VISIBLE);
            cover_camera_btn.setVisibility(View.VISIBLE);
        }

    }

    private void pictureTakeCallBacks() {
        if (isPersonalCompanyProfile) {
            mCompanyProfileImg.setOnClickListener(view -> {
                currentPictureType = Constants.COMPANY_PROFILE_IMG;
                // ImagePicker.pickImage(CompanyProfileView.this, "Select your image:");
                imagePicker.pickImage(CompanyProfileView.this);
            });
            cover_camera_btn.setOnClickListener(view -> {
                currentPictureType = Constants.COMPANY_COVER_IMAGE;
                imagePicker.pickImage(CompanyProfileView.this);
                //ImagePicker.pickImage(CompanyProfileView.this, "Select your image:");
            });
        }
    }

    private void hideCompanyImg() {
        mIsImageShown = false;


        mCompanyProfileImg.animate()
                .scaleY(0).scaleX(0)
                .setDuration(200)
                .start();
        cover_camera_btn.animate()
                .scaleY(0).scaleX(0)
                .setDuration(200)
                .start();
    }

    private void showCompanyImg() {
        mIsImageShown = true;

        mCompanyProfileImg.animate()
                .scaleY(1).scaleX(1)
                .start();

        cover_camera_btn.animate()
                .scaleY(1).scaleX(1)
                .start();
    }

    private void addAppBarOffSetChangeListener() {
        appbarLayout.addOnOffsetChangedListener((appBarLayout, i) -> {

            swipe_refresh.setEnabled(i == 0);

            if (mMaxScrollSize == 0)
                mMaxScrollSize = appBarLayout.getTotalScrollRange();

            int percentage = (Math.abs(i)) * 100 / mMaxScrollSize;

            if (percentage >= PERCENTAGE_TO_ANIMATE_IMAGE && mIsImageShown) {
                hideCompanyImg();
            }

            if (percentage <= PERCENTAGE_TO_ANIMATE_IMAGE && !mIsImageShown) {
                showCompanyImg();
            }
        });
    }

    private void init() {

        //intent data
        currentCompanyId = getIntent().getStringExtra(INTENT_COMPANY_ID);
        isPersonalCompanyProfile = currentCompanyId != null && currentCompanyId.equals(preference.getString(Constants.MY_COMPANY_ID));


        //pagination and pull to refresh
        isSwipeRefreshCall = false;
        last_num = null;
        isScrollCall = true;


        // myCompanyProfileData = new PublicCompanyProfileData();

        //handler
        handler = new Handler();
        runnable = () -> getNewsFeedData();

        //img picker
        imagePicker = new CustomImagePicker();
        setLikeCommentAnimation();

        //bottom sheet
        shareBottomSheet = new ShareBottomSheet
                .Builder(CompanyProfileView.this, preference)
                .setListeners(getShareCallBack())
                .create();

        //feed
        newsFeedUtils = NewsFeedUtils.getInstance();

    }

    private void initViews() {
        cover_camera_btn = findViewById(R.id.cover_camera_btn);

        appbarLayout = findViewById(R.id.materialup_appbar);
        mCompanyProfileImg = findViewById(R.id.profile_img_to_hide);

        mMaxScrollSize = appbarLayout.getTotalScrollRange();
        coverPic = findViewById(R.id.cover_pic);
        company_profile_img = findViewById(R.id.company_profile_img);

        companyPicTakePicture = findViewById(R.id.company_img_camera_btn);

        //pull to refresh
        swipe_refresh = findViewById(R.id.swipe_refresh);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (resultCode == RESULT_OK) {
            if (requestCode == EDIT_PROFILE_SETTING) {
                PublicCompanyProfileData tempData = gson.fromJson(intent.getStringExtra("myCompanyData"), PublicCompanyProfileData.class);
                if (tempData != null) {
                    updateProfileData(tempData);
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);
                ApiUtils.uploadImage(resultUri, currentPictureType, preference, CompanyProfileView.this);
                setImage(currentPictureType, resultUri);
            } else if (requestCode == COMMENT_ACTIVITY_CODE) {
                updateComment(intent);
            } else if (requestCode == PRIVACY_ACTIVITY_CODE) {
                shareBottomSheet.updateDialogOnActivityResult(intent);
            } else {
                //Bitmap bitmap = ImagePicker.getImageFromResult(this, requestCode, resultCode, intent);
                Bitmap bitmap = imagePicker.handleImagePick(requestCode, CompanyProfileView.this, intent);
                //   Bitmap bitmap = ImagePicker.getImageFromResult(this, requestCode, resultCode, intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(this, bitmap), Uri.fromFile(new File(getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, this, currentPictureType);
                    uCrop.start(CompanyProfileView.this);
                }
            }

        }
    }

    private void updateComment(Intent intent) {
        mFeedList.get(clickIndex).setLike_count(intent.getIntExtra("likeCount", 0));
        mFeedList.get(clickIndex).setIs_like(intent.getIntExtra("isLike", 0));
        mFeedList.get(clickIndex).setComment_count(intent.getIntExtra("commentCount", 0));

        if (mFeedList.get(clickIndex).getUpdateCommentCountForImageOverlay() != null) {
            mFeedList.get(clickIndex).getUpdateCommentCountForImageOverlay().act();
        }

        mFeedAdapter.notifyItemChanged(clickIndex);


    }

    private void updateProfileData(PublicCompanyProfileData tempData) {
        myCompanyProfileData.setCompanyName(tempData.getCompanyName());
        myCompanyProfileData.setAddress(tempData.getAddress());
        myCompanyProfileData.setCountryName(tempData.getCountryName());
        myCompanyProfileData.setCityName(tempData.getCityName());
        myCompanyProfileData.setZipCode(tempData.getZipCode());
        myCompanyProfileData.setTelephoneNumber(tempData.getTelephoneNumber());
        myCompanyProfileData.setCompanyBio(tempData.getCompanyBio());
        myCompanyProfileData.setSize(tempData.getSize());
        myCompanyProfileData.setCurrencyName(tempData.getCurrencyName());
        myCompanyProfileData.setWebsiteUrl(tempData.getWebsiteUrl());
        myCompanyProfileData.setInterest(tempData.getInterest());
        myCompanyProfileData.setIndustry(tempData.getIndustry());
        myCompanyProfileData.setBusiness(tempData.getBusiness());
        myCompanyProfileData.setBusinessValue(getStringFromList(tempData.getBusiness()));
        myCompanyProfileData.setIndustryValue(getStringFromList(tempData.getIndustry()));
        myCompanyProfileData.setIndustryId(tempData.getIndustryId());
        myCompanyProfileData.setCompanySizeName(tempData.getCompanySizeName());
        mFeedAdapter.notifyDataSetChanged();
    }

    private String getStringFromList(List<String> business) {
        if (business == null) {
            return null;
        } else if (business != null && business.size() <= 0) {
            return null;
        }
        String value = "";
        for (int i = 0; i < business.size(); i++) {
            value += business.get(i) + ",";
        }
        return value.substring(0, value.length() - 1);
    }

    private void setImage(String type, Uri uri) {
        if (type.equals(Constants.COMPANY_PROFILE_IMG)) {
            company_profile_img.setImageURI(uri);
        } else if (type.equals(Constants.COMPANY_COVER_IMAGE)) {
            coverPic.setImageURI(uri);
        }
    }

    /**
     * Profile View Loader
     * */
    private void addProfileLoader(){
        mFeedList.add(new NewsFeedArray(Constants.PROFILE_VIEW_LOADER));
    }

    /**
     *
     * Initializing Adapter
     * */
    private void setUpProfileViewAdapter() {

        mRecyclerView = findViewById(R.id.company_profile_view_recycler_view);
        mFeedList = new ArrayList<>();


        addProfileLoader();

        //init adapter
        mFeedAdapter = new CompanyProfileViewAdapter(mFeedList, CompanyProfileView.this, getDeviceResolution());
        setUpAdapterListeners();
        mLayoutManager = new LinearLayoutManager(CompanyProfileView.this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mFeedAdapter);
        ((SimpleItemAnimator) mRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
        setScrollListener();

        //get data
        new Handler().postDelayed(() -> {
            getCompanyInfo();
        }, Constants.SECONDS_TO_LOAD);

    }

    private void setUpAdapterListeners() {
        mFeedAdapter.setListener((position, type, view) -> {
            switch (type) {
                case Constants.IN_APP_WEBVIEW:
                    gotoInAppWebView();
                    break;
                case Constants.EDIT_PROFILE_CALLBACK:
                    gotoProfileSettings();
                    break;
                case Constants.MARKET_PLACE_CALLBACK:
                    gotoMarketPlace();
                    break;
                case Constants.VIEW_EMPLOYEES_CALLBACK:
                    gotoViewEmployeesScreen();
                    break;
                case Constants.CONNECTION_BTN_CALLBACK:
                    onConnectionButtonClick(position);
                    break;
                case Constants.SHARE_CALLBACK:
                    newsFeedUtils.openDialog(mFeedList.get(position), mFeedList.get(position).getPostType() == Constants.LISTING_POST ? Constants.LISTING_SHARE : Constants.POST_SHARE, view, shareBottomSheet, commentShareAnim);
                    break;
                case Constants.LIKE_CALLBACK:
                    newsFeedUtils.sendLike(mFeedList.get(position), position, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),null);
                    break;
                case Constants.DELETE_CALLBACK:
                    newsFeedUtils.showDeletePopUpMenu(view, mFeedList.get(position), position, this, preference);
                    break;
                case Constants.COMMENT_CALLBACK:
                    view.startAnimation(commentShareAnim);
                    clickIndex = position;
                    Intent intent = new Intent(this, CommentsActivity.class);
                    intent.putExtra("CommentDataObj", mFeedList.get(position));
                    startActivityForResult(intent, COMMENT_ACTIVITY_CODE);
                    overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                    break;
                case Constants.POST_CALLBACK:
                    onPostClick(position);
                    break;
                case Constants.SHOW_MESSAGE_VIEW:
                    showMessageView(view);
                    break;
                case Constants.COMPANY_PROFILE:
                    gotoCompanyProfile("" + mFeedList.get(position).getCompany_id());
                    break;
                case Constants.MY_COMPANY_PROFILE:
                    gotoCompanyProfile("" + preference.getString(Constants.MY_COMPANY_ID));
                    break;
                case Constants.CONNECT_COMPANY_PROFILE:
                    gotoCompanyProfile("" + mFeedList.get(position).getAutoPostHtml().getConnect_company_id());
                    break;
                case Constants.USER_PROFILE:
                    gotoUserProfile("" + mFeedList.get(position).getUser_id());
                    break;
                case Constants.OWNER_USER_PROFILE:
                    gotoUserProfile("" + mFeedList.get(position).getOwner().getUser_id());
                    break;
                case Constants.POST_IMAGE_CALLBACK:
                    animateImage(mFeedList.get(position).getAsset(), mFeedList.get(position).getDescription(), mFeedList.get(position), position);
                    break;

            }
        });


        mFeedAdapter.setSendMessageCallBack(message -> {
            sendMessage(message);
            removeMessageView();
            hideFocusKeyboard();
        });
    }
    private void animateImage(String imgPath, String description, NewsFeedArray item, final int position) {
        FeedImageOverlayView overlayView = new FeedImageOverlayView(this);
        String[] posters = new String[]{imgPath};
        new ImageViewer.Builder<>(this, posters)
                .setOverlayView(overlayView)
                .setImageChangeListener(getImageChangeListener(description, item, position, overlayView))
                .show();
    }

    private ImageViewer.OnImageChangeListener getImageChangeListener(final String description, NewsFeedArray item, final int adapterPos, FeedImageOverlayView overlayView) {
        return position -> {
            // CustomImage image = images.get(position);
            overlayView.setDescription(description);
            overlayView.setNo_of_like("" + item.getLike_count());
            overlayView.setNo_of_comments("" + item.getComment_count());

            overlayView.setLikeEffect(item.getIs_like(), this);

            item.setUpdateCommentCountForImageOverlay(() -> {
                overlayView.setNo_of_comments("" + item.getComment_count());
                overlayView.setNo_of_like("" + item.getLike_count());
                overlayView.setLikeEffect(item.getIs_like(), this);
            });


            /**
             *
             *
             * Feed Like
             *
             * */
            overlayView.getLike_container().setOnClickListener(view -> {
                newsFeedUtils.sendLike(item, adapterPos, view, mFeedAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),(isLike) -> {
                    overlayView.setLikeEffect(isLike, this);
                    overlayView.setNo_of_like("" + item.getLike_count());
                });

            });

            /**
             * Comments
             * */
            overlayView.getComment_container().setOnClickListener(view -> {
                gotoCommentActivity(overlayView.getComment_container(), adapterPos);
            });
        };
    }

    /**
     * Comments Page
     */
    private void gotoCommentActivity(View view, int position) {
        view.startAnimation(commentShareAnim);
        clickIndex = position;
        Intent intent = new Intent(this, CommentsActivity.class);
        intent.putExtra("CommentDataObj", mFeedList.get(position));
        startActivityForResult(intent, COMMENT_ACTIVITY_CODE);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
    }

    private void gotoUserProfile(String userId) {
        Intent intent = new Intent(this, UserProfileView.class);
        intent.putExtra(UserProfileView.INTENT_USER_ID, userId);
        startActivity(intent);
    }

    private void gotoCompanyProfile(String companyId) {
        Intent intent = new Intent(this, CompanyProfileView.class);
        intent.putExtra(CompanyProfileView.INTENT_COMPANY_ID, companyId);
        startActivity(intent);
    }


    /**
     * Show the Message View
     * @param messageButton
     */
    private void showMessageView(View messageButton) {

        messageButton.setEnabled(false);

        if (mFeedList.get(1).getPostType() != Constants.COMPANY_PROFILE_MESSAGE_VIEW) {
            mFeedList.add(1, new NewsFeedArray(Constants.COMPANY_PROFILE_MESSAGE_VIEW));
            mFeedAdapter.notifyItemInserted(1);

        }

        appbarLayout.setExpanded(false,true);


        //Scroll item 2 to 20 pixels from the top
        mLayoutManager.scrollToPositionWithOffset(1, 20);


        messageButton.setEnabled(true);

    }


    private void removeMessageView() {
        if (mFeedList.get(1).getPostType() == Constants.COMPANY_PROFILE_MESSAGE_VIEW) {
            mFeedAdapter.removeAt(1);
        }
    }




    private void onPostClick(int position) {
        NewsFeedArray feed = mFeedList.get(position);
        if (feed.getPostType() == Constants.ARTICLE_POST) {
            Intent articleIntent = new Intent(this, ArticleDetail.class);
            articleIntent.putExtra("article_id", feed.getPost_track_id());
            startActivity(articleIntent);
        } else if (feed.getPostType() == Constants.AUCTION_POST) {
            Intent inAppWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
            inAppWebViewIntent.putExtra("feed_type", "auction");
            inAppWebViewIntent.putExtra("web_view_url", appUtils.getUrlWithUid(feed.getShareUrl(), preference));
            startActivity(inAppWebViewIntent);

        } else if (feed.getPostType() == Constants.LINKED_POST) {
            Intent linkWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
            linkWebViewIntent.putExtra("web_view_url", feed.getShareUrl());
            startActivity(linkWebViewIntent);

        } else if (feed.getPostType() == Constants.LISTING_POST) {
            Intent listingDetailIntent = new Intent(this, ListingDetail.class);
            listingDetailIntent.putExtra("listing_id", "" + feed.getPost_track_id());
            listingDetailIntent.putExtra("listing_pg_name", "" + feed.getHtmlParse().getTitle());
            startActivity(listingDetailIntent);
        }
    }

    private void onConnectionButtonClick(int position) {
        switch (AppUtils.getConNetStatus(myCompanyProfileData.getNetwork_info())) {
            case NOT_CONNECTED:
                sendNetworkRequest(position);
                break;
            case INVITATION_RECEIVED:
                gotoPendingRequest();
                break;
            case CONNECTED:
                if(myCompanyProfileData.getCompanyId().equals(CarousalCardsAdapter.COMPANY_NOT_TO_REMOVE)){
                    showToast("Can't remove this network");
                    return;
                }
                showRemoveDialog(position);
                break;
            default:
                break;
        }
    }


    private void showRemoveDialog(final int position) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Are you sure you want to remove this network?")
                .setDescription("You will also be removed from this user's network list.")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    removeNetwork(position);
                });

        dialog.show();


    }


    private void gotoPendingRequest() {
        Intent intent = new Intent(this, PendingRequestActivity.class);
        startActivity(intent);
    }


    private void changeStatus(final int position, String status) {
        myCompanyProfileData.setNetwork_info(status);
        mFeedAdapter.notifyItemChanged(position);
    }

    private void gotoInAppWebView() {
        if (myCompanyProfileData.getWebsiteUrl() == null || myCompanyProfileData.getWebsiteUrl().isEmpty())
            return;
        Intent intent = new Intent(this, InAppWebViewCollapseActivity.class);
        intent.putExtra("web_view_url", myCompanyProfileData.getWebsiteUrl());
        startActivity(intent);
    }

    private void gotoViewEmployeesScreen() {
        Intent intent = new Intent(this, ListOfEmployeesAndConnections.class);
        intent.putExtra(ListOfEmployeesAndConnections.NAME_KEY, myCompanyProfileData.getCompanyName());
        intent.putExtra(ListOfEmployeesAndConnections.COMPANY_ID, myCompanyProfileData.getCompanyId());
        startActivity(intent);
    }

    private void gotoProfileSettings() {
        Intent profileSettingIntent = new Intent(CompanyProfileView.this, MyCompanyProfileSettings.class);
        profileSettingIntent.putExtra("my_company_profile_data", gson.toJson(CompanyProfileView.this.myCompanyProfileData));
        startActivityForResult(profileSettingIntent, EDIT_PROFILE_SETTING);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void gotoMarketPlace() {
        if (!(appUtils.getConNetStatus(myCompanyProfileData.getNetwork_info()) == ConNetStatus.CONNECTED)) {
            //show pop up
            showPopUp();
            return;
        }
        Intent marketPlaceIntent = new Intent(this, MarketPlacePage.class);
        marketPlaceIntent.putExtra("currentItem", 0);
        marketPlaceIntent.putExtra("networkId", myCompanyProfileData.getCompanyId());
        marketPlaceIntent.putExtra("connectionId", "0");
        marketPlaceIntent.putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE);
        marketPlaceIntent.putExtra(MarketPlacePage.TOOLBAR_NAME, myCompanyProfileData.getCompanyName());
        startActivity(marketPlaceIntent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }


    private void setScrollListener() {

        scrollListener =  new EndlessRecyclerViewScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int totalItemsCount, RecyclerView view) {
                if (last_num != null && !isSwipeRefreshCall) {
                    onScroll();
                }else{
                    scrollListener.resetState();
                }
            }
        };

        mRecyclerView.addOnScrollListener(scrollListener);

        /*mRecyclerView.addOnScrollListener(new EndlessOnScrollListener(mLayoutManager) {
            @Override
            public void onScrolledToEnd() {
                if (last_num != null && !isSwipeRefreshCall && !isScrollCall) {
                    onScroll();
                }
            }
        });*/
    }

    private void showPopUp() {
        NormalAppDialog dialog = (NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this);
        dialog.hideCancelButton()
                .setDescription("Hi, You need to be networked with this company to view their marketplace.")
                .setConfirmButtonText("OK")
                .hideCancelButton()
                .setIcon(R.drawable.exclamation_img);


        dialog.show();
    }

    private void onScroll() {
        isScrollCall = true;
        handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }




    private void setToolbarTitle(String title){
        setNormalPageToolbar(title + "'s Profile");
    }


    private void onCompanyProfileDetailResponse(Response<CompanyProfileDetailResponseModel> response) {
        if (currentCompanyId == null) {
            currentCompanyId = response.body().getData().getCompanyId();
        }

        pictureTakeCallBacks();


        myCompanyProfileData = response.body().getData();
        myCompanyProfileData.setBusinessValue(getStringFromList(myCompanyProfileData.getBusiness()));
        myCompanyProfileData.setIndustryValue(getStringFromList(myCompanyProfileData.getIndustry()));


        company_profile_img.setImageURI(Uri.parse(Constants.BASE_IMG_URL + myCompanyProfileData.getProfilePic()));
        coverPic.setImageURI(Uri.parse(Constants.BASE_IMG_URL + myCompanyProfileData.getCoverPic()));


        setToolbarTitle( myCompanyProfileData.getCompanyName());
        //setUpProfileViewAdapter(myCompanyProfileData);

        mFeedList.remove(0);

        if (isPersonalCompanyProfile) {
            mFeedList.add(new NewsFeedArray(Constants.PERSONAL_PROFILE_VIEW));

        } else {
            mFeedList.add(new NewsFeedArray(Constants.OTHER_PROFILE_VIEW));
        }

        mFeedList.add(new NewsFeedArray(Constants.INFO_POST));

        if (myCompanyProfileData.getMy_connections() != null && myCompanyProfileData.getMy_connections().size() > 0) {
            mFeedList.add(new NewsFeedArray(Constants.OTHER_CONNECTION_EMPLOYS_VIEW));
        }
        if (myCompanyProfileData.getMy_dealers() != null && myCompanyProfileData.getMy_dealers().size() > 0) {
            mFeedList.add(new NewsFeedArray(Constants.OFFICIAL_DEALERS_VIEW));
        }

        mFeedAdapter.setUpdatedData(myCompanyProfileData);
        mFeedList.add(new NewsFeedArray(Constants.LOADER));
        mFeedAdapter.notifyDataSetChanged();
        getNewsFeedData();
    }


    private CustomShareCallBack getShareCallBack() {

        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(CompanyProfileView.this, SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", appUtils.convertToJson(selectedPrivacy));
            intent.putExtra("selected_network_group", appUtils.convertToJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", appUtils.convertToJson(tempDealerGroup));
            startActivityForResult(intent, PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }



    private void onNewsFeedResponse(Response<CompanyNewsFeedResponse> response) {


        /**
         * Pagination
         * */
        scrollListener.resetState();


        //swipe refresh
        if(isSwipeRefreshCall){
            swipe_refresh.setEnabled(true);
            swipe_refresh.setRefreshing(false);
        }

        //remove loader
        for (int i = (mFeedList.size() - 1); i >= 0; i--) {
            if (mFeedList.get(i).getPostType() == Constants.LOADER) {
                mFeedList.remove(i);
                mFeedAdapter.notifyItemRemoved(i);
                break;
            }
        }
        isSwipeRefreshCall = false;
        last_num = response.body().getData().getLast_num();
        isScrollCall = false;

        //setting newsfeed
        final List<NewsFeedArray> tempItems = response.body().getData().getFeeds();
        for (int i = 0; i < tempItems.size(); i++) {
            newsFeedUtils.getNewsFeedType(tempItems.get(i));
            setCallBacks(tempItems.get(i));
        }

        int oldSize = mFeedList.size();


        mFeedList.addAll(tempItems);


        if (mFeedList.get(mFeedList.size() - 1).getPostType() == Constants.OTHER_CONNECTION_EMPLOYS_VIEW) {
            if (mFeedList.size() == 4) {
                mFeedList.add(new NewsFeedArray(Constants.EMPTY_NEWS_FEED, "" + response.body().getMessage()));
            }
        } else if (mFeedList.get(mFeedList.size() - 1).getPostType() == Constants.OFFICIAL_DEALERS_VIEW) {
            if (mFeedList.size() == 3) {
                mFeedList.add(new NewsFeedArray(Constants.EMPTY_NEWS_FEED, "" + response.body().getMessage()));
            }
        } else if (mFeedList.get(mFeedList.size() - 1).getPostType() == Constants.INFO_POST) {
            if (mFeedList.size() == 2) {
                mFeedList.add(new NewsFeedArray(Constants.EMPTY_NEWS_FEED, "" + response.body().getMessage()));
            }
        }

        /**
         * Footer Loader
         * */
        if(last_num != null){
            mFeedList.add(new NewsFeedArray(Constants.LOADER));
        }

        mFeedAdapter.notifyItemRangeInserted(oldSize, mFeedList.size());
    }

    private void setCallBacks(NewsFeedArray feed) {
        // other than auto Post
        if (feed.getPostType() == Constants.NETWORK_POST || feed.getPostType() == Constants.DEALER_POST || feed.getPostType() == Constants.KRANK_POST) {
            if (feed.getPostType() == Constants.KRANK_POST) {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, true, CompanyProfileView.this));
            } else {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, false, CompanyProfileView.this));
            }
        } else {
            feed.setHeaderSpannableString(newsFeedUtils.getSpannablePostHeader(feed, CompanyProfileView.this, preference));
        }

        if (feed.getPostType() == Constants.CHECK_IN) {
            feed.setCheckInAddress(newsFeedUtils.getSpannableCheckInAddress(feed.getTitle(), feed.getDescription(), feed.getTime_difference(), CompanyProfileView.this));
        }

    }





    /**
     * Api
     * */

    private void getNewsFeedData() {
        feedServiceCall = getAPI().getCompanyNewsFeed(preference.getString(Constants.ACCESS_TOKEN),last_num, Constants.PAGE_LIMIT_1, currentCompanyId);

        feedServiceCall.enqueue(new Callback<CompanyNewsFeedResponse>() {
            @Override
            public void onResponse(Call<CompanyNewsFeedResponse> call, Response<CompanyNewsFeedResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        onNewsFeedResponse(response);
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<CompanyNewsFeedResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }
    private void sendMessage(String message) {
        getAPI().sendMessageToCompanyRep(preference.getString(Constants.ACCESS_TOKEN), myCompanyProfileData.getCompanyId(), message).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        showToast(response.body().getMessage());
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
            }
        });
    }


    private void removeNetwork(int position) {

        changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);

        getAPI().removeNetwork(preference.getString(Constants.ACCESS_TOKEN), Integer.parseInt(myCompanyProfileData.getCompanyId())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (!response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        showToast(response.body().getMessage());
                        changeStatus(position, Constants.CONNECTED_TEXT);
                    }
                } else {
                    onResponseFailure();
                    changeStatus(position, Constants.CONNECTED_TEXT);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                onResponseFailure();
                changeStatus(position, Constants.CONNECTED_TEXT);
            }
        });
    }


    private void sendNetworkRequest(final int position) {
        changeStatus(position, Constants.REQUEST_PENDING);
        getAPI().doNetworkRequestOnly(preference.getString(Constants.ACCESS_TOKEN), myCompanyProfileData.getUser_id()).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {

                    } else {
                        changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
                        showToast(response.body().getMessage());
                    }

                } else {
                    changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                changeStatus(position, Constants.CONNECTION_NOT_CONNECTED);
                onResponseFailure();
            }
        });
    }

    private void getCompanyInfo() {

        String slug = getIntent().getStringExtra("company_slug");

        companyInfoServiceCall = getAPI().getCompanyProfileDetails(preference.getString(Constants.ACCESS_TOKEN), currentCompanyId, slug == null ? "" : slug);

        companyInfoServiceCall.enqueue(new Callback<CompanyProfileDetailResponseModel>() {
            @Override
            public void onResponse(Call<CompanyProfileDetailResponseModel> call, Response<CompanyProfileDetailResponseModel> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {

                        onCompanyProfileDetailResponse(response);

                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<CompanyProfileDetailResponseModel> call, Throwable t) {
                onResponseFailure();

            }
        });
    }
}