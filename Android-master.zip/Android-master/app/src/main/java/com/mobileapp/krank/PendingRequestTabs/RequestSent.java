package com.mobileapp.krank.PendingRequestTabs;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.mobileapp.krank.Activities.ArticleDetail;
import com.mobileapp.krank.Activities.InAppWebViewCollapseActivity;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.PendingRequestActivity;
import com.mobileapp.krank.Adapters.RequestAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.RequestRecievedItem;
import com.mobileapp.krank.Model.Enums.TypeOfRequest;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.PendingRecieveRequestResponseModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Yaseen on 28/04/2018.
 */
public class RequestSent extends BaseFragment {

    private RecyclerView requestSentRecyclerView;
    private RecyclerView.Adapter requestSentRecyclerAdapter;
    List<RequestRecievedItem> requestSentItems;
    ProgressBar loader;
    String requestType = "request_sent";

    public int connectionRequestLeft;
    public int networkRequestLeft;
    public int dealerRequestLeft;


    private static final String TAG = RequestSent.class.getSimpleName();

    private SwipeRefreshLayout mSwipeRefreshLayout;
    View no_internet_root_view;

    PendingRequestActivity activityRef;



    public RequestSent() {
        setTitle("Requests Sent");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.request_sent_page, container, false);
        setFragmentView(me);

        init();

        initViews();


        setUpRequestSentAdapter();

        getSentRequests();

        addOnSwipeRefreshListener();
        addOnNoInternetMessageClick();

        return me;
    }

    private void init() {
        connectionRequestLeft = 0;
        networkRequestLeft = 0;
        dealerRequestLeft = 0;

        activityRef = (PendingRequestActivity) getActivity();
    }

    private void initViews() {
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout);
        no_internet_root_view = findViewById(R.id.no_internet_root_view);


        loader = (ProgressBar) findViewById(R.id.loader);
        loader.setVisibility(View.VISIBLE);
    }

    private void addOnNoInternetMessageClick() {
        no_internet_root_view.setOnClickListener(view -> {
            //request again from rest api
            loader.setVisibility(View.VISIBLE);
            no_internet_root_view.setVisibility(View.GONE);
            disableNoInternetMessageBtn();
            getSentRequests();
        });
    }

    private void enableNoInternetMessageBtn() {
        no_internet_root_view.setEnabled(true);
        mSwipeRefreshLayout.setEnabled(true);
    }

    private void disableNoInternetMessageBtn() {
        no_internet_root_view.setEnabled(false);
        mSwipeRefreshLayout.setEnabled(false);
    }

    private void setUpRequestSentAdapter() {
        requestSentRecyclerView = (RecyclerView) findViewById(R.id.request_sent_recycler);
        requestSentItems = new ArrayList<>();

    }

    private void addOnSwipeRefreshListener() {
        mSwipeRefreshLayout.setOnRefreshListener(() -> {
            if (requestSentRecyclerAdapter != null) {
                requestSentItems.clear();
                requestSentRecyclerAdapter.notifyDataSetChanged();
            }
            getSentRequests();
        });

    }

    private void getSentRequests() {
        activityRef.getAPI().getPendingSentRequests(activityRef.preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<PendingRecieveRequestResponseModel>() {
            @Override
            public void onResponse(Call<PendingRecieveRequestResponseModel> call, Response<PendingRecieveRequestResponseModel> response) {

                try {
                    no_internet_root_view.setVisibility(View.GONE);
                    mSwipeRefreshLayout.setEnabled(true);


                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                            onSuccess(response);
                        } else {
                            loader.setVisibility(View.GONE);
                            Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        loader.setVisibility(View.GONE);
                        activityRef.onResponseFailure();
                    }

                    mSwipeRefreshLayout.setRefreshing(false);
                } catch (Exception ex) {

                }

            }

            @Override
            public void onFailure(Call<PendingRecieveRequestResponseModel> call, Throwable t) {
                addOnFailure(t);
            }
        });
    }

    private void onSuccess(Response<PendingRecieveRequestResponseModel> response) {
        /*connection Requests*/
        requestSentItems.add(new RequestRecievedItem(TypeOfRequest.CONNECTION_REQUEST_HEADER));
        List<RequestRecievedItem> connectionTempData = response.body().getData().getConnectionRequests();
        setDataInList(connectionTempData, PendingRequestActivity.CONNECTION, new TypeOfRequest[]{TypeOfRequest.CONNECTION_BLANK_VIEW, TypeOfRequest.CONNECTION_REQUEST_LIST_ITEM, TypeOfRequest.NO_CONNECTION_REQUEST});

        /*network request*/
        requestSentItems.add(new RequestRecievedItem(TypeOfRequest.NETWORK_REQUEST_HEADER));
        List<RequestRecievedItem> networkTempData = response.body().getData().getNetworkRequest();
        setDataInList(networkTempData, PendingRequestActivity.NETWORK, new TypeOfRequest[]{TypeOfRequest.NETWORK_BLANK_VIEW, TypeOfRequest.NETWORK_REQUEST_LIST_ITEM, TypeOfRequest.NO_NETWORK_REQUEST});
        /*network request*/

        /*dealer request*/
        requestSentItems.add(new RequestRecievedItem(TypeOfRequest.DEALER_REQUEST_HEADER));
        List<RequestRecievedItem> dealerTempData = response.body().getData().getDealerRequests();

        setDataInList(dealerTempData, PendingRequestActivity.DEALER, new TypeOfRequest[]{TypeOfRequest.DEALER_BLANK_VIEW, TypeOfRequest.DEALER_REQUEST_LIST_ITEM, TypeOfRequest.NO_DEALER_REQUEST});
        /*dealer request*/


        requestSentRecyclerAdapter = new RequestAdapter(requestSentItems, getActivity(), requestType, connectionRequestLeft, networkRequestLeft, dealerRequestLeft);
        requestSentRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        requestSentRecyclerView.setAdapter(requestSentRecyclerAdapter);
        loader.setVisibility(View.GONE);
    }

    private void addOnFailure(Throwable t) {
        if (t instanceof IOException) {
            enableNoInternetMessageBtn();
            no_internet_root_view.setVisibility(View.VISIBLE);
        } else {
            no_internet_root_view.setVisibility(View.GONE);
            if (activityRef != null) {
                activityRef.onResponseFailure();
            }
        }

        mSwipeRefreshLayout.setRefreshing(false);
        loader.setVisibility(View.GONE);
    }

    private void setDataInList(List<RequestRecievedItem> data, int type, TypeOfRequest[] typeOfRequests) {
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).shouldShowListItem()) {
                /**
                 * List Item
                 * */
                data.get(i).setTypeOfRequest(typeOfRequests[1]);
            } else {

                /**
                 * Blank View
                 * */
                //  data.get(i).setTypeOfRequest(TypeOfRequest.CONNECTION_BLANK_VIEW);
                data.get(i).setTypeOfRequest(typeOfRequests[0]);
            }

            /**
             * Bottom Label
             * */
            if(data.get(i).shouldShowBottomLabel()){
                data.get(i).setEnquiryMessageBuilder(activityRef.getSpannableStringBuilder(data.get(i).getType(), data.get(i).getTrack_id(), data.get(i).getTrack_url(), data.get(i).getText(),data.get(i).getTrack_name()));
            }
        }

        if (data.size() > 0) {
            // connectionRequestLeft = data.size();
            if (type == PendingRequestActivity.NETWORK) {
                networkRequestLeft = data.size();
            } else if (type == PendingRequestActivity.CONNECTION) {
                connectionRequestLeft = data.size();
            } else if (type == PendingRequestActivity.DEALER) {
                dealerRequestLeft = data.size();
            }
            requestSentItems.addAll(data);
        } else {
            //requestSentItems.add(new RequestRecievedItem(TypeOfRequest.NO_CONNECTION_REQUEST));
            requestSentItems.add(new RequestRecievedItem(typeOfRequests[2]));
        }
    }


}