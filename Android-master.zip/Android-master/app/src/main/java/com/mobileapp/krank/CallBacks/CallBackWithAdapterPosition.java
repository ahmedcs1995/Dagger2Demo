package com.mobileapp.krank.CallBacks;

public interface CallBackWithAdapterPosition {
    void act(int position);
}
