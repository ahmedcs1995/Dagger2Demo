package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Ignore;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupChatConversationMsgModel {

    @SerializedName("msg_id")
    @Expose
    @ColumnInfo(name = "msgId")
    private int msgId;

    @SerializedName("msg_text")
    @Expose
    @ColumnInfo(name = "msg_text")
    private String msgText;

    @SerializedName("msg_user_id")
    @Expose
    @ColumnInfo(name = "msg_user_id")
    private int msgUserId;

    @SerializedName("msg_group_id")
    @Expose
    @ColumnInfo(name = "msg_group_id")
    private int msgGroupId;

    @SerializedName("msg_type")
    @Expose
    @ColumnInfo(name = "msg_type")
    private String msgType;

    @SerializedName("msg_added")
    @Expose
    @ColumnInfo(name = "msg_added")
    private String msgAdded;

    @SerializedName("msg_updated")
    @Expose
    @ColumnInfo(name = "msg_updated")
    private String msgUpdated;

    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    private int id;

    @SerializedName("profile_pic")
    @Expose
    @ColumnInfo(name = "profile_pic")
    private String profilePic;

    @SerializedName("first_name")
    @Expose
    @ColumnInfo(name = "first_name")
    private String firstName;

    @SerializedName("last_name")
    @Expose
    @ColumnInfo(name = "last_name")
    private String lastName;

    @SerializedName("type")
    @Expose
    @ColumnInfo(name = "type")
    private String type;

    @SerializedName("online")
    @Expose
    @ColumnInfo(name = "online")
    private String online;

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }

    public int getMsgUserId() {
        return msgUserId;
    }

    public void setMsgUserId(int msgUserId) {
        this.msgUserId = msgUserId;
    }

    public int getMsgGroupId() {
        return msgGroupId;
    }

    public void setMsgGroupId(int msgGroupId) {
        this.msgGroupId = msgGroupId;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getMsgAdded() {
        return msgAdded;
    }

    public void setMsgAdded(String msgAdded) {
        this.msgAdded = msgAdded;
    }

    public String getMsgUpdated() {
        return msgUpdated;
    }

    public void setMsgUpdated(String msgUpdated) {
        this.msgUpdated = msgUpdated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

}