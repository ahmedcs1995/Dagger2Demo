package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "group_chat_conversation_list_table")
public class GroupChatConversationGroupModel {


    @SerializedName("member_id")
    @Expose
    @ColumnInfo(name = "memberId")
    @NonNull
    @PrimaryKey
    private int memberId;

    @SerializedName("member_user_id")
    @Expose
    @ColumnInfo(name = "member_user_id")
    private int memberUserId;

    @SerializedName("member_group_id")
    @Expose
    @ColumnInfo(name = "member_group_id")
    private int memberGroupId;

    @SerializedName("member_added_by")
    @Expose
    @ColumnInfo(name = "member_added_by")
    private int memberAddedBy;

    @SerializedName("member_added")
    @Expose
    @ColumnInfo(name = "member_added")
    private String memberAdded;

    @SerializedName("member_updated")
    @Expose
    @ColumnInfo(name = "member_updated")
    private String memberUpdated;

    @SerializedName("member_status")
    @Expose
    @ColumnInfo(name = "member_status")
    private int memberStatus;

    @SerializedName("member_is_read")
    @Expose
    @ColumnInfo(name = "member_is_read")
    private int memberIsRead;

    @SerializedName("member_notifications")
    @Expose
    @ColumnInfo(name = "member_notifications")
    private String memberNotifications;

    @SerializedName("member_leave_on")
    @Expose
    @ColumnInfo(name = "member_leave_on")
    private String memberLeaveOn;

    @SerializedName("group_id")
    @Expose
    @ColumnInfo(name = "group_id")
    private int groupId;

    @SerializedName("group_name")
    @Expose
    @ColumnInfo(name = "group_name")
    private String groupName;

    @SerializedName("group_user_id")
    @Expose
    @ColumnInfo(name = "group_user_id")
    private int groupUserId;

    @SerializedName("group_added")
    @Expose
    @ColumnInfo(name = "group_added")
    private String groupAdded;

    @SerializedName("group_updated")
    @Expose
    @ColumnInfo(name = "group_updated")
    private String groupUpdated;

    @SerializedName("group_is_auction")
    @Expose
    @ColumnInfo(name = "group_is_auction")
    private String groupIsAuction;

    @SerializedName("msg")
    @Expose
    @Embedded
    private GroupChatConversationMsgModel msg;

    @SerializedName("unread_count")
    @Expose
    @ColumnInfo(name = "unread_count")
    private String unread_count;

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getMemberUserId() {
        return memberUserId;
    }

    public void setMemberUserId(int memberUserId) {
        this.memberUserId = memberUserId;
    }

    public int getMemberGroupId() {
        return memberGroupId;
    }

    public void setMemberGroupId(int memberGroupId) {
        this.memberGroupId = memberGroupId;
    }

    public int getMemberAddedBy() {
        return memberAddedBy;
    }

    public void setMemberAddedBy(int memberAddedBy) {
        this.memberAddedBy = memberAddedBy;
    }

    public String getMemberAdded() {
        return memberAdded;
    }

    public void setMemberAdded(String memberAdded) {
        this.memberAdded = memberAdded;
    }

    public String getMemberUpdated() {
        return memberUpdated;
    }

    public void setMemberUpdated(String memberUpdated) {
        this.memberUpdated = memberUpdated;
    }

    public int getMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(int memberStatus) {
        this.memberStatus = memberStatus;
    }

    public int getMemberIsRead() {
        return memberIsRead;
    }

    public void setMemberIsRead(int memberIsRead) {
        this.memberIsRead = memberIsRead;
    }

    public String getMemberNotifications() {
        return memberNotifications;
    }

    public void setMemberNotifications(String memberNotifications) {
        this.memberNotifications = memberNotifications;
    }

    public String getMemberLeaveOn() {
        return memberLeaveOn;
    }

    public void setMemberLeaveOn(String memberLeaveOn) {
        this.memberLeaveOn = memberLeaveOn;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getGroupUserId() {
        return groupUserId;
    }

    public void setGroupUserId(int groupUserId) {
        this.groupUserId = groupUserId;
    }

    public String getGroupAdded() {
        return groupAdded;
    }

    public void setGroupAdded(String groupAdded) {
        this.groupAdded = groupAdded;
    }

    public String getGroupUpdated() {
        return groupUpdated;
    }

    public void setGroupUpdated(String groupUpdated) {
        this.groupUpdated = groupUpdated;
    }

    public String getGroupIsAuction() {
        return groupIsAuction;
    }

    public void setGroupIsAuction(String groupIsAuction) {
        this.groupIsAuction = groupIsAuction;
    }

    public GroupChatConversationMsgModel getMsg() {
        return msg;
    }

    public void setMsg(GroupChatConversationMsgModel msg) {
        this.msg = msg;
    }

    public String getUnread_count() {
        return unread_count;
    }

    public void setUnread_count(String unread_count) {
        this.unread_count = unread_count;
    }


    public GroupChatConversationGroupModel() {

    }

    @Ignore
    public GroupChatConversationGroupModel(String groupName,String memberId,String groupId,String memberNotifications,String memberLeaveOn,String memberStatus,String memberAddedBy) {
        this.groupName=groupName;
        this.memberId=Integer.parseInt(memberId);
        this.groupId=Integer.parseInt(groupId);
        this.memberNotifications=memberNotifications;
        this.memberLeaveOn=memberLeaveOn;
        this.memberStatus=Integer.parseInt(memberStatus);
        this.memberAddedBy=Integer.parseInt(memberAddedBy);
    }
    @Ignore
    public GroupChatConversationGroupModel(int memberId){
        this.memberId=memberId;
    }
}