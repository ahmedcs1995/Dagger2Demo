package com.mobileapp.krank.Functions

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit





object DateTimeUtils {

    private const val DATE_FORMAT = "yyyy-MM-dd HH:mm:ss"

    @JvmStatic
    fun convertUTCToLocalDeviceTime(dateStr : String?): Long {
        if(dateStr == null) return 0
        if(dateStr.isEmpty()) return 0
        val df = SimpleDateFormat(DATE_FORMAT, Locale.ENGLISH)
        df.timeZone = TimeZone.getTimeZone("UTC")
        var date: Date? = null
        try {
            date = df.parse(dateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        df.timeZone = TimeZone.getDefault()
        val formattedDate = df.format(date)

        return getTimeStamp(formattedDate)

    }
    @JvmStatic
    private fun getTimeStamp(inputDate: String): Long {
        return try {
            val date = SimpleDateFormat(DATE_FORMAT).parse(inputDate)
            date.time
        } catch (e: Exception) {
            0
        }

    }

    @JvmStatic
    @Throws(ParseException::class)
    fun getTimeDifference(date: String?): Long {
        if(date == null || date.isEmpty()) return Constants.POP_UP_DURATION_TO_SHOW.toLong()
       var dateFormat = SimpleDateFormat(DATE_FORMAT)
        val d1 = dateFormat.parse(date)
        val d2 = dateFormat.parse(getCurrentUTCTime())
        val diffInMillies = Math.abs(d1.time - d2.time)

        return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS)

    }


    @JvmStatic
    fun getCurrentUTCTime() : String{
        var dateFormat = SimpleDateFormat(DATE_FORMAT)
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
        return dateFormat.format(GregorianCalendar.getInstance().time)
    }





    @JvmStatic
    fun getCurrentDate() : String{
        val c = Calendar.getInstance().time
        val df = SimpleDateFormat("dd-MMM-yyyy")
        return df.format(c)

    }


}
