package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yaseen on 05/05/2018.
 */

public class NewMessageAdapter extends RecyclerView.Adapter<NewMessageAdapter.ViewHolder> {
    private List<ConnectionsDataModel> items = new ArrayList<>();
    PrivateNewMessage privateNewMessage;
    AppUtils appUtils;

    ConnectionsDataModel previousSelectedItem = null;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        CircleImageView profile_image_view;
        TextView people_name;
        TextView company_name_text_view;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView=item.findViewById(R.id.uncheck_view);
            checkedView=item.findViewById(R.id.check_view);
            checkb=item.findViewById(R.id.checkb);
            company_name_text_view=item.findViewById(R.id.company_name_text_view);
            people_name=item.findViewById(R.id.people_name);
            profile_image_view=item.findViewById(R.id.profile_image_view);

        }
    }

    public NewMessageAdapter(List<ConnectionsDataModel> items, PrivateNewMessage privateNewMessage) {
        this.items = items;
        this.privateNewMessage = privateNewMessage;
        appUtils =  AppUtils.getInstance();
    }



    @Override
    public NewMessageAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.contacts_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final NewMessageAdapter.ViewHolder holder, final int position) {
        final ConnectionsDataModel item = items.get(position);

        if(item.isItemCheck()){
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        }
        else{
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
/*
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(previousSelectedItem == null){
                    item.setItemCheck(true);
                    notifyDataSetChanged();
                    previousSelectedItem = items.get(position);
                    privateNewMessage.setSelected_index(position);
                    //privateNewMessage.getChip_name().setVisibility(View.VISIBLE);
                 ///   privateNewMessage.getChip_name().setText("" + item.getCompanyData().getFirstName() + " " + item.getCompanyData().getLastName());
                    return;
                }
                previousSelectedItem.setItemCheck(false);
                item.setItemCheck(true);
                notifyDataSetChanged();
                previousSelectedItem = items.get(position);
                privateNewMessage.setSelected_index(position);
             //   privateNewMessage.getChip_name().setText("" + item.getCompanyData().getFirstName() + " " + item.getCompanyData().getLastName());


            }
        });*/
        holder.people_name.setText(item.getCompanyData().getFirstName() + " " + item.getCompanyData().getLastName());
        Glide.with(privateNewMessage.getApplicationContext()).load(Constants.BASE_IMG_URL + item.getCompanyData().getUserProfilePic()).into(holder.profile_image_view);
        holder.company_name_text_view.setText(AppUtils.getCompanyAndDesignation(item.getCompanyData().getCompanyName(),item.getCompanyData().getJobTitle()));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}





