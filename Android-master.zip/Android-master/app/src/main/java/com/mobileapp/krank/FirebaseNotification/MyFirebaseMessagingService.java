package com.mobileapp.krank.FirebaseNotification;

/**
 * Created by Yaseen on 12/05/2018.
 */

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.ArticleDetail;
import com.mobileapp.krank.Activities.CommentsActivity;
import com.mobileapp.krank.Activities.CommentsReplyActivity;
import com.mobileapp.krank.Activities.DiscoverPeople;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Activities.PendingRequestActivity;
import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChatConversationActivity;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MyFirebaseMessagingService extends FirebaseMessagingService {




    //notification types
    public static final String NETWORK_REQUEST = "1";
    public static final String CONNECTION_REQUEST = "2";
    public static final String DEALER_REQUEST = "3";
    public static final String LISTING = "5";
    public static final String TAG_NOTIFICATION = "6";
    public static final String COMMENTS = "7";
    public static final String POST_LIKE = "8";
    public static final String COMMENTS_CHILD = "9";
    public static final String COMMENTS_LIKE = "10";
    public static final String COMMENTS_REPLY_LIKE = "11";
    public static final String PERSONAL_CHAT_TYPE = "12";
    public static final String GROUP_CHAT_TYPE = "13";
    public static final String NEW_USER_PUSH = "14";
    public static final String ARTICLE_PUSH = "15";





    private static String IMG_URL = "http://dev-api.krank.com/assets/uploads/images/";

    SaveInSharedPreference preferences;

    // NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();
    public static String CURRENT_CONV_ID = "-1";
    public static String CURRENT_MEMBER_ID = "-1";
    AppUtils appUtils =  AppUtils.getInstance();




    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO: Handle FCM messages here.
        // If the application is in the foreground handle both data and notification messages here.
        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated.


        //Log.e("notification data -> ", "" + gson.toJson(remoteMessage.getData()));
        handleNotification(remoteMessage);
    }


    private void handleNotification(RemoteMessage remoteMessage) {


        //   String title = remoteMessage.getData().get("t");
        //  String msg = remoteMessage.getData().get("msg");
        // Bitmap bitmap = getBitmapFromURL(img);


        //

        String img="",notification_type="",id="";

        if(remoteMessage.getData() !=null){
            if(remoteMessage.getData().get("img") !=null){
                img = IMG_URL + remoteMessage.getData().get("img");
            }

            if(remoteMessage.getData().get("nt") !=null){
                notification_type = remoteMessage.getData().get("nt");
            }

            if(remoteMessage.getData().get("id") !=null){
                id = remoteMessage.getData().get("id");
            }

        }


        if(remoteMessage.getNotification() !=null){
            //create notification
            String title = remoteMessage.getNotification().getTitle();
            String msg = remoteMessage.getNotification().getBody();


            Intent notificationIntent = getNotificationIntent(getApplicationContext(), notification_type, id);
            if (notificationIntent != null) {
                createNotification(title, msg, notificationIntent,this);
            }

        }else{
            // update badge count
            if(remoteMessage.getData() != null && remoteMessage.getData().get("badge") !=null){
                CustomApplication app = (CustomApplication)getApplicationContext();
                app.badgeCount = Integer.parseInt(remoteMessage.getData().get("badge"));
               // ShortcutBadger.applyCount(getApplicationContext(), Integer.parseInt(remoteMessage.getData().get("badge")));
            }
        }

    }

    public static void createNotification(String msg, String title, Intent notificationIntent,Context context) {

        int iUniqueId = (int) (System.currentTimeMillis() & 0xfffffff);

        final PendingIntent pendingIntent = PendingIntent.getActivity(context, iUniqueId, notificationIntent,
                PendingIntent.FLAG_ONE_SHOT);

        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);


        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, context.getString(R.string.default_notification_channel_id))
                .setSmallIcon(R.mipmap.notifiation_icon)
                .setContentTitle(msg)
                .setContentText(title)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setGroupSummary(true)
                .setSound(defaultSoundUri)
                .setNumber(100)
                .setContentIntent(pendingIntent);


        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        int notificationId = new Random().nextInt(60000);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(context.getString(R.string.default_notification_channel_id),
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_DEFAULT);


            channel.setShowBadge(true);


            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(notificationId, notificationBuilder.build());

    }




    public Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            // Log exception
            return null;
        }
    }

    @Override
    public void onNewToken(String token) {
        //To displaying token on logcat
        Log.d("TOKEN: ", token);
        sendPushNotificationToken(token);

    }

    private void sendPushNotificationToken(final String newToken) {
        preferences = new SaveInSharedPreference(getApplicationContext());
        String device_id = AppUtils.getDeviceName();
        final String device_token = FirebaseInstanceId.getInstance().getToken();
        ServiceManager.getInstance().getAPI().sendPushNotificationToken(preferences.getString(Constants.ACCESS_TOKEN), device_id, device_token, newToken, "Android").enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                preferences.setString(Constants.FIREBASE_TOKEN, newToken);

            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }

        });

    }

    public static Intent getNotificationIntent(Context context, String notification_type, String id) {
        Intent notificationIntent = null;

        switch (notification_type) {
            case NETWORK_REQUEST:
                notificationIntent = new Intent(context, PendingRequestActivity.class);
                break;
            case CONNECTION_REQUEST:
                /*notificationIntent = new Intent(context, UserProfileView.class);
                notificationIntent.putExtra("userId", id);*/
                notificationIntent = new Intent(context, PendingRequestActivity.class);
                break;
            case DEALER_REQUEST:
                notificationIntent = new Intent(context, PendingRequestActivity.class);
                break;
            case LISTING:
                notificationIntent = new Intent(context, ListingDetail.class);
                notificationIntent.putExtra("listing_id", id);
                break;
            case TAG_NOTIFICATION:
                notificationIntent = new Intent(context, CommentsActivity.class);
                notificationIntent.putExtra("from_notification", true);
                notificationIntent.putExtra("postId", id);
                break;
            case COMMENTS:
                String[] CommentPostIds = id.split(","); // 3198,747
                if (CommentPostIds.length > 0) {
                    notificationIntent = new Intent(context, CommentsActivity.class);
                    notificationIntent.putExtra("from_notification", true);
                    notificationIntent.putExtra("postId", CommentPostIds[0]);
                    Log.e("sending postId", "for comment " + CommentPostIds[0]);
                    if (CommentPostIds.length > 1) {
                        notificationIntent.putExtra("commentId", CommentPostIds[1]);
                    }
                } else {
                    notificationIntent = new Intent(context, MainPage.class);
                }
                break;
            case POST_LIKE:
                notificationIntent = new Intent(context, CommentsActivity.class);
                notificationIntent.putExtra("from_notification", true);
                notificationIntent.putExtra("postId", id);
                break;
            case COMMENTS_CHILD:
                String[] ids = id.split(","); // 3198,747,356
                if (ids.length > 0) {
                    notificationIntent = new Intent(context, CommentsReplyActivity.class);
                    notificationIntent.putExtra("from_notification", true);
                    notificationIntent.putExtra("postId", ids[0]);
                    if (ids.length > 1) {
                        notificationIntent.putExtra("commentId", ids[1]);
                        if (ids.length > 2) {
                            notificationIntent.putExtra("subcommentId", ids[2]);
                        }
                    }
                } else {
                    notificationIntent = new Intent(context, MainPage.class);
                }
                break;
            case COMMENTS_LIKE:
                String[] CommentLikeIds = id.split(","); // 3198,747
                if (CommentLikeIds.length > 0) {
                    notificationIntent = new Intent(context, CommentsActivity.class);
                    notificationIntent.putExtra("from_notification", true);
                    notificationIntent.putExtra("postId", CommentLikeIds[0]);
                    if (CommentLikeIds.length > 1) {
                        notificationIntent.putExtra("commentId", CommentLikeIds[1]);
                    }
                } else {
                    notificationIntent = new Intent(context, MainPage.class);
                }
                break;
            case COMMENTS_REPLY_LIKE:
                String[] CommentPostIdsForReplyLike = id.split(","); // 3198,747,356
                if (CommentPostIdsForReplyLike.length > 0) {
                    notificationIntent = new Intent(context, CommentsReplyActivity.class);
                    notificationIntent.putExtra("from_notification", true);
                    notificationIntent.putExtra("postId", CommentPostIdsForReplyLike[0]);
                    if (CommentPostIdsForReplyLike.length > 1) {
                        notificationIntent.putExtra("commentId", CommentPostIdsForReplyLike[1]);
                        if (CommentPostIdsForReplyLike.length > 2) {
                            notificationIntent.putExtra("subcommentId", CommentPostIdsForReplyLike[2]);
                            Log.e("subcommentId", "sending = " + CommentPostIdsForReplyLike[2]);
                        }
                    }
                } else {
                    notificationIntent = new Intent(context, MainPage.class);
                }
                break;
            case PERSONAL_CHAT_TYPE:
                if (!(id.equals(MyFirebaseMessagingService.CURRENT_CONV_ID))) {
                    notificationIntent = new Intent(context, PrivateChatConversationActivity.class);
                    notificationIntent.putExtra("conv_id", id);
                    notificationIntent.putExtra("from_notification", true);
                    //  MyFirebaseMessagingService.CURRENT_CONV_ID = id;
                }
                break;
            case GROUP_CHAT_TYPE:
                Log.e("CURRENT_MEMBER_ID", "" + MyFirebaseMessagingService.CURRENT_MEMBER_ID);
                if (!(id.equals(MyFirebaseMessagingService.CURRENT_MEMBER_ID))) {
                    notificationIntent = new Intent(context, GroupChatConversationActivity.class);
                    notificationIntent.putExtra("from_notification", true);
                    notificationIntent.putExtra("member_id", "" + id);
                    Log.e("member_id", "sending = " + id);
                    //    MyFirebaseMessagingService.CURRENT_MEMBER_ID = id;
                }
                break;
            case NEW_USER_PUSH:
                notificationIntent = new Intent(context, DiscoverPeople.class);
                notificationIntent.putExtra(DiscoverPeople.CURRENT_ITEM_KEY,1);
                notificationIntent.putExtra(DiscoverPeople.NEW_USER_ID_KEY,id);
                notificationIntent.putExtra(DiscoverPeople.FROM_NOTIFICATION,true);
                break;
            case ARTICLE_PUSH:
                notificationIntent = new Intent(context, ArticleDetail.class);
                notificationIntent.putExtra(ArticleDetail.ARTICLE_ID,Integer.parseInt(id));
                break;
            default:
                notificationIntent = new Intent(context, MainPage.class);
                break;

        }
        return notificationIntent;

    }


}