package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import cn.pedant.SweetAlert.SweetAlertDialog

import com.mobileapp.krank.Adapters.CarousalCardsAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Model.Enums.CardsListenerType
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.yarolegovich.discretescrollview.DiscreteScrollView
import com.yarolegovich.discretescrollview.transform.ScaleTransformer
import kotlinx.android.synthetic.main.activity_dealers_card.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import java.util.ArrayList

class DealersCard : BaseActivity() {

    //list items
    lateinit var items: MutableList<NetworkDealersData>
    private var cardsAdapter: CarousalCardsAdapter<NetworkDealersData>? = null


    //current index
    private var currentItem: Int = 0

    //flag
    var isDataDeleted: Boolean = false


    lateinit var app: CustomApplication


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dealers_card)
        init()


        setUpAdapter()

    }

    private fun init() {
        items = ArrayList()

        currentItem = intent.getIntExtra("currentItem", 0)


        app = applicationContext as CustomApplication



    }

    private fun setUpAdapter() {


        items.addAll(app.dealerItems)

        cardsAdapter = CarousalCardsAdapter(CarousalCardsAdapter.COMPANY_VIEW, items, this, deviceResolution, object : CarousalCardsAdapter.CardsListeners {
            override fun onBind(holder: RecyclerView.ViewHolder, position: Int) {

                cardsAdapter?.setDealerView(holder as CarousalCardsAdapter<NetworkDealersData>.CompanyCardsViewHolder, items!![position], position)

            }

            override fun getViewType(position: Int): Int {
                return CarousalCardsAdapter.ITEM_VIEW

            }

        }, object : CarousalCardsAdapter.ClickListeners {
            override fun itemClickListener(position: Int, type: CardsListenerType) {
                when (type) {
                    CardsListenerType.DELETE -> {
                        showRemoveDialog(items[position].dealerId.toInt(), position)
                    }

                    CardsListenerType.VIEW_LISTING -> {
                        viewListing(items[position])
                    }
                    CardsListenerType.VIEW_PROFILE -> {
                        profileView(items[position])
                    }
                    CardsListenerType.COMPANY_IMG -> {
                        profileView(items[position])
                    }
                    CardsListenerType.VIEW_EMPLOYEES -> {
                        viewConnections(items[position], false)
                    }

                    CardsListenerType.VIEW_YOUR_CONNECTIONS -> {
                        viewConnections(items[position], true)
                    }


                }
            }

        })

        carosuel_view.adapter = cardsAdapter

        carosuel_view.setItemTransitionTimeMillis(130)

        carosuel_view.setItemTransformer(ScaleTransformer.Builder().setMinScale(0.90f)
                .build())

        carosuel_view.scrollToPosition(currentItem)
        setCompanyNameOnToolbar(items[currentItem].companyName)


        carosuel_view.addScrollStateChangeListener(object : DiscreteScrollView.ScrollStateChangeListener<RecyclerView.ViewHolder> {
            override fun onScrollStart(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {

            }

            override fun onScrollEnd(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {
                setCompanyNameOnToolbar(items[adapterPosition].companyName)

            }

            override fun onScroll(scrollPosition: Float, currentPosition: Int, newPosition: Int, currentHolder: RecyclerView.ViewHolder?, newCurrent: RecyclerView.ViewHolder?) {
              //  setCompanyNameOnToolbar(items[newPosition].companyName)

            }
        })
    }

    private fun setCompanyNameOnToolbar(userName: String) {
        setNormalPageToolbar( "$userName's Card")
    }


    private fun showRemoveDialog(companyId: Int, position: Int) {

        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this) as NormalAppDialog)
                .setHeading("Remove Dealer")
                .setDescription("Are you sure you want to remove dealer?")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener {
                    isDataDeleted = true
                    removeDealer(companyId)
                    it.dismiss()



                    //remove the thread
                    items.removeAt(position)
                    cardsAdapter!!.notifyDataSetChanged()


                    if(items.size == 0){
                        onBackPressed()
                        return@setConfirmButtonListener
                    }



                    if(position < items.size ){
                        setCompanyNameOnToolbar(items[position].companyName)
                    }
                    else if(position -1  >= 0 && position - 1 < items.size){
                        setCompanyNameOnToolbar(items[position -1].companyName)
                    }
                    else{
                        setCompanyNameOnToolbar("")
                    }
                }
        dialog.show()

    }

    private fun removeDealer(dealerId: Int) {
        api.removeDealer(preference.getString(Constants.ACCESS_TOKEN), dealerId).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        showToast("Successfully removed dealer")
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }

            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                onResponseFailure()
            }
        })
    }


    private fun viewConnections(item: NetworkDealersData, viewYourConnection: Boolean) {
        val intent = Intent(this, ListOfEmployeesAndConnections::class.java)
        with(intent) {
            putExtra(ListOfEmployeesAndConnections.NAME_KEY, item.companyName)
            putExtra(ListOfEmployeesAndConnections.COMPANY_ID, item.companyId)
            putExtra("is_view_your_connection_click", viewYourConnection)
        }

        startActivity(intent)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun profileView(item: NetworkDealersData) {
        val intent = Intent(this, CompanyProfileView::class.java)

        with(intent) {
            putExtra("companyId", item.companyId)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun viewListing(item: NetworkDealersData) {
        val intent = Intent(this, MarketPlacePage::class.java)
        with(intent) {
            putExtra("currentItem", 0)
            putExtra("networkId", item.companyId)
            putExtra("connectionId", "0")
            putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE)
            putExtra(MarketPlacePage.TOOLBAR_NAME, item.companyName)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }


    override fun onBackPressed() {
        if (isDataDeleted) {
            app.dealerItems = items
            val intent = Intent()
            intent.putExtra("isDataDeleted", isDataDeleted)
            setResult(RESULT_OK, intent)
            finish()
            overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
            return
        }
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }


}
