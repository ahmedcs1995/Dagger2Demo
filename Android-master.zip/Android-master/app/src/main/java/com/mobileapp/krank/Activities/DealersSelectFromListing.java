package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.mobileapp.krank.Adapters.DealerListingAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DealersSelectFromListing extends BaseActivity {

    private RecyclerView connectionsRecyclerView;
    private RecyclerView.Adapter connectionsRecyclerAdapter;
    List<DealerDataListing> dealerDataListings;
    public static int EMPLOYEES_ACTIVITY_CODE = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealers_select_from_listing);

        setNormalPageToolbar("Select Dealer");
        setUpAdapter();

    }
    private void setUpAdapter() {

        connectionsRecyclerView = findViewById(R.id.network_recycler);
        dealerDataListings = new ArrayList<>();
        Log.e("dealers data","" + getIntent().getStringExtra("dealerList"));
        dealerDataListings.addAll(Arrays.asList(gson.fromJson(getIntent().getStringExtra("dealerList"),DealerDataListing[].class)));
        connectionsRecyclerAdapter = new DealerListingAdapter(dealerDataListings, DealersSelectFromListing.this);
        connectionsRecyclerView.setLayoutManager(new LinearLayoutManager(DealersSelectFromListing.this));
        connectionsRecyclerView.setAdapter(connectionsRecyclerAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            if(requestCode==EMPLOYEES_ACTIVITY_CODE){
                Intent intent = new Intent();
                intent.putExtra("selected_employee","" + data.getStringExtra("selected_employee"));
                intent.putExtra("dealer_item_index",data.getIntExtra("dealer_item_index",0));
                setResult(RESULT_OK, intent);
                finish();
            }
        }
    }
}
