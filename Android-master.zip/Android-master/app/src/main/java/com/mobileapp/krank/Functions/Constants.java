package com.mobileapp.krank.Functions;

/**
 * Created by Ahmed on 4/3/2018.
 */

public class Constants {

    /*for wizard*/
    public static boolean USER_IMG = false;
    public static boolean COVER_IMG = false;
    public static boolean COMPANY_COVER_IMG = false;
    public static boolean COMPANY_IMG = false;
    public static String IMAGE_TYPE = "imgType";
    /*for wizard*/


    public static final int UAT = 1;
    public static final int LIVE = 2;
    public static final int DEV_API = 3;

    /*
    INITIAL_BASE_URL
    */

    //live
    public static final String LIVE_BASE_URL = "https://api.krank.com/";
    //uat api
    public static final String UAT_BASE_URL = "https://uat-api.krank.com/";

    //dev api
    public static String DEV_BASE_URL = "http://dev-api.krank.com/";


    //web view base url
    public static String LIVE_WEB_VIEW_BASE_URL = "https://www.krank.com";
    public static String DEV_WEB_VIEW_BASE_URL = "https://dev.krank.com";
    public static String UAT_WEB_VIEW_BASE_URL = "https://uat.krank.com";


    public static String SITE_BASE_URL = "";


    // public static final String BASE_IMG_URL = "http://dev-api.krank.com/assets/uploads/images/";
    public static final String BASE_IMG_URL = "";
    //  private static String INITIAL_BASE_URL = "https://dev.krank.com";

    public static String CHAT_SERVER_URL;
    public static String BASE_LOGIN_URL;
    public static String LISTING_EDIT_URL;
    //listing detail pdf download btn
    public static String LISTING_PDF_BASE_URL;


    //for api calls
    public static String BASE_URL = "";

    public static void setBaseUrl(int serverType) {

        if (serverType == DEV_API) {
            BASE_URL = DEV_BASE_URL;
            SITE_BASE_URL = DEV_WEB_VIEW_BASE_URL;
        } else if (serverType == LIVE) {

            BASE_URL = LIVE_BASE_URL;
            SITE_BASE_URL = LIVE_WEB_VIEW_BASE_URL;
        } else if (serverType == UAT) {

            BASE_URL = UAT_BASE_URL;
            SITE_BASE_URL = UAT_WEB_VIEW_BASE_URL;
        }

        CHAT_SERVER_URL = SITE_BASE_URL + ":3000/chat";
        BASE_LOGIN_URL = SITE_BASE_URL + "/login/mobile?uid=";
        LISTING_EDIT_URL = SITE_BASE_URL + "/add-listing?edit=";
        LISTING_PDF_BASE_URL = SITE_BASE_URL + "/listings/pdfgenerate/";

    }
    /*
    INITIAL_BASE_URL
    */



    //for redirect to sign up verification code page
    public static String GOTO_VERIFICATION_SCREEN = "verification_screen_key";

    /**
     *
     * response shared constants keys
     * */
    public static String PACKAGE_ID = "pakage_id_key";
    public static String HISTORY_ID = "history_id";
    public static String COMPANY_NAME = "currentCompany";
    public static String USER_EMAIL = "email";
    public static String NEW_COMPANY = "company";
    public static String OLD_COMPANY = "old_company";
    public static String VERIFY_CODE = "verify";
    public static String TEMP_USER_ID = "tempuser";
    public static String ACCESS_TOKEN = "access";
    public static String FIREBASE_TOKEN = "firebase_token";
    public static String REFRESH_TOKEN = "refresh";
    public static String FIRST_NAME = "fname";
    public static String LAST_NAME = "lname";
    public static String WEBSITE_URL = "website";
    public static String DEPARTMENT = "department";
    public static String MOBILE_NUMBER = "mobile";
    public static String COMPANY_SIZE = "company_size";
    public static String JOB_TITLE = "job_title";
    public static String PROFILE_PICTURE = "profile_pic";
    public static String COMPANY_PROFILE_PICTURE = "company_profile_pic";
    public static String USER_UID = "user_uid";
    public static String USER_SLUG = "user_slug_key";

    //sync adapter account
    public static String SYNC_ADAPTER_SETUP_COMPLETE = "sync_adapter_account_setup_complete";


    //contacts work
    public static String CONTACTS_SYNC_COUNT = "contacts_sync_count";
    public static String CONTACTS_SYNC_ENABLED = "contacts_sync_enabled";
    public static String VERIFY_PHONE_NUM_STATUS = "phone_num_status";
    public static String IS_PHONE_NUMBER_ON_WIZARD_ENTERED = "is_phone_number_on_wizard_entered";
    public static String IS_CONTACT_DB_EMPTY = "is_contact_db_empty";

    public static String TOTAL_CONTACTS_COUNT = "total_contacts_count";
    public static String MY_CONTACT_COUNT = "my_contacts_count";




    //for pop up
    public static String CONTACT_POP_UP_LAST_DURATION_SHOWN = "contact_pop_up_last_duration_shown";
    public static String CONTACT_POP_UP_DONT_ASK_ME_VALUE = "dont_ask_me";


    public static int POP_UP_DURATION_TO_SHOW = 10080;
   // public static int POP_UP_DURATION_TO_SHOW = 2;


    //for sync
    public static String LAST_CONTACT_UPDATE_TIME_STAMP = "last_contact_update_time_stamp";
    public static String LAST_CONTACT_DELETE_TIME_STAMP = "last_contact_delete_time_stamp";

    public static String TEMP_LAST_CONTACT_UPDATE_TIME_STAMP = "temp_last_contact_update_time_stamp";
    public static String TEMP_LAST_CONTACT_DELETE_TIME_STAMP = "temp_last_contact_delete_time_stamp";

    /*response shared constants keys*/


    /*for runtime image display*/
    public static String TEMP_USER_PROFILE_PICTURE = "temp_profile_pic";
    public static String TEMP_COMPANY_PROFILE_PICTURE = "temp_company_profile_pic";
    /*for runtime image display*/



    public static String COVER_PICTURE = "cover_pic";
    public static String COMPANY_COVER_PICTURE = "company_cover_pic";
    public static String NETWORK_COUNT = "network_count";
    public static String CONNECTION_COUNT = "connection_count";
    public static String LIST_COUNT = "list_count";
    public static String TOTAL_COMPANY_LIST = "total_company_list";
    public static String TOTAL_COMPANY_LIST_LIMIT = "total_company_list_limit";
    public static String INVITE_COMPANIES_URL = "invite_company_url";


    //invitation data
    public static String INVITATION_CODE = "invitation_code";
    public static String TYPE_OF_INVITATION = "type_of_invitation_key";
    public static String INVITATION_RESPONSE_DATA = "invitation_response_data";
    //invitation data


    //country city
    public static String COMPANY_COUNTRY_DATA = "company_country_data";
    public static String COMPANY_CITY_DATA = "company_city_data";

    public static String USER_COUNTRY_DATA = "company_country_data";
    public static String USER_CITY_DATA = "company_city_data";
    //country city


    public static String COUNTRY = "country";
    public static String CITY = "city";
    public static String CITY_ID_KEY = "city_id_key";
    public static String COUNTRY_CODE = "country_code_key";
    public static String COUNTRY_DIAL_CODE = "country_dial_code_key";
    public static String USER_ID = "uid";
    public static String MY_COMPANY_ID = "my_company_id";
    public static String INTENT_KEY = "intent";
    public static String COMPANY_ID = "company_id";
    public static String USER_ID_ENCRYPTED = "company_id";

    /**
     *
     * response shared constants keys
     */


    // youtube API KEY
    public static final String YOUTUBE_API_KEY = "AIzaSyClBLNGTPFXoOgFBrJTZxxW5b2iMY735fQ";


    //Error Msgs
    public static final String ERROR_MSG_TOAST = "There was a error while loading";
    public static final String ERROR_MSG_TOAST_1 = "Something went wrong";
    public static final String ERROR_SENDING_REQUEST = "Error while sending request";


    // google api key
    public static String GOOGLE_API_KEY = "AIzaSyClBLNGTPFXoOgFBrJTZxxW5b2iMY735fQ";


    // for handler
    public static int SECONDS_TO_LOAD = 200;



    // flag for public and network market place
    public static String PUBLIC_MARKET_PLACE = "Public";
    public static String NETWORK_MARKET_PLACE = "Network";


    //


    //font name
    public static String ROBOTO_BOLD = "fonts/Roboto-Bold.ttf";
    public static String ROBOTO_NORMAL = "fonts/Roboto-Regular.ttf";

    //type of share
    public final static int LISTING_SHARE = 1;
    public final static int POST_SHARE = 0;
    public final static int ARTICLE_SHARE = 2;

    public static int TAB_TEXT_SIZE = 15;


    // connection && Network Status status
    public static final String CONNECTION_NOT_CONNECTED = "Not Connected";
    public static final String NO_CONNECTION_TEXT = "No Connection";
    public static final String CONNECTED_TEXT = "Connected";
    public static final String REQUEST_PENDING = "Request Pending";
    public static final String NO_CONNECTION_TEXT_VALUE = "No Connection";
    public static final String NO_NETWORK_TEXT_VALUE = "No Connection";
    public static final String ACCEPT_REQUEST = "Accept Request";
    public static final String INVITATION_RECEIVED = "Invitation Received";


    //type of messages
    public static final String TEXT_LEFT = "text_left";
    public static final String TEXT_RIGHT = "text_right";
    public static final String V_CARD_LEFT = "v_card_left";
    public static final String V_CARD_RIGHT = "v_card_right";
    public static final String IMAGE_RIGHT = "image_right";
    public static final String IMAGE_LEFT = "image_left";
    public static final String OTHER = "other";
    public static final String OTHER_ATTACHMENT_LEFT = "other_attachment_left";
    public static final String OTHER_ATTACHMENT_RIGHT = "other_attachment_right";
    public static final String PROGRESS_BAR = "progress_bar";
    public static final String SYSTEM_MESSAGE = "system_message";
    public static final String RETRY_BUTTON_CHAT = "retry_btn";
    public static final String TYPING_MSG_VIEW = "typing_view";


    //type of msg Status
    public static final int STATUS_FAIL = 0;
    public static final int STATUS_PENDING = 1;
    public static final int STATUS_SEND = 2;


    // type of Feed
    public static final int SHARE_UPDATE = 0;
    public static final int INVITE_COMPANIES = 1;
    public static final int ADD_CO_WORKERS = 2;
    public static final int LINKED_POST = 3;
    public static final int TEXT_POST = 4;
    public static final int IMAGE_POST = 5;
    public static final int PERSONAL_PROFILE_VIEW = 6;
    public static final int INFO_POST = 7;
    public static final int LOADER = 8;
    public static final int OTHER_PROFILE_VIEW = 9;
    public static final int OTHER_CONNECTION_EMPLOYS_VIEW = 10;
    public static final int OFFICIAL_DEALERS_VIEW = 11;
    public static final int CHECK_IN = 12;
    public static final int NETWORK_POST = 13;
    public static final int DEALER_POST = 14;
    public static final int LISTING_POST = 15;
    public static final int YOUTUBE_VIDEO = 16;
    public static final int VIMEO_VIDEO = 17;
    public static final int ARTICLE_POST = 18;
    public static final int OTHER_POST = 19;
    public static final int EMPTY_NEWS_FEED = 20;
    public static final int KRANK_POST = 21;
    public static final int RETRY_ITEM = 22;
    public static final int PROFILE_VIEW_LOADER = 23;
    public static final int AUCTION_POST = 24;
    public static final int NETWORK_NOT_CONNECTED_VIEW = 25;
    public static final int SUGGESTED_CONNECTIONS = 26;
    public static final int VERIFY_PHONE_NUMBER_VIEW = 27;
    public static final int COMPANY_PROFILE_MESSAGE_VIEW = 28;
    public static final int COMMENT = 29;
    public static final int COMMENT_REPLY = 30;
    public static final int LISTING_POST_TYPE_TWO = 31;
    public static final int LISTING_POST_TYPE_THREE = 32;


    // ids
    public static final int EMMA_COOPER_ID = 69;
    public static final String EMMA_COOPER_ID_IN_STRING = "69";
    public static final int KRANK_ID = 23;




    // Web View constants
    public static final String CONTACT_KRANK = "Contact Krank";
    public static final String FAQS = "FAQs";
    public static final String COOKIES_POLICY = "Cookies Policy";
    public static final String TERMS_CONDITION = "Terms & Conditions";
    public static final String PRIVACY = "Privacy";

    public static final String PURCHASE_ADDONS = "Purchase Add-ons";
    public static final String UPDATE_CARD = "Update Card";
    public static final String PAYMENT_HISTORY = "Payment History";


    // loading text
    public static final String LOADING = "Loading ...";
    public static final String SIGN_IN_LOADING = "Signing in Please wait...";

    //validation messages
    public static final String ENTER_EMAIL_TEXT = "Please enter your email address";
    public static final String ENTER_VALID_EMAIL_TEXT = "Please enter valid email address";
    public static final String ENTER_PASSWORD_TEXT = "Please enter your password";
    public static final String ENTER_NEW_PASSWORD_TEXT = "Please enter your new password";
    public static final String RE_ENTER_NEW_PASSWORD_TEXT = "Please re-enter your new password";
    public static final String EQUAL_PASSWORD_TEXT = "Confirm Password and Password must match.";
    public static final String ENTER_FIRST_NAME = "Please enter your first name";
    public static final String ENTER_LAST_NAME = "Please enter your last name";
    public static final String ENTER_COMPANY_NAME = "Please enter company name";
    public static final String SELECT_COUNTRY = "Please select your country";
    public static final String SELECT_CITY = "Please select your city";
    public static final String ENTER_CONFIRM_PASSWORD = "Please enter your confirm password";
    public static final String ENTER_JOB_TITLE = "Please enter your job title";
    public static final String ENTER_MOBILE_NUM = "Please enter your cell number";
    public static final String ENTER_VALID_MOBILE_NUM = "Please enter valid cell number";
    public static final String ENTER_WEBSITE_TEXT = "Please enter website url";
    public static final String SELECT_COMPANY_SIZE = "Please select company size";
    public static final String ENTER_BIO_TEXT = "Please enter your company bio";
    public static final String MINIMUM_PASSWORD_LENGTH_ERROR = "Password must be greater than 8 characters";
    public static final String SELECT_INDUSTRY_ERROR = "Please select industry";
    public static final String SELECT_BUSSINESS_ERROR = "Please select type of bussiness";
    public static final String ENTER_DEPT = "Please enter department";
    public static final String ENTER_COMPANY_ADDRESS = "Please enter company address";
    public static final String ENTER_POSTAL_CODE = "Please enter your postal code";
    public static final String ENTER_PHONE_NUMBER = "Please enter your cell number";
    public static final String SELECT_CURRENCY = "Please select currency";
    public static final String CORRECT_WEBSITE_URL = "Please enter correct website url";
    public static final String SELECT_MARKETPLACE = "Please select marketplaces";
    public static final String SELECT_OPTION = "Please select an option";


    //all search Types
    public static final String ALL_SALE = "all_sale";
    public static final String ALL_RENT = "all_rent";


    // no data found text
    public static final String NO_LISTING_FOUND_TEXT = "No Listings Found";
    public static final String NO_CONNECTION_FOUND_TEXT = "No Connections Found";
    public static final String NO_NETWORK_FOUND_TEXT = "No Networks Found";
    public static final String NO_GROUP_FOUND_TEXT = "No Groups Found";
    public static final String NO_CHAT_FOUND_TEXT = "No chat Found";
    public static final String NO_RESULT_FOUND_TEXT = "No result found";
    public static final String NO_NETWORK_DEALERS_FOUND = "No network Dealers Found";
    public static final String INVALID_INPUT = "Invalid Input";
    public static final String NO_SUGGESTION_FOUND_TEXT = "No Suggestions Found";


    //localDb flags for chat
    public static final String FROM_LOCAL_DB_TRUE = "1";
    public static final String FROM_LOCAL_DB_FALSE = "0";

    // html messages
    public static final String EMMA_COOPER_MSG = "auto";
    public static final String LISTING_MSG = "listing";


    // respoonse success status text
    public static final String SUCCESS_STATUS = "success";


    /*Activity Codes*/
    public static final int PRIVACY_ACTIVITY_CODE = 200;
    public static final int ENQUIRY_ACTIVITY_CODE = 400;
    //Listing Detail Code
    public static final int LISTING_DETAIL_CODE = 300;
    /*Activity Codes*/


    //img upload types
    public static final String USER_PROFILE_IMG = "user-profile";
    public static final String USER_COVER_IMG = "user-cover";
    public static final String COMPANY_PROFILE_IMG = "company-profile";
    public static final String COMPANY_COVER_IMAGE = "company-cover";


    //free account values
    public static final String FREE_ACCOUNT_EMAIL = "1";
    public static final String BUSSINESS_EMAIL = "3";


    //Wizard Img Upload Messages
    public static final String USER_IMG_UPLOAD_MESSAGE = "Looking good! Please hit next below to upload your cover image";
    public static final String USER_COVER_IMG_UPLOAD_MESSAGE = "Good job, your profile is starting to look great! \nClick next below for profile info";
    public static final String COMPANY_IMG_UPLOAD_MESSAGE = "Looks smart, click Next below to add your company cover image";
    public static final String COMPANY_COVER_IMG_UPLOAD_MESSAGE = "Good job, your profile is starting to look great! \nClick next below for profile info";


    //listing public constants
    public static final String PUBLIC_LISTING = "1";


    // privacy values
    public static final String PUBLIC_PRIVACY = "Public";
    public static final String CONNECTIONS_PRIVACY = "Connections";
    public static final String CO_WORKER_PRIVACY = "Co-Worker";
    public static final String NETWORK_PRIVACY = "Network";
    public static final String NETWORK_GROUPS_PRIVACY = "Network Groups";
    public static final String DEALER_GROUPS_PRIVACY = "Dealer Groups";
    public static final String PRIVATE_CONNECTIONS_PRIVACY = "Private Connections";


    // Loading Progress Dialog Messages Messages
    public static final String SENDING_CONNECTION_REQUEST = "Sending your connection \nrequest";
    public static final String ACCEPTING_REQUEST = "Accepting Request";
    public static final String SENDING_NETWORK_REQUEST = "Sending your network \nrequest";
    public static final String ENQUIRY_SENDING_MESSAGE = "Sending your enquiry";
    public static final String UPLOAD_FILES_MESSAGE = "Uploading Files";

    //max limits
    public static final int NUMBER_OF_CHARACTERS_OF_PH_NUM = 8;


    //image extensions in Chat
    public static final String XLS = "xls";
    public static final String XLSX = "xlsx";
    public static final String DOC = "doc";
    public static final String DOCX = "docx";
    public static final String PPT = "ppt";
    public static final String PPTX = "pptx";
    public static final String PDF = "pdf";
    public static final String ZIP = "zip";
    public static final String RAR = "rar";


    // max file Size
    public static final long MAX_FILE_SIZE = 4 * 1024;


    // html space

    public static final String NBSP = "&nbsp";


    //external link text
    public static final String INVITE_STRING = "I would like to invite you to network with me on KRANK. It's free!";
    public static final String INVITE_CO_WORKER_STRING = "Hi, I'd like to invite you to join our company's official network on KRANK. It's free!";
    public static final String PRIVATE_INVITE_STRING = "I would like to invite you to private invitation on KRANK.";
    public static final String DEALER_INVITE_STRING = "Hi, I’d like to invite you to be our dealer network on KRANK. It's free!";
    public static final String LISTING_SHARE_STRING = "Here's a listing I thought you might be interested in ";
    public static final String ARTICLE_SHARE_STRING = "Here's a article I thought you might be interested in ";
    public static final String NORMAL_SHARE_STRING = "Here's something I thought you might be interested in ";


    //chat message type (server msgs)
    public static final String TEXT_MSG_TYPE = "text";
    public static final String V_CARD_TYPE = "vcard";
    public static final String ATTACHMENT_TYPE = "attachment";

    //dealer post type
    public static final int DEALER_POST_TYPE_ONE = 1;
    public static final int DEALER_POST_TYPE_TWO = 2;
    public static final int DEALER_POST_TYPE_THREE = 3;





    //loader and post view
    public static final int LOADER_VIEW = 1;
    public static final int ITEM_VIEW = 0;


    //NewsFeed callbacks type
    public static final int SHARE_CALLBACK = 1;
    public static final int LIKE_CALLBACK = 2;
    public static final int COMMENT_CALLBACK = 3;
    public static final int DELETE_CALLBACK = 4;
    public static final int POST_CALLBACK = 5;
    public static final int CREATE_POST_CALLBACK = 6;
    public static final int INVITE_COMPANIES_CALLBACK = 7;
    public static final int PHONE_VERIFY_CODE_CALLBACK = 8;
    public static final int EDIT_PROFILE_CALL_BACK = 9;
    public static final int SEND_CODE_CALL_BACK = 10;
    public static final int IN_APP_WEBVIEW = 8;
    public static final int EDIT_PROFILE_CALLBACK = 9;
    public static final int MARKET_PLACE_CALLBACK = 10;
    public static final int VIEW_EMPLOYEES_CALLBACK = 11;
    public static final int CONNECTION_BTN_CALLBACK = 12;
    public static final int SHOW_MESSAGE_VIEW = 13;
    public static final int USER_STATUS_BUTTON = 14;
    public static final int GOTO_CHAT = 15;
    public static final int MY_LISTING_PAGE = 16;
    public static final int USER_PROFILE = 17;
    public static final int REMOVE_SUGGESTED_CONNECTION_VIEW = 18;
    public static final int CONNECT_COMPANY_PROFILE = 19;
    public static final int MY_COMPANY_PROFILE = 20;
    public static final int COMPANY_PROFILE = 21;
    public static final int POST_IMAGE_CALLBACK = 22;
    public static final int GOTO_COMMENTS_REPLAY = 23;
    public static final int INVITE_CO_WORKER_CALLBACK = 24;
    public static final int OWNER_USER_PROFILE = 25;
    public static final int COMMENTS_USER_ID = 26;

    //account types
    public static final String FIRST_COMPANY = "first_company";
    public static final String ALREADY_COMPANY = "already_company";
    public static final String FREE_COMPANY = "free_company";
    public static final String GENERIC_INVITE = "generic_invite";


    //typing time delay
    public static final int TYPING_TIME_DELAY = 400;

    //page limit
    public static final int PAGE_LIMIT = 20;
    public static final int PAGE_LIMIT_1 = 10;

    //count down timer
    public static final int TIME_LIMIT = 60000;
    //public static final int TIME_LIMIT = 6000;
    public static final int COUNT_DOWN_INTERVAL = 1000;

    //for public market place
    public static final boolean IS_PUBLIC_MARKET_PLACE_VISIBLE = false;

    //sync unsync contacts
    public static final int UNSYNC = 1;
    public static final int UNSYNC_ALL = 2;

    //device name
    public static final String ANDROID_DEVICE = "Android";



    /**
     *
     * User Meta Keys
     *
     */
    public static String CONTACT_POPUP_META_KEY = "contact_popup_meta_key";


}
