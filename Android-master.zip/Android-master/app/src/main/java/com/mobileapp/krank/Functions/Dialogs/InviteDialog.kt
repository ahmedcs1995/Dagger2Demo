package com.mobileapp.krank.Functions.Dialogs


import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.Window

import com.mobileapp.krank.R

class InviteDialog(context: Context) : Dialog(context), View.OnClickListener {

    //listener
    internal var listener: DialogClickListener? = null
    var dialog: Dialog? = null


    //views
    private lateinit var private_btn: View
    private lateinit var close_btn: View


    private lateinit var comapany_invite_btn: View
    private lateinit var view3: View

    //interface
    interface DialogClickListener {
        fun onPrivateInviteClick(dialog: Dialog)
        fun onCompanyInviteClick(dialog: Dialog)
        fun onCloseClick(dialog: Dialog)
    }

    fun setListener(listener: DialogClickListener) {
        this.listener = listener
    }

    private var showDontAskButton: Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.invite_dialog)

        setCancelable(false)

        //init views
        private_btn = findViewById(R.id.private_btn)
        // learn_more_btn = findViewById(R.id.learn_more_btn);
        close_btn = findViewById(R.id.close_btn)

        comapany_invite_btn = findViewById(R.id.comapany_invite_btn)
        view3 = findViewById(R.id.view3)


        //listeners
        private_btn.setOnClickListener(this)
        //  learn_more_btn.setOnClickListener(this);
        close_btn.setOnClickListener(this)
        comapany_invite_btn.setOnClickListener(this)


    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.private_btn -> {
                if (listener != null) {
                    listener?.onPrivateInviteClick(this@InviteDialog)
                }
                dismiss()
            }
            R.id.comapany_invite_btn -> if (listener != null) {
                if (listener != null) {
                    listener?.onCompanyInviteClick(this@InviteDialog)

                }
                dismiss()
            }
            R.id.close_btn -> {

                dismiss()
            }

            else -> {
            }
        }

    }

}