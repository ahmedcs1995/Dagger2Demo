package com.mobileapp.krank.Activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import com.mobileapp.krank.Adapters.AppGeneralAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkGroupDataModel
import com.mobileapp.krank.ResponseModels.NetworkGroupResponse
import com.mobileapp.krank.ViewHolders.NetworkDealerGroupViewHolder
import kotlinx.android.synthetic.main.activity_network_dealer_group_screen.*
import kotlinx.android.synthetic.main.app_progress_bar.*

import java.util.ArrayList
import java.util.Arrays

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NetworkGroupScreen : BaseActivity() {

    //list items
    private lateinit var networkGroupList: MutableList<NetworkGroupDataModel>
    private lateinit var networkGroupRecyclerAdapter: AppGeneralAdapter<NetworkGroupDataModel>
    private var networkDataReceived: MutableList<NetworkGroupDataModel>?=null


    //adapter listeners
    private lateinit var callBack: CallBackWithAdapterPosAndType

    //previous selected
    private val selectedNetworkGroup: List<NetworkGroupDataModel>
        get() {

            val dealerGroup = ArrayList<NetworkGroupDataModel>()
            for (item in networkGroupList) {
                if (item.isItemChecked) {
                    dealerGroup.add(item)
                }
            }
            return dealerGroup
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network_dealer_group_screen)

        setUpCallBack()


        setNormalPageToolbar( "Network Groups")


        setUpAdapter()

        getDealerGroupData()


        done_btn.setOnClickListener {
            if (networkGroupList != null) {
                val selectedNetworkGroup = selectedNetworkGroup
                if (selectedNetworkGroup.isNotEmpty()) {
                    val intent = Intent()
                    intent.putExtra("SelectedDealerGroup", "" + appUtils.convertToJson(selectedNetworkGroup))
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                    overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
                } else {
                    Toast.makeText(this@NetworkGroupScreen, "Please Select Network Group", Toast.LENGTH_SHORT).show()
                }
            }

        }


    }


    private fun setUpCallBack(){
        callBack = object : CallBackWithAdapterPosAndType{
            override fun act(position: Int, type: Int) {
                when(type){
                    NetworkDealerGroupViewHolder.ITEM_CLICK -> {
                        networkGroupList[position].isItemChecked = !networkGroupList[position].isItemChecked
                        networkGroupRecyclerAdapter.updateListItem(position)
                    }
                    NetworkDealerGroupViewHolder.MORE_BTN_CLICK -> {
                        //goto Next Page
                        val intent = Intent(this@NetworkGroupScreen,NetworkAndDealerListInGroup::class.java)
                        with(intent){
                            putExtra("id",networkGroupList[position].id)
                            putExtra(NetworkAndDealerListInGroup.PAGE_KEY,NetworkAndDealerListInGroup.NETWORK_LIST)
                            putExtra(NetworkAndDealerListInGroup.PAGE_TITLE,networkGroupList[position].groupName)
                        }
                        startActivity(intent)
                    }
                }
            }
        }
    }

    private fun setUpAdapter() {
        networkGroupList = ArrayList()
        networkGroupRecyclerAdapter = object : AppGeneralAdapter<NetworkGroupDataModel>(networkGroupList) {
            override fun onBind(viewHolder: RecyclerView.ViewHolder, item: NetworkGroupDataModel, position: Int) {
                if (viewHolder is NetworkDealerGroupViewHolder) {
                    viewHolder.onBindNetworkGroup(item,this@NetworkGroupScreen)
                }
            }

            override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.dealer_group_parent_item, parent, false)
                return NetworkDealerGroupViewHolder(v,callBack)
            }
        }
        dealer_group_recycler_view.layoutManager = LinearLayoutManager(this@NetworkGroupScreen)
        dealer_group_recycler_view.adapter = networkGroupRecyclerAdapter
        networkGroupRecyclerAdapter.setItemAnimator(dealer_group_recycler_view)
    }

    private fun getDealerGroupData() {
        api.getNetworkGroup(preference.getString(Constants.ACCESS_TOKEN)).enqueue(object : Callback<NetworkGroupResponse> {
            override fun onResponse(call: Call<NetworkGroupResponse>, response: Response<NetworkGroupResponse>) {

                hideLoader()

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        onSuccess(response)
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    onResponseFailure()
                }
            }

            override fun onFailure(call: Call<NetworkGroupResponse>, t: Throwable) {
                hideLoader()
                onResponseFailure()

            }
        })
    }


    private fun onSuccess(response: Response<NetworkGroupResponse>) {
     //   networkGroupList = response.body().data

        //previous screen data
        val dataReceived = intent.getStringExtra("selectedArray").toString()

        networkDataReceived = Arrays.asList(*gson.fromJson(dataReceived, Array<NetworkGroupDataModel>::class.java))

        //updating data
        if(networkDataReceived != null){
            for (i in networkGroupList.indices) {
                for (j in networkDataReceived!!.indices) {
                    if (networkDataReceived!![j].id == networkGroupList[i].id) {
                        networkGroupList[i].isItemChecked = networkDataReceived!![j].isItemChecked
                    }
                }
            }
        }


        networkGroupRecyclerAdapter.addAll(response.body().data)

        checkForData()


    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }

    private fun checkForData() {
        if (networkGroupList.size <= 0) {
            no_network_group_text.visibility = View.VISIBLE
        }
    }

    private fun hideLoader() {
        loader.visibility = View.GONE
    }
}
