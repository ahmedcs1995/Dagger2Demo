package com.mobileapp.krank.Activities;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;

public class HelpAndSupportWebViews extends BaseActivity {


  //  ProgressBar progressBar;
    WebView webView;


    ProgressBar toolbar_loader;


    private static final String TERMS_AND_CONDITION_URL= Constants.SITE_BASE_URL +"/resources/terms-and-conditions";
    private static final String CONTACT_US=Constants.SITE_BASE_URL +"/contact-us";
    private static final String FAQ_URL=Constants.SITE_BASE_URL + "/faqs";
    private static final String PRIVACY_POLICY=Constants.SITE_BASE_URL + "/resources/privacy-policy";
    private static final String COOKIES_POLICY=Constants.SITE_BASE_URL + "/resources/cookie-policy";

    private static final String TERMS_AND_CONDITION_SCRIPT = "javascript:(function() { " +
            "document.getElementsByClassName('page-header')[0].style.display = 'none';" +
            "document.getElementsByClassName('navbar')[0].style.display = 'none';" +
            "document.getElementsByClassName('sidebar')[0].style.display = 'none';" +
            "document.getElementById('side-menu').style.display = 'none';" +
            "document.getElementById('page-wrapper').style.paddingTop = '10px'"+
            "})()";

    private static final String CONTACT_US_SCRIPT="javascript:(function() { " +
            "document.getElementsByTagName('header')[0].style.display = 'none';"+
            "document.getElementsByClassName('banner-contact')[0].style.marginTop = '0px';"+
            "document.getElementsByTagName('footer')[0].style.display = 'none';"+
            "document.getElementsByClassName('btn btn-primary create-accou')[0].style.display='none';"+
            "})()";

    private static final String FAQ_URL_SCRIPT="javascript:(function() { " +
            "document.getElementsByTagName('header')[0].style.display = 'none';"+
            "document.getElementsByClassName('banner-faqbg')[0].style.marginTop = '0px';"+
            "document.getElementsByTagName('footer')[0].style.display = 'none';"+
            "})()";

    private static final String PRIVACY_POLICY_SCRIPT="javascript:(function() { " +
            "document.getElementsByClassName('navbar-fixed-top')[0].style.display = 'none';" +
            "document.getElementsByClassName('page-header')[0].style.display = 'none';"+
            "})()";

    private static final String COOKIES_POLICY_SCRIPT=PRIVACY_POLICY_SCRIPT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_conditions);

        setNormalPageToolbar(getIntent().getStringExtra("web_view_type"));
        webView = (WebView) findViewById(R.id.webview);
        webView.setVisibility(View.GONE);


        toolbar_loader = findViewById(R.id.toolbar_loader);

     //   progressBar = findViewById(R.id.loader);

        //progressBar.setVisibility(View.VISIBLE);
        switch (getIntent().getStringExtra("web_view_type")){
            case Constants.CONTACT_KRANK:
                webView.loadUrl(getQueryStringUrl(CONTACT_US));
                break;
            case Constants.FAQS:
                webView.loadUrl(getQueryStringUrl(FAQ_URL));
                break;
            case Constants.COOKIES_POLICY:
                webView.loadUrl(getQueryStringUrl(COOKIES_POLICY));
                break;
            case Constants.TERMS_CONDITION:
                webView.loadUrl(getQueryStringUrl(TERMS_AND_CONDITION_URL));
                break;
            case Constants.PRIVACY:
                webView.loadUrl(getQueryStringUrl(PRIVACY_POLICY));
                break;
            case Constants.PURCHASE_ADDONS:
                break;
            case Constants.UPDATE_CARD:
                break;
            case Constants.PAYMENT_HISTORY:
                break;
        }

        webView.getSettings().setJavaScriptEnabled(true);
        webView.setInitialScale(1);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(false);


        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                webView.setVisibility(View.VISIBLE);

                switch (getIntent().getStringExtra("web_view_type")){
                    case Constants.CONTACT_KRANK:
                        webView.loadUrl(CONTACT_US_SCRIPT);
                        break;
                    case Constants.FAQS:
                        webView.loadUrl(FAQ_URL_SCRIPT);
                        break;
                    case Constants.COOKIES_POLICY:
                        webView.loadUrl(COOKIES_POLICY_SCRIPT);
                        break;
                    case Constants.TERMS_CONDITION:
                        webView.loadUrl(TERMS_AND_CONDITION_SCRIPT);
                        break;
                    case Constants.PRIVACY:
                        webView.loadUrl(PRIVACY_POLICY_SCRIPT);
                        break;
                    case Constants.PURCHASE_ADDONS:
                        break;
                    case Constants.UPDATE_CARD:
                        break;
                    case Constants.PAYMENT_HISTORY:
                        break;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {

            public void onProgressChanged(WebView view, int progress) {

                toolbar_loader.setProgress(progress);
                if(progress == 100){
                    toolbar_loader.setVisibility(View.GONE);
                }
                /*if (progress == 100) {
                    Log.e("progress done ->", "" + progress);
                   // progressBar.setVisibility(View.GONE);
                }*/

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

}
