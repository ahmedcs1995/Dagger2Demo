package com.mobileapp.krank.AccountSetupPages;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomUCropUtils;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.ApiUtils;
import com.yalantis.ucrop.UCrop;

import java.io.File;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Yaseen on 17/04/2018.
 */

public class AccountSetUpCompanyPicture extends BaseFragment {

    //views
    View imgSelect;
    ImageView companyImg;
    TextView picText;
    TextView text_view_name;


    CustomImagePicker imagePicker;

    public AccountSetUpCompanyPicture() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_five, container, false);
        setFragmentView(me);

        init();

        initViews();
        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));
        imgSelect.setOnClickListener(view -> {
            imagePicker.pickImage(AccountSetUpCompanyPicture.this);
        });

        setCompanyProfileImg();
        return me;
    }

    private void init(){
        preference = ((AccountSetupPage)getActivity()).preference;
        imagePicker = new CustomImagePicker();
    }

    private void initViews(){
        imgSelect = findViewById(R.id.img_select);
        picText = (TextView) findViewById(R.id.pic_text);
        companyImg = (ImageView) findViewById(R.id.company_img);
        text_view_name = (TextView) findViewById(R.id.text_view_name);
    }
    private void setCompanyProfileImg(){
        if(!(preference.getString(Constants.COMPANY_PROFILE_PICTURE).isEmpty())){
            picText.setText(Constants.COMPANY_IMG_UPLOAD_MESSAGE);
            Glide.with(getActivity()).load(preference.getString(Constants.COMPANY_PROFILE_PICTURE)).into(companyImg);
        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if(resultCode == RESULT_OK){
            if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(intent);
                ApiUtils.uploadImage(resultUri, Constants.COMPANY_PROFILE_IMG, preference, getContext());
                preference.setString(Constants.TEMP_COMPANY_PROFILE_PICTURE,resultUri.toString());
                setImage(resultUri);
            }
            else{
                Bitmap bitmap = imagePicker.handleImagePick(requestCode,getActivity(),  intent);
                if (bitmap != null) {
                    String destinationFileName = CustomUCropUtils.getFileName();
                    UCrop uCrop = UCrop.of(ImageUtils.getImageUri(getContext(), bitmap), Uri.fromFile(new File(getActivity().getCacheDir(), destinationFileName)));
                    uCrop = CustomUCropUtils.advancedConfig(uCrop, getContext(), Constants.COMPANY_PROFILE_IMG);
                    uCrop.start(getContext(), AccountSetUpCompanyPicture.this);
                }
            }
        }
    }


    private void setImage(Uri uri) {
        Constants.COMPANY_IMG = true;
        ((AccountSetupPage)getActivity()).hideSkipNowView();
        Glide.with(getContext()).load(uri).apply(new RequestOptions().centerCrop()).into(companyImg);
        picText.setText(Constants.COMPANY_IMG_UPLOAD_MESSAGE);
    }
}
