package com.mobileapp.krank.Base;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.util.Log;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.ContactsFetcher;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.DateTimeUtils;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.VersionChecker;
import com.mobileapp.krank.Model.Enums.SplashLinkReceived;
import com.mobileapp.krank.Repository.ContactsImportRepository;
import com.mobileapp.krank.ResponseModels.ContactsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList;
import com.mobileapp.krank.ResponseModels.UserOnlineStatusResponseModel;
import com.mobileapp.krank.SynchronizationFromServer.SyncUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import io.socket.client.IO;
import io.socket.client.Socket;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomApplication extends Application {
    Handler handler;
    Runnable runnable;
    //  private static long SECONDS_TO_REFRESH = 100000;
    private static long SECONDS_TO_REFRESH = 3000;
    private SaveInSharedPreference preference;

    AppUtils appUtils;

    ServiceManager serviceManager;

    //socket
    private Socket mSocket;
    private static final String ENCOD_SCHEME = "utf-8";


    //listing
    public String listingUrl;
    public SplashLinkReceived pageToRedirect;

    //network tab
    public List<NetworkList> networksItems;
    //connection tab
    public List<ConnectionsDataModel> connectionItems;
    //network tab
    public List<NetworkDealersData> dealerItems;

    Activity activity;


    boolean shouldStartService;
    public int badgeCount;

    //flag is phoneNumber change
    public boolean isNumberChange = false;

    boolean isDialogShow;

    //for new msg
    public List<ChatConversationListDataModel> recentChat;

    NormalAppDialog updateAppDialog;



    String deviceId;

    ContactsFetcher contactsFetcher;
    ContactsImportRepository mRepository;

    @Override
    public void onCreate() {
        super.onCreate();

        init();

        registerActivityLifeCycle();

        Constants.setBaseUrl(Constants.DEV_API);

        setUpRunnable();

        assignDeviceId();

        startService();



        //syncContacts();
    }

    private void fetchVersion() {
        if (activity instanceof MainPage) {
            isDialogShow = true;
            VersionChecker versionChecker = new VersionChecker();
            try {
                String latestVersion = versionChecker.execute().get();

                PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                String version = pInfo.versionName;
                int versionCode = pInfo.versionCode;
                //  Log.e("versionName","" + version);
                //  Log.e("versionCode","" + versionCode);
                //  Log.e("latestVersion","" + latestVersion);
                if (!(version.equals(latestVersion))) {
                    showDialog();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }


    private void setUpRunnable() {
        runnable = () -> {
            if (!(preference.getString(Constants.ACCESS_TOKEN).isEmpty())) {
                onlineApiCall();
            }
            handler.postDelayed(runnable, SECONDS_TO_REFRESH);
        };
    }


    private void init() {
        shouldStartService = true;
        appUtils = AppUtils.getInstance();
        serviceManager = ServiceManager.getInstance();


        //initialize fresco library
        Fresco.initialize(this);

        handler = new Handler();

        preference = new SaveInSharedPreference(getApplicationContext());

        //contacts
        contactsFetcher = new ContactsFetcher(getApplicationContext());
        mRepository = new ContactsImportRepository((Application) getApplicationContext());
    }

    public ContactsFetcher getContactsFetcher() {
        return contactsFetcher;
    }

    private void registerActivityLifeCycle() {
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle bundle) {
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

                CustomApplication.this.activity = activity;

            }

            @Override
            public void onActivityStarted(Activity activity) {
                startService();
                CustomApplication.this.activity = activity;

            }

            @Override
            public void onActivityResumed(Activity activity) {
            }

            @Override
            public void onActivityPaused(Activity activity) {
                handler.removeCallbacks(runnable);
                shouldStartService = true;
            }

            @Override
            public void onActivityStopped(Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {


            }
        });
    }


    private void startService() {
        if (shouldStartService) {
            handler.postDelayed(runnable, SECONDS_TO_REFRESH);
            shouldStartService = false;
        }
    }

    private void onlineApiCall() {


        serviceManager.getAPI().onlineStatus(preference.getString(Constants.ACCESS_TOKEN), preference.getInt(Constants.HISTORY_ID)).enqueue(new Callback<UserOnlineStatusResponseModel>() {
            @Override
            public void onResponse(Call<UserOnlineStatusResponseModel> call, Response<UserOnlineStatusResponseModel> response) {
              //  Log.e("onResponse","Online APi");
                if (response.isSuccessful()) {
                    if (response.body().getStatus().toLowerCase().equals("logout")) {
                        if (activity != null) {
                            BaseActivity baseActivity = (BaseActivity) activity;
                            baseActivity.logOut();
                        }
                    } else if (response.body().getStatus().toLowerCase().equals(Constants.SUCCESS_STATUS)) {
                        if (response.body().getData() != null) {

                            //badge count
                            if (response.body().getData().getBadge_count() != badgeCount) {
                                badgeCount = response.body().getData().getBadge_count();

                                if (response.body().getData().getForce_update() && activity != null && !isDialogShow) {
                                    fetchVersion();
                                }
                                // ShortcutBadger.applyCount(getApplicationContext(), badgeCount);
                            }

                            /*if (deviceId != null) {
                                Log.e("mTotalContactsCount", CustomGson.getInstance().toJson(response.body().getData()));
                                int mTotalContactsCount;
                                int mMyContactsCount;

                                mTotalContactsCount = response.body().getData().getTotal_contacts();
                                mMyContactsCount = response.body().getData().getMy_contacts();

                                //time stamps
                                updateSyncTimeStamps(response.body().getData().getLast_sync_date());

                                //update cache
                                preference.setInt(Constants.TOTAL_CONTACTS_COUNT,mTotalContactsCount);
                                preference.setInt(Constants.MY_CONTACT_COUNT,mMyContactsCount);

                                //flag
                                if (mMyContactsCount > 0) {
                                    SyncUtils.createSyncAccount(getApplicationContext(),false, new CustomCallBack() {
                                        @Override
                                        public void act() {
                                            preference.setBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE,true);
                                        }
                                    });
                                    preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, true);
                                } else {
                                    //disable sync
                                    preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, false);
                                    SyncUtils.disableSync();
                                }

                                //if total sim count is zero, clear the local Db
                                if (mTotalContactsCount == 0) {
                                    preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, false);

                                    Log.e("IS_CONTACT_DB_EMPTY","" + preference.getBoolean(Constants.IS_CONTACT_DB_EMPTY));
                                  //  if (!preference.getBoolean(Constants.IS_CONTACT_DB_EMPTY)) {
                                        Log.e("IS_CONTACT_DB_EMPTY","In to the If");
                                        mRepository.deleteAllRecords();
                                   //     preference.setBoolean(Constants.IS_CONTACT_DB_EMPTY, true);
                                 //   }

                                }
                                deviceId = null;
                            }*/
                        }
                    }
                }


            }

            @Override
            public void onFailure(Call<UserOnlineStatusResponseModel> call, Throwable t) {
               // Log.e("OnFailure","Online APi");
            }
        });
    }

    private void updateSyncTimeStamps(String last_sync_date){

        if(preference.getLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP) <= 0){
            preference.setLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP,DateTimeUtils.convertUTCToLocalDeviceTime(last_sync_date));
            preference.setLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP,DateTimeUtils.convertUTCToLocalDeviceTime(last_sync_date));
        }

    }

    public void assignDeviceId() {
        deviceId = AppUtils.getDeviceId(getApplicationContext());
    }

    private void showDialog() {
        if (activity == null) return;
        updateAppDialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, activity))
                .setHeading("New version available")
                .setDescription("Please update your App to get the latest version with new features")
                .setConfirmButtonText("Update")
                .setConfirmButtonListener(dialog -> gotoPlayStore())
                .setCancelableDialog(false)
                .hideIcon();
        updateAppDialog.show();
    }

    private void gotoPlayStore() {
        final String appPackageName = getPackageName(); // package name of the app
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    public Socket initSocket() {

        if (mSocket != null) {
            return mSocket;
        }
        try {
            String socketUrl = Constants.CHAT_SERVER_URL;


            HostnameVerifier hostnameVerifier = (hostname, session) -> true;


            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {

                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {

                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new java.security.cert.X509Certificate[0];
                }
            }};
            X509TrustManager trustManager = (X509TrustManager) trustAllCerts[0];

            SSLContext sslContext = SSLContext.getInstance("SSL");
            // SSLContext sslContext = SSLContext.getDefault();
            sslContext.init(null, trustAllCerts, null);
            SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();


            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .hostnameVerifier(hostnameVerifier)
                    .sslSocketFactory(sslSocketFactory, trustManager)
                    .build();


            IO.Options opts = new IO.Options();

            opts.secure = true;
            opts.callFactory = okHttpClient;
            opts.webSocketFactory = okHttpClient;

            try {
                opts.query = "token=" + getEncodedToken(preference.getString(Constants.USER_ID_ENCRYPTED));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }


            mSocket = IO.socket(socketUrl, opts);

        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            e.printStackTrace();
        }
        return mSocket;
    }

    private String getEncodedToken(String USER_ENCREYPTED_ID) throws UnsupportedEncodingException {
        return URLEncoder.encode(USER_ENCREYPTED_ID, ENCOD_SCHEME);
    }

   /* public int getmTotalSimCount() {
        //get only other sim counts...merged contacts
        if(preference.getBoolean(Constants.CONTACTS_SYNC_ENABLED)){
            //only my device
            if(mTotalSimCount == 1){
                return 0;
            }
            //other devices
            else if(mTotalSimCount > 1){
                return mTotalSimCount - 1;
            }

        }
        return mTotalSimCount;
    }*/

    public int getmMyContactsCount() {
        return preference.getInt(Constants.MY_CONTACT_COUNT);
    }

    public int getmTotalContactsCount() {
        return preference.getInt(Constants.TOTAL_CONTACTS_COUNT);
    }

    public void setmMyContactsCount(int mMyContactsCount) {
        preference.setInt(Constants.MY_CONTACT_COUNT,mMyContactsCount);
    }

    public void setmTotalContactsCount(int mTotalContactsCount) {
        preference.setInt(Constants.TOTAL_CONTACTS_COUNT,mTotalContactsCount);
    }
}

