package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.CustomViews.SwitchButton;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.TypeOfBussinessData;
import java.util.List;

public class TypeOfBussinessAdapter extends RecyclerView.Adapter<TypeOfBussinessAdapter.ViewHolder> {
    private List<TypeOfBussinessData> items;
    Context context;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        TextView interest_text_view;
        SwitchButton check_box;
        Boolean isTouched = false;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            interest_text_view = itemView.findViewById(R.id.interest_text_view);
            check_box = itemView.findViewById(R.id.check_box);

            check_box.setOnTouchListener((view, motionEvent) -> {
                isTouched = true;
                return false;
            });
            check_box.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isTouched) {
                    isTouched = false;
                    items.get(getAdapterPosition()).setItemSelected(isChecked);
                }
            });
        }
    }

    public TypeOfBussinessAdapter(List<TypeOfBussinessData> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_stup_page_eight_checkbox_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final TypeOfBussinessAdapter.ViewHolder holder, final int position) {
        final TypeOfBussinessData item = items.get(position);


        holder.check_box.setChecked(item.isItemSelected());

        holder.interest_text_view.setText(item.getName());



    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}






