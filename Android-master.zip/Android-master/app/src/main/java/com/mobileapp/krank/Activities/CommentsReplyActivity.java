package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.mobileapp.krank.Adapters.CommentsReplyAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.CustomViews.MyBounceInterpolator;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Model.Enums.TypeOfComment;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.ChildCommentAddResponse;
import com.mobileapp.krank.ResponseModels.ChildCommentResponse;
import com.mobileapp.krank.ResponseModels.CommentGetByIdResponse;
import com.mobileapp.krank.ResponseModels.CommentLikeResponse;
import com.mobileapp.krank.ResponseModels.DataModel.ChildCommentDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsDataResponse;
import com.mobileapp.krank.ResponseModels.GeneralResponse;


import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommentsReplyActivity extends BaseActivity {
    private RecyclerView commentsRecyclerView;
    private CommentsReplyAdapter commentsRecyclerAdapter;
    List<ChildCommentDataModel> commentsItems;
    private ShimmerFrameLayout mShimmerViewContainer;
    CommentsDataResponse commentsDataResponse;
    public EditText commentAddText;
    View postBtn;
    public long lastCommentId;
    CircleImageView profileImg;
    View commentBox;

    private boolean exit;
    private int lastListSize;
    boolean isSendBtnClick;

    //callback
    CallBackWithPosTypeAndView callBackWithView;

    //animation
    MyBounceInterpolator interpolator;
    Animation myAnim;



    public static final String COMMENT_ID = "comment_id_key";
    public static final String COMMENT_DATA = "comment_data_key";
    public static final String IS_ACCESSIBLE = "is_accessable_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments_reply);
        lastCommentId = -1;

        exit = false;
        isSendBtnClick = false;


        //views
        mShimmerViewContainer = findViewById(R.id.shimmer_view_container);
        commentAddText = findViewById(R.id.comment_add_text);
        postBtn = findViewById(R.id.post_btn);
        commentAddText.setHint("Type your Reply");
        profileImg = findViewById(R.id.profile_img);
        commentBox = findViewById(R.id.footer);


        //animation
        interpolator = new MyBounceInterpolator(0.2, 20);
        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce_for_comment_click);


        setUpCallBack();

        if (getIntent().getBooleanExtra("from_notification", false)) {
            getCommentById();

        } else {
            final String commentData = getIntent().getStringExtra(COMMENT_DATA);
            commentsDataResponse = gson.fromJson(commentData.toString(), CommentsDataResponse.class);
            setNormalPageToolbar("" + commentsDataResponse.getFirstName() + " " + commentsDataResponse.getLastName() + "'s comment replies");
            setUpCommentsAdapter();
            getComments(false);
        }

        postBtn.setOnClickListener(view -> {
            if (commentAddText.getText().length() > 0) {
                isSendBtnClick = true;
                postComment(commentsDataResponse.getCid(), commentAddText.getText().toString());
                commentAddText.setText("");
            }
        });

        Glide.with(this).load(AppUtils.getImgUrl(preference.getString(Constants.PROFILE_PICTURE))).into(profileImg);


    }

    private void setUpCallBack() {
        callBackWithView = (position, type, view) -> {
            switch (type) {
                case CommentsReplyAdapter.SEND_COMMENT_LIKE:
                    sendCommentLike(commentsDataResponse, position, view);
                    break;
                case CommentsReplyAdapter.SEND_COMMENT_REPLY_LIKE:
                    sendReplyLike(commentsItems.get(position), position, view);
                    break;
                case CommentsReplyAdapter.REPLY_CALLBACK:
                    view.startAnimation(myAnim);
                    commentAddText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                    break;
                case CommentsReplyAdapter.DELETE_COMMENT_CALLBACK:
                    showDeletePopUpMenu(view, commentsItems.get(position), position);
                    break;
                case CommentsReplyAdapter.COMMENT_USER_PROFILE:
                    gotoUserProfile(String.valueOf(commentsDataResponse.getUser_id()));
                    break;
                case CommentsReplyAdapter.COMMENT_REPLY_USER_PROFILE:
                    gotoUserProfile(String.valueOf(commentsItems.get(position).getUser_id()));
                    break;

            }

        };

    }

    private void gotoUserProfile(String userId) {
        Intent intent = new Intent(this, UserProfileView.class);
        intent.putExtra(UserProfileView.INTENT_USER_ID, userId);
        startActivity(intent);
    }
    private void getCommentById() {
        getAPI().commentGetById(preference.getString(Constants.ACCESS_TOKEN), getIntent().getStringExtra("postId"), getIntent().getStringExtra(COMMENT_ID)).enqueue(new Callback<CommentGetByIdResponse>() {
            @Override
            public void onResponse(Call<CommentGetByIdResponse> call, Response<CommentGetByIdResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (response.body().getData().size() > 0) {
                            commentsDataResponse = response.body().getData().get(0);
                            setNormalPageToolbar( "" + commentsDataResponse.getFirstName() + " " + commentsDataResponse.getLastName() + "'s comment replies");
                            setUpCommentsAdapter();
                            getComments(false);
                            return;
                        }
                    }
                }
                hideLoader();
                appUtils.gotoHomePage(CommentsReplyActivity.this);
            }

            @Override
            public void onFailure(Call<CommentGetByIdResponse> call, Throwable t) {
                hideLoader();
                appUtils.gotoHomePage(CommentsReplyActivity.this);
            }
        });
    }


    /**
     *
     * Comment Box Privacy
     *
     * */
    private void commentBoxPrivacy(){
        if(getIntent().getBooleanExtra(IS_ACCESSIBLE,false)){
            commentBox.setVisibility(View.VISIBLE);
        }else{
            commentBox.setVisibility(View.GONE);
        }
    }


    private void setUpCommentsAdapter() {
        commentsRecyclerView = findViewById(R.id.comments_recycler);
        commentsItems = new ArrayList<>();

        commentsItems.add(new ChildCommentDataModel(TypeOfComment.COMMENT));

        commentsRecyclerAdapter = new CommentsReplyAdapter(commentsItems, CommentsReplyActivity.this, commentsDataResponse, callBackWithView);
        commentsRecyclerView.setLayoutManager(new LinearLayoutManager(CommentsReplyActivity.this));
        commentsRecyclerView.setAdapter(commentsRecyclerAdapter);

        ((SimpleItemAnimator) commentsRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        commentBoxPrivacy();
    }

    private void getComments(boolean pullRequest) {
        final String commentId = getIntent().getStringExtra(COMMENT_ID);
        getAPI().getChildComments(preference.getString(Constants.ACCESS_TOKEN), commentId).enqueue(new Callback<ChildCommentResponse>() {
            @Override
            public void onResponse(Call<ChildCommentResponse> call, Response<ChildCommentResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        List<ChildCommentDataModel> comments = response.body().getData();
                        if (comments.size() > 0) {
                            if (lastCommentId == -1) {
                                for (ChildCommentDataModel item : comments) {
                                    item.setTypeOfComment(TypeOfComment.SUB_COMMENT);
                                }

                                lastListSize = commentsItems.size();
                                commentsItems.addAll(comments);

                                CommentsReplyActivity.this.commentsDataResponse.setChildCount(String.valueOf(commentsItems.size() - 1));

                                commentsRecyclerAdapter.notifyItemRangeInserted(lastListSize, commentsItems.size());
                                commentsRecyclerAdapter.notifyItemChanged(0);

                                if (isSendBtnClick) {
                                    isSendBtnClick = false;
                                    commentsRecyclerView.scrollToPosition(commentsRecyclerAdapter.getItemCount() - 1);
                                }
                                lastCommentId = Long.parseLong(comments.get(comments.size() - 1).getI());

                                if (getIntent().getBooleanExtra("from_notification", false)) {
                                    highlightView();
                                }

                            } else {
                                int i = 0;
                                while (i < comments.size()) {
                                    if (Long.parseLong(comments.get(i).getI()) == lastCommentId) {
                                        break;
                                    }
                                    i++;
                                }

                                if (i + 1 < comments.size()) {
                                    List<ChildCommentDataModel> newComments = comments.subList(i + 1, comments.size());

                                    for (ChildCommentDataModel item : newComments) {
                                        item.setTypeOfComment(TypeOfComment.SUB_COMMENT);
                                    }
                                    lastListSize = commentsItems.size();
                                    commentsItems.addAll(newComments);
                                    commentsRecyclerAdapter.notifyItemRangeInserted(lastListSize, commentsItems.size());
                                    CommentsReplyActivity.this.commentsDataResponse.setChildCount(String.valueOf(commentsItems.size() - 1));
                                    commentsRecyclerAdapter.notifyItemChanged(0);
                                    if (isSendBtnClick) {
                                        isSendBtnClick = false;
                                        commentsRecyclerView.scrollToPosition(commentsRecyclerAdapter.getItemCount() - 1);
                                    }
                                    lastCommentId = Long.parseLong(comments.get(comments.size() - 1).getI());
                                }
                            }
                        }
                    } else {
                        //show the error Message
                        if (!pullRequest) {
                            onResponseFailure();
                        }
                    }
                } else {
                    //show the error Message
                    if (!pullRequest) {
                        onResponseFailure();
                    }
                }


                //hide the loader
                hideLoader();

                // pull for new data
                if (!exit) {
                    pull();
                }

            }

            @Override
            public void onFailure(Call<ChildCommentResponse> call, Throwable t) {
                mShimmerViewContainer.setVisibility(View.GONE);
                commentsRecyclerView.setVisibility(View.VISIBLE);
                if (!exit) {
                    pull();
                }

            }
        });
    }

    private void hideLoader() {
        mShimmerViewContainer.setVisibility(View.GONE);
        if (commentsRecyclerView != null) {
            commentsRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void postComment(String commentId, String comment) {

        comment = appUtils.replaceScriptString(comment);
        if (comment.length() <= 0) {
            Toast.makeText(getApplicationContext(), Constants.INVALID_INPUT, Toast.LENGTH_SHORT).show();
            return;
        }

        getAPI().postChildComment(preference.getString(Constants.ACCESS_TOKEN), commentId, String.valueOf(comment)).enqueue(new Callback<ChildCommentAddResponse>() {
            @Override
            public void onResponse(Call<ChildCommentAddResponse> call, Response<ChildCommentAddResponse> response) {
                commentAddText.setText("");
            }

            @Override
            public void onFailure(Call<ChildCommentAddResponse> call, Throwable t) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        //  super.onBackPressed();

        if (isTaskRoot()) {
            Intent intent = new Intent(CommentsReplyActivity.this, CommentsActivity.class);
            intent.putExtra("from_notification", true);
            intent.putExtra("postId", getIntent().getStringExtra("postId"));
            startActivity(intent);
            finish();
        } else {
            Log.e("news feed up", "" + commentsDataResponse.getIsLike());
            Log.e("news feed up", "" + commentsDataResponse.getTotalLikes());
            Intent intent = new Intent();
            intent.putExtra("likeCount", commentsDataResponse.getTotalLikes());
            intent.putExtra("isLike", commentsDataResponse.getIsLike());
            intent.putExtra("reply_count", commentsItems.size() - 1);
            if ((commentsItems.size() - 1) > 0) {
                intent.putExtra("first_reply", appUtils.convertToJson(commentsItems.get(1)));
            } else {
                intent.putExtra("first_reply", "No Items");
            }
            setResult(RESULT_OK, intent);
            finish();
            overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
        }

    }

    private void pull() {
        getComments(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        exit = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exit = true;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        exit = false;
        pull();
    }

    private void highlightView() {
        String subCommentId = getIntent().getStringExtra("subcommentId");
        for (int i = 1; i < commentsItems.size(); i++) {
            if (commentsItems.get(i).getI().equals(subCommentId)) {
                commentsItems.get(i).setFoucsComment(true);
                commentsRecyclerAdapter.notifyItemChanged(i);
                commentsRecyclerView.scrollToPosition(i);
            }
        }
    }

    private void sendCommentLike(final CommentsDataResponse commentItem, final int position, final View likeBtn) {

        /*animate like btn*/

        Animation likeAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        likeAnim.setInterpolator(interpolator);

        likeBtn.startAnimation(likeAnim);

        /*animate like btn*/

        int isLike = commentItem.getIsLike();
        final int likeToSend;
        if (isLike == 1) {
            likeToSend = 0;
        } else {
            likeToSend = 1;
        }

        /*changing runtime*/

        if (likeToSend == 0) {
            commentItem.setTotalLikes("" + (Integer.parseInt(commentItem.getTotalLikes()) - 1));
        } else {
            commentItem.setTotalLikes("" + (Integer.parseInt(commentItem.getTotalLikes()) + 1));
        }
        commentItem.setIsLike(likeToSend);
        commentsRecyclerAdapter.notifyItemChanged(position);
        likeBtn.setEnabled(false);

        /*changing runtime*/
        getAPI().postCommentLike(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(commentItem.getCid()), String.valueOf(likeToSend)).enqueue(new Callback<CommentLikeResponse>() {
            @Override
            public void onResponse(Call<CommentLikeResponse> call, Response<CommentLikeResponse> response) {
               likeBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                    }

                }
            }

            @Override
            public void onFailure(Call<CommentLikeResponse> call, Throwable t) {
                likeBtn.setEnabled(true);

            }
        });
    }

    private void sendReplyLike(final ChildCommentDataModel childCommentItem, final int position, final View likeBtn) {

        /*animate like btn*/

        Animation likeAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        likeAnim.setInterpolator(interpolator);

        likeBtn.startAnimation(likeAnim);

        /*animate like btn*/

        int isLike = childCommentItem.getIsLike();
        final int likeToSend;
        if (isLike == 1) {
            likeToSend = 0;
        } else {
            likeToSend = 1;
        }


        /*changing runtime*/
        int likeCount;
        if (likeToSend == 0) {
            likeCount = Integer.parseInt(childCommentItem.getTotalLikes()) - 1;
            childCommentItem.setTotalLikes(String.valueOf(likeCount));
        } else {
            likeCount = Integer.parseInt(childCommentItem.getTotalLikes()) + 1;
            childCommentItem.setTotalLikes(String.valueOf(likeCount));
        }
        childCommentItem.setIsLike(likeToSend);
        commentsRecyclerAdapter.notifyItemChanged(position);
        likeBtn.setEnabled(false);
        /*changing runtime*/

        getAPI().postChildCommentLike(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(childCommentItem.getI()), String.valueOf(likeToSend)).enqueue(new Callback<CommentLikeResponse>() {
            @Override
            public void onResponse(Call<CommentLikeResponse> call, Response<CommentLikeResponse> response) {
                likeBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                    }

                }
            }

            @Override
            public void onFailure(Call<CommentLikeResponse> call, Throwable t) {
                likeBtn.setEnabled(true);


            }
        });
    }

    private void showDeletePopUpMenu(View view, final ChildCommentDataModel commentItem, final int position) {

        PopupMenu popupMenu = AppUtils.getDeletePopUpMenu(view, this, (popupMenu1) -> {
            popupMenu1.dismiss();
            showDialog(commentItem, position);
        });

        popupMenu.show();

    }

    private void showDialog(ChildCommentDataModel commentItem, int position) {
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Are you sure?")
                .setDescription("Are you sure you want to delete the comment")
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    removeComment(commentItem, position);
                });

        dialog.show();
    }

    private void removeComment(final ChildCommentDataModel commentItem, final int position) {


        getAPI().newsFeedChildCommentRemove(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(commentItem.getI())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        commentsRecyclerAdapter.removeAt(position);
                        commentsDataResponse.setChildCount(String.valueOf(commentsItems.size() - 1));
                        commentsRecyclerAdapter.notifyItemChanged(0);

                        if (commentsItems.size() == 1) {
                            lastCommentId = -1;
                        }

                    }
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {


            }
        });
    }


}
