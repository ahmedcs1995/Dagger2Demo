package com.mobileapp.krank.Activities

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle

/**
 * For Avoiding Multiple Instances of the App
 * */
class IntentDeepLinkForwardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
    }

    override fun onNewIntent(intent_1: Intent?) {
        super.onNewIntent(intent_1)
        handleIntent(intent)
    }
    private fun handleIntent(intent: Intent) {
        intent.setClass(this, SplashScreen::class.java)
        startActivity(intent)
        finish()
    }

}