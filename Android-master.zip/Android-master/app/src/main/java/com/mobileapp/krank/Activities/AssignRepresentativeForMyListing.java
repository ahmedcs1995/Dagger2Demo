package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IntDef;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.AssignRepresentativeChipAdapter;
import com.mobileapp.krank.Adapters.ListingEmployeesDataAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.AddRemoveListener;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.GetNetworkEmployeeResponse;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AssignRepresentativeForMyListing extends BaseActivity {

    private static final String TAG = AssignRepresentativeForMyListing.class.getSimpleName();


    // vertical list
    List<GetNetworkEmployeeData> mEmployeesData;
    RecyclerView mEmployeeRecyclerView;
    RecyclerView.Adapter mEmployeesAdapter;


    AddRemoveListener listener;

    //horizontal list
    List<GetNetworkEmployeeData> mChipAdapterItems;
    RecyclerView mChipRecyclerView;
    RecyclerView.Adapter mChipAdapter;
    LinearLayoutManager mSelectedAssignmentLayoutManager;

    //flag for vertical and horizontal list
    public static final int SELECTED_LIST_ITEM = 0;
    public static final int MAIN_LIST = 1;

    View select_btn;

    ListingDataArray mListingItem;

    ProgressBar mProgressBar;

    private SweetAlertDialog showProgressAlert;


    boolean removeItemFromList;
    // Bundling them under one definition
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({SELECTED_LIST_ITEM, MAIN_LIST})
    public @interface OperationsDef {
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_representative_for_my_listing);
        init();
        initViews();

        mListingItem = getListingItem();

        mChipAdapterItems.addAll(getRepresentativeSelectedData());

        setNormalPageToolbar( "Assign Representative");

        setmChipAdapter();

        setmEmployeesAdapter();

        getEmployeesData();

    }

    private void setCallBacks(){
        select_btn.setOnClickListener(view -> {
            if(mChipAdapterItems.size() <= 0){
                Toast.makeText(AssignRepresentativeForMyListing.this,Constants.SELECT_OPTION,Toast.LENGTH_SHORT).show();
                return;
            }
            showProgressAlert.show();
            getAPI().listingRepresentativePost(preference.getString(Constants.ACCESS_TOKEN),mListingItem.getId(),getSelectedRepresentativeIds()).enqueue(new Callback<GeneralResponse>() {
                @Override
                public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                    Log.e(TAG,gson.toJson(response.body()));
                    Log.e(TAG,gson.toJson(call.request()));
                    showProgressAlert.dismiss();

                    if(response.isSuccessful()){
                        if(response.body().getStatus().equals(Constants.SUCCESS_STATUS)){
                            Intent intent = new Intent();
                            intent.putExtra("assign_data",gson.toJson(mChipAdapterItems));
                            intent.putExtra("remove_item_from_list",removeItemFromList);

                            intent.putExtra("item_index",getIntent().getIntExtra("item_index",0));
                            setResult(RESULT_OK, intent);
                            finish();
                            Toast.makeText(AssignRepresentativeForMyListing.this,response.body().getMessage(),Toast.LENGTH_SHORT);
                        }
                        else{
                            Toast.makeText(AssignRepresentativeForMyListing.this,response.body().getMessage(),Toast.LENGTH_SHORT);
                        }
                    }else{

                    }
                }

                @Override
                public void onFailure(Call<GeneralResponse> call, Throwable t) {
                    showProgressAlert.dismiss();
                    Log.e(TAG,gson.toJson(call.request()));
                    onResponseFailure();
                }
            });
        });
    }

    private ArrayList<String> getSelectedRepresentativeIds(){
        ArrayList<String> ids = new ArrayList<>();
        for (GetNetworkEmployeeData item : mChipAdapterItems) {
            if(item.getId().equals(preference.getString(Constants.USER_ID))){
                // remove the listing
                removeItemFromList = false;
            }
            ids.add(item.getId());
        }
        return ids;
    }
    private void init() {
        mChipAdapterItems = new ArrayList<>();
        mEmployeesData = new ArrayList<>();

        showProgressAlert = showAlert(Constants.LOADING,SweetAlertDialog.PROGRESS_TYPE,false);

        removeItemFromList = true;


        listener = new AddRemoveListener() {
            @Override
            public void add(GetNetworkEmployeeData item, int type) {
                if (type == MAIN_LIST) {
                    mChipAdapterItems.add(item);
                    mChipAdapter.notifyItemInserted(mChipAdapterItems.size() - 1);
                    if (mChipAdapterItems.size() > 1) {
                        mChipRecyclerView.smoothScrollToPosition(mChipAdapterItems.size() - 1);
                    }
                } else {
                    //TODO

                }
            }

            @Override
            public void remove(GetNetworkEmployeeData item, int type) {
                if (type == MAIN_LIST) {
                    for (int i = 0; i < mChipAdapterItems.size(); i++) {
                        if (mChipAdapterItems.get(i).getId().equals(item.getId())) {
                            mChipAdapterItems.remove(i);
                            mChipAdapter.notifyItemRemoved(i);
                            mChipAdapter.notifyItemRangeChanged(i, mChipAdapterItems.size());
                            break;
                        }
                    }
                } else {
                    for (int i = 0; i < mEmployeesData.size(); i++) {
                        if (mEmployeesData.get(i).getId().equals(item.getId())) {
                            mEmployeesData.get(i).setItemSelected(false);
                            mEmployeesAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }

            }
        };

    }

    private void initViews() {
        mChipRecyclerView = findViewById(R.id.chip_adapter);
        mEmployeeRecyclerView = findViewById(R.id.employee_recycler_view);
        select_btn = findViewById(R.id.select_btn);
        mProgressBar = findViewById(R.id.loader);
    }

    private void setmChipAdapter() {
        mChipAdapter = new AssignRepresentativeChipAdapter(mChipAdapterItems, this, listener);
        mSelectedAssignmentLayoutManager=new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        mChipRecyclerView.setLayoutManager(mSelectedAssignmentLayoutManager);
        //    mChipRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mChipRecyclerView.setAdapter(mChipAdapter);

    }

    private void setmEmployeesAdapter() {
        mEmployeesAdapter = new ListingEmployeesDataAdapter(mEmployeesData, this, listener);
        mEmployeeRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mEmployeeRecyclerView.setAdapter(mEmployeesAdapter);
        ((SimpleItemAnimator) mEmployeeRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

    }

    private void getEmployeesData() {
        getAPI().getListingNetworkEmployee(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<GetNetworkEmployeeResponse>() {
            @Override
            public void onResponse(Call<GetNetworkEmployeeResponse> call, Response<GetNetworkEmployeeResponse> response) {
                Log.e(TAG, appUtils.convertToJson(response.body()));
                Log.e(TAG, appUtils.convertToJson(call.request()));
                mProgressBar.setVisibility(View.GONE);
                setCallBacks();
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        mEmployeesData.addAll(response.body().getData());
                        for (GetNetworkEmployeeData item : mEmployeesData) {
                            for (GetNetworkEmployeeData mChipData : mChipAdapterItems) {
                                if (item.equals(mChipData)) {
                                    // set item selected == true
                                    item.setItemSelected(true);
                                }
                            }
                        }
                        mEmployeesAdapter.notifyDataSetChanged();

                    } else {
                        // Toast.makeText(AssignRepresentativeForMyListing.this,response.body().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                } else {
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<GetNetworkEmployeeResponse> call, Throwable t) {
                setCallBacks();
                mProgressBar.setVisibility(View.GONE);
                Log.e(TAG, appUtils.convertToJson(call.request()));
                onResponseFailure();
            }
        });
    }


    private List<GetNetworkEmployeeData> getRepresentativeSelectedData() {
        return mListingItem.getRepresentativeData();
    }

    private ListingDataArray getListingItem() {
        return gson.fromJson(getIntent().getStringExtra("listing_item"), ListingDataArray.class);
    }


}
