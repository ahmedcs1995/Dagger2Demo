package com.mobileapp.krank.Model;

import com.mobileapp.krank.CallBacks.CustomCallBack;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ahmed on 4/12/2018.
 */

public class DrawerMenu {
    String name;
    String sign = null;
    int drawableIcon;
    CustomCallBack ItemClick;


    List<DrawerSubItem> items = new ArrayList<>();

    public DrawerMenu(String name, String sign) {
        this.name = name;
        this.sign = sign;
    }

    public DrawerMenu(String name, String sign, List<DrawerSubItem> items) {
        this.name = name;
        this.sign = sign;
        this.items = items;
    }

    public DrawerMenu(String name, int drawableIcon, CustomCallBack itemClick) {
        this.name = name;
        this.drawableIcon = drawableIcon;
        ItemClick = itemClick;
    }

    public DrawerMenu(String name, String sign, CustomCallBack subItemClick){
        this.name = name;
        this.sign = sign;
        this.ItemClick = subItemClick;
    }

    public DrawerMenu(String name, String sign, int drawableIcon, List<DrawerSubItem> items) {
        this.name = name;
        this.sign = sign;
        this.drawableIcon = drawableIcon;
        this.items = items;
    }

    public List<DrawerSubItem> getItems() {
        return items;
    }

    public void setItems(List<DrawerSubItem> items) {
        this.items = items;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public CustomCallBack getItemClick() {
        return ItemClick;
    }

    public void setItemClick(CustomCallBack itemClick) {
        ItemClick = itemClick;
    }

    public int getDrawableIcon() {
        return drawableIcon;
    }

    public void setDrawableIcon(int drawableIcon) {
        this.drawableIcon = drawableIcon;
    }


}
