package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.SimpleItemAnimator
import android.text.Editable
import android.text.TextWatcher
import android.view.View

import com.mobileapp.krank.Adapters.ListOfEmployeesAndConnectionsAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ResponseModels.GetNetworkEmployeeResponse

import java.util.ArrayList

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import com.mobileapp.krank.ViewHolders.NetworkEmployeeViewHolder.BaseViewHolder
import kotlinx.android.synthetic.main.activity_view_connections_in_my_network.*


class ListOfEmployeesAndConnections : BaseActivity(), CallBackWithAdapterPosAndType {

    //list items
    private var networksRecyclerAdapter: ListOfEmployeesAndConnectionsAdapter? = null
    private lateinit var listItem: MutableList<GetNetworkEmployeeData>
    private lateinit var layoutManager: LinearLayoutManager

    var offset: Int = 0

    private var hideCoWorkerView: Boolean = false
    private var shouldScrollCalled: Boolean = false


    //delay
    var handler: Handler = Handler()
    var runnable: Runnable? = null


    //typing events
    private var onTypingTimeout: Runnable? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_connections_in_my_network)




        setUpTypingTimeoutRunnable()
        runnable = Runnable {
            getEmployeesData()
        }


        //views
        shimmer_view_container.startShimmer()


        setUpAdapter()


        // employees and connections

        setUpToolbar()

        hideCoWorkerView = true

        networksRecyclerAdapter!!.setFlag(hideCoWorkerView)

        getEmployeesData()



        addOnScrollEndListener()
        addOnSwipeToRefreshListener()



        search_edit_text.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(onTypingTimeout)
            }

            override fun afterTextChanged(editable: Editable) {
                addOnTextChangeListener()
            }
        })
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {


            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            listItem.clear()
            listItem.add(GetNetworkEmployeeData(GetNetworkEmployeeData.LOADER_VIEW))
            networksRecyclerAdapter!!.notifyDataSetChanged()


            //api data
            getEmployeesData()
            //  }

        }
    }


    private fun addOnTextChangeListener() {

        handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())


    }

    private fun addOnScrollEndListener() {
        view_connections_recycler_view.addOnScrollListener(object : EndlessOnScrollListener(layoutManager) {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun addOnSwipeToRefreshListener() {
        swipe_refresh.setOnRefreshListener {
            //scroll
            offset = 0
            shouldScrollCalled = false

            //reset the data
            listItem.clear()
            networksRecyclerAdapter!!.notifyDataSetChanged()


            swipe_refresh.isRefreshing = true

            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())
        }
    }

    private fun onScrollEnd() {
        //call the api
        if (shouldScrollCalled) {
            shouldScrollCalled = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())

        }
    }

    private fun setUpAdapter() {
        listItem = ArrayList()
        networksRecyclerAdapter = ListOfEmployeesAndConnectionsAdapter(listItem, this@ListOfEmployeesAndConnections, this)
        layoutManager = LinearLayoutManager(this@ListOfEmployeesAndConnections)
        view_connections_recycler_view.layoutManager = layoutManager
        view_connections_recycler_view.adapter = networksRecyclerAdapter
        (view_connections_recycler_view.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false


    }

    private fun setUpToolbar() {
        if (intent.getBooleanExtra(IS_VIEW_YOUR_CONNECTION_CLICK, false)) {
            setNormalPageToolbar(intent.extras.getString(NAME_KEY) + "'s Connections")
            return
        }
        else if(intent.getBooleanExtra(FROM_USER_PROFILE, false)){
            setNormalPageToolbar(intent.extras.getString(USER_NAME) + "'s Co-Workers")
            return
        }
        setNormalPageToolbar( intent.extras.getString(NAME_KEY) + "'s Employees")
    }

    private fun removeListLoader() {
        for (i in listItem.indices.reversed()) {
            if (listItem[i].viewType == GetNetworkEmployeeData.LOADER_VIEW) {
                listItem.removeAt(i)
                networksRecyclerAdapter!!.notifyItemRemoved(i)
                break
            }
        }
    }


    private fun checkForData(errorMessage: String) {
        if (listItem.size <= 0) {
            no_connection_text.visibility = View.VISIBLE
            no_connection_text.text = errorMessage
            // view_connections_recycler_view.visibility = View.GONE
        } else {
            no_connection_text.visibility = View.GONE
            // view_connections_recycler_view.visibility = View.VISIBLE
        }
    }

    private fun getEmployeesData() {
        api.getNetworkEmployee(preference.getString(Constants.ACCESS_TOKEN), Integer.parseInt(intent.extras!!.getString(COMPANY_ID)), Constants.PAGE_LIMIT, offset, search_edit_text.text.toString(), if (intent.getBooleanExtra(IS_VIEW_YOUR_CONNECTION_CLICK, false)) "connected" else "all")
                .enqueue(object : Callback<GetNetworkEmployeeResponse> {
                    override fun onResponse(call: Call<GetNetworkEmployeeResponse>, response: Response<GetNetworkEmployeeResponse>) {

                        swipe_refresh.isRefreshing = false
                        removeLoader()
                        removeListLoader()

                        if (response.isSuccessful) {
                            if (response.body().status == Constants.SUCCESS_STATUS) {

                                var data: List<GetNetworkEmployeeData> = response.body().data

                                listItem.addAll(data)


                                /*for pagination*/
                                if (data.size >= Constants.PAGE_LIMIT) {
                                    listItem.add(GetNetworkEmployeeData(GetNetworkEmployeeData.LOADER_VIEW))
                                    shouldScrollCalled = true
                                }
                                /*for pagination*/

                                networksRecyclerAdapter!!.notifyItemRangeInserted(listItem.size - response.body().data.size, listItem.size)

                                checkForData(Constants.NO_CONNECTION_FOUND_TEXT)

                            } else {
                                checkForData(Constants.NO_CONNECTION_FOUND_TEXT)
                            }

                        } else {
                            onResponseFailure()
                        }
                    }

                    override fun onFailure(call: Call<GetNetworkEmployeeResponse>, t: Throwable) {
                        onResponseFailure()
                        removeLoader()
                    }
                })
    }

    private fun removeLoader() {
        shimmer_view_container.stopShimmer()
        shimmer_view_container.visibility = View.GONE
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == PROFILE_VIEW_ACTIVITY_CODE) {
                // update the list here
                networksRecyclerAdapter!!.updateListItem(data!!.getIntExtra("item_index", 0), data.getStringExtra("connection_status"))
            }
        }
    }

    override fun act(position: Int, type: Int) {
        when (type) {
            BaseViewHolder.USER_PROFILE -> {
                val intent = Intent(applicationContext, UserProfileView::class.java)
                intent.putExtra("userId", listItem[position].id)
                intent.putExtra("userName", listItem[position].firstName)
                intent.putExtra("IsPersonalProfile", false)
                intent.putExtra("conStatus", listItem[position].conStatus)
                intent.putExtra("item_index", position)
                startActivityForResult(intent, PROFILE_VIEW_ACTIVITY_CODE)
            }
        }
    }

    companion object {
        const val PROFILE_VIEW_ACTIVITY_CODE = 200

        /**
         * Intent Keys
         * */
        const val NAME_KEY = "name_key"
        const val USER_NAME = "user_name_key"
        const val COMPANY_ID = "company_id_key"
        const val ITEM_INDEX = "item_index"
        const val IS_VIEW_YOUR_CONNECTION_CLICK = "is_view_your_connection_click"
        const val FROM_USER_PROFILE = "from_user_profile_key"
    }
}
