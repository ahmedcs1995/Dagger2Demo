package com.mobileapp.krank.CustomViews;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mobileapp.krank.R;

public class FeedImageOverlayView extends RelativeLayout {

    private TextView mDescription;
    private TextView no_of_like;
    private TextView no_of_comments;
    private TextView like_text;
    private View like_container;
    private View comment_container;
    private ImageView like_img;


    public FeedImageOverlayView(Context context) {
        super(context);
        init();
    }

    public FeedImageOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FeedImageOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void setDescription(String description) {
        mDescription.setText(description);
    }


    public void setNo_of_like(String no_of_like) {
        this.no_of_like.setText("" + no_of_like);
    }

    public View getLike_container() {
        return like_container;
    }

    public TextView getNo_of_comments() {
        return no_of_comments;
    }

    public void setNo_of_comments(String no_of_comments) {
        this.no_of_comments.setText("" + no_of_comments);
    }

    public View getComment_container() {
        return comment_container;
    }

    public void setLikeEffect(int isLike,Context context){
        if (isLike == 0) {
            like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                like_img.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.AppWhiteColor)));
            }
            like_text.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor));
        } else {
            like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new));
            like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                like_img.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.drawer_background)));
            }
        }
    }
    private void init() {
        View view = inflate(getContext(), R.layout.view_image_overlay, this);
        mDescription = view.findViewById(R.id.tvDescription);
        like_container = view.findViewById(R.id.like_container);
        no_of_like = view.findViewById(R.id.no_of_like);
        no_of_comments = view.findViewById(R.id.no_of_comments);
        comment_container = view.findViewById(R.id.comment_container);
        like_img = view.findViewById(R.id.like_img);
        like_text = view.findViewById(R.id.like_text);

    }
}

