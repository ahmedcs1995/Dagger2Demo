package com.mobileapp.krank.ResponseModels.DataModel;


import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import android.text.SpannableStringBuilder;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


import static android.arch.persistence.room.ForeignKey.CASCADE;

@Entity(tableName = "personal_chat_conversation_table",
        foreignKeys = @ForeignKey(entity = ChatConversationListDataModel.class,
        parentColumns = "id",
        childColumns = "conversation_id",
        onDelete = CASCADE))
//onUpdate = CASCADE
public class ConversationDetail  {
    @SerializedName("sender_name")
    @Expose
    @ColumnInfo(name = "sender_name")
    private String senderName;

    @SerializedName("senderImg")
    @Expose
    @ColumnInfo(name = "senderImg")
    private String senderImg;

    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "sid")
    private String id;

    @ColumnInfo(name = "mid")
    @NonNull
    @PrimaryKey(autoGenerate = true)
    private long mid;

    @SerializedName("reply")
    @Expose
    @ColumnInfo(name = "reply")
    private String reply;

    @SerializedName("sender_id")
    @Expose
    @ColumnInfo(name = "sender_id")
    private String senderId;

    @SerializedName("ip")
    @Expose
    @ColumnInfo(name = "ip")
    private String ip;

    @SerializedName("time")
    @Expose
    @ColumnInfo(name = "time")
    private String time;

    @SerializedName("conversation_id")
    @Expose
    @ColumnInfo(name = "conversation_id")
    private String conversationId;

    @SerializedName("is_read")
    @Expose
    @ColumnInfo(name = "is_read")
    private String isRead;

    @SerializedName("type")
    @Expose
    @ColumnInfo(name = "type")
    private String type;

    @SerializedName("sentByme")
    @Expose
    @ColumnInfo(name = "sentByme")
    private int sentByme;

    @SerializedName("sentTime")
    @Expose
    @ColumnInfo(name = "sentTime")
    private String sentTime;

    @SerializedName("msgId")
    @Expose
    @ColumnInfo(name = "msgId")
    private String msgId;

    @SerializedName("thumb")
    @Expose
    @ColumnInfo(name = "thumb")
    private String thumb;

    @SerializedName("file")
    @Expose
    @ColumnInfo(name = "file")
    private String file;

    @SerializedName("file_type")
    @Expose
    @ColumnInfo(name = "file_type")
    private String fileType;

    @SerializedName("attachment")
    @Expose
    @Embedded
    private MessageAttachment attachment;

    @SerializedName("vCardData")
    @Expose
    @Embedded
    private MessageVCardData vCardData;

    @SerializedName("conStatus")
    @Expose
    @ColumnInfo(name = "conStatus")
    private String conStatus;

    private String typeOfMessage;

    @ColumnInfo(name = "msgStatus")
    private int msgStatus;


    @ColumnInfo(name = "timeStamp")
    private long timeStamp;

    @SerializedName("htm_parse")
    @Expose
    @Embedded
    private ChatHtmlParse htm_parse;

    @SerializedName("is_html")
    @Expose
    @ColumnInfo(name = "is_html")
    private int is_html;


    @SerializedName("device_id")
    @Expose
    private String device_id;

    @Ignore
    SpannableStringBuilder ssb;

    @ColumnInfo(name = "msgBubbleTime")
    private String msgBubbleTime;

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getSenderImg() {
        return senderImg;
    }

    public void setSenderImg(String senderImg) {
        this.senderImg = senderImg;
    }

    public String getId() {
        return id;
    }



    public void setId(String id) {
        this.id = id;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSentByme() {
        return sentByme;
    }

    public void setSentByme(int sentByme) {
        this.sentByme = sentByme;
    }

    public String getSentTime() {
        return sentTime;
    }

    public void setSentTime(String sentTime) {
        this.sentTime = sentTime;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public MessageAttachment getAttachment() {
        return attachment;
    }

    public void setAttachment(MessageAttachment attachment) {
        this.attachment = attachment;
    }

    public MessageVCardData getVCardData() {
        return vCardData;
    }

    public void setVCardData(MessageVCardData vCardData) {
        this.vCardData = vCardData;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getTypeOfMessage() {
        return typeOfMessage;
    }

    public void setTypeOfMessage(String typeOfMessage) {
        this.typeOfMessage = typeOfMessage;
    }
    @Ignore
    public ConversationDetail(String typeOfMessage){
        this.typeOfMessage = typeOfMessage;
    }

    @Ignore
    public ConversationDetail(String reply, String typeOfMessage,int msgStatus,String conversationId) {
        this.reply = reply;
        this.typeOfMessage = typeOfMessage;
        this.msgStatus = msgStatus;
        this.conversationId = conversationId;
    }




    @Ignore
    public ConversationDetail(String id,String reply, String typeOfMessage,int msgStatus,String conversationId,long timeStamp,String time,String sentTime,MessageVCardData messageVCardData,MessageAttachment messageAttachment) {
        this.reply = reply;
        this.typeOfMessage = typeOfMessage;
        this.msgStatus = msgStatus;
        this.conversationId = conversationId;
        this.timeStamp = timeStamp;
        this.time = time;
        this.sentTime = sentTime;
        this.id = id;
        this.vCardData = messageVCardData;
        this.attachment = messageAttachment;
    }

    @Ignore
    public ConversationDetail(String id,String reply, String typeOfMessage,int msgStatus,String conversationId,long timeStamp,String time,String sentTime) {
        this.reply = reply;
        this.typeOfMessage = typeOfMessage;
        this.msgStatus = msgStatus;
        this.conversationId = conversationId;
        this.timeStamp = timeStamp;
        this.time = time;
        this.sentTime = sentTime;
        this.id = id;
    }

    public ConversationDetail() {
    }

    @NonNull
    public long getMid() {
        return mid;
    }

    public void setMid(@NonNull long mid) {
        this.mid = mid;
    }

    public int getMsgStatus() {
        return msgStatus;
    }

    public void setMsgStatus(int msgstatus) {
        msgStatus = msgstatus;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int getIs_html() {
        return is_html;
    }

    public void setIs_html(int is_html) {
        this.is_html = is_html;
    }

    public ChatHtmlParse getHtm_parse() {
        return htm_parse;
    }

    public void setHtm_parse(ChatHtmlParse htm_parse) {
        this.htm_parse = htm_parse;
    }

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public SpannableStringBuilder getSsb() {
        return ssb;
    }

    public void setSsb(SpannableStringBuilder ssb) {
        this.ssb = ssb;
    }

    public String getMsgBubbleTime() {
        return msgBubbleTime;
    }

    public void setMsgBubbleTime(String msgBubbleTime) {
        this.msgBubbleTime = msgBubbleTime;
    }
}
