package com.mobileapp.krank.Chat.PrivateChat;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.PrivateChatMessagesAdapter2;
import com.mobileapp.krank.Adapters.PrivateChatMessagesAdapterPaggingListAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Chat.ChatUtils.ChatUtils;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.Database.MyViewModelFactory;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.Utils.AnimationUtils;
import com.mobileapp.krank.ViewModels.ChatConversationListViewModel2;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class PrivateChatConversationActivity2 extends BaseActivity {


    public interface onScrollCall {
        void act(List<ConversationDetail> items);
    }


    public interface onSuccessCallBack {
        void act(List<ConversationDetail> items);
    }


    public interface onFailureCallBack {
        void act(List<ConversationDetail> items);
    }

    /*socket Events Name*/
    public static final String EVENT_CONNECT = Socket.EVENT_CONNECT;
    public static final String EVENT_DISCONNECT = Socket.EVENT_DISCONNECT;
    public static final String EVENT_CONNECT_ERROR = Socket.EVENT_CONNECT_ERROR;
    public static final String EVENT_CONNECT_TIMEOUT = Socket.EVENT_CONNECT_TIMEOUT;
    public static final String EVENT_MESSAGE = "msg";
    public static final String EVENT_TYPING = "typing";
    public static final String EVENT_STOP_TYPING = "stop typing";
    /*socket Events Name*/


    //for chat list items
   // private PrivateChatMessagesAdapter2 chatMessagesRecyclerAdapter;
    private PrivateChatMessagesAdapterPaggingListAdapter chatMessagesRecyclerAdapter;
    private RecyclerView chatMessagesRecyclerView;
    List<ConversationDetail> chatMessagesItems;
    LinearLayoutManager layoutManager;

    //loader
    View loader;


    //bottom buttons
    View send_btn;
    View attachment_btn;
    View image_btn;
    View v_card_btn;
    View add_people_footer_btn;

    //msg textbox
    EditText msg_box;

    //top toolbar
    View moreOptions;
    View collapseAbleHeader;
    View addPeopleClick;


    //data variables
    String conv_id;

    //flag for header show/hide
    boolean iscollapseAbleHeaderVisible;

    //view Model
    private ChatConversationListViewModel2 chatConversationListViewModel;


    //chat utils
    ChatUtils chatUtils;


    //socket.io
    Socket mSocket;

    private boolean isConnected;

    //for pagination
    int firstVisibleItem, visibleItemCount, totalItemCount;
    private int visibleThreshold = 5;
    private int previousTotal = 0;
    private boolean loading = true;
    private boolean isScrollCalled;


    private static final int NUMBER_OF_ITEMS = 20;
    private static final int V_CARD_PAGE_CODE = 500;
    private static int MAX_FILE_COUNT = 6;



    private Runnable onTypingTimeout;

    private boolean mTyping = false;

    private Handler mTypingHandler = new Handler();

    //typing object
    JSONObject typingObj;
    JSONObject stopTypingObj;

    private static String TAG = PrivateChatConversationActivity2.class.getSimpleName();

    private static final int TYPING_TIMER_LENGTH = 10000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat_conversation2);

        init();

        initViews();

        setToolbar();

        setUpAdapter();


        mSocket = getSocket();

        //typing timer
        setUpTypingTimeoutRunnable();

        //pass ref of socket
        chatConversationListViewModel.setmSocket(mSocket, this);

        initSocket();

        bindListeners();

        //request from the api
        chatConversationListViewModel.getmRepository().getMessages2(this,items -> {
            if (items.size() >= NUMBER_OF_ITEMS) {
                loading = false;
                isScrollCalled = false;
            }
        });


    }

    private void addOnScrollListener() {
        visibleItemCount = chatMessagesRecyclerView.getChildCount();
        totalItemCount = layoutManager.getItemCount();
        firstVisibleItem = layoutManager.findFirstVisibleItemPosition();
        if (loading) {
            if (totalItemCount > previousTotal) {
                loading = false;
                previousTotal = totalItemCount;
            }
        }
        if (!loading && !isScrollCalled && (totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)) {
            isScrollCalled = true;
            loading = true;

          //  chatMessagesItems.add(new ConversationDetail(Constants.PROGRESS_BAR));
          //  chatMessagesRecyclerAdapter.notifyItemInserted(chatMessagesItems.size() - 1);


            /*chatConversationListViewModel.getmRepository().getMessages(this, items -> {
                int lastMsgsSize = chatMessagesItems.size();
                chatMessagesItems.addAll(items);
                removeProgressBar(false);
                chatMessagesRecyclerAdapter.notifyItemRangeInserted(lastMsgsSize, chatMessagesItems.size());
                //flag for scroll
                if (items.size() >= NUMBER_OF_ITEMS) {
                    loading = false;
                    isScrollCalled = false;
                }
            });*/

            chatConversationListViewModel.getmRepository().getMessages2(this,items -> {
                if (items.size() >= NUMBER_OF_ITEMS) {
                    loading = false;
                    isScrollCalled = false;
                }
            });


        }
    }


    public void removeProgressBar(boolean retryIcon) {
        for (int i = (chatMessagesItems.size() - 1); i >= 0; i--) {

            if (chatMessagesItems.get(i).getTypeOfMessage().equals(Constants.PROGRESS_BAR)) {
                if (retryIcon) {
                    chatMessagesItems.get(i).setTypeOfMessage(Constants.RETRY_BUTTON_CHAT);
                    chatMessagesRecyclerAdapter.notifyItemChanged(i);
                } else {
                    chatMessagesItems.remove(i);
                    chatMessagesRecyclerAdapter.notifyItemRemoved(i);
                }
                break;
            }
        }
    }

    private void initSocket() {
        mSocket.on(EVENT_CONNECT, onConnect);
        mSocket.on(EVENT_DISCONNECT, onDisconnect);
        mSocket.on(EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.on(EVENT_TYPING + "-" + conv_id, onTyping);
        mSocket.on(EVENT_STOP_TYPING +"-" + conv_id, onStopTyping);
    //    mSocket.connect();
    }

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(() -> {
                Log.e(TAG, "Connected");
                if (!isConnected) {
                    Toast.makeText(PrivateChatConversationActivity2.this.getApplicationContext(),
                            "Connected", Toast.LENGTH_LONG).show();
                    isConnected = true;
                }
            });
        }
    };

    private Emitter.Listener onTyping = args -> runOnUiThread(() -> {

        Toast.makeText(PrivateChatConversationActivity2.this, "OnTyping Event", Toast.LENGTH_SHORT).show();
        JSONObject data = (JSONObject) args[0];

        Log.e("onTyping", "Emitter Listener => " + data.toString());

        // chatMessagesRecyclerAdapter.startTypingEvent();
        //  chatMessagesRecyclerView.scrollToPosition(0);
    });


    private Emitter.Listener onStopTyping = args -> runOnUiThread(() -> {
        JSONObject data = (JSONObject) args[0];

        Toast.makeText(PrivateChatConversationActivity2.this, "Stop Typing Event", Toast.LENGTH_SHORT).show();

        Log.e("onStopTyping", "Emitter Listener => " + data.toString());

        //  chatMessagesRecyclerAdapter.stopTypingEvent();
    });

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(() -> {
                Log.i(TAG, "diconnected");
                isConnected = false;
                Toast.makeText(PrivateChatConversationActivity2.this.getApplicationContext(),
                        "disconnect", Toast.LENGTH_LONG).show();
            });
        }
    };

    private Emitter.Listener onConnectError = args -> runOnUiThread(() -> {
        Log.e(TAG, "Error connecting");
        Toast.makeText(PrivateChatConversationActivity2.this.getApplicationContext(),
                "Connection Error", Toast.LENGTH_LONG).show();
    });


    private void observeMsgs() {
     /*   chatConversationListViewModel.getAllMsgs().observe(this, msgs -> {

            Log.e(TAG, "observer " + msgs.size());
            loader.setVisibility(View.GONE);

            setSpannableBuilder(msgs);

            if (msgs.size() > 0) {
                chatMessagesItems.clear();
                chatMessagesItems.addAll(msgs);
                chatMessagesRecyclerAdapter.notifyDataSetChanged();
            }
            // chatMessagesRecyclerAdapter.setListItems(msgs,chatMessagesRecyclerView);
        });*/

        chatConversationListViewModel.getMsgsLists().observe(this, pagedList -> {
            Log.e(TAG,"observer onChange => "  + pagedList.size());
           // Log.e(TAG,"chatMessagesRecyclerAdapter onChange => "  +  chatMessagesRecyclerAdapter.getCurrentList().size());


            chatMessagesRecyclerAdapter.submitList(pagedList);
        });

    }

    private void registerAdapterDataObserver(){
        chatMessagesRecyclerAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                if (positionStart == 0) {
                    layoutManager.scrollToPosition(0);
                }
            }
        });

    }
    private Socket getSocket() {
        CustomApplication app = (CustomApplication) getApplication();
        return app.initSocket();
    }


    private void setSpannableBuilder(List<ConversationDetail> msgs) {
        for (ConversationDetail item : msgs) {
            item.setSsb(chatUtils.setSpannableString(item, this));
        }
    }


    private void setUpAdapter() {
        chatMessagesRecyclerView = (RecyclerView) findViewById(R.id.chat_messages_recycler_view);
        chatMessagesItems = new ArrayList<>();

        layoutManager = new LinearLayoutManager(PrivateChatConversationActivity2.this);

        layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        DeviceInfo deviceInfo = getDeviceResolution();


        chatMessagesRecyclerAdapter = new PrivateChatMessagesAdapterPaggingListAdapter(this, deviceInfo);
        //chatMessagesRecyclerAdapter = new PrivateChatMessagesAdapter2(chatMessagesItems,this, deviceInfo);

        observeMsgs();


        chatMessagesRecyclerView.setLayoutManager(layoutManager);
        chatMessagesRecyclerView.setAdapter(chatMessagesRecyclerAdapter);
        ((SimpleItemAnimator) chatMessagesRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        registerAdapterDataObserver();

        chatMessagesRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                addOnScrollListener();
            }
        });
    }


    private void init() {

        //for show hide collapse Header
        iscollapseAbleHeaderVisible = false;

        //flag for scroll
        isScrollCalled = true;

        //chat utils
        chatUtils = new ChatUtils();

        //typing handler
        mTypingHandler = new Handler();


        if (!(getIntent().getBooleanExtra("start_conversation", false)) && getIntent().getStringExtra("conv_id") != null) {
            conv_id = getIntent().getStringExtra("conv_id");

            try {
                typingObj = getTypingJSONObject();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            try {
                stopTypingObj = getTypingJSONObject();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            initializeViewModel();
        }

    }

    private void setUpTypingTimeoutRunnable(){
        onTypingTimeout = () -> {
            if (!mTyping) return;
            emitTopTyping();
        };
    }


    private void emitTopTyping(){
        mTyping = false;
        mSocket.emit(EVENT_STOP_TYPING,stopTypingObj);
    }

    private void initializeViewModel() {
        chatConversationListViewModel = ViewModelProviders.of(PrivateChatConversationActivity2.this, new MyViewModelFactory(this.getApplication(), conv_id)).get(ChatConversationListViewModel2.class);
    }

    private void bindListeners() {
        send_btn.setOnClickListener(view -> {
            String msg = msg_box.getText().toString();

            if (msg.isEmpty()) {
                return;
            }
            emitTopTyping();
            chatConversationListViewModel.sendTextMessage(msg);
            msg_box.setText("");
        });

        addPeopleClick.setOnClickListener(view -> {
       /*     Intent intent = new Intent(PrivateChatConversationActivity2.this, AddPeopleInPrivateChat.class);
            intent.putExtra("people_list_in_chat", appUtils.convertToJson(userDetail));
            intent.putExtra("isPersonalChat", true);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);*/
        });

        add_people_footer_btn.setOnClickListener(view -> {
           /* Intent intent = new Intent(PrivateChatConversationActivity2.this, AddPeopleInPrivateChat.class);
            intent.putExtra("people_list_in_chat", appUtils.convertToJson(userDetail));
            intent.putExtra("isPersonalChat", true);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);*/
        });

        moreOptions.setOnClickListener(view -> {
            if (iscollapseAbleHeaderVisible) {
                AnimationUtils.collapse(collapseAbleHeader);
                chatMessagesRecyclerView.setAlpha(1);
                iscollapseAbleHeaderVisible = false;
                return;
            }
            AnimationUtils.expand(collapseAbleHeader);
            chatMessagesRecyclerView.setAlpha((float) 0.2);
            iscollapseAbleHeaderVisible = true;
        });

        v_card_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), PrivateNewMessage.class);
            intent.putExtra("type", "visiting_card");
            intent.putExtra("page_title", "Select Contact Card");
            startActivityForResult(intent, V_CARD_PAGE_CODE);
        });

        attachment_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickFile(PrivateChatConversationActivity2.this));

        image_btn.setOnClickListener(view -> FilePickerBuilder.getInstance().setMaxCount(MAX_FILE_COUNT)
                .setActivityTheme(R.style.CustomAppLibTheme)
                .pickPhoto(PrivateChatConversationActivity2.this));

        msg_box.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                addOnTextChangeListener();

            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void addOnTextChangeListener(){
        if (!mTyping) {
            mTyping = true;
            mSocket.emit(EVENT_TYPING,typingObj);
        }

        mTypingHandler.removeCallbacks(onTypingTimeout);
        mTypingHandler.postDelayed(onTypingTimeout, TYPING_TIMER_LENGTH);
    }

    private void setToolbar() {
        if (getIntent().getStringExtra("recipient_name") != null) {
            setNormalPageToolbar( getIntent().getStringExtra("recipient_name"));
        }
    }

    private void initViews() {
        //top toolbar
        moreOptions = findViewById(R.id.more_options);
        collapseAbleHeader = findViewById(R.id.collpaseable_header);
        addPeopleClick = findViewById(R.id.add_people_click);

        //loader
        loader = findViewById(R.id.loader);

        //msg text box
        msg_box = findViewById(R.id.msg_box);

        //bottom buttons
        add_people_footer_btn = findViewById(R.id.add_people_footer_btn);
        send_btn = findViewById(R.id.send_btn);
        attachment_btn = findViewById(R.id.attachment_btn);
        image_btn = findViewById(R.id.image_btn);
        v_card_btn = findViewById(R.id.v_card_btn);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectSocket();
    }

    private void disconnectSocket() {
        mSocket.off(EVENT_CONNECT, onConnect);
        mSocket.off(EVENT_DISCONNECT, onDisconnect);
        mSocket.off(EVENT_CONNECT_ERROR, onConnectError);
        mSocket.off(EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.off(EVENT_TYPING +"-" + conv_id, onTyping);
        mSocket.off(EVENT_STOP_TYPING + "-" + conv_id, onStopTyping);
        chatConversationListViewModel.disconnectSocket();
        mSocket.disconnect();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case FilePickerConst.REQUEST_CODE_PHOTO:
                    if (data != null) {
                        ArrayList<String> imagesPath = data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA);
                        for (String item : imagesPath) {
                            chatConversationListViewModel.sendAttachmentMessage(item);
                        }
                    }
                    break;
                case FilePickerConst.REQUEST_CODE_DOC:
                    ArrayList<String> docPath =data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS);
                    for (String item : docPath) {
                        chatConversationListViewModel.sendAttachmentMessage(item);
                    }
                    break;
                case V_CARD_PAGE_CODE:
                    if (data.getStringExtra("selected_data") != null) {
                        ConnectionsDataModel connectionsDataModel = gson.fromJson(data.getStringExtra("selected_data"), ConnectionsDataModel.class);
                        chatConversationListViewModel.sendVCard(connectionsDataModel);
                    }
                    break;
            }
        }
    }

    private JSONObject getTypingJSONObject() throws JSONException {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("convoId",conv_id);
            jsonObject.put("userID",preference.getString(Constants.USER_ID_ENCRYPTED));
            return jsonObject;
    }

}
