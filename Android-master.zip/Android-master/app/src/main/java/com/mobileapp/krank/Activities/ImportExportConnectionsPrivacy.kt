package com.mobileapp.krank.Activities

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.text.Editable
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.util.Log
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Functions.AppUtils
import kotlinx.android.synthetic.main.activity_import_export_connections_privacy.*
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.mobileapp.krank.CustomViews.CustomButton
import com.mobileapp.krank.CustomViews.CustomFaView
import com.mobileapp.krank.FirebaseNotification.MyFirebaseMessagingService
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Functions.launchActivity
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.ExportConnectionsResponseModel
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.ImportConnectionsResponseModel
import kotlinx.android.synthetic.main.error_text.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class ImportExportConnectionsPrivacy : BaseActivity() {


    companion object {
        /**
         * Regex
         * */
        const val WEAK_PASS = "(?=.{8,}).*"
        const val MEDIUM_PASS = "^(?=\\S*?[A-Z])(?=\\S*?[a-z])(?=\\S*?[0-9])\\S{8,}$"
        //Must contain at least one upper case letter, one lower case letter and (one number AND one special char).
        const val STRONG_PASS = "^(?=\\S*?[A-Z])(?=\\S*?[a-z])(?=\\S*?[0-9])(?=\\S*?[^\\w\\*])\\S{8,}$"


        /**
         * Progress values
         * */
        const val VERY_WEAK_PROGRESS = 0
        const val WEAK_PROGRESS = 25
        const val MEDIUM_PROGRESS = 50
        const val STRONG_PROGRESS = 100


        /**
         * Intent Data key
         * */
        const val PAGE_NAME = "page_name_key"
        const val FILE_PATH = "file_path_key"


        //pages name
        const val IMPORT_CONNECTION = "Import Connections"
        const val EXPORT_CONNECTION = "Export Connections"


        /**
         * Permissions
         * */

        const val WRITE_EXTERNAL_STORAGE_PERMISSION = 700
    }

    //temp response of json for export
    private var tempExportResponse : String? =null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_import_export_connections_privacy)

        var pageName = intent.getStringExtra(PAGE_NAME)

        setNormalPageToolbar( pageName)

        if(pageName == EXPORT_CONNECTION){

            setUpExportConnectionsView()
        }else{
            setUpImportConnectionsView()
        }

    }

    private fun setUpImportConnectionsView(){
        export_view.visibility = View.GONE
        import_view.visibility = View.VISIBLE



        showHidePasswordView(file_password_verify,file_password_verify_icon)

        try {
            val filePath = intent.getStringExtra(FILE_PATH)
            var file = File(filePath)


            file_name.text = file.name


            import_connections_btn.setOnClickListener {

                if(file_password_verify.text.toString().isEmpty()){
                    error_view_2.text = "Please enter file password"
                    return@setOnClickListener
                }else if(file_password_verify.text.toString().length < Constants.NUMBER_OF_CHARACTERS_OF_PH_NUM){
                    error_view_2.text = Constants.MINIMUM_PASSWORD_LENGTH_ERROR
                    return@setOnClickListener
                }

                /**
                 * file sending
                 * */
                import_connections_btn.text = "Importing Connections..."
                import_connections_btn.isEnabled = false

                if (file.extension.toLowerCase() == "krank") {
                    //api call
                    sendFileToServer(file,import_connections_btn)
                    return@setOnClickListener
                }
            }
        }catch (ex : Exception){
            onResponseFailure()
        }


    }


    private fun setNormalStateOfImportButton(button: Button,defaultText : String) {
        button.text = defaultText
        button.isEnabled = true
    }


    private fun setUpExportConnectionsView(){

        export_view.visibility = View.VISIBLE
        import_view.visibility = View.GONE

        setProgressBarColor(VERY_WEAK_PROGRESS)

        addOnTextChangeListeners()



        showHidePasswordView(account_password,account_pass_icon)
        showHidePasswordView(file_password,edit_text_icon)
        showHidePasswordView(account_password,account_pass_icon)
        showHidePasswordView(retype_password,retype_password_icon)


        export_btn.setOnClickListener {
            when {
                account_password.text.toString().isEmpty() -> {
                    error_view.text = "Please type your current Krank's password"
                    return@setOnClickListener
                }
                file_password.text.toString().isEmpty() -> {
                    error_view.text = "Please password for Krank's connection file"
                    return@setOnClickListener
                }
                retype_password.text.toString().isEmpty() -> {
                    error_view.text = "Please re-type your new password for Krank's connection file"
                    return@setOnClickListener

                }
                retype_password.text.toString() != file_password.text.toString() -> {
                    error_view.text = "Krank's file password and confirm file passwords do not match"
                    return@setOnClickListener
                }
                file_password.text.toString().length < Constants.NUMBER_OF_CHARACTERS_OF_PH_NUM -> {
                    error_view.text = Constants.MINIMUM_PASSWORD_LENGTH_ERROR
                    return@setOnClickListener
                }
            }

            export_btn.text = "Exporting Connections..."
            exportConnections(export_btn)

        }



    }


    private fun addOnTextChangeListeners(){
        file_password.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                when {
                    getCheckedRegex(p0, STRONG_PASS) -> {
                        startAnimation(STRONG_PROGRESS)
                        setProgressBarColor(STRONG_PROGRESS)
                        Log.e("afterTextChanged","STRONG_PROGRESS")
                    }
                    getCheckedRegex(p0, MEDIUM_PASS) -> {
                        startAnimation(MEDIUM_PROGRESS)
                        setProgressBarColor(MEDIUM_PROGRESS)
                        Log.e("afterTextChanged","MEDIUM_PROGRESS")
                    }
                    getCheckedRegex(p0, WEAK_PASS) -> {
                        startAnimation(WEAK_PROGRESS)
                        setProgressBarColor(WEAK_PROGRESS)
                        Log.e("afterTextChanged","WEAK_PROGRESS")
                    }
                    else -> {
                        startAnimation(VERY_WEAK_PROGRESS)
                        setProgressBarColor(VERY_WEAK_PROGRESS)
                        Log.e("afterTextChanged","VERY_WEAK_PROGRESS")
                    }
                }



            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

        })
    }






    private fun showNotification(fileName: String) {

        MyFirebaseMessagingService.createNotification(fileName, "Krank Contacts has been exported", AppUtils.openDownloads(this@ImportExportConnectionsPrivacy), this)
    }


    private fun writeFile(res: String?) {
        if(res == null) return
        val fileName = AppUtils.writeFileOnInternalStorage(res, preference)
        showNotification(fileName)
        showSuccessPopUp()
    }

    private fun showSuccessPopUp(){
        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this@ImportExportConnectionsPrivacy) as NormalAppDialog)
                .setHeading("Success")
                .setDescription("File has been successfully exported to your download folder")
                .setConfirmButtonText("OK")
                .hideCancelButton()
                //private button listener
                .setConfirmButtonListener {
                    onBackPressed()
                }
        dialog.show()

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == WRITE_EXTERNAL_STORAGE_PERMISSION && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                writeFile(tempExportResponse)
            }
        }
    }


    private fun showHidePasswordView(editText : EditText,icon : CustomFaView){
        icon.setOnClickListener{


            if(editText.transformationMethod is PasswordTransformationMethod){
                //show
                editText.transformationMethod = HideReturnsTransformationMethod.getInstance()

                icon.text = AppUtils.fromHtml("&#xf06e;")
            }else{
                //hide
                editText.transformationMethod = PasswordTransformationMethod.getInstance()
                icon.text = AppUtils.fromHtml("&#xf070;")
            }


            editText.setSelection(editText.text.toString().length)


        }
    }


    private fun startAnimation(value: Int) {
        //progress_bar.progress = value
        if(progress_bar.progress == value) return
        AppUtils.setProgressWithAnimation(progress_bar, value)
    }

    private fun setProgressBarColor(value: Int) {
        var color : ColorStateList?=null
        when (value) {
            VERY_WEAK_PROGRESS -> {
                color = ContextCompat.getColorStateList(this,R.color.AppDarkGray)
                password_strength_label.text = "Very weak"
            }
            WEAK_PROGRESS -> {
                color = ContextCompat.getColorStateList(this,R.color.redColor)
                password_strength_label.text = "Weak"
            }
            MEDIUM_PROGRESS -> {
                color = ContextCompat.getColorStateList(this,R.color.app_orange_color)
                password_strength_label.text = "Medium"
            }
            STRONG_PROGRESS -> {
                color = ContextCompat.getColorStateList(this,R.color.green_color)
                password_strength_label.text = "Strong"
            }
        }

        progress_bar.progressTintList =color
        password_strength_label.setTextColor(color)

    }


    private fun sendFileToServer(file: File, import_connections_btn: CustomButton) {


        val requestBodyid = RequestBody.create(MediaType.parse("*/*"), file)

        val body = MultipartBody.Part.createFormData("upload_file", file.name, requestBodyid)


        api.importConnectionsFile(preference.getString(Constants.ACCESS_TOKEN), "con-imp-file", body,file_password_verify.text.toString()).enqueue(object : Callback<ImportConnectionsResponseModel> {
            override fun onFailure(call: Call<ImportConnectionsResponseModel>?, t: Throwable?) {
                onResponseFailure()
                setNormalStateOfImportButton(import_connections_btn,IMPORT_CONNECTION)
            }

            override fun onResponse(call: Call<ImportConnectionsResponseModel>?, response: Response<ImportConnectionsResponseModel>?) {
                setNormalStateOfImportButton(import_connections_btn, IMPORT_CONNECTION)

                if (response == null) return
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                        /**
                         * Request Sent
                         * */
                        if(response.body().data!!.count > 0){
                            this@ImportExportConnectionsPrivacy.launchActivity<PendingRequestActivity> {
                                putExtra(PendingRequestActivity.CURRENT_TAB_INDEX_KEY, 1)
                                putExtra(PendingRequestActivity.SHOULD_SHOW_POPUP, true)
                            }
                            finish()
                        }else{
                            /**
                             * No Request Sent
                             * */

                            this@ImportExportConnectionsPrivacy.launchActivity<MainPage> {
                                putExtra(MainPage.CURRENT_PAGE, MainPage.CONNECTION_TAB_INDEX)
                            }
                            finishAffinity()
                        }

                    }else{
                        error_view_2.text = response.body().message
                    }
                }else{
                    onResponseFailure()
                }
            }

        })
    }

    private fun getCheckedRegex(p0: Editable?, regex: String): Boolean = p0.toString().matches(regex.toRegex())

    private fun exportConnections(export_btn: CustomButton) {
        api.exportConnections(preference.getString(Constants.ACCESS_TOKEN),account_password.text.toString(),file_password.text.toString(),retype_password.text.toString()).enqueue(object : Callback<ExportConnectionsResponseModel> {
            override fun onFailure(call: Call<ExportConnectionsResponseModel>?, t: Throwable?) {
                onResponseFailure()
                setNormalStateOfImportButton(export_btn, EXPORT_CONNECTION)
            }

            override fun onResponse(call: Call<ExportConnectionsResponseModel>?, response: Response<ExportConnectionsResponseModel>?) {
                // Log.e("response","==> " + response.toString())

                setNormalStateOfImportButton(export_btn, EXPORT_CONNECTION)

                if (response == null || (response != null && !response.isSuccessful)) {
                    onResponseFailure()
                    return
                }
                if(response.body().status == Constants.SUCCESS_STATUS){
                    if(!AppUtils.isPermissionAllowed(this@ImportExportConnectionsPrivacy, Manifest.permission.WRITE_EXTERNAL_STORAGE)){
                        AppUtils.requestPermissions(WRITE_EXTERNAL_STORAGE_PERMISSION, this@ImportExportConnectionsPrivacy,arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE))
                        tempExportResponse = response.body().data?.file_json
                        return
                    }
                    writeFile(response.body().data?.file_json)
                }else{
                    error_view.text = response.body().message
                }

            }

        })
    }
}
