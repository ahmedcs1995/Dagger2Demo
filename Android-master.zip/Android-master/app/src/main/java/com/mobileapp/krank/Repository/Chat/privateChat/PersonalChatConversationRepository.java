package com.mobileapp.krank.Repository.Chat.privateChat;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.Dao.PersonalChatConversationDao;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;

import java.util.List;

public class PersonalChatConversationRepository {
    private PersonalChatConversationDao mConversationDetailDao;

    AppExecutors executors;
   // private LiveData<List<ConversationDetail>> mAllConversationDetail;

    // Note that in order to unit test the WordRepository, you have to remove the Application
    // dependency. This adds complexity and much more code, and this sample is not about testing.
    // See the BasicSample in the android-architecture-components repository at
    // https://github.com/googlesamples
    public PersonalChatConversationRepository(Application application) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        mConversationDetailDao = db.chatConversationListDao();
        executors= AppExecutors.getInstance();
      //  mAllConversationDetail = mConversationDetailDao.getAllRecords();
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    public  LiveData<List<ConversationDetail>> getmAllMsgs(String id) {
        return mConversationDetailDao.getAllRecords(id);
    }

    public PersonalChatConversationDao getConversationDao(){
        return mConversationDetailDao;
    }

    // You must call this on a non-UI thread or your app will crash.
    // Like this, Room ensures that you're not doing any long running operations on the main
    // thread, blocking the UI.
    public void insert (ConversationDetail msg) {

        executors.diskIO().execute(() -> {
            mConversationDetailDao.insert(msg);
        });
    }
    public void delete (long mId) {

        executors.diskIO().execute(() -> {
            mConversationDetailDao.deleteByMid(mId);
        });
    }


    public void NewMsgBulkInsert(final List<ConversationDetail> msgs) {

        executors.diskIO().execute(() -> {
            mConversationDetailDao.bulkInsert(msgs);
        });

    }
    public void updateMsgByMid(String convId,long mId,ConversationDetail data){
        executors.diskIO().execute(() -> {

            mConversationDetailDao.updateMsgByMid(convId,mId,data.getId(),data.getReply(),data.getSenderId(),data.getIp(),data.getTime(),data.getConversationId(),data.getIsRead(),data.getType(),data.getMsgStatus());
        });
    }
    public void updateMsgStatusByMid(String convId,long mId,int status){
        executors.diskIO().execute(() -> {

            mConversationDetailDao.updateStatusMsgByMid(convId,mId,status);
        });
    }
}


