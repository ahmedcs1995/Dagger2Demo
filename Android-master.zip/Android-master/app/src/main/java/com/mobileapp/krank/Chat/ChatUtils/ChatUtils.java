package com.mobileapp.krank.Chat.ChatUtils;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.View;

import com.mobileapp.krank.Activities.AddListing;
import com.mobileapp.krank.Activities.InviteCompaniesAndCoWorker;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.CustomViews.CustomTypefaceSpan;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMessageModel;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.SpannableUtils;

import java.util.List;

public class ChatUtils {
    AppUtils appUtils;

    public ChatUtils(){
        appUtils = AppUtils.getInstance();
    }

    public SpannableStringBuilder setSpannableString(ConversationDetail item, Activity activity){
        if (item.getIs_html() == 1) {
            SpannableStringBuilder ssb = new SpannableStringBuilder();

            if (item.getHtm_parse().getMessage_type().equals(Constants.EMMA_COOPER_MSG)) {
                ssb = SpannableUtils.getEmmaCooperMsg(item,activity,appUtils);
            } else if (item.getHtm_parse().getMessage_type().equals(Constants.LISTING_MSG)) {
              setListingMsg(item,activity,ssb);
            }
            return ssb;
        }
        return null;
    }

    private void setListingMsg(ConversationDetail item, Activity activity, SpannableStringBuilder ssb){
        String listingMsg = "";
        for (int i = 0; i < item.getHtm_parse().getHtml_message().size(); i++) {
            if(i == item.getHtm_parse().getHtml_message().size() - 1){
                listingMsg+=item.getHtm_parse().getHtml_message().get(i);
                continue;
            }
            listingMsg+=item.getHtm_parse().getHtml_message().get(i) +"\n";
        }

        // listing message  + listing link + link message = total length
        // start =>  highlight link by => total -  listing message
        // end =>  highlight link by => total -  link message

        int start = listingMsg.length() - item.getHtm_parse().getLinks().get(0).getText().length()  -  item.getHtm_parse().getHtml_message().get(item.getHtm_parse().getHtml_message().size() - 1).length() -1 ;
        int end  = listingMsg.length() -  item.getHtm_parse().getHtml_message().get(item.getHtm_parse().getHtml_message().size() - 1).length();


        ssb.append(listingMsg);

        ssb.setSpan(new CustomTypefaceSpan("", Typeface.createFromAsset(activity.getAssets(), Constants.ROBOTO_BOLD)),start , end,Spannable.SPAN_EXCLUSIVE_INCLUSIVE);

        ssb.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, ListingDetail.class);
                intent.putExtra("listing_id",item.getHtm_parse().getListing_id());
                activity.startActivity(intent);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
               if(item.getTypeOfMessage().equals(Constants.TEXT_RIGHT)){
                   ds.setColor(ContextCompat.getColor(activity, R.color.AppWhiteColor));
               }else{
                   ds.setColor(ContextCompat.getColor(activity, R.color.drawer_background));
               }

                ds.setUnderlineText(false);
            }
        }, start, end, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);

    }


    public void setPersonalChatMsgsType(List<ConversationDetail> tempMsgs, boolean newMsgs, Activity activity , SaveInSharedPreference preference) {
        for (ConversationDetail item : tempMsgs) {
            item.setMsgStatus(Constants.STATUS_SEND);

            // set spannable string for listing and emma cooper msgs
            item.setSsb(setSpannableString(item,activity));

            /*setting time Stamp*/
            if (newMsgs) {
                item.setTimeStamp(appUtils.getCurrentTimeStamp());
            } else {
                item.setTimeStamp(appUtils.getTimeStamp(item.getTime()));
            }
            /*setting time Stamp*/

            /*setting the time for msg bubble*/
           // item.setMsgBubbleTime(appUtils.setTimeInChatBubble(item.getTime()));
            /*setting the time for msg bubble*/


            /*setting msgs type*/
            item.setTypeOfMessage(getTypeOfMessage(item.getType(),preference.getString(Constants.USER_ID),item.getSenderId(),(item.getAttachment() == null) ? "" : item.getAttachment().getFileExt()));
            /*setting msgs type*/
        }
    }

    public void setPersonalChatMsgsType2(List<ConversationDetail> tempMsgs, boolean newMsgs, String loggedInUserId) {
        for (ConversationDetail item : tempMsgs) {
            item.setMsgStatus(Constants.STATUS_SEND);


            /*setting time Stamp*/
            if (newMsgs) {
                item.setTimeStamp(appUtils.getCurrentTimeStamp());
            } else {
                item.setTimeStamp(appUtils.getTimeStamp(item.getTime()));
            }
            /*setting time Stamp*/

            /*setting the time for msg bubble*/
            // item.setMsgBubbleTime(appUtils.setTimeInChatBubble(item.getTime()));
            /*setting the time for msg bubble*/


            /*setting msgs type*/
            item.setTypeOfMessage(getTypeOfMessage(item.getType(),loggedInUserId,item.getSenderId(),(item.getAttachment() == null) ? "" : item.getAttachment().getFileExt()));
            /*setting msgs type*/
        }
    }

    public static String getTypeOfMessage(String type,String loggedInUserId,String msgUserId,String attachmentType){
        if (type.equals("text")) {
            if (msgUserId.equals(loggedInUserId)) {
                return Constants.TEXT_RIGHT;
            } else {
                return Constants.TEXT_LEFT;
            }
        } else if (type.equals("attachment")) {
            if (attachmentType.equals("jpg") || attachmentType.equals("jpeg") || attachmentType.equals("png")) {
                if (msgUserId.equals(loggedInUserId)) {
                    return Constants.IMAGE_RIGHT;
                } else {
                    return Constants.IMAGE_LEFT;
                }
            } else {
                if (msgUserId.equals(loggedInUserId)) {
                    return Constants.OTHER_ATTACHMENT_RIGHT;
                } else {
                    return Constants.OTHER_ATTACHMENT_LEFT;
                }

            }
        } else if (type.equals("vcard")) {
            if (msgUserId.equals(loggedInUserId)) {
                return Constants.V_CARD_RIGHT;
            } else {
                return Constants.V_CARD_LEFT;
            }
        }

        //returning default
        return Constants.TEXT_RIGHT;
    }

    public Drawable getAttachmentIcon(String fileExt,Activity activity){
        switch (fileExt){
            case Constants.XLS:
            case Constants.XLSX:
                return ContextCompat.getDrawable(activity,R.drawable.xls_icon);
            case Constants.DOC:
            case Constants.DOCX:
                return ContextCompat.getDrawable(activity,R.drawable.doc_icon);
            case Constants.PPT:
            case Constants.PPTX:
                return ContextCompat.getDrawable(activity,R.drawable.ppt_icon);
            case Constants.PDF:
                return ContextCompat.getDrawable(activity,R.drawable.pdf_icon);
            case Constants.ZIP:
                return ContextCompat.getDrawable(activity,R.drawable.zip_icon);
            case Constants.RAR:
                return ContextCompat.getDrawable(activity,R.drawable.rar_icon);
        }
        return ContextCompat.getDrawable(activity,R.drawable.xls_icon);
    }


    public void setGroupMessagesType(List<GroupChatConversationMessageModel> tempMsgs, boolean newMsgs, String memberId) {
        for (GroupChatConversationMessageModel item : tempMsgs) {
            item.setMsgStatus(Constants.STATUS_SEND);
            item.setMember_id(memberId);

            /*setting the time stamp*/
            if (newMsgs) {
                item.setTimeStamp(appUtils.getCurrentTimeStamp());
            } else {
                item.setTimeStamp(appUtils.getTimeStamp(item.getSentTime()));
            }
            /*setting the time stamp*/


            /*setting the time for msg bubble*/
        //    item.setMsgBubbleTime(appUtils.setTimeInChatBubble(item.getMsgAdded()));
            /*setting the time for msg bubble*/


            /*setting Msgs Type*/
            if (item.getType().equals("text")) {
                if (item.getSentByme() == 1) {
                    item.setTypeOfMessage(Constants.TEXT_RIGHT);
                } else {
                    item.setTypeOfMessage(Constants.TEXT_LEFT);
                }
            } else if (item.getType().equals("attachment")) {
                if (item.getAttachment().getFileExt().equals("jpg") || item.getAttachment().getFileExt().equals("jpeg") || item.getAttachment().getFileExt().equals("png")) {
                    if (item.getSentByme() == 1) {
                        item.setTypeOfMessage(Constants.IMAGE_RIGHT);
                    } else {
                        item.setTypeOfMessage(Constants.IMAGE_LEFT);
                    }
                } else {
                    if (item.getSentByme() == 1) {
                        item.setTypeOfMessage(Constants.OTHER_ATTACHMENT_RIGHT);
                    } else {
                        item.setTypeOfMessage(Constants.OTHER_ATTACHMENT_LEFT);
                    }
                }
            } else if (item.getType().equals("vcard")) {
                if (item.getSentByme() == 1) {
                    item.setTypeOfMessage(Constants.V_CARD_RIGHT);
                } else {
                    item.setTypeOfMessage(Constants.V_CARD_LEFT);
                }
            } else if (item.getType().equals("system")) {
                item.setTypeOfMessage(Constants.SYSTEM_MESSAGE);
            } else {
                item.setTypeOfMessage(Constants.OTHER);
            }
            /*setting Msgs Type*/
        }
    }

}
