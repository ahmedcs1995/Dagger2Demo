package com.mobileapp.krank.Functions.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobileapp.krank.R;

public class NormalAppDialog extends Dialog implements View.OnClickListener {


    @FunctionalInterface
    public interface ConfirmButtonListener {
        void act(NormalAppDialog dialog);
    }

    @FunctionalInterface
    public interface CancelButtonListener {
        void act(NormalAppDialog dialog);
    }

    private Context context;

    private ConfirmButtonListener confirmButtonListener;
    private CancelButtonListener cancelButtonListener;

    //views
    private ImageView icon_img;
    //text views
    private TextView heading;
    private TextView description;

    //dividers
    private View view_1;
    private View view_2;

    //btns
    private TextView ok_btn;
    private TextView cancel_btn;

    //text
    private String headingText;
    private String descipritonText;
    private String confirmBtnText;
    private String cancelBtnText;

    //flags
    private boolean isCancelHide;
    private boolean isIconVisible;
    private boolean isNotCancelable;

    //id
    @DrawableRes
    int drawableid;

    @ColorRes
    int iconTintColor= R.color.drawer_background;
    @ColorRes
    int headingColor = R.color.drawer_background;

    public NormalAppDialog setConfirmButtonListener(ConfirmButtonListener listener) {
        this.confirmButtonListener = listener;
        return this;
    }

    public NormalAppDialog setCancelButtonListener(CancelButtonListener listener) {
        this.cancelButtonListener = listener;
        return this;
    }

    public NormalAppDialog setHeading(String text) {
        headingText = text;
        return this;
    }


    public NormalAppDialog setDescription(String text) {
        descipritonText = text;
        return this;
    }


    public NormalAppDialog setConfirmButtonText(String text) {
        confirmBtnText = text;
        return this;
    }

    public NormalAppDialog setCancelButtonText(String text) {
        cancelBtnText = text;
        return this;
    }

    public NormalAppDialog(Context context) {
        super(context);
        this.context = context;

    }

    public NormalAppDialog setIcon(@DrawableRes int id) {
        isIconVisible = true;
        drawableid = id;
        return this;
    }

    public NormalAppDialog setIconTint(@ColorRes int iconTintColor) {
        this.iconTintColor = iconTintColor;
        return this;
    }

    public NormalAppDialog setHeadingColor(@ColorRes int headingColor) {
        this.headingColor = headingColor;
        return this;
    }

    public NormalAppDialog setCancelableDialog(boolean enabled) {
        setCancelable(enabled);
        isNotCancelable = true;
        return this;
    }

    public NormalAppDialog hideCancelButton() {
        isCancelHide = true;
        return this;
    }

    public NormalAppDialog hideIcon() {
        isIconVisible = false;
        return this;
    }


    private void viewVisibility(int visibility, View view) {
        view.setVisibility(visibility);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.normal_app_dialog);

        //btns
        ok_btn = getView(R.id.ok_btn);
        cancel_btn = getView(R.id.cancel_btn);

        ok_btn.setOnClickListener(this);
        cancel_btn.setOnClickListener(this);
        //text
        description = getView(R.id.description);
        heading = getView(R.id.heading);

        //dividers
        view_1  = getView(R.id.view_1);
        view_2  = getView(R.id.view_2);


        //img
        icon_img = getView(R.id.icon_img);

        if (!isIconVisible) {
            viewVisibility(View.GONE, icon_img);
        } else {
            icon_img.setImageDrawable(ContextCompat.getDrawable(context, drawableid));
            icon_img.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(context,iconTintColor)));
        }



        heading.setTextColor(ContextCompat.getColor(context,headingColor));

        setText(heading, headingText);
        setText(description, descipritonText);
        setTextOnButtons(ok_btn,view_1, confirmBtnText == null? "OK" : confirmBtnText);
        setTextOnButtons(cancel_btn,view_2, isCancelHide ?  null : cancelBtnText == null? "Cancel" : cancelBtnText);

    }

    private void setText(TextView textView, String text) {
        if (text == null) {
            viewVisibility(View.GONE, textView);
        } else {
            textView.setText(text);
        }
    }

    private void setTextOnButtons(TextView textView,View divider, String text){
        if (text == null) {
            viewVisibility(View.GONE, textView);
          //  viewVisibility(View.GONE, divider);
        } else {
            textView.setText(text);
        }
    }

    public <T extends View> T getView(int id) {
        return findViewById(id);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ok_btn:
                if (confirmButtonListener != null) {
                    confirmButtonListener.act(this);
                }
                break;
            case R.id.cancel_btn:
                if (cancelButtonListener != null) {
                    cancelButtonListener.act(this);
                }
                break;
        }
        if (!isNotCancelable) {
            dismiss();
        }

    }

}