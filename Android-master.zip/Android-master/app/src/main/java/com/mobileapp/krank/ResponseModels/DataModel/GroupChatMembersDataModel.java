package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "group_chat_members_list_table")
public class GroupChatMembersDataModel {
    @SerializedName("user_slug")
    @Expose
    @ColumnInfo(name = "user_slug")
    private String userSlug;

    @SerializedName("company_slug")
    @Expose
    @ColumnInfo(name = "company_slug")
    private String companySlug;

    @SerializedName("online")
    @Expose
    @ColumnInfo(name = "online")
    private String online;

    @SerializedName("package_id")
    @Expose
    @ColumnInfo(name = "package_id")
    private String packageId;

    @SerializedName("email_address")
    @Expose
    @ColumnInfo(name = "email_address")
    private String emailAddress;

    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    private String id;

    @SerializedName("firstName")
    @Expose
    @ColumnInfo(name = "firstName")
    private String firstName;

    @SerializedName("lastName")
    @Expose
    @ColumnInfo(name = "lastName")
    private String lastName;

    @SerializedName("companyId")
    @Expose
    @ColumnInfo(name = "companyId")
    private String companyId;

    @SerializedName("profilePic")
    @Expose
    @ColumnInfo(name = "profilePic")
    private String profilePic;

    @SerializedName("designation")
    @Expose
    @ColumnInfo(name = "designation")
    private String designation;

    @SerializedName("company_profile_pic")
    @Expose
    @ColumnInfo(name = "company_profile_pic")
    private String companyProfilePic;

    @SerializedName("companyName")
    @Expose
    @ColumnInfo(name = "companyName")
    private String companyName;

    @SerializedName("country")
    @Expose
    @ColumnInfo(name = "country")
    private String country;

    @SerializedName("city")
    @Expose
    @ColumnInfo(name = "city")
    private String city;

    @SerializedName("user_url")
    @Expose
    @ColumnInfo(name = "user_url")
    private String userUrl;

    @SerializedName("company_url")
    @Expose
    @ColumnInfo(name = "company_url")
    private String companyUrl;

    @SerializedName("member_id")
    @Expose
    @ColumnInfo(name = "member_id")
    private String memberId;

    @SerializedName("is_group_admin")
    @Expose
    @ColumnInfo(name = "is_group_admin")
    private int isGroupAdmin;

    @SerializedName("is_delete")
    @Expose
    @ColumnInfo(name = "is_delete")
    private int isDelete;

    @SerializedName("user_profile_pic")
    @Expose
    @ColumnInfo(name = "user_profile_pic")
    private String userProfilePic;


    @ColumnInfo(name = "groupIdUserId")
    @PrimaryKey
    @NonNull
    private String groupIdUserId;

    @ColumnInfo(name = "groupId")
    private String groupId;

    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUserUrl() {
        return userUrl;
    }

    public void setUserUrl(String userUrl) {
        this.userUrl = userUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public int getIsGroupAdmin() {
        return isGroupAdmin;
    }

    public void setIsGroupAdmin(int isGroupAdmin) {
        this.isGroupAdmin = isGroupAdmin;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public String getGroupIdUserId() {
        return groupIdUserId;
    }

    public void setGroupIdUserId(String groupIdUserId) {
        this.groupIdUserId = groupIdUserId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public  GroupChatMembersDataModel(){

    }

}

