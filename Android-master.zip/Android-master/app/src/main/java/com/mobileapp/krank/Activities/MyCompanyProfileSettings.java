package com.mobileapp.krank.Activities;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Adapters.PagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CompanyProfileSettingsTabs.CompanyProfileSettingsPageFour;
import com.mobileapp.krank.CompanyProfileSettingsTabs.CompanyProfileSettingsPageOne;
import com.mobileapp.krank.CompanyProfileSettingsTabs.CompanyProfileSettingsPageThree;
import com.mobileapp.krank.CompanyProfileSettingsTabs.CompanyProfileSettingsPageTwo;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityForPublicCompanyProfileData;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CompanySizeData;
import com.mobileapp.krank.ResponseModels.DataModel.CountryForPublicCompanyProfileData;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.DataModel.PublicCompanyProfileData;
import com.mobileapp.krank.ResponseModels.DataModel.SizeForPublicCompanyProfileData;

import java.util.ArrayList;
import java.util.List;

public class MyCompanyProfileSettings extends BaseActivity {


    ViewPager mViewPager;
    ProgressBar mProgressBar;
    Button next_btn;
    View prev_btn;
    PublicCompanyProfileData myCompanyProfileData;


    CompanyProfileSettingsPageOne companyProfileSettingsPageOne;
    CompanyProfileSettingsPageTwo companyProfileSettingsPageTwo;
    CompanyProfileSettingsPageThree companyProfileSettingsPageThree;
    CompanyProfileSettingsPageFour companyProfileSettingsPageFour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_company_profile_settings);
        mViewPager = findViewById(R.id.viewpager);
        mProgressBar = findViewById(R.id.progress_bar);
        next_btn = findViewById(R.id.next_btn);
        prev_btn = findViewById(R.id.prev_btn);

        myCompanyProfileData = getIntentData();

        setNormalPageToolbar( "Company Profile Settings");

        companyProfileSettingsPageOne = new CompanyProfileSettingsPageOne();
        companyProfileSettingsPageTwo = new CompanyProfileSettingsPageTwo();
        companyProfileSettingsPageThree = new CompanyProfileSettingsPageThree();
        companyProfileSettingsPageFour = new CompanyProfileSettingsPageFour();


        companyProfileSettingsPageOne.setData(myCompanyProfileData.getCompanyName(), myCompanyProfileData.getAddress(), myCompanyProfileData.getZipCode(), myCompanyProfileData.getTelephoneNumber(), getCountry(), getCity());
        companyProfileSettingsPageTwo.setData(myCompanyProfileData.getCompanyBio(), myCompanyProfileData.getWebsiteUrl(), getCompanySize(), myCompanyProfileData.getInterest(), myCompanyProfileData.getCurrencyName());
        companyProfileSettingsPageThree.setData(myCompanyProfileData.getIndustry());
        companyProfileSettingsPageFour.setData(myCompanyProfileData.getBusiness());

        ArrayList<BaseFragment> pages = new ArrayList<>();

        pages.add(companyProfileSettingsPageOne);
        pages.add(companyProfileSettingsPageTwo);
        pages.add(companyProfileSettingsPageThree);
        pages.add(companyProfileSettingsPageFour);

        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));


        mViewPager.setOffscreenPageLimit(pages.size());


        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //Log.e("onPageScrolled", "" + position);

            }

            @Override
            public void onPageSelected(int position) {
                Log.e("onPageSelected", "" + position);
                //  setBackgroundImg(position);
                if (position == 0) {
                    prev_btn.setVisibility(View.INVISIBLE);
                    next_btn.setText("Next");
                    startAnimation(25);
                } else if (position == 1) {
                    prev_btn.setVisibility(View.VISIBLE);
                    next_btn.setText("Next");
                    startAnimation(50);
                } else if (position == 2) {
                    prev_btn.setVisibility(View.VISIBLE);
                    next_btn.setText("Next");
                    startAnimation(75);
                } else if (position == 3) {
                    prev_btn.setVisibility(View.VISIBLE);
                   // prev_btn.setVisibility(View.INVISIBLE);
                    next_btn.setText("Submit");
                    startAnimation(100);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                Log.e("onPageScrollState", "" + state);
            }
        });
        next_btn.setOnClickListener(view -> {
            switch (mViewPager.getCurrentItem()) {
                case 0:
                    if (!(companyProfileSettingsPageOne.checkForError())) {
                        setPageOneData();
                        companyProfileSettingsPageOne.updateProfile();
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                    break;
                case 1:
                    if (!(companyProfileSettingsPageTwo.isErrorExists())) {
                        setPageTwoData();
                        companyProfileSettingsPageTwo.updateProfile();
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                    break;
                case 2:
                    companyProfileSettingsPageThree.updateProfile(() -> {
                        setPageThreeData();
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    });
                    break;
                case 3:
                    companyProfileSettingsPageFour.updateProfile(() -> {
                        setPageFourData();
                        onBackPressed();
                    });
                    break;

            }


        });
        prev_btn.setOnClickListener(view -> {
            if (!(mViewPager.getCurrentItem() == 0)) {
                mViewPager.setCurrentItem(mViewPager.getCurrentItem() - 1);
            }
        });
        prev_btn.setVisibility(View.INVISIBLE);
    }

    private void setPageOneData() {
        myCompanyProfileData.setCompanyName(companyProfileSettingsPageOne.company_name_edit_text.getText().toString());
        myCompanyProfileData.setAddress(companyProfileSettingsPageOne.company_address_edit_text.getText().toString());
        CountryForPublicCompanyProfileData countryForPublicCompanyProfileData = new CountryForPublicCompanyProfileData(companyProfileSettingsPageOne.selectedCountryData.getCode(), companyProfileSettingsPageOne.selectedCountryData.getName(), companyProfileSettingsPageOne.selectedCountryData.getPhoneCode());
        myCompanyProfileData.setCountry(countryForPublicCompanyProfileData);
        myCompanyProfileData.setCountryName(companyProfileSettingsPageOne.country_text.getText().toString());
        myCompanyProfileData.setCityName(companyProfileSettingsPageOne.city_text.getText().toString());
        CityForPublicCompanyProfileData cityForPublicCompanyProfileData = new CityForPublicCompanyProfileData(companyProfileSettingsPageOne.selectedCityData.getCityId(), companyProfileSettingsPageOne.selectedCityData.getCityName());
        myCompanyProfileData.setCity(cityForPublicCompanyProfileData);
        myCompanyProfileData.setZipCode(companyProfileSettingsPageOne.postal_code_edit_text.getText().toString());
        myCompanyProfileData.setTelephoneNumber(companyProfileSettingsPageOne.mobile_code_edit_text.getText().toString() + "-" + companyProfileSettingsPageOne.phone_edit_text.getText().toString());
    }

    private void setPageTwoData() {
        myCompanyProfileData.setCompanyBio(companyProfileSettingsPageTwo.bio_edit_text.getText().toString());
        myCompanyProfileData.setSize(new SizeForPublicCompanyProfileData(companyProfileSettingsPageTwo.selectedCompanySize.getId(), companyProfileSettingsPageTwo.selectedCompanySize.getCompanySize()));
        myCompanyProfileData.setCurrencyName(companyProfileSettingsPageTwo.preferred_trading_currency.getText().toString());
        myCompanyProfileData.setWebsiteUrl(companyProfileSettingsPageTwo.website_edit_text.getText().toString());
        myCompanyProfileData.setInterest(companyProfileSettingsPageTwo.getSelectedInterestList());
        myCompanyProfileData.setCompanySizeName(companyProfileSettingsPageTwo.company_size_edit_text.getText().toString());
    }

    public void setError(EditText editText, String error){
        editText.setError(error);
    }
    private void setPageThreeData() {
        List<String> industryData = companyProfileSettingsPageThree.getSelectedIndustries();
        String industryId="";
        for(int i=0; i< industryData.size(); i++){
            if(!(i == industryData.size() - 1)){
                industryId+=industryData.get(i);
            }else{
                industryId+=industryData.get(i) + ",";

            }
        }
        myCompanyProfileData.setIndustry(industryData);
        myCompanyProfileData.setIndustryId(industryId);
    }
    private void setPageFourData() {
        Log.e("CompanyProfile",appUtils.convertToJson(companyProfileSettingsPageFour.getSelectedBussiness()));
        myCompanyProfileData.setBusiness(companyProfileSettingsPageFour.getSelectedBussiness());

    }

    private void startAnimation(int value) {
        AppUtils.setProgressWithAnimation(mProgressBar,value);
    }

    private PublicCompanyProfileData getIntentData() {
        return gson.fromJson(getIntent().getStringExtra("my_company_profile_data"), PublicCompanyProfileData.class);
    }

    private CountyListData getCountry() {
        CountyListData selectedCountryData;
        if (myCompanyProfileData.getCountry() != null) {
            selectedCountryData = new CountyListData(myCompanyProfileData.getCountry().getCountryCode(), myCompanyProfileData.getCountry().getCountryName(), myCompanyProfileData.getCountry().getCountryDialCode());
            return selectedCountryData;
        }
        return null;

    }

    private CityListData getCity() {
        CityListData selectedCityData;
        if (myCompanyProfileData.getCountry() != null) {
            selectedCityData = new CityListData(myCompanyProfileData.getCity().getCityName(), myCompanyProfileData.getCity().getCityId());
            return selectedCityData;
        }
        return null;
    }
    private CompanySizeData getCompanySize() {
        CompanySizeData selectedCompanySize;
        if (myCompanyProfileData.getSize() != null) {
            selectedCompanySize = new CompanySizeData(myCompanyProfileData.getSize().getSizeId(), myCompanyProfileData.getSize().getSizeName());
            return selectedCompanySize;
        }
        return null;
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("myCompanyData", appUtils.convertToJson(myCompanyProfileData));
        setResult(RESULT_OK, intent);
        finish();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
}
