package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.mobileapp.krank.Adapters.CoWorkerListAdapter;
import com.mobileapp.krank.Adapters.DealerListingAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CoWorkerAssignmentPage extends BaseActivity {
    private RecyclerView co_worker_recycler;
    private CoWorkerListAdapter co_worker_adapter;
    List<PublicMarketPlaceAssignment> publicMarketPlaceAssignments;
    View done_btn;
    public int selectedIndex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_co_worker_assignment_page);

        setNormalPageToolbar("Select Co-Worker");
        done_btn = findViewById(R.id.done_btn);
        selectedIndex = -1;
        setUpAdapter();
        done_btn.setOnClickListener(view -> {
            if (selectedIndex != -1) {
                Intent intent = new Intent();
                intent.putExtra("selected_assignment", gson.toJson(publicMarketPlaceAssignments.get(selectedIndex)));
                intent.putExtra("co_worker_selected_index",selectedIndex);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
    private void setUpAdapter() {
        co_worker_recycler = findViewById(R.id.co_worker_recycler);
        publicMarketPlaceAssignments = new ArrayList<>();
        co_worker_adapter = new CoWorkerListAdapter(publicMarketPlaceAssignments, CoWorkerAssignmentPage.this);
        co_worker_recycler.setLayoutManager(new LinearLayoutManager(CoWorkerAssignmentPage.this));
        co_worker_recycler.setAdapter(co_worker_adapter);
        setDataInAdapter();
    }
    private void setDataInAdapter(){
        Log.e("assignmentData","" + getIntent().getStringExtra("assignmentData"));
        String cuId =String.valueOf(getIntent().getIntExtra("cu_id",0));

        publicMarketPlaceAssignments.addAll(Arrays.asList(gson.fromJson(getIntent().getStringExtra("assignmentData"),PublicMarketPlaceAssignment[].class)));

       // Log.e("selected_assignment","" + getIntent().getStringExtra("selected_assignment"));


        if(getIntent().getStringExtra("selected_assignment") !=null){
            PublicMarketPlaceAssignment publicMarketPlaceAssignment = gson.fromJson(getIntent().getStringExtra("selected_assignment"),PublicMarketPlaceAssignment.class);
            if(publicMarketPlaceAssignment!=null){
                for(int i=0 ; i < publicMarketPlaceAssignments.size();i++){
                    if(!compareCuId(cuId,publicMarketPlaceAssignments.get(i).getId())){
                        /*if(publicMarketPlaceAssignments.get(i).getId().equals(publicMarketPlaceAssignment.getId())){
                            selectedIndex=i;
                            publicMarketPlaceAssignments.get(i).setIsItemSelected(true);
                            co_worker_adapter.prevData= publicMarketPlaceAssignments.get(i);
                        }else{
                            publicMarketPlaceAssignments.get(i).setIsItemSelected(false);
                        }*/
                        if(publicMarketPlaceAssignments.get(i).equals(publicMarketPlaceAssignment)){
                            selectedIndex=i;
                            publicMarketPlaceAssignments.get(i).setIsItemSelected(true);
                            co_worker_adapter.prevData= publicMarketPlaceAssignments.get(i);
                        } else{
                            publicMarketPlaceAssignments.get(i).setIsItemSelected(false);
                        }
                    }else{
                        publicMarketPlaceAssignments.remove(i);
                    }
                }
            }
        }

        co_worker_adapter.notifyDataSetChanged();
    }

    private boolean compareCuId(String cu_id,String assignment_id){
        return assignment_id.equals(cu_id);
    }
}

