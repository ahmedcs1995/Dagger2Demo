package com.mobileapp.krank.Chat.GroupChatPakage;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.mobileapp.krank.Adapters.GroupChatAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.ChatMainPage;
import com.mobileapp.krank.Chat.PrivateNewMessage;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;
import com.mobileapp.krank.ViewModels.GroupChatConversationListViewModel;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Yaseen on 30/04/2018.
 */

public class GroupChat extends BaseFragment {
    private RecyclerView ChatRecyclerView;
    private RecyclerView.Adapter chatRecyclerAdapter;

    List<GroupChatConversationGroupModel> groupChatConvo;

    FloatingActionMenu mainFab;
    FloatingActionButton msgFab;
    FloatingActionButton groupFab;
    boolean isFabsVisible;
    private ShimmerFrameLayout mShimmerViewContainer;


    boolean isFirstTimeInit;
    AppUtils appUtils;


    private GroupChatConversationListViewModel groupChatConversationListViewModel;
    boolean onResumeFirstTimeCall;

    public static boolean EXIT = false;

    CustomCallBack customCallBack;
    //  TextView no_item_found_view;
    View shimmer_layout_container;


    List<ChatConversationListDataModel> personalChatConvo;


    public GroupChat() {
        setTitle("Group Chats");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.group_chat, container, false);
        setFragmentView(me);

        init();

        initViews();

        bindListeners();

        observerMsgs();


        customCallBack = () -> {
            if(shimmer_layout_container.getVisibility() ==  View.VISIBLE){
                // Log.e("into the = > ","customCallBack");
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
                shimmer_layout_container.setVisibility(View.GONE);
                ChatRecyclerView.setVisibility(View.VISIBLE);
            }
            //ChatRecyclerView.setVisibility(View.VISIBLE);
        };

        setUpChatAdapter();



        return me;
    }

    private void setUpChatAdapter() {
        ChatRecyclerView = (RecyclerView) findViewById(R.id.personal_chat_recycler_view);
        groupChatConvo = new ArrayList<>();
        chatRecyclerAdapter = new GroupChatAdapter(groupChatConvo, this);
        ChatRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        ChatRecyclerView.setAdapter(chatRecyclerAdapter);
        ((SimpleItemAnimator) ChatRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

    }


    private void observerMsgs(){
        groupChatConversationListViewModel.getAllConversaionList().observe(this, conversationList -> {

            try{
                if (isFirstTimeInit) {
                    if(conversationList.size() <=0){
                        //no_item_found_view.setVisibility(View.VISIBLE);
                        return;
                    }
                    groupChatConvo.clear();
                    groupChatConvo.addAll(conversationList);
                    chatRecyclerAdapter.notifyDataSetChanged();
                    isFirstTimeInit = false;
                    return;
                } else if (!isFirstTimeInit && groupChatConvo.size() > 0) {
                    int i = 0;
                    while (i < groupChatConvo.size()) {
                        if(groupChatConvo.get(i).getMsg()!=null && conversationList.get(i).getMsg() !=null){
                          /* if (!(groupChatConvo.get(i).getMsg().getMsgUpdated().equals(conversationList.get(i).getMsg().getMsgUpdated())) || !(groupChatConvo.get(i).getUnread_count().equals(conversationList.get(i).getUnread_count()))) {
                        groupChatConvo.set(i, conversationList.get(i));
                        chatRecyclerAdapter.notifyItemChanged(i);
                    }*/


                            if(!(compareServerAndDbValues(groupChatConvo.get(i).getMsg().getMsgUpdated(),conversationList.get(i).getMsg().getMsgUpdated())) || !(compareServerAndDbValues(groupChatConvo.get(i).getUnread_count(),conversationList.get(i).getUnread_count()))){
                                groupChatConvo.set(i, conversationList.get(i));
                                chatRecyclerAdapter.notifyItemChanged(i);
                            }
                        }


                        i++;
                    }
                    if (i < conversationList.size()) {
                        groupChatConvo.addAll(conversationList.subList(i, conversationList.size()));
                        chatRecyclerAdapter.notifyItemRangeInserted(i, conversationList.size());
                    }
                }
            }
            catch (Exception ex){

            }

        });
    }

    private boolean compareServerAndDbValues(String value1, String value2){
        if(value2 !=null){
            return value1.equals(value2);
        }
        return false;
    }
    @Override
    public void onStop() {
        super.onStop();
        EXIT = true;
        groupChatConversationListViewModel.getmRepository().stopTask();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        EXIT = true;
        groupChatConversationListViewModel.getmRepository().stopTask();
    }


    @Override
    public void onResume() {
        super.onResume();
        EXIT = false;
        groupChatConversationListViewModel.getmRepository().startTask(customCallBack);

    }

    private void init(){
        isFabsVisible = false;
        isFirstTimeInit = true;
        onResumeFirstTimeCall = true;
        groupChatConversationListViewModel = ViewModelProviders.of(GroupChat.this).get(GroupChatConversationListViewModel.class);

        appUtils = AppUtils.getInstance();
    }

    private void initViews(){
        mainFab = (FloatingActionMenu) findViewById(R.id.main_fab);
        msgFab = (FloatingActionButton) findViewById(R.id.msg_fab);
        groupFab = (FloatingActionButton) findViewById(R.id.group_fab);


        mShimmerViewContainer = (ShimmerFrameLayout) findViewById(R.id.shimmer_view_container);


        //no_item_found_view =(TextView) findViewById(R.id.no_item_found_view);
        shimmer_layout_container = findViewById(R.id.shimmer_layout_container);

        //  no_item_found_view.setText(Constants.NO_GROUP_FOUND_TEXT);

        mShimmerViewContainer.startShimmer();
        mShimmerViewContainer.setVisibility(View.VISIBLE);

        mainFab.setClosedOnTouchOutside(true);

    }

    private void bindListeners(){
        msgFab.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), PrivateNewMessage.class);
            // intent.putExtra("chat_data", ((ChatMainPage) getActivity()).appUtils.convertToJson(personalChatConvo));

            ChatMainPage activityRef = ((ChatMainPage) getActivity());

            //saving the data
            if(activityRef!=null){
                activityRef.getApplicationRef().recentChat = personalChatConvo;
            }



            intent.putExtra("type", "personal_chat");
            intent.putExtra("page_title", "New Message");
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
        groupFab.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), NewGroupMessage.class);
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

    }

    public void personalChatConvoList(List<ChatConversationListDataModel> items){
        personalChatConvo = items;
    }
}