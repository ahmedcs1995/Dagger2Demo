package com.mobileapp.krank.Functions;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;

import com.mobileapp.krank.Functions.Dialogs.FollowPeopleDialog;
import com.mobileapp.krank.Functions.Dialogs.InviteDialog;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.Dialogs.VerifyPopUpDialog;

public class DialogFactory {
    public enum DialogType {
        VERIFY_NUMBER,
        FOLLOW_PEOPLE,
        NORMAL_DIALOG,
        INVITE_CONNECTIONS_DIALOG,
    }


    public static Dialog getDialog(DialogType dialogType, Context context) {
        switch (dialogType) {
            case FOLLOW_PEOPLE:
                return new FollowPeopleDialog(context);
            case VERIFY_NUMBER:
                return new VerifyPopUpDialog(context);
            case NORMAL_DIALOG:
                return new NormalAppDialog(context);
            case INVITE_CONNECTIONS_DIALOG:
                return new InviteDialog(context);
            default:
                return null;
        }
    }
}
