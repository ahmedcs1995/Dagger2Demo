package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 6/8/2018.
 */

public class CurrenciesListData {


    private boolean isItemSelected;
    private String currencyValue;

    public CurrenciesListData(String currencyValue) {
        this.currencyValue = currencyValue;
    }

    public CurrenciesListData(boolean isItemSelected, String currencyValue) {
        this.isItemSelected = isItemSelected;
        this.currencyValue = currencyValue;
    }

    public boolean isItemSelected() {
        return isItemSelected;
    }

    public void setItemSelected(boolean itemSelected) {
        isItemSelected = itemSelected;
    }

    public String getCurrencyValue() {
        return currencyValue;
    }

    public void setCurrencyValue(String currencyValue) {
        this.currencyValue = currencyValue;
    }
}
