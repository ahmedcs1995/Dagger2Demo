package com.mobileapp.krank.CallBacks

import android.view.View

interface CallBackWithPosTypeAndView{
    fun act(position: Int,type : Int,view: View)
}
