package com.mobileapp.krank.AccountSetupPages;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Activities.CompanySizeDropDownScreen;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CustomViews.CustomViewPager.SwipeableViewPager;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CreateCompanyProfile;
import com.mobileapp.krank.ResponseModels.DataModel.CompanySizeData;
import com.mobileapp.krank.ResponseModels.DataModel.PublicCompanyProfileData;
import com.mobileapp.krank.ResponseModels.PublicCompanyProfileResponse;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Yaseen on 18/04/2018.
 */

public class AccountSetUpCompanyInfo extends BaseFragment implements AccountSetupPage.ProceedButtonListener {

    //views
    private TextView text_view_name, mobile_code_edit_text;
    private EditText website_edit_text, phone_edit_text, bio_edit_text;
    private TextView error;
    EditText company_size_view;

    //activity codes
    private static int COMPANY_SIZE_ACTIVITY_CODE = 100;


    //data
    PublicCompanyProfileData myCompanyProfileData;
    CompanySizeData selectedCompanySize;

    //utils
    Gson gson;

    //activity ref
    AccountSetupPage accountSetupPage;

    private static final String API_FLAG_KEY = "api_flag_1";

    public AccountSetUpCompanyInfo() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_seven, container, false);
        setFragmentView(me);

        init();

        initViews();


        addOnCompanySizeClickListener();

        //call api once
        if (shouldCallApi(savedInstanceState)) {
            getCompanyData();
        } else {
            //load from activity
            if (accountSetupPage != null) {
                myCompanyProfileData = accountSetupPage.getmCompanyData();
                if (myCompanyProfileData != null) {
                    updateUI();
                }
            }
        }

        //focus for add http
        addOnFocusChangeListener();


        return me;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(API_FLAG_KEY, 1);
    }

    private boolean shouldCallApi(Bundle savedInstanceState) {
        return !(savedInstanceState != null && savedInstanceState.getInt(API_FLAG_KEY, 0) == 1);
    }


    private void initViews() {
        company_size_view = (EditText) findViewById(R.id.company_size_view);
        text_view_name = (TextView) findViewById(R.id.text_view_name);
        mobile_code_edit_text = (TextView) findViewById(R.id.mobile_code_edit_text);
        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));
        website_edit_text = (EditText) findViewById(R.id.website_edit_text);
        phone_edit_text = (EditText) findViewById(R.id.phone_edit_text);
        bio_edit_text = (EditText) findViewById(R.id.bio_edit_text);
        error = (TextView) findViewById(R.id.error_view);
    }

    private void init() {
        accountSetupPage = (AccountSetupPage) getActivity();

        accountSetupPage.setmCompanyInfoProceedListener(this::onProceed);

        preference = accountSetupPage.preference;
        gson = CustomGson.getInstance();
        selectedCompanySize = null;
    }

    private void addOnCompanySizeClickListener() {
        company_size_view.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), CompanySizeDropDownScreen.class);

            if (selectedCompanySize != null) {
                intent.putExtra("selectedCompanySize", gson.toJson(selectedCompanySize));
            }

            startActivityForResult(intent, COMPANY_SIZE_ACTIVITY_CODE);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
    }

    private void addOnFocusChangeListener() {
        website_edit_text.setOnFocusChangeListener((view, b) -> {
            if (!b) {
                if (!website_edit_text.getText().toString().isEmpty() && !(AppUtils.isStringContainsHttpHttps(website_edit_text.getText().toString()))) {
                    website_edit_text.setText("http://" + website_edit_text.getText().toString());
                }
            }
        });
    }

    /*
     *Get Company info
     */
    private void getCompanyData() {
       accountSetupPage.getAPI().getMyCompanyProfile(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<PublicCompanyProfileResponse>() {
            @Override
            public void onResponse(Call<PublicCompanyProfileResponse> call, Response<PublicCompanyProfileResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        myCompanyProfileData = response.body().getData();

                        //save in activity
                        if (accountSetupPage != null) {
                            accountSetupPage.setmCompanyData(myCompanyProfileData);
                        }

                        //update Ui
                        if (myCompanyProfileData != null) {
                            updateUI();
                        }

                    }
                }

            }

            @Override
            public void onFailure(Call<PublicCompanyProfileResponse> call, Throwable t) {

            }
        });
    }

    /*
     * Fill data on Fields
     */
    private void updateUI() {
        setTextOnEditText(website_edit_text, myCompanyProfileData.getWebsiteUrl());
        setTextOnEditText(bio_edit_text, myCompanyProfileData.getCompanyBio());
        setTextOnEditText(phone_edit_text, splitTelephoneNumber(myCompanyProfileData.getTelephoneNumber()));

        mobile_code_edit_text.setText("" + myCompanyProfileData.getCountry().getCountryDialCode());

        if (myCompanyProfileData.getCompanySize().length() > 0) {
            selectedCompanySize = new CompanySizeData(myCompanyProfileData.getCompanySize(), myCompanyProfileData.getCompanySizeName());
            company_size_view.setText("" + selectedCompanySize.getCompanySize());
        }
    }

    /*
     * Hold data on Activity
     */
    private void updateDataInActivity() {

        //company size
        myCompanyProfileData.setCompanySize(selectedCompanySize.getId());
        myCompanyProfileData.setCompanySizeName(selectedCompanySize.getCompanySize());

        //website
        myCompanyProfileData.setWebsiteUrl(website_edit_text.getText().toString());

        //bio
        myCompanyProfileData.setCompanyBio(bio_edit_text.getText().toString());

        //country dial
        myCompanyProfileData.getCountry().setCountryDialCode(mobile_code_edit_text.getText().toString());
        //telephone
        myCompanyProfileData.setTelephoneNumber(getMobileNumber());


    }

    private void setTextOnEditText(EditText editText, String value) {
        if (value != null) {
            editText.setText(value);
        }
    }

    private boolean checkValidation() {
        String website = website_edit_text.getText().toString().trim();
        String bio = bio_edit_text.getText().toString().trim();

        boolean isError = false;
        String errorMessage = "";

        if (website.isEmpty()) {
            isError = true;
            errorMessage = Constants.ENTER_WEBSITE_TEXT;
        } else if (phone_edit_text.getText().toString().trim().isEmpty()) {
            isError = true;
            errorMessage = Constants.ENTER_MOBILE_NUM;
        } else if (phone_edit_text.getText().toString().trim().length() < Constants.NUMBER_OF_CHARACTERS_OF_PH_NUM) {
            isError = true;
            errorMessage = Constants.ENTER_VALID_MOBILE_NUM;
        } else if (selectedCompanySize == null) {
            isError = true;
            errorMessage = Constants.SELECT_COMPANY_SIZE;
        } else if (bio.isEmpty()) {
            isError = true;
            errorMessage = Constants.ENTER_BIO_TEXT;
        }

        error.setText(errorMessage);
        return isError;
    }

    private String getMobileNumber() {
        return mobile_code_edit_text.getText().toString().trim() + "-" + phone_edit_text.getText().toString().trim();
    }


    public void update(View nextBtn) {
        if (checkValidation()) {
            return;
        }

        nextBtn.setEnabled(false);

        updateDataOnServer(nextBtn);

    }

    private void updateDataOnServer(View nextBtn) {
        accountSetupPage.getAPI().createCompanyProfile(preference.getString(Constants.ACCESS_TOKEN),
                bio_edit_text.getText().toString().trim(),
                "", // set empty String
                getMobileNumber(),
                myCompanyProfileData.getCountry().getCountryCode(),
                myCompanyProfileData.getCity().getCityId(),
                "", // set empty String
                selectedCompanySize.getId(),
                "", // set empty String
                website_edit_text.getText().toString().trim(),
                "", // set empty String
                0 // set default zero
        ).enqueue(new Callback<CreateCompanyProfile>() {
            @Override
            public void onResponse(Call<CreateCompanyProfile> call, Response<CreateCompanyProfile> response) {
                nextBtn.setEnabled(true);
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        onSuccess();
                    } else {
                        error.setText(response.body().getMessage());
                    }
                } else {
                    error.setText(Constants.ERROR_MSG_TOAST_1);
                }
            }

            @Override
            public void onFailure(Call<CreateCompanyProfile> call, Throwable t) {
                nextBtn.setEnabled(true);
                error.setText(Constants.ERROR_MSG_TOAST_1);
            }
        });
    }

    private void onSuccess() {
        //update on activity
        updateDataInActivity();


        error.setText("");
        accountSetupPage.getListener().onNextPage();
    }

    private String splitTelephoneNumber(String telephone_number) {
        if (telephone_number == null) {
            return null;
        }
        return telephone_number.substring(telephone_number.indexOf('-') + 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COMPANY_SIZE_ACTIVITY_CODE) {
                selectedCompanySize = gson.fromJson(data.getStringExtra("selectedCompanySize"), CompanySizeData.class);
                company_size_view.setText("" + selectedCompanySize.getCompanySize());
            }

        }
    }

    @Override
    public void onProceed(SwipeableViewPager mViewPager, ImageView nextBtn) {
        update(nextBtn);
    }
}