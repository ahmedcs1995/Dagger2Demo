package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.CustomViews.SwitchButton;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInterestListData;

import java.util.List;

public class CompanyInterestListAdapter extends RecyclerView.Adapter<CompanyInterestListAdapter.ViewHolder> {
    public List<CompanyInterestListData> items;
    Context context;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        TextView interest_text_view;
        SwitchButton check_box;
        Boolean isTouched = false;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            interest_text_view = itemView.findViewById(R.id.interest_text_view);
            check_box = itemView.findViewById(R.id.check_box);

            item.setOnClickListener(view -> {
                items.get(getAdapterPosition()).setIsSelected(!items.get(getAdapterPosition()).getIsSelected());
                notifyDataSetChanged();
            });


            /*Switch btn*/
            check_box.setEnableEffect(false);

            check_box.setOnTouchListener((view, motionEvent) -> {
                check_box.setEnableEffect(true);
                isTouched = true;
                return false;
            });
            check_box.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isTouched) {
                    isTouched = false;
                    check_box.setChecked(!items.get(getAdapterPosition()).getIsSelected());
                    check_box.setEnableEffect(false);
                    items.get(getAdapterPosition()).setIsSelected(isChecked);
                }
            });
        }
    }

    public CompanyInterestListAdapter(List<CompanyInterestListData> items, Context context) {
        this.items = items;
        this.context = context;
    }


    @Override
    public CompanyInterestListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_stup_page_eight_checkbox_item, parent, false);
        return new CompanyInterestListAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CompanyInterestListAdapter.ViewHolder holder, int position) {
        final CompanyInterestListData item = items.get(position);
        holder.check_box.setChecked(item.getIsSelected());
        holder.interest_text_view.setText(item.getTitle());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}





