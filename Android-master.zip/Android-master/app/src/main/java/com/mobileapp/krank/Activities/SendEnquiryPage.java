package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.ListingModelForEnquiry;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDealerRepDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SendEnquiryPage extends BaseActivity {
    //message
    TextView listing_message;
    //edit text
    EditText mEnquiryMessageEditText;
    //bns
    View send_btn;
    View select_dealers;
    View select_connection;

    //underline
    View underline;
    //  ListingDataArray listingDataArray;

    //listing model
    ListingModelForEnquiry mListingModelForEnquiry;

    //loader
    private SweetAlertDialog showProgressAlert;

    //assign dealer
    List<DealerDataListing> dealerDataListings;

    //assignment
    List<PublicMarketPlaceAssignment> market_place_assignments;

    //activity code
    private static int SELECT_EMPLOYEE_CODE = 500;
    private static int SELECT_CO_WORKER_CODE = 600;


    TextView chip_name;

    //selected dealer rep assign
    public ListingDealerRepDataModel mDealerRepresentatives;

    //selected assignment
    public PublicMarketPlaceAssignment mAssignments;

    //for chip name
    String employee_name = "";

    //messages
    private static String IS_DEALER_YES = "Yes";
    private static String ENQUIRY_MSG = "You are not connected with the owner of this listing, we will send a connection request along with your listing enquiry";
    private static String ENQUIRY_MSG_FOR_REQUEST_PENDING = "You have already sent the connection request to the owner of this listing, please check your sent requests.";

    //flag
    private String isDealer;

    private int itemIndex;
    // index
    private int coWorkerSelectedIndex;
    private int dealerSelectedIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_enquiry_page);

        initViews();

        init();

        setNormalPageToolbar( "Send Enquiry");

        setInitialConditions();

        mListingModelForEnquiry = getListingDataFromIntent();

        setEnquiryMessages();

        handleCallBacks();
    }
    private void setInitialConditions() {
        if (isDealerList()) {
            select_dealers.setVisibility(View.VISIBLE);
            select_connection.setVisibility(View.GONE);
            hideEditTextAndUnderLine();
            dealerDataListings.addAll(Arrays.asList(gson.fromJson(getIntent().getStringExtra("dealerList"), DealerDataListing[].class)));

        } else if (isCoWorkerAssignment()) {
            select_connection.setVisibility(View.VISIBLE);
            select_dealers.setVisibility(View.GONE);
            showEditTextAndUnderLine();
            market_place_assignments.addAll(Arrays.asList(gson.fromJson(getIntent().getStringExtra("assignmentData"), PublicMarketPlaceAssignment[].class)));

            /*skip the logged in user*/
            for(int i = 0; i< market_place_assignments.size();i++){
                if(market_place_assignments.get(i).isLoggedInUser(preference.getString(Constants.USER_ID))){
                    market_place_assignments.remove(i);
                }
            }
            /*skip the logged in user*/

            coWorkerSelectedIndex = 0;
            initMarketPlaceAssignments();

            setTextOnChipView();
        } else {
            select_dealers.setVisibility(View.GONE);
            select_connection.setVisibility(View.GONE);
            showEditTextAndUnderLine();
        }
    }

    private void initMarketPlaceAssignments(){
        if(market_place_assignments.size() > 0){
            mAssignments =  market_place_assignments.get(0);
            employee_name = mAssignments.getFirstName() + " " + mAssignments.getLastName();
            return;
        }
        //mAssignments = (market_place_assignments.size() > 0) ? market_place_assignments.get(0): null;
    }
    private ListingModelForEnquiry getListingDataFromIntent() {
        return gson.fromJson(getIntent().getStringExtra("listing_data"), ListingModelForEnquiry.class);
    }

    private void init() {
        dealerDataListings = new ArrayList<>();
        market_place_assignments = new ArrayList<>();
        mDealerRepresentatives = null;
        mAssignments = null;
        isDealer = "";
        showProgressAlert = showAlert(Constants.ENQUIRY_SENDING_MESSAGE, SweetAlertDialog.PROGRESS_TYPE, false);

        itemIndex = getItemIndex();
    }

    private int getItemIndex() {
        return getIntent().getIntExtra("item_index", 0);
    }

    private void initViews() {
        listing_message = findViewById(R.id.listing_message);
        mEnquiryMessageEditText = findViewById(R.id.post_description);
        chip_name = findViewById(R.id.chip_name);
        send_btn = findViewById(R.id.send_btn);
        select_dealers = findViewById(R.id.select_dealers);
        select_connection = findViewById(R.id.select_connection);
        underline = findViewById(R.id.underline);
    }

    private void handleCallBacks() {
        send_btn.setOnClickListener(view -> {
            /*Assign Dealers block*/
            if (isDealerList()) {
                if (mDealerRepresentatives == null) {
                    Toast.makeText(getApplicationContext(), "Please select dealer", Toast.LENGTH_SHORT).show();
                    return;
                } else if (mEnquiryMessageEditText.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter enquiry message", Toast.LENGTH_SHORT).show();
                    return;
                }

            } else {
                if (mEnquiryMessageEditText.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter enquiry message", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            sendListingMsg();
            /*Assign Dealers block*/


        });

        select_dealers.setOnClickListener(view -> {
            Intent intent = new Intent(SendEnquiryPage.this, DealersSelectFromListing.class);
            intent.putExtra("dealerList", getIntent().getStringExtra("dealerList"));
            intent.putExtra("selected_employee", gson.toJson(mDealerRepresentatives));
            intent.putExtra("listing_id", mListingModelForEnquiry.getId());
            startActivityForResult(intent, SELECT_EMPLOYEE_CODE);
        });

        select_connection.setOnClickListener(view -> {
            Intent intent = new Intent(SendEnquiryPage.this, CoWorkerAssignmentPage.class);
            intent.putExtra("assignmentData", gson.toJson(market_place_assignments));
            intent.putExtra("selected_assignment", gson.toJson(mAssignments));
            intent.putExtra("cu_id", mListingModelForEnquiry.getCuId());
            startActivityForResult(intent, SELECT_CO_WORKER_CODE);
        });
    }

    private void hideEditTextAndUnderLine(){
        mEnquiryMessageEditText.setVisibility(View.GONE);
        underline.setVisibility(View.GONE);
    }
    private void showEditTextAndUnderLine(){
        mEnquiryMessageEditText.setVisibility(View.VISIBLE);
        underline.setVisibility(View.VISIBLE);
    }

    private void sendListingMsg() {
        showProgressAlert.show();
        String userId = "";

        /*if (getIntent().getStringExtra("user_id_to_send") != null) {
            userId = getIntent().getStringExtra("user_id_to_send");
        } else if (isDealerList()) {
            userId = mDealerRepresentatives.getUserId();
        } else if (isCoWorkerAssignment()) {
            userId = mAssignments.getUserId();
        } else {
            userId = mListingModelForEnquiry.getUserId();
        }*/


        if (isDealerList()) {
            userId = mDealerRepresentatives.getId();
        } else if (isCoWorkerAssignment()) {
            userId = mAssignments.getId();
        } else {
            userId = mListingModelForEnquiry.getUserId();
        }

        getAPI().listingSendMsg(preference.getString(Constants.ACCESS_TOKEN), userId, mListingModelForEnquiry.getId(), "1", mEnquiryMessageEditText.getText().toString(), isDealer).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        showProgressAlert.dismiss();
                        Toast.makeText(SendEnquiryPage.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();


                        Intent intent = new Intent();


                        if(isDealerList()){
                            dealerDataListings.get(dealerSelectedIndex).setNetworkStatus(Constants.REQUEST_PENDING);
                            intent.putExtra("dealer_data_listing",gson.toJson(dealerDataListings));
                            Log.e("sending data","=> " + gson.toJson(dealerDataListings));
                        }
                        /*updating co-worker data and sending back*/
                        else if(isCoWorkerAssignment()){
                            /*updating connection request*/

                            mAssignments.setConnectionStatus(Constants.REQUEST_PENDING);

                            /*updating connection request*/


                            market_place_assignments.set(coWorkerSelectedIndex, mAssignments);
                            intent.putExtra("co_worker_assignments", gson.toJson(market_place_assignments));
                        }else{
                            /*updating network status*/
                            if(mListingModelForEnquiry.getNetStatus().equals(Constants.NO_CONNECTION_TEXT)){
                                intent.putExtra("updated_network_status", Constants.REQUEST_PENDING);
                            }else{
                                intent.putExtra("updated_network_status", mListingModelForEnquiry.getNetStatus());
                            }
                            /*updating network status*/


                            /*updating connection status*/
                            if(mListingModelForEnquiry.getConStatus().equals(Constants.NO_CONNECTION_TEXT)){
                                intent.putExtra("updated_connection_status", Constants.REQUEST_PENDING);
                            }else{
                                intent.putExtra("updated_connection_status", mListingModelForEnquiry.getNetStatus());
                            }
                            /*updating connection status*/
                        }
                        /*updating co-worker data and sending back*/


                        intent.putExtra("item_index", itemIndex);

                        setResult(RESULT_OK, intent);
                        finish();

                        return;
                    } else {
                        showProgressAlert.dismiss();
                        Toast.makeText(SendEnquiryPage.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                showProgressAlert.dismiss();
                Toast.makeText(SendEnquiryPage.this, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                Toast.makeText(SendEnquiryPage.this, Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();

            }
        });
    }


    private boolean isDealerList() {
        return getIntent().getBooleanExtra("isDealer", false);
    }

    private boolean isCoWorkerAssignment() {

        return getIntent().getBooleanExtra("isCoWorkerAssignment", false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_EMPLOYEE_CODE) {
                if (data.getStringExtra("selected_employee") != null) {
                    dealerSelectedIndex = data.getIntExtra("dealer_item_index",0);
                    mDealerRepresentatives = gson.fromJson(data.getStringExtra("selected_employee"), ListingDealerRepDataModel.class);
                    employee_name = mDealerRepresentatives.getFirstName() + " " + mDealerRepresentatives.getLastName();
                    setTextOnChipView();
                    isDealer = IS_DEALER_YES;
                    setEnquiryMessages();
                    showEditTextAndUnderLine();
                }
            } else if (requestCode == SELECT_CO_WORKER_CODE) {
                if (data.getStringExtra("selected_assignment") != null) {
                    mAssignments = gson.fromJson(data.getStringExtra("selected_assignment"), PublicMarketPlaceAssignment.class);
                    employee_name = mAssignments.getFirstName() + " " + mAssignments.getLastName();
                    setTextOnChipView();
                    setEnquiryMessages();
                    mEnquiryMessageEditText.setVisibility(View.VISIBLE);
                    coWorkerSelectedIndex = data.getIntExtra("co_worker_selected_index",coWorkerSelectedIndex);
                }
            }
        }
    }

    private void setTextOnChipView(){
        chip_name.setVisibility(View.VISIBLE);
        chip_name.setText("" + employee_name);
    }


    private void setEnquiryMessages() {

        if (mListingModelForEnquiry.getDealers().size() > 0 && mDealerRepresentatives != null) {

            if(mDealerRepresentatives.getConnectionStatus().equals(Constants.CONNECTION_NOT_CONNECTED)){
                listing_message.setText("You and " + employee_name + " are not connected, we will send a connection request along with your listing enquiry");
            }
            else if(mDealerRepresentatives.getConnectionStatus().equals(Constants.REQUEST_PENDING)){
                listing_message.setText(ENQUIRY_MSG_FOR_REQUEST_PENDING);
            }
            else if(mDealerRepresentatives.getConnectionStatus().equals(Constants.CONNECTED_TEXT)){
                listing_message.setText("");
            }

        } else if (mListingModelForEnquiry.getAssignments().size() > 0 && mAssignments != null) {

            if(mAssignments.getConnectionStatus().equals(Constants.CONNECTION_NOT_CONNECTED)) {
                listing_message.setText("You and " + employee_name + " are not connected, we will send a connection request along with your listing enquiry");
            }
            else if(mAssignments.getConnectionStatus().equals(Constants.REQUEST_PENDING)){
                listing_message.setText(ENQUIRY_MSG_FOR_REQUEST_PENDING);
            }
            else if(mAssignments.getConnectionStatus().equals(Constants.CONNECTED_TEXT)){
                listing_message.setText("");
            }

        } else if (mListingModelForEnquiry.getDealers().size() <= 0 && mListingModelForEnquiry.getAssignments().size() <= 0) {
            if (mListingModelForEnquiry.getConStatus().equals(Constants.NO_CONNECTION_TEXT) && mListingModelForEnquiry.getNetStatus().equals(Constants.NO_CONNECTION_TEXT)) {
                listing_message.setText(ENQUIRY_MSG);
            } else if (mListingModelForEnquiry.getConStatus().equals(Constants.NO_CONNECTION_TEXT) && mListingModelForEnquiry.getNetStatus().equals(Constants.CONNECTED_TEXT)) {
                listing_message.setText(ENQUIRY_MSG);
            } else if (mListingModelForEnquiry.getConStatus().equals(Constants.REQUEST_PENDING) && mListingModelForEnquiry.getNetStatus().equals(Constants.CONNECTED_TEXT)) {
                listing_message.setText(ENQUIRY_MSG_FOR_REQUEST_PENDING);
            } else if (mListingModelForEnquiry.getConStatus().equals(Constants.REQUEST_PENDING) && mListingModelForEnquiry.getNetStatus().equals(Constants.REQUEST_PENDING)) {
                listing_message.setText(ENQUIRY_MSG_FOR_REQUEST_PENDING);
            } else {
                // Connection and Network Both Connected
                listing_message.setText("");
            }
        }
    }
}
