package com.mobileapp.krank.Activities;

import android.Manifest;
import android.content.Context;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.mobileapp.krank.AccountSetupPages.MarketPlaceInterestPage;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpCompanyPicture;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpUserInfo;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpPageNine;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpPageOne;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpCompanyInfo;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpCompanyCoverPicture;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpUserCoverPicture;
import com.mobileapp.krank.AccountSetupPages.AccountSetUpUserPicture;
import com.mobileapp.krank.AccountSetupPages.VerifyPhoneNumber;
import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.PhoneCodeAutoReadListener;
import com.mobileapp.krank.CustomViews.CustomViewPager.FixedSpeedScroller;
import com.mobileapp.krank.CustomViews.CustomViewPager.SwipeableViewPager;
import com.mobileapp.krank.Functions.AppSignatureHelper;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Listeners.SmsListener;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInterestListData;
import com.mobileapp.krank.ResponseModels.DataModel.PublicCompanyProfileData;

import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class AccountSetupPage extends BaseActivity {




    //interfaces
    public interface PageChangeListener {
        void onNextPage();

        void onPreviousPage();
    }

    @FunctionalInterface
    public interface UpdatePhoneNumberListener {
        void update(String phoneNumber, boolean isVerified);
    }

    @FunctionalInterface
    public interface PictureChangeListener {
        void onPictureChange();
    }

    @FunctionalInterface
    public interface ProceedButtonListener {
        void onProceed(SwipeableViewPager mViewPager, ImageView nextBtn);
    }

    SwipeableViewPager mViewPager;

    //btns
    public ImageView nextBtn;
    View prevBtnContainer;
    public ImageView prevBtn;


    public TextView skipNowText;
    View footer;
    View cancelBtn;

    private static final int OFF_SCREEN_PAGE_LIMIT = 1;

    //phoneNumber
    String phoneNumber;
    public boolean isVerified;

    //pages
    ArrayList<BaseFragment> pages;

    //adapter
    CustomFragmentStatePagerAdapter adapter;


    //phone code listener
    PhoneCodeAutoReadListener phoneCodeListener;

    //page change listener
    PageChangeListener listener;

    //image select
    PictureChangeListener mUserPicChangeListener;
    PictureChangeListener mCompanyPicChangeListener;

    //next btn
    ProceedButtonListener mUserInfoInfoProceedListener;
    ProceedButtonListener mCompanyInfoProceedListener;
    ProceedButtonListener mMarketPlaceInterestProceedListener;

    //phone Number
    UpdatePhoneNumberListener mUpdatePhoneNumberListener;


    //company Info
    PublicCompanyProfileData mCompanyData;
    //market place interest
    List<CompanyInterestListData> marketPlaceInterest;

    //sms
    SmsListener mSmsListener;
    ArrayList<String> appSignatures;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkOrAskForMultipleRunTimePermission(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA);

        setContentView(R.layout.activity_account_setup1);

        initViews();

        init();

        AppUtils.setSpannableUnderlineText(skipNowText, "Skip for now");

        setUpViewPager();

        checkPrevBtnEnablility(this);


        hideSkipNowView();

        addOnCancelBtnListener();

        addOnPageChangeListener();

        addOnFooterBtnClickListener();


        addOnViewPagerPageChangeListener();

    }
    private void startSMSListener() {

        SmsRetriever.getClient(this).startSmsRetriever()
                .addOnSuccessListener(aVoid -> {

                }).addOnFailureListener(e -> {

        });
    }

    public void bindSmsListener() {
        startSMSListener();

        mSmsListener.initOTPListener(new SmsListener.OTPReceiveListener() {
            @Override
            public void onOTPReceived(@NotNull String otp) {
                if (phoneCodeListener == null) return;
                phoneCodeListener.onCodeReceived(otp);
            }

            @Override
            public void onOTPTimeOut() {

            }
        });


        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);

        registerReceiver(mSmsListener, intentFilter);


    }

    private void addOnViewPagerPageChangeListener() {
        //page change listener
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                onViewPagerPageSelected(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void init() {
        //phoneNumber
        isVerified = false;
        mSmsListener =new SmsListener();
    }

    private void setScrollerForViewPager(){
        try {
            Field mScroller;
            mScroller = ViewPager.class.getDeclaredField("mScroller");
            mScroller.setAccessible(true);
            FixedSpeedScroller scroller = new FixedSpeedScroller(mViewPager.getContext(), new AccelerateInterpolator());
            // scroller.setFixedDuration(5000);
            mScroller.set(mViewPager, scroller);
        } catch (NoSuchFieldException e) {
        } catch (IllegalArgumentException e) {
        } catch (IllegalAccessException e) {
        }
    }

    public String getAppSignature(){
        //Used to generate hash signature
        if(appSignatures == null){
            appSignatures = new AppSignatureHelper(AccountSetupPage.this).getAppSignatures();
        }
        if(appSignatures.size() > 0){
            return appSignatures.get(0);
        }

        return null;

    }

    private void setUpViewPager() {

        TabLayout mTabLayout = findViewById(R.id.tab_dots);


        //set scroller
        //setScrollerForViewPager();


        //pages
        final AccountSetUpPageOne accountSetUpPageOne = new AccountSetUpPageOne(); //0
        final AccountSetUpUserPicture accountSetUpPageTwo = new AccountSetUpUserPicture(); //1
        final AccountSetUpUserCoverPicture accountSetUpPageThree = new AccountSetUpUserCoverPicture(); //2
        final AccountSetUpUserInfo accountSetUpPageFour = new AccountSetUpUserInfo(); //3
        final VerifyPhoneNumber verifyPhoneNumber = new VerifyPhoneNumber(); //4
        final AccountSetUpCompanyPicture accountSetUpPageFive = new AccountSetUpCompanyPicture(); //5
        final AccountSetUpCompanyCoverPicture accountSetUpPageSix = new AccountSetUpCompanyCoverPicture(); //6
        final AccountSetUpCompanyInfo accountSetUpPageSeven = new AccountSetUpCompanyInfo(); //7
        final MarketPlaceInterestPage accountSetUpPageEight = new MarketPlaceInterestPage(); // 8
        final AccountSetUpPageNine accountSetUpPageNine = new AccountSetUpPageNine(); //9

        pages = new ArrayList<>();
        pages.add(accountSetUpPageOne);
        pages.add(accountSetUpPageTwo);
        pages.add(accountSetUpPageThree);
        pages.add(accountSetUpPageFour);
        pages.add(verifyPhoneNumber);
        pages.add(accountSetUpPageFive);
        pages.add(accountSetUpPageSix);
        pages.add(accountSetUpPageSeven);
        pages.add(accountSetUpPageEight);
        pages.add(accountSetUpPageNine);


        //setting viewpager
        mViewPager.setOffscreenPageLimit(OFF_SCREEN_PAGE_LIMIT);
        adapter = new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages);
        mViewPager.setAdapter(adapter);
        mTabLayout.setupWithViewPager(mViewPager);

        //disable tabs
        LinearLayout tabStrip = ((LinearLayout)mTabLayout.getChildAt(0));
        for(int i = 0; i < tabStrip.getChildCount(); i++) {
            tabStrip.getChildAt(i).setOnTouchListener((v, event) -> true);
        }
    }

    private void addOnFooterBtnClickListener() {
        nextBtn.setOnClickListener(v -> {
            Fragment fragment = getSelectedFragment();


            if (fragment instanceof AccountSetUpUserCoverPicture) {
                gotoNextPage();
                if (mUserPicChangeListener != null) {
                    mUserPicChangeListener.onPictureChange();
                }
                // accountSetUpPageThree.update();
            } else if (fragment instanceof AccountSetUpUserInfo) {
                if (mUserInfoInfoProceedListener != null) {
                    mUserInfoInfoProceedListener.onProceed(mViewPager, nextBtn);
                }
                // accountSetUpPageFour.update(mViewPager, nextBtn);
            } else if (fragment instanceof AccountSetUpCompanyCoverPicture) {
                gotoNextPage();
                // accountSetUpPageSix.update();
                if (mCompanyPicChangeListener != null) {
                    mCompanyPicChangeListener.onPictureChange();
                }
            } else if (fragment instanceof AccountSetUpCompanyInfo) {
                if (mCompanyInfoProceedListener != null) {
                    mCompanyInfoProceedListener.onProceed(mViewPager, nextBtn);
                }
                // accountSetUpPageSeven.update(mViewPager, nextBtn);
            } else if (fragment instanceof MarketPlaceInterestPage) {
                if (mMarketPlaceInterestProceedListener != null) {
                    mMarketPlaceInterestProceedListener.onProceed(mViewPager, nextBtn);
                }
                //accountSetUpPageEight.update(mViewPager);
            } else {
                gotoNextPage();
            }

        });

        prevBtn.setOnClickListener(v -> mViewPager.setCurrentItem(getItem(-1), true));
        skipNowText.setOnClickListener(v -> gotoNextPage());

    }

    private void onViewPagerPageSelected(final int position) {

        //hide keyboard
        try {
            hideKeyBoard();
        } catch (Exception ex) {

        }
        Fragment fragment = getSelectedFragment();


        if (fragment instanceof AccountSetUpPageOne) {
            hideSkipNowView();
        } else if (fragment instanceof AccountSetUpUserPicture) {
            if (Constants.USER_IMG) {
                hideSkipNowView();
            } else {
                showSkipNowView();
            }
        }
        // for update process
        else if (fragment instanceof AccountSetUpUserCoverPicture) {
            //picture
            if (Constants.COVER_IMG) {
                hideSkipNowView();
            } else {
                showSkipNowView();
            }

            //picture change listener
            if (mUserPicChangeListener != null) {
                mUserPicChangeListener.onPictureChange();
            }
        } else if (fragment instanceof AccountSetUpUserInfo) {
            hideSkipNowView();
        } else if (fragment instanceof AccountSetUpCompanyPicture) {
            if (Constants.COMPANY_IMG) {
                hideSkipNowView();
            } else {
                showSkipNowView();
            }
        } else if (fragment instanceof AccountSetUpCompanyCoverPicture) {
            //picture
            if (Constants.COMPANY_COVER_IMG) {
                hideSkipNowView();
            } else {
                showSkipNowView();
            }

            //picture change listener
            if (mCompanyPicChangeListener != null) {
                mCompanyPicChangeListener.onPictureChange();
            }
        } else if (fragment instanceof VerifyPhoneNumber) {
            // verifyPhoneNumber.updatePhoneNum(phoneNumber, isVerified);
            hideSkipNowView();


            //update phoneNumber
            if (mUpdatePhoneNumberListener != null) {
                mUpdatePhoneNumberListener.update(phoneNumber, isVerified);
            }

        } else if (position == pages.size() - 1) {
            footer.setVisibility(View.GONE);
            skipNowText.setVisibility(View.GONE);
            //cancelBtn.setVisibility(View.GONE);
            return;
        } else {
            footer.setVisibility(View.VISIBLE);
            skipNowText.setVisibility(View.VISIBLE);
            //cancelBtn.setVisibility(View.VISIBLE);
        }

        checkPrevBtnEnablility(AccountSetupPage.this);


    }

    public Fragment getSelectedFragment() {
        return pages.get(mViewPager.getCurrentItem());
    }

    private void addOnCancelBtnListener() {
        cancelBtn.setVisibility(View.GONE);
    }

    private void addOnPageChangeListener() {
        listener = new PageChangeListener() {
            @Override
            public void onNextPage() {
                gotoNextPage();
            }

            @Override
            public void onPreviousPage() {
                gotoPreviousPage();
            }
        };
    }



    public void setPhoneNumber(String phoneNumber) {
        if (this.phoneNumber == null) {
            isVerified = false;
        } else if (!phoneNumber.equals(this.phoneNumber)) {
            isVerified = false;
        }
        this.phoneNumber = phoneNumber;
    }


    private int getItem(int i) {
        return mViewPager.getCurrentItem() + i;
    }


    private void initViews() {
        mViewPager = findViewById(R.id.view_pager);
        nextBtn = findViewById(R.id.next_btn);
        prevBtnContainer = findViewById(R.id.prev_btn_container);
        prevBtn = findViewById(R.id.prev_btn);
        skipNowText = findViewById(R.id.skip_now_text);
        footer = findViewById(R.id.inner_footer);
        cancelBtn = findViewById(R.id.cancel_btn);
    }

    private void checkPrevBtnEnablility(Context context) {
        if (mViewPager.getCurrentItem() == 0) {
            // prevBtnContainer.setVisibility(View.GONE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                prevBtn.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.drawerGray)));
            }
        } else {
            // prevBtnContainer.setVisibility(View.VISIBLE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                prevBtn.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.btnColor)));
            }
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        unRegisterListener();
    }


    private void unRegisterListener(){
        try {
            unregisterReceiver(mSmsListener);
        }catch (Exception e){

        }

    }
    /**/
    public void gotoNextPage() {
        mViewPager.setCurrentItem(getItem(+1), true);
    }

    public void gotoPreviousPage() {
        mViewPager.setCurrentItem(getItem(-1), true);
    }

    public void setPhoneCodeListener(PhoneCodeAutoReadListener phoneCodeListener) {
        this.phoneCodeListener = phoneCodeListener;
    }

    /*Pictures*/
    public void setmUserPicChangeListener(PictureChangeListener mUserPicChangeListener) {
        this.mUserPicChangeListener = mUserPicChangeListener;
    }

    public void setmCompanyPicChangeListener(PictureChangeListener mCompanyPicChangeListener) {
        this.mCompanyPicChangeListener = mCompanyPicChangeListener;
    }
    /*Pictures*/

    /*User Info*/
    public void setmUsernfoInfoProceedListener(ProceedButtonListener mUsernfoInfoProceedListener) {
        this.mUserInfoInfoProceedListener = mUsernfoInfoProceedListener;
    }

    public void setmCompanyInfoProceedListener(ProceedButtonListener mCompanyInfoProceedListener) {
        this.mCompanyInfoProceedListener = mCompanyInfoProceedListener;
    }
    /*User Info*/


    public void setmMarketPlaceInterestProceedListener(ProceedButtonListener mMarketPlaceInterestProceedListener) {
        this.mMarketPlaceInterestProceedListener = mMarketPlaceInterestProceedListener;
    }


    public void setmUpdatePhoneNumberListener(UpdatePhoneNumberListener mUpdatePhoneNumberListener) {
        this.mUpdatePhoneNumberListener = mUpdatePhoneNumberListener;
    }

    public PageChangeListener getListener() {
        return listener;
    }

    public void showSkipNowView() {
        skipNowText.setVisibility(View.VISIBLE);
    }

    public void hideSkipNowView() {
        skipNowText.setVisibility(View.INVISIBLE);
    }

    public void setMarketPlaceInterest(List<CompanyInterestListData> items) {
        this.marketPlaceInterest = items;
    }


    /*Interest List*/
    public List<CompanyInterestListData> getMarketPlaceInterest() {
        return marketPlaceInterest;
    }
    /*Interest List*/


    /*Company Info*/
    public PublicCompanyProfileData getmCompanyData() {
        return mCompanyData;
    }

    public void setmCompanyData(PublicCompanyProfileData mCompanyData) {
        this.mCompanyData = mCompanyData;
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
