package com.mobileapp.krank.Model;

import com.mobileapp.krank.Model.Enums.TypeOfDetailInListing;

public class ListingDetailListItem {

    TypeOfDetailInListing typeOfDetailInListing;


    private String latitude;


    private DetailItem detailItem;

    private String address;

    private String longitude;

    private String heading;

    private String id;

    private String title;

    private String url;

    private String quantity;

    private String description;

    private String type;

    private String createdDate;

    private String status;

    private String listingId;

    private String vimeo_thumbnail;

    private Object rfqId;

    private String number;


    private String errorText;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getListingId() {
        return listingId;
    }

    public void setListingId(String listingId) {
        this.listingId = listingId;
    }

    public Object getRfqId() {
        return rfqId;
    }

    public void setRfqId(Object rfqId) {
        this.rfqId = rfqId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }


    public ListingDetailListItem(TypeOfDetailInListing typeOfDetailInListing) {
        this.typeOfDetailInListing = typeOfDetailInListing;
    }




    public ListingDetailListItem(TypeOfDetailInListing typeOfDetailInListing, String heading) {
        this.typeOfDetailInListing = typeOfDetailInListing;
        this.heading = heading;
    }

    public TypeOfDetailInListing getTypeOfDetailInListing() {
        return typeOfDetailInListing;
    }

    public void setTypeOfDetailInListing(TypeOfDetailInListing typeOfDetailInListing) {
        this.typeOfDetailInListing = typeOfDetailInListing;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public ListingDetailListItem(String id, String title, String url, String createdDate, String status, String listingId,String vimeo_thumbnail,TypeOfDetailInListing typeOfDetailInListing) {
        this.id = id;
        this.title = title;
        this.url = url;
        this.createdDate = createdDate;
        this.status = status;
        this.listingId = listingId;
        this.vimeo_thumbnail = vimeo_thumbnail;
        this.typeOfDetailInListing = typeOfDetailInListing;
    }



    public ListingDetailListItem(String id, String title, String url, String createdDate, String status, String listingId,TypeOfDetailInListing typeOfDetailInListing) {
        this.id = id;
        this.title = title;
        this.url = url;
        this.createdDate = createdDate;
        this.status = status;
        this.listingId = listingId;
        this.typeOfDetailInListing = typeOfDetailInListing;
    }

    public ListingDetailListItem(String id, String quantity, String description, String type, String created_date, String status,String listingId,String rfqId,String number,TypeOfDetailInListing typeOfDetailInListing) {
        this.id = id;
        this.quantity = quantity;
        this.description = description;
        this.type = type;
        this.createdDate = created_date;
        this.status = status;
        this.listingId = listingId;
        this.rfqId = rfqId;
        this.number = number;
        this.typeOfDetailInListing = typeOfDetailInListing;
    }

    public ListingDetailListItem(TypeOfDetailInListing typeOfDetailInListing, DetailItem detailItem) {
        this.typeOfDetailInListing = typeOfDetailInListing;
        this.detailItem = detailItem;
    }

    public DetailItem getDetailItem() {
        return detailItem;
    }

    public void setDetailItem(DetailItem detailItem) {
        this.detailItem = detailItem;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getVimeo_thumbnail() {
        return vimeo_thumbnail;
    }

    public void setVimeo_thumbnail(String vimeo_thumbnail) {
        this.vimeo_thumbnail = vimeo_thumbnail;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }


}
