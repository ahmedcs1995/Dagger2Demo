package com.mobileapp.krank.Activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CustomViews.SwitchButton;
import com.mobileapp.krank.Functions.DateTimeUtils;
import com.mobileapp.krank.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.text.ParseException;


public class TestActivity extends BaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);




    }
}