package com.mobileapp.krank.CallBacks;

import com.mobileapp.krank.Model.PrivacyItem;
import com.mobileapp.krank.ResponseModels.DataModel.DealerGroupDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkGroupDataModel;

import java.util.ArrayList;

public interface CustomShareCallBack {
    void shareFeed(PrivacyItem selectedPrivacy, ArrayList<DealerGroupDataModel> tempDealerGroup, ArrayList<NetworkGroupDataModel> tempNetworkGroup);
}
