package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.SimpleItemAnimator
import android.view.View

import com.mobileapp.krank.Adapters.SortByConnectionsDealersAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.ConnectionResponse
import com.mobileapp.krank.Scroll.EndlessOnScrollListener
import kotlinx.android.synthetic.main.app_progress_bar.*
import kotlinx.android.synthetic.main.no_record_found_layout.*
import kotlinx.android.synthetic.main.toolbar_with_reset_btn.*
import kotlinx.android.synthetic.main.activity_sort_by_connections_and_dealers.*

import java.util.ArrayList

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SortByConnectionsAndDealers : BaseActivity() , CallBackWithAdapterPosition {


    private var sortRecyclerAdapter: RecyclerView.Adapter<*>? = null
    internal lateinit var Items: MutableList<ConnectionsDataModel>
    internal lateinit var layoutManager: LinearLayoutManager
    var checkIndex: Int = 0



    //pagination
    private var offset: Int = 0
    private var shouldScrollCall: Boolean = false

    //delay
    internal lateinit var handler: Handler
    internal lateinit var runnable: Runnable


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sort_by_connections_and_dealers)


        shouldScrollCall = false
        checkIndex = -1
        offset = 0


        //delay
        handler = Handler()
        runnable = Runnable {
            getData()
        }

        no_item_found_view.text = Constants.NO_NETWORK_FOUND_TEXT
        no_item_found_view.visibility = View.GONE


        setNormalPageToolbar( "Sort By Connections And Dealers")

        if (intent.extras != null && intent.getBooleanExtra("show_reset_btn", false)) {
            reset_btn.visibility = View.VISIBLE
        } else {
            reset_btn.visibility = View.GONE
        }
        reset_btn.setOnClickListener { view ->
            val intent = Intent()
            intent.putExtra("reset_click", true)
            setResult(RESULT_OK, intent)
            finish()
        }


        setUpAdapter()

        getData()


        addOnDoneBtnListener()
    }


    private fun addOnRecyclerViewScrollListener() {
        sort_recycler.addOnScrollListener(object : EndlessOnScrollListener(layoutManager) {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun setUpAdapter(){
        Items = ArrayList()
        layoutManager = LinearLayoutManager(this@SortByConnectionsAndDealers)
        sortRecyclerAdapter = SortByConnectionsDealersAdapter(Items, this@SortByConnectionsAndDealers,this,appUtils)
        sort_recycler.layoutManager = layoutManager
        sort_recycler.adapter = sortRecyclerAdapter
        (sort_recycler.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
        addOnRecyclerViewScrollListener()
    }
    private fun addOnDoneBtnListener() {
        done_btn.setOnClickListener {
            val intent = Intent()
            intent.putExtra("userId", "" + Items[checkIndex].companyData.userId)
            intent.putExtra("companyId", "" + Items[checkIndex].companyData.companyId)
            intent.putExtra("userName", "" + Items[checkIndex].companyData.firstName)
            setResult(RESULT_OK, intent)
            finish()
        }
    }

    private fun checkForData() {
        if (Items.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }


    private fun onScrollEnd() {
        if (shouldScrollCall) {
            shouldScrollCall = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())
        }
    }

    private fun getData() {


        api.getConnectionByPage(preference.getString(Constants.ACCESS_TOKEN),offset,"","",Constants.PAGE_LIMIT).enqueue(object : Callback<ConnectionResponse> {
            override fun onResponse(call: Call<ConnectionResponse>, response: Response<ConnectionResponse>) {

                if (response.isSuccessful) {
                    if(response.body().status == Constants.SUCCESS_STATUS){
                        val tempList = response.body().data.connectionsData


                        removeLoader()


                        loader.visibility = View.GONE



                        if (intent.extras != null && intent.getStringExtra("selected_connection") != null) {
                            for (i in tempList.indices) {
                                if (tempList[i].companyData != null && tempList[i].companyData.userId == intent.getStringExtra("selected_connection")) {
                                    tempList[i].isItemCheck = true
                                    checkIndex = Items.size + i
                                }
                            }
                        }

                        val oldSize = Items.size


                        Items.addAll(tempList)

                        if (tempList.size >= Constants.PAGE_LIMIT) {
                            Items.add(ConnectionsDataModel(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }


                        sortRecyclerAdapter!!.notifyItemRangeInserted(oldSize, Items.size)

                        checkForData()
                    }else{
                        onResponseFailure()
                    }
                }else{
                    onResponseFailure()
                }
            }

            override fun onFailure(call: Call<ConnectionResponse>, t: Throwable) {
                onResponseFailure()
            }
        })
    }

    private fun removeLoader() {
        for (i in Items.indices.reversed()) {
            if (Items[i].type == Constants.LOADER_VIEW) {
                Items.removeAt(i)
                sortRecyclerAdapter!!.notifyItemRemoved(i)
                break
            }
        }
    }

    override fun act(position: Int) {
        if (Items.get(position).getCompanyData() == null) return

        Items.get(position).isItemCheck = !Items.get(position).isItemCheck
        sortRecyclerAdapter!!.notifyItemChanged(position)

        if (checkIndex != -1 && checkIndex != position && Items.size > checkIndex) {
            Items[checkIndex].isItemCheck = false
            sortRecyclerAdapter!!.notifyItemChanged(checkIndex)
        }


        checkIndex = position
    }

}
