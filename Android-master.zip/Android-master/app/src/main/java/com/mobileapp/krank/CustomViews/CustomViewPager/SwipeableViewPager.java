package com.mobileapp.krank.CustomViews.CustomViewPager;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;


public class SwipeableViewPager extends ViewPager {


    private boolean swipeable;


    public SwipeableViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    public SwipeableViewPager(@NonNull Context context) {
        super(context);

    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        return swipeable ?
                super.onInterceptTouchEvent(event) : false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return swipeable ?
                super.onTouchEvent(event) : false;
    }

    public boolean isSwipeable() {
        return swipeable;
    }

    public void setSwipeable(boolean swipeable) {
        this.swipeable = swipeable;
    }
}