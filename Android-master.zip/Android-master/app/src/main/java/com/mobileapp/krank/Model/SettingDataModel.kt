package com.mobileapp.krank.Model

import android.support.annotation.DrawableRes

data class SettingDataModel(val title : String?,
                            @DrawableRes
                            val icon : Int? = null,
                            val description : String? = null,
                            val type : Int,
                            var state : Boolean = false,
                            var isButtonEnable : Boolean = true){
    companion object{
        const val HEADER = 1
        const val ITEM_TOGGLE = 2
        const val ITEM_DELETE_BUTTON = 3
        const val ITEM_IMPORT_EXPORT = 4


        //buttons type
        const val IMPORT_BUTTON = 5
        const val EXPORT_BUTTON = 6
    }
}