package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ViewHolders.CommonViewHolder.ConnectionsListItemViewHolder

class SortByConnectionsDealersAdapter(private val items: List<ConnectionsDataModel>, internal var context: Context, internal var callBack: CallBackWithAdapterPosition, internal var appUtils: AppUtils) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v : View
        when(viewType){
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                return AppListItemLoader(v)
            }
            2->{
                v = LayoutInflater.from(parent.context).inflate(R.layout.sort_by_connection_dealer_item, parent, false)
                return ConnectionsListItemViewHolder(v,callBack)
            }
            else ->{
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                return AppListItemLoader(v)
            }
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]


        if (item.type == Constants.ITEM_VIEW) {
            setItemView(holder as ConnectionsListItemViewHolder, item)
        }

    }


    override fun getItemViewType(position: Int): Int {
        when (items[position].type) {
            Constants.LOADER_VIEW -> return 1
            Constants.ITEM_VIEW -> return 2
            else -> return 1
        }
    }
    private fun setItemView(holder: ConnectionsListItemViewHolder, item: ConnectionsDataModel) {
        if (item.isItemCheck) {
            holder.unCheckView.visibility = View.GONE
            holder.checkedView.visibility = View.VISIBLE
        } else {
            holder.unCheckView.visibility = View.VISIBLE
            holder.checkedView.visibility = View.GONE
        }


        if (item.companyData != null) {
            holder.people_name.text = item.companyData.firstName + " " + item.companyData.lastName

            holder.company_name_text_view.text = AppUtils.getCompanyAndDesignation(item.companyData.companyName, item.companyData.jobTitle)


            holder.profile_image_view.setImageURI("" +  item.companyData.userProfilePic)

        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

}






