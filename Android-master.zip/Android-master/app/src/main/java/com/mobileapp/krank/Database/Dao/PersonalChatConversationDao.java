package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.paging.DataSource;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.mobileapp.krank.ResponseModels.DataModel.ChatConversationListDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConversationDetail;

import java.util.List;
@Dao
public interface PersonalChatConversationDao {


    /*@Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId  order by timeStamp desc")
    LiveData<List<ConversationDetail>> getAllRecords(String conId);*/

    @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId  order by timeStamp desc")
   // @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId  order by mid desc")
    LiveData<List<ConversationDetail>> getAllRecords(String conId);


    @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId order by timeStamp desc")
        // @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId  order by mid desc")
    List<ConversationDetail> getAllRecordsTest(String conId);



    //testing
    @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId order by timeStamp desc")
        // @Query("SELECT * from personal_chat_conversation_table WHERE conversation_id=:conId  order by mid desc")
    DataSource.Factory<Integer, ConversationDetail> getAllRecordsTest2(String conId);
    //testing

    @Query("SELECT * from personal_chat_conversation_table where conversation_id=:conId AND sid < :msgId order by timeStamp desc")
    List<ConversationDetail> getPreviousMsgsById(String conId,String msgId);

    @Query("SELECT * from personal_chat_conversation_table where sid > :msgId order by timeStamp desc")
    LiveData<List<ConversationDetail>> getNewMsgsById(String msgId);

    @Insert
    long insert(ConversationDetail conversationDetail);

    @Query("DELETE FROM personal_chat_conversation_table")
    void deleteAll();

    @Query("SELECT * from personal_chat_conversation_table where conversation_id=:conId AND msgStatus=0")
    List<ConversationDetail> getAllUnSentMsgs(String conId);


    @Query("DELETE FROM personal_chat_conversation_table where mid=:mId")
    void deleteByMid(long mId);

    @Query("DELETE FROM personal_chat_conversation_table where conversation_id=:conv_id AND msgStatus=2")
   // @Query("DELETE FROM personal_chat_conversation_table where conversation_id=:conv_id")
   // @Query("DELETE FROM personal_chat_conversation_table where conversation_id=:conv_id")
    void deleteByConvId(String conv_id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<ConversationDetail> conversationDetails);

    @Query("select sid from personal_chat_conversation_table WHERE conversation_id=:conId and sid is not null order by sid desc limit 1")
    String getLatestMsgId(String conId);

    @Query("select sid from personal_chat_conversation_table WHERE conversation_id=:conId and sid is not null order by sid asc limit 1")
    String getFirstMsgId(String conId);

    @Query("select timeStamp from personal_chat_conversation_table WHERE conversation_id=:conId  order by timeStamp desc limit 1")
    long getLastMsgTime(String conId);

    @Query("select mid from personal_chat_conversation_table WHERE conversation_id=:conId  order by timeStamp desc limit 1")
    int getLatestMsgMId(String conId);


    @Query("update personal_chat_conversation_table SET  sid=:id, msgStatus=:status WHERE mid=:mid AND conversation_id=:convId")
    void updateMsg(String convId,long mid,String id,int status);

    @Query("update personal_chat_conversation_table SET  msgStatus=:status WHERE mid=:mid AND conversation_id=:convId")
    void updateMsg(String convId,long mid,int status);

    @Query("update personal_chat_conversation_table SET  sid=:id, reply=:reply, sender_id=:sender_id, ip=:ip, time=:time, conversation_id=:conversation_id, is_read=:is_read, type=:type,msgStatus=:status WHERE mid=:mid AND conversation_id=:convId")
    void updateMsgByMid(String convId,long mid,String id,String reply,String sender_id,String ip,String time,String conversation_id,String is_read,String type,int status);

    @Query("update personal_chat_conversation_table SET msgStatus=:msgStatus WHERE mid=:mid AND conversation_id=:convId")
    void updateStatusMsgByMid(String convId,long mid,int msgStatus);


    @Query("SELECT * from personal_chat_conversation_table where conversation_id=:conId AND sid > :msgId order by timeStamp desc")
    List<ConversationDetail> getMsgsByLatestId(String conId,long msgId);

    @Query("update personal_chat_conversation_table SET sender_name='', senderImg='', sid=:id, reply=:reply, sender_id=:sender_id, ip=:ip, time=:time, conversation_id=:conversation_id, is_read=:is_read, type=:type, sentByme='', sentTime='',msgId='', thumb='', file='', file_type='', conStatus='',  file_name='', file_thumb='', file_path='', file_ext='', user_slug='', company_slug='', online='', company_id='', package_id='', email_address='', vcard_id='', firstName='', lastName='', profilePic='', designation='', company_profile_pic='', companyName='', country='', city='', user_url='', companyUrl='' WHERE mid=:mid")
    void updateMsgByMidForVCard(long mid,String id,String reply,String sender_id,String ip,String time,String conversation_id,String is_read,String type);


}
