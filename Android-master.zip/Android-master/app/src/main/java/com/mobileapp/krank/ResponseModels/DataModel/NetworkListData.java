
package com.mobileapp.krank.ResponseModels.DataModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NetworkListData {

    @SerializedName("networkCount")
    @Expose
    private String networkCount;


    @SerializedName("reminderCount")
    @Expose
    private int reminderCount;


    @SerializedName("network_list")
    @Expose
    private List<NetworkList> networkList = null;

    public String getNetworkCount() {
        return networkCount;
    }

    public void setNetworkCount(String networkCount) {
        this.networkCount = networkCount;
    }

    public List<NetworkList> getNetworkList() {
        return networkList;
    }

    public void setNetworkList(List<NetworkList> networkList) {
        this.networkList = networkList;
    }


    public int getReminderCount() {
        return reminderCount;
    }

    public void setReminderCount(int reminderCount) {
        this.reminderCount = reminderCount;
    }
}
