package com.mobileapp.krank.ResponseModels.DataModel;


import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.text.SpannableStringBuilder;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.CallBacks.FeedCustomButtonCallBack;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.CallBacks.CustomLikeCallBack;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CallBacks.FeedPostClick;
import com.mobileapp.krank.CallBacks.LikeButtonCallBack;
import com.mobileapp.krank.CallBacks.ShareButtonCallBack;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DateTimeUtils;
import com.mobileapp.krank.ResponseModels.FeedListingOwnerModel;

import java.util.Date;


@Entity(tableName = "news_feed_table")
public class NewsFeedArray implements Parcelable  {


    /*
    * States of Verify phone Number
    */
    @Ignore
    public static final int VERIFIED =1;
    @Ignore
    public static final int NOT_VERIFIED =0;
    @Ignore
    public static final int VERIFICATION_FAILED =2;
    @Ignore
    public static final int UNDER_VERIFICATION =3;
    @Ignore
    public static final int VERIFICATION_TIMEOUT =4;
    @Ignore
    public static final int ALREADY_IN_USE =5;
    /*
     * States of Verify phone Number
    */


    /*phoneCode fields*/
    @Ignore
    private boolean isViewVisible;

    @Ignore
    private String phoneCode;

    @Ignore
    private String phoneCodeReceived;


    @Ignore
    private int phoneNumberVerificationState;

    @Ignore
    private String phoneNumber;

    /*phoneCode fields*/



    /**
     * Custom Call Back Listeners
     */

    @Ignore
    private CustomLikeCallBack likeCallBack;



    @Ignore
    CallBackWithAdapterPosition callBackWithAdapterPosition;

    @Ignore
    private FeedCustomButtonCallBack commentClick;


    @Ignore
    private CustomCallBack updateCommentCountForImageOverlay;


    /**
     * Custom Call Back Listeners
     */


    /**
     * Attributed Text
     */
    @Ignore
    private SpannableStringBuilder headerSpannableString;

    @Ignore
    private SpannableStringBuilder checkInAddress;


    @Ignore
    private SpannableStringBuilder dealerPostString;

    /**
     * Attributed Text
     */

    @ColumnInfo(name = "postType")
    private int postType;

    @ColumnInfo(name = "noNewsFeedMsg")
    private String noNewsFeedMsg;

    @SerializedName("user_slug")
    @Expose
    @ColumnInfo(name = "user_slug")
    private String user_slug;

    @SerializedName("company_slug")
    @Expose
    @ColumnInfo(name = "company_slug")
    private String company_slug;

    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "id")
    @PrimaryKey
    @NonNull
    private int id;

    @SerializedName("title")
    @Expose
    @ColumnInfo(name = "title")
    private String title;

    @SerializedName("description")
    @Expose
    @ColumnInfo(name = "description")
    private String description;

    @SerializedName("is_company_news")
    @Expose
    @ColumnInfo(name = "is_company_news")
    private int is_company_news;

    @SerializedName("asset")
    @Expose
    @ColumnInfo(name = "asset")
    private String asset;

    @SerializedName("post_type")
    @Expose
    @ColumnInfo(name = "post_type")
    private int post_type;

    @SerializedName("user_id")
    @Expose
    @ColumnInfo(name = "user_id")
    private int user_id;

    @SerializedName("parent_id")
    @Expose
    @ColumnInfo(name = "parent_id")
    private String parent_id;

    @SerializedName("status")
    @Expose
    @ColumnInfo(name = "status")
    private int status;


    @SerializedName("created_date")
    @Expose
    @ColumnInfo(name = "created_date")
    private String created_date;


    @SerializedName("modified_date")
    @Expose
    @ColumnInfo(name = "modified_date")
    private String  modified_date;

    @SerializedName("privacy_id")
    @Expose
    @ColumnInfo(name = "privacy_id")
    private int  privacy_id;

    @SerializedName("c_id")
    @Expose
    @ColumnInfo(name = "c_id")
    private int  c_id;

    @SerializedName("post_hash")
    @Expose
    @ColumnInfo(name = "post_hash")
    private String  post_hash;

    @SerializedName("post_share_type")
    @Expose
    @ColumnInfo(name = "post_share_type")
    private int post_share_type;


    @SerializedName("post_from")
    @Expose
    @ColumnInfo(name = "post_from")
    private String post_from;

    @SerializedName("post_track_id")
    @Expose
    @ColumnInfo(name = "post_track_id")
    private int post_track_id;

    @SerializedName("company_id")
    @Expose
    @ColumnInfo(name = "company_id")
    private int company_id;


    @SerializedName("company_name")
    @Expose
    @ColumnInfo(name = "company_name")
    private String company_name;

    @SerializedName("profile_pic")
    @Expose
    @ColumnInfo(name = "profile_pic")
    private String profile_pic;


    @SerializedName("email_address")
    @Expose
    @ColumnInfo(name = "email_address")
    private String email_address;


    @SerializedName("first_name")
    @Expose
    @ColumnInfo(name = "first_name")
    private String first_name;

    @SerializedName("last_name")
    @Expose
    @ColumnInfo(name = "last_name")
    private String last_name;

    @SerializedName("designation")
    @Expose
    @ColumnInfo(name = "designation")
    private String designation;


    @SerializedName("user_url")
    @Expose
    @ColumnInfo(name = "user_url")
    private String user_url;


    @SerializedName("company_url")
    @Expose
    @ColumnInfo(name = "company_url")
    private String company_url;


    @SerializedName("c_url")
    @Expose
    @ColumnInfo(name = "c_url")
    private String c_url;

    @SerializedName("isAutoPost")
    @Expose
    @ColumnInfo(name = "isAutoPost")
    private int isAutoPost;

    @SerializedName("is_post_admin")
    @Expose
    @ColumnInfo(name = "is_post_admin")
    private int is_post_admin;

    @SerializedName("share_url")
    @Expose
    @ColumnInfo(name = "share_url")
    private String shareUrl;

    @SerializedName("post_share_text")
    @Expose
    @ColumnInfo(name = "post_share_text")
    private String postShareText;

    @SerializedName("feed_type")
    @Expose
    @ColumnInfo(name = "feed_type")
    private String feedType;

    @SerializedName("auto_post_html")
    @Expose
    @Embedded
    private AutoPostHtml autoPostHtml;

    @SerializedName("owner")
    @Expose
    @Embedded
    private FeedListingOwnerModel owner;


    @SerializedName("is_html_post")
    @Expose
    @ColumnInfo(name = "is_html_post")
    private Integer isHtmlPost;

    @SerializedName("html_parse")
    @Expose
    @Embedded
    private HtmlParse htmlParse;

    @SerializedName("comment_count")
    @Expose
    @ColumnInfo(name = "comment_count")
    private int comment_count;

    @SerializedName("like_count")
    @Expose
    @ColumnInfo(name = "like_count")
    private int like_count;

    @SerializedName("is_like")
    @Expose
    @ColumnInfo(name = "is_like")
    private int is_like;

    @SerializedName("social_network")
    @Expose
    @ColumnInfo(name = "social_network")
    private Integer socialNetwork;

    @SerializedName("image_width")
    @Expose
    @ColumnInfo(name = "image_width")
    private int image_width;

    @SerializedName("image_height")
    @Expose
    @ColumnInfo(name = "image_height")
    private int image_height;

    @ColumnInfo(name = "last_num")
    private String last_num;

    @SerializedName("created_date_original")
    @ColumnInfo(name = "created_date_original")
    private String created_date_original;

    @SerializedName("is_accessable")
    @ColumnInfo(name = "is_accessable")
    private int is_accessable;

    /*for check in*/
    @ColumnInfo(name = "time_difference")
    private long time_difference;
    /*for check in*/

    protected NewsFeedArray(Parcel in) {
        postType = in.readInt();
        noNewsFeedMsg = in.readString();
        user_slug = in.readString();
        company_slug = in.readString();
        id = in.readInt();
        title = in.readString();
        description = in.readString();
        is_company_news = in.readInt();
        asset = in.readString();
        post_type = in.readInt();
        user_id = in.readInt();
        parent_id = in.readString();
        status = in.readInt();
        created_date = in.readString();
        modified_date = in.readString();
        privacy_id = in.readInt();
        c_id = in.readInt();
        post_hash = in.readString();
        post_share_type = in.readInt();
        post_from = in.readString();
        post_track_id = in.readInt();
        company_id = in.readInt();
        company_name = in.readString();
        profile_pic = in.readString();
        email_address = in.readString();
        first_name = in.readString();
        last_name = in.readString();
        designation = in.readString();
        user_url = in.readString();
        company_url = in.readString();
        c_url = in.readString();
        isAutoPost = in.readInt();
        is_post_admin = in.readInt();
        shareUrl = in.readString();
        postShareText = in.readString();
        feedType = in.readString();
        autoPostHtml = in.readParcelable(AutoPostHtml.class.getClassLoader());
        owner = in.readParcelable(FeedListingOwnerModel.class.getClassLoader());
        if (in.readByte() == 0) {
            isHtmlPost = null;
        } else {
            isHtmlPost = in.readInt();
        }
        htmlParse = in.readParcelable(HtmlParse.class.getClassLoader());
        comment_count = in.readInt();
        like_count = in.readInt();
        is_like = in.readInt();
        if (in.readByte() == 0) {
            socialNetwork = null;
        } else {
            socialNetwork = in.readInt();
        }
        image_width = in.readInt();
        image_height = in.readInt();
        last_num = in.readString();
        created_date_original = in.readString();
        time_difference = in.readLong();
        is_accessable = in.readInt();
    }

    public static final Creator<NewsFeedArray> CREATOR = new Creator<NewsFeedArray>() {
        @Override
        public NewsFeedArray createFromParcel(Parcel in) {
            return new NewsFeedArray(in);
        }

        @Override
        public NewsFeedArray[] newArray(int size) {
            return new NewsFeedArray[size];
        }
    };

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getPostShareText() {
        return postShareText;
    }

    public void setPostShareText(String postShareText) {
        this.postShareText = postShareText;
    }

    public String getFeedType() {
        return feedType;
    }

    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }

    public AutoPostHtml getAutoPostHtml() {
        return autoPostHtml;
    }

    public void setAutoPostHtml(AutoPostHtml autoPostHtml) {
        this.autoPostHtml = autoPostHtml;
    }

    public Integer getIsHtmlPost() {
        return isHtmlPost;
    }

    public void setIsHtmlPost(Integer isHtmlPost) {
        this.isHtmlPost = isHtmlPost;
    }

    public HtmlParse getHtmlParse() {
        return htmlParse;
    }

    public void setHtmlParse(HtmlParse htmlParse) {
        this.htmlParse = htmlParse;
    }

    public Integer getSocialNetwork() {
        return socialNetwork;
    }

    public void setSocialNetwork(Integer socialNetwork) {
        this.socialNetwork = socialNetwork;
    }

    public String getPost_hash() {
        return post_hash;
    }

    public void setPost_hash(String post_hash) {
        this.post_hash = post_hash;
    }

    public int getPost_share_type() {
        return post_share_type;
    }

    public void setPost_share_type(int post_share_type) {
        this.post_share_type = post_share_type;
    }

    public String getPost_from() {
        return post_from;
    }

    public void setPost_from(String post_from) {
        this.post_from = post_from;
    }

    public int getPost_track_id() {
        return post_track_id;
    }

    public void setPost_track_id(int post_track_id) {
        this.post_track_id = post_track_id;
    }

    public int getCompany_id() {
        return company_id;
    }

    public void setCompany_id(int company_id) {
        this.company_id = company_id;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(String profile_pic) {
        this.profile_pic = profile_pic;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getUser_url() {
        return user_url;
    }

    public void setUser_url(String user_url) {
        this.user_url = user_url;
    }

    public String getCompany_url() {
        return company_url;
    }

    public void setCompany_url(String company_url) {
        this.company_url = company_url;
    }

    public String getC_url() {
        return c_url;
    }

    public void setC_url(String c_url) {
        this.c_url = c_url;
    }

    public int getIsAutoPost() {
        return isAutoPost;
    }

    public void setIsAutoPost(int isAutoPost) {
        this.isAutoPost = isAutoPost;
    }

    public int getIs_post_admin() {
        return is_post_admin;
    }

    public void setIs_post_admin(int is_post_admin) {
        this.is_post_admin = is_post_admin;
    }

    public int getComment_count() {
        return comment_count;
    }

    public void setComment_count(int comment_count) {
        this.comment_count = comment_count;
    }

    public int getLike_count() {
        return like_count;
    }

    public void setLike_count(int like_count) {
        this.like_count = like_count;
    }

    public int getIs_like() {
        return is_like;
    }

    public void setIs_like(int is_like) {
        this.is_like = is_like;
    }


    @Ignore
    public NewsFeedArray(int typeOfPost , String noNewsFeedMsg){
        this.postType = typeOfPost;
        this.noNewsFeedMsg=noNewsFeedMsg;
    }

    @Ignore
    public NewsFeedArray(int postType){
        this.postType=postType;
    }

    public NewsFeedArray(){

    }


    public FeedCustomButtonCallBack getCommentClick() {
        return commentClick;
    }

    public void setCommentClick(FeedCustomButtonCallBack commentClick) {
        this.commentClick = commentClick;
    }

    public int getPostType() {
        return postType;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public String getUser_slug() {
        return user_slug;
    }

    public void setUser_slug(String user_slug) {
        this.user_slug = user_slug;
    }

    public String getCompany_slug() {
        return company_slug;
    }

    public void setCompany_slug(String company_slug) {
        this.company_slug = company_slug;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIs_company_news() {
        return is_company_news;
    }

    public void setIs_company_news(int is_company_news) {
        this.is_company_news = is_company_news;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public int getPost_type() {
        return post_type;
    }

    public void setPost_type(int post_type) {
        this.post_type = post_type;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getParent_id() {
        return parent_id;
    }

    public void setParent_id(String parent_id) {
        this.parent_id = parent_id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getModified_date() {
        return modified_date;
    }

    public void setModified_date(String modified_date) {
        this.modified_date = modified_date;
    }

    public int getPrivacy_id() {
        return privacy_id;
    }

    public void setPrivacy_id(int privacy_id) {
        this.privacy_id = privacy_id;
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public int getImage_width() {
        return image_width;
    }

    public void setImage_width(int image_width) {
        this.image_width = image_width;
    }

    public int getImage_height() {
        return image_height;
    }

    public void setImage_height(int image_height) {
        this.image_height = image_height;
    }


    public String getNoNewsFeedMsg() {
        return noNewsFeedMsg;
    }

    public void setNoNewsFeedMsg(String noNewsFeedMsg) {
        this.noNewsFeedMsg = noNewsFeedMsg;
    }


    public String getLast_num() {
        return last_num;
    }

    public void setLast_num(String last_num) {
        this.last_num = last_num;
    }


    public CustomLikeCallBack getLikeCallBack() {
        return likeCallBack;
    }

    public void setLikeCallBack(CustomLikeCallBack likeCallBack) {
        this.likeCallBack = likeCallBack;
    }



    public CustomCallBack getUpdateCommentCountForImageOverlay() {
        return updateCommentCountForImageOverlay;
    }

    public void setUpdateCommentCountForImageOverlay(CustomCallBack updateCommentCountForImageOverlay) {
        this.updateCommentCountForImageOverlay = updateCommentCountForImageOverlay;
    }



    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(postType);
        parcel.writeString(noNewsFeedMsg);
        parcel.writeString(user_slug);
        parcel.writeString(company_slug);
        parcel.writeInt(id);
        parcel.writeString(title);
        parcel.writeString(description);
        parcel.writeInt(is_company_news);
        parcel.writeString(asset);
        parcel.writeInt(post_type);
        parcel.writeInt(user_id);
        parcel.writeString(parent_id);
        parcel.writeInt(status);
        parcel.writeString(created_date);
        parcel.writeString(modified_date);
        parcel.writeInt(privacy_id);
        parcel.writeInt(c_id);
        parcel.writeString(post_hash);
        parcel.writeInt(post_share_type);
        parcel.writeString(post_from);
        parcel.writeInt(post_track_id);
        parcel.writeInt(company_id);
        parcel.writeString(company_name);
        parcel.writeString(profile_pic);
        parcel.writeString(email_address);
        parcel.writeString(first_name);
        parcel.writeString(last_name);
        parcel.writeString(designation);
        parcel.writeString(user_url);
        parcel.writeString(company_url);
        parcel.writeString(c_url);
        parcel.writeInt(isAutoPost);
        parcel.writeInt(is_post_admin);
        parcel.writeString(shareUrl);
        parcel.writeString(postShareText);
        parcel.writeString(feedType);
        parcel.writeParcelable(autoPostHtml, i);
        parcel.writeParcelable(owner, i);
        if (isHtmlPost == null) {
            parcel.writeByte((byte) 0);
        } else {
            parcel.writeByte((byte) 1);
            parcel.writeInt(isHtmlPost);
        }
        parcel.writeParcelable(htmlParse, i);
        parcel.writeInt(comment_count);
        parcel.writeInt(like_count);
        parcel.writeInt(is_like);
        if (socialNetwork == null) {
            parcel.writeByte((byte) 0);
        } else {
            parcel.writeByte((byte) 1);
            parcel.writeInt(socialNetwork);
        }
        parcel.writeInt(image_width);
        parcel.writeInt(image_height);
        parcel.writeString(last_num);
        parcel.writeString(created_date_original);
        parcel.writeLong(time_difference);
        parcel.writeInt(is_accessable);
    }

    public CallBackWithAdapterPosition getCallBackWithAdapterPosition() {
        return callBackWithAdapterPosition;
    }

    public void setCallBackWithAdapterPosition(CallBackWithAdapterPosition callBackWithAdapterPosition) {
        this.callBackWithAdapterPosition = callBackWithAdapterPosition;
    }

    public String getCreated_date_original() {
        return created_date_original;
    }

    public void setCreated_date_original(String created_date_original) {
        this.created_date_original = created_date_original;
    }

    public long getTime_difference() {
        return time_difference;
    }

    public void setTime_difference(long time_difference) {
        this.time_difference = time_difference;
    }


    public SpannableStringBuilder getHeaderSpannableString() {
        return headerSpannableString;
    }

    public void setHeaderSpannableString(SpannableStringBuilder headerSpannableString) {
        this.headerSpannableString = headerSpannableString;
    }

    public SpannableStringBuilder getCheckInAddress() {
        return checkInAddress;
    }

    public void setCheckInAddress(SpannableStringBuilder checkInAddress) {
        this.checkInAddress = checkInAddress;
    }


    public SpannableStringBuilder getDealerPostString() {
        return dealerPostString;
    }

    public void setDealerPostString(SpannableStringBuilder dealerPostString) {
        this.dealerPostString = dealerPostString;
    }

    /*
     * phone Code view
     */
    public boolean isViewVisible() {
        return isViewVisible;
    }

    public void setViewVisible(boolean viewVisible) {
        isViewVisible = viewVisible;
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    public String getPhoneCodeReceived() {
        return phoneCodeReceived;
    }

    public void setPhoneCodeReceived(String phoneCodeReceived) {
        this.phoneCodeReceived = phoneCodeReceived;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getPhoneNumberVerificationState() {
        return phoneNumberVerificationState;
    }

    public void setPhoneNumberVerificationState(int phoneNumberVerificationState) {
        this.phoneNumberVerificationState = phoneNumberVerificationState;
    }

    /**
     * phone Code view
     */


    /**
     *
     * Feed View Types
     * */
    public void getNewsFeedType() {

        if (getPrivacy_id() == 10) {
            setPostType(Constants.KRANK_POST);
        } else if (getIsAutoPost() == 1 && getFeedType() != null && getFeedType().equals("auto_post_network")) {
            // c_id === 0 || feedType === auto_post_network || feedType === auto_post_dealer
            setPostType(Constants.NETWORK_POST);
        } else if (getIsAutoPost() == 1 && getFeedType() != null && getFeedType().equals("auto_post_dealer")) {
            setPostType(Constants.DEALER_POST);
        } else if (getIsHtmlPost() == 1 && ((getFeedType() != null && getFeedType().equals("listing")) || getPost_from().equals("Listing"))) {
            // feed pageToRedirect === listing  && getFeedType() != null       remove
            setPostType(Constants.LISTING_POST);

        } else if (getIsHtmlPost() == 1 && (getPost_from().equals("Article") || (getFeedType() != null && getFeedType().equals("article")))) {
            // feed pageToRedirect === article  && getFeedType() != null      remove
            setPostType(Constants.ARTICLE_POST);
        } else if (getIsHtmlPost() == 1 && (getPost_from().equals("Auction") || (getFeedType() != null && getFeedType().equals("auction")))) {
            // feed pageToRedirect === article  && getFeedType() != null      remove
            setPostType(Constants.AUCTION_POST);
        } else if (getFeedType() == null && getIsHtmlPost() == 1 && getHtmlParse().getVideoUrl().contains("https://www.youtube.com")) {
            setPostType(Constants.YOUTUBE_VIDEO);
        } else if (getFeedType() == null && getIsHtmlPost() == 1 && getHtmlParse().getVideoUrl().contains("https://player.vimeo.com")) {
            setPostType(Constants.VIMEO_VIDEO);
        } else if (getFeedType() == null && getIsHtmlPost() == 1) {
            // Link Post
            setPostType(Constants.LINKED_POST);
        } else if (getPost_type() == 11) {
            setPostType(Constants.CHECK_IN);
            try {
                setTime_difference(DateTimeUtils.getTimeDifference(getCreated_date_original()));
            } catch (Exception ex) {

            }
        } else if ((getAsset() != null && getAsset().equals("")) && getPost_type() == 0) {
            setPostType(Constants.TEXT_POST);
        } else if (getPost_type() == 1) {
            setPostType(Constants.IMAGE_POST);
        } else {
            setPostType(Constants.OTHER_POST);
        }
    }

    public FeedListingOwnerModel getOwner() {
        return owner;
    }

    public void setOwner(FeedListingOwnerModel owner) {
        this.owner = owner;
    }

    public int getIs_accessable() {
        return is_accessable;
    }

    public void setIs_accessable(int is_accessable) {
        this.is_accessable = is_accessable;
    }

    public boolean showCommentBox(){
        return is_accessable == 1;
    }

    public boolean isPostOwner(){
        return getOwner()!=null && getOwner().getOwn().toLowerCase().equals("no");
    }
}