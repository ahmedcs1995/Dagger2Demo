package com.mobileapp.krank.Model.Enums

enum class CardsListenerType {
    DELETE,
    SEND_MESSAGE,
    SEND_CONTACT_CARD,
    VIEW_LISTING,
    VIEW_PROFILE,
    COMPANY_IMG,
    VIEW_EMPLOYEES,
    VIEW_YOUR_CONNECTIONS,
    PRIVATE_CONNECTION,
}