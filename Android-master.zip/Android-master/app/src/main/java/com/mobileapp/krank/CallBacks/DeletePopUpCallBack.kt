package com.mobileapp.krank.CallBacks

import android.widget.PopupMenu

interface DeletePopUpCallBack{
    fun act(view : PopupMenu)
}