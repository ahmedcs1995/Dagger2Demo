package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Chat.GroupChatPakage.NewGroupMessage;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;

import java.util.List;

public class NewGroupMsgChipAdapter extends RecyclerView.Adapter<NewGroupMsgChipAdapter.ViewHolder>  {
    private List<ConnectionsDataModel> items;
    NewGroupMessage newGroupMessage;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View cancelBtn;
        TextView name;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            cancelBtn=itemView.findViewById(R.id.cancel_btn);
            name=itemView.findViewById(R.id.name);
        }
    }

    public NewGroupMsgChipAdapter(List<ConnectionsDataModel> items, NewGroupMessage newGroupMessage) {
        this.items = items;
        this.newGroupMessage = newGroupMessage;
    }



    @Override
    public NewGroupMsgChipAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chip_view_item, parent, false);
        return new NewGroupMsgChipAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final NewGroupMsgChipAdapter.ViewHolder holder, final int position) {
        final ConnectionsDataModel item = items.get(position);

        holder.name.setText("" + item.getCompanyData().getFirstName()  + " " + item.getCompanyData().getLastName());



        holder.cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                items.remove(position);
                uncheckConnection(item.getCompanyData().getUserId());
                notifyDataSetChanged();
            }
        });
    }



    @Override
    public int getItemCount() {
        return items.size();
    }

   private void uncheckConnection(String id){
        for(int i = 0; i < newGroupMessage.getPeopleItems().size(); i++){
            if(newGroupMessage.getPeopleItems().get(i).getCompanyData().getUserId().equals(id)){
                newGroupMessage.getPeopleItems().get(i).setItemCheck(false);
                newGroupMessage.getPeopleRecyclerAdapter().notifyDataSetChanged();
                break;
            }
        }
   }
}



