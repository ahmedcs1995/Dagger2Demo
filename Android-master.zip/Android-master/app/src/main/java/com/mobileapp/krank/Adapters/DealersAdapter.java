package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.DealersCard;
import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.HomePageTabs.MyDealers;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Yaseen on 26/04/2018.
 */


public class DealersAdapter extends RecyclerView.Adapter<DealersAdapter.ViewHolder> {
    private List<NetworkDealersData> items;
    MyDealers myDealers;
    Gson gson;


    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;

        SimpleDraweeView network_dealers_profile_image_view;
        TextView company_name_text_view;
        TextView country_and_city_text_view;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            network_dealers_profile_image_view = itemView.findViewById(R.id.network_dealers_profile_image_view);
            company_name_text_view = itemView.findViewById(R.id.company_name_text_view);
            country_and_city_text_view = itemView.findViewById(R.id.country_and_city_text_view);


            item.setOnClickListener(view -> {
                CustomApplication app = (CustomApplication) myDealers.getActivity().getApplicationContext();
                app.dealerItems = items;


                Intent intent = new Intent(myDealers.getContext(), DealersCard.class);
                intent.putExtra(Constants.INTENT_KEY, item.getId());
                intent.putExtra("NetworkDealersList", gson.toJson(items));
                intent.putExtra("currentItem", getAdapterPosition());
                myDealers.startActivityForResult(intent, MyDealers.CARDS_ACTIVITY_CODE);
                myDealers.getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            });
        }
    }

    public DealersAdapter(List<NetworkDealersData> items, MyDealers myDealers) {
        this.items = items;
        this.myDealers = myDealers;
        gson = CustomGson.getInstance();
    }



    @Override
    public DealersAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_dealers_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final DealersAdapter.ViewHolder holder, int position) {
        final NetworkDealersData item = items.get(position);
        String country = item.getCountryName() != null ? item.getCountryName() : "N/A";
        String city = item.getCityName() != null ? item.getCityName() : "N/A";

        holder.company_name_text_view.setText(item.getCompanyName());
        holder.country_and_city_text_view.setText(city + ", " + country);
      //  Glide.with(currentView.getContext()).load(Constants.BASE_IMG_URL + item.getProfilePic()).into(holder.network_dealers_profile_image_view);

        holder.network_dealers_profile_image_view.setImageURI(Uri.parse("" + Constants.BASE_IMG_URL + item.getProfilePic()));




    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}





