package com.mobileapp.krank.Functions;
import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.View;

import com.google.gson.Gson;
import com.mobileapp.krank.ViewHolders.MarketPlaceViewHolder.MarketPlaceViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

public class MarketPlaceFunctions {


    AppUtils appUtils;
    Context context;

    Fragment fragment;


    Gson gson;
    public SaveInSharedPreference preference;
    String type;
    String sub_type;
    ServiceManager serviceManager;

    RecyclerView.Adapter adapter;



    public MarketPlaceFunctions(String type, String sub_type, Fragment fragment, RecyclerView.Adapter adapter) {


        this.context = fragment.getContext();
        this.type = type;
        this.sub_type = sub_type;
        this.adapter = adapter;
        this.fragment = fragment;
        initialize();
    }
    public MarketPlaceFunctions( Fragment fragment, RecyclerView.Adapter adapter) {
        this.context = fragment.getContext();
        this.adapter = adapter;
        this.fragment = fragment;
        initialize();
    }
    private void initialize(){
        appUtils = AppUtils.getInstance();
        preference = new SaveInSharedPreference(context);
        serviceManager = ServiceManager.getInstance();
        this.gson = CustomGson.getInstance();
    }

    public void setPostView(@NonNull RecyclerView.ViewHolder holder, final int position, final ListingDataArray item) {

        final MarketPlaceViewHolder marketPlaceViewHolder = (MarketPlaceViewHolder) holder;
        //   final ListingModelForEnquiry listingModelForEnquiry = new ListingModelForEnquiry(item.getUserId(),item.getUserId(),item.getDealers(),item.getConStatus(),item.getNetStatus(),item.getAssignments());

        marketPlaceViewHolder.time_ago.setText("" + item.getCreatedDate());

        marketPlaceViewHolder.description.setText("" + Html.fromHtml(item.getDescription()));


        marketPlaceViewHolder.price.setText(item.getCurrency_code() + " " + item.getPrice_Privacy());
        marketPlaceViewHolder.listing_name.setText("" + item.getListingName());


       // Glide.with(context).load("" + item.getIMAGENAME()).apply(appUtils.getRequestOptions(context)).into(marketPlaceViewHolder.img);

        marketPlaceViewHolder.img.setImageURI(Uri.parse(item.getIMAGENAME()));

        //setProfileClickActionsForSaleListingAdapter(marketPlaceViewHolder.people_name, item);


        /*share btn privacy*/

        if (item.getListingPrivacy().equals(Constants.PUBLIC_LISTING)) {
            marketPlaceViewHolder.share_btn.setVisibility(View.VISIBLE);
        } else {
            marketPlaceViewHolder.share_btn.setVisibility(View.GONE);
        }

        /*share btn privacy*/


        /*marketPlaceViewHolder.item.setOnClickListener(view -> {
            updateList(item.getUserId());
            Intent intent = new Intent(context, ListingDetail.class);
            intent.putExtra("listing_id", item.getLid());
            intent.putExtra("listing_pg_name", item.getListingName());
            intent.putExtra("item_index", position);
            fragment.startActivityForResult(intent, Constants.LISTING_DETAIL_CODE);
        });*/
        if (item.getIsFav() == null) {
            marketPlaceViewHolder.fav_text.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor));
        } else {
            marketPlaceViewHolder.fav_text.setTextColor(ContextCompat.getColor(context, R.color.yellowColor));
        }

      /*  marketPlaceViewHolder.fav_btn.setOnClickListener(view -> {
            marketPlaceViewHolder.fav_btn.setEnabled(false);
            addToFavUnFav(item, marketPlaceViewHolder, position);
        });*/

       // marketPlaceViewHolder.share_btn.setOnClickListener(view -> openDialog(item));


        /*listing added by logged in user then hide the enquiry btn*/


        if (item.getUserId().equals(preference.getString(Constants.USER_ID))) {
            marketPlaceViewHolder.enquiry_btn.setVisibility(View.GONE);
        } else {
            marketPlaceViewHolder.enquiry_btn.setVisibility(View.VISIBLE);
        }

        /*listing added by logged in user then hide the enquiry btn*/



        /**
         * Market PLace Privacy
         *
         * */
        /*if (item.getDealers().size() > 0) {
            setCompanyView(marketPlaceViewHolder, item, true);
        }
        else if (item.getInMyNetwork().equals("1")  || (item.getListingPrivacy().equals("1") && item.getShow_name().equals("Yes")) || item.isPrivate()) {
            if(item.getAssignments().size() > 0){
                setCompanyView(marketPlaceViewHolder, item, false);
            }else{
                setUserView(marketPlaceViewHolder, item);
            }

        }  else {
            setBlankUserView(marketPlaceViewHolder);

        }*/

        switch (item.getTypeOfView()){
            case DEALER:
                setCompanyView(marketPlaceViewHolder, item, true);
                break;
            case COMPANY:
                setCompanyView(marketPlaceViewHolder, item, false);
                break;
            case USER:
                setUserView(marketPlaceViewHolder, item);
                break;
            case NONE:
                setBlankUserView(marketPlaceViewHolder);
                break;
        }

        /**
         * Market PLace Privacy
         *
         * */


    }
    private void setUserView(MarketPlaceViewHolder marketPlaceViewHolder, final ListingDataArray item) {
        marketPlaceViewHolder.people_name.setText("" + item.getFirstName() + " " + item.getLastName());
        marketPlaceViewHolder.black_user_view.setVisibility(View.GONE);
        marketPlaceViewHolder.user_detail_view.setVisibility(View.VISIBLE);
      //  Glide.with(context).load("" + item.getUProfilePic()).into(marketPlaceViewHolder.profile_image_view);
        marketPlaceViewHolder.profile_image_view.setImageURI(Uri.parse(item.getUProfilePic()));
        marketPlaceViewHolder.company_image_view.setVisibility(View.GONE);
        marketPlaceViewHolder.profile_image_view.setVisibility(View.VISIBLE);
        marketPlaceViewHolder.designation.setText(AppUtils.getCompanyAndDesignation(item.getCompanyName(), item.getDesignation()));

        marketPlaceViewHolder.people_name.setOnClickListener(view -> appUtils.gotoUserProfile(context, item.getUserId(), preference));


        marketPlaceViewHolder.profile_image_view.setOnClickListener(view -> {
            appUtils.gotoUserProfile(context, item.getUserId(), preference);
        });
    }
    private void setBlankUserView(MarketPlaceViewHolder marketPlaceViewHolder) {
        marketPlaceViewHolder.user_detail_view.setVisibility(View.GONE);
        marketPlaceViewHolder.black_user_view.setVisibility(View.VISIBLE);
    }
    private void setCompanyView(MarketPlaceViewHolder marketPlaceViewHolder, final ListingDataArray item, final boolean isDealer) {
        if (isDealer) {
            marketPlaceViewHolder.people_name.setText("" + item.getCompanyName() + " (DEALERS)");
        } else {
            marketPlaceViewHolder.people_name.setText("" + item.getCompanyName());
        }
        marketPlaceViewHolder.black_user_view.setVisibility(View.GONE);
        marketPlaceViewHolder.user_detail_view.setVisibility(View.VISIBLE);
       // Glide.with(context).load("" + item.getProfilePic()).into(marketPlaceViewHolder.company_image_view);
        marketPlaceViewHolder.company_image_view.setImageURI(Uri.parse(item.getProfilePic()));


        marketPlaceViewHolder.company_image_view.setVisibility(View.VISIBLE);
        marketPlaceViewHolder.profile_image_view.setVisibility(View.GONE);
        marketPlaceViewHolder.designation.setText(item.getCompCity() + "," + item.getCompCountry());

        marketPlaceViewHolder.people_name.setOnClickListener(view -> appUtils.gotoCompanyProfile(context, item.getCompanyId(), preference));

        marketPlaceViewHolder.company_image_view.setOnClickListener(view -> {
            appUtils.gotoCompanyProfile(context, item.getCompanyId(), preference);
        });

    }


}
