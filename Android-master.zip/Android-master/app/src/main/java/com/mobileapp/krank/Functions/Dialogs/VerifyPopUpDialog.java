package com.mobileapp.krank.Functions.Dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.mobileapp.krank.R;

public class VerifyPopUpDialog extends Dialog implements android.view.View.OnClickListener {


    public interface DialogClickListener{
        void onConfirmClick(VerifyPopUpDialog dialog);
        void onEditClick(VerifyPopUpDialog dialog);
    }
    public Context context;
    public Dialog dialog;
    View edit_btn, ok_btn;

    TextView phone_number;

    DialogClickListener listener;
    String number;


    public VerifyPopUpDialog(Context context, DialogClickListener listener) {
        super(context);
        this.context = context;
        this.listener = listener;

    }

    public void setListener(DialogClickListener listener) {
        this.listener = listener;
    }

    public VerifyPopUpDialog(Context context) {
        super(context);
        this.context = context;

    }
    public void setPhoneNumber(String number){
        this.number=number;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.phone_number_verify_dialog);

        //init views
        edit_btn = findViewById(R.id.edit_btn);
        ok_btn = findViewById(R.id.ok_btn);
        phone_number = findViewById(R.id.phone_number);


        //setting data
        if(number!=null){
            phone_number.setText(number);
        }

        //listeners
        edit_btn.setOnClickListener(this);
        ok_btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.edit_btn:
                if(listener!=null){
                    listener.onEditClick(VerifyPopUpDialog.this);
                }
                break;
            case R.id.ok_btn:
                if(listener!=null){
                    listener.onConfirmClick(VerifyPopUpDialog.this);
                }
                break;
            default:
                break;
        }
        dismiss();
    }
}