package com.mobileapp.krank.Adapters

import android.content.Context
import android.content.Intent
import android.os.Build
import android.support.v7.widget.RecyclerView
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.Activities.CompanyProfileView
import com.mobileapp.krank.Activities.DiscoverPeople
import com.mobileapp.krank.Activities.ListOfEmployeesAndConnections
import com.mobileapp.krank.Activities.UserProfileView
import com.mobileapp.krank.CallBacks.CustomCallBack
import com.mobileapp.krank.CustomViews.CustomFaView
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.launchActivity
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.ResponseModels.SentConnectionRequestResponse
import com.mobileapp.krank.Utils.ApiUtils
import com.mobileapp.krank.Utils.SaveInSharedPreference
import com.mobileapp.krank.Utils.ServiceManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SuggestedConnectionsHorizontalAdapter(private val items: MutableList<GetNetworkEmployeeData>?, internal var context: Context, val preference: SaveInSharedPreference, val servicesUtil : ServiceManager,private val removeCallBack:CustomCallBack) : RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    var appUtils = AppUtils.getInstance()
    var serviceManager = ServiceManager.getInstance()

    inner class SuggestedConnectionsCardsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        internal var user_img: SimpleDraweeView = itemView.findViewById(R.id.user_img)
        internal var company_img: SimpleDraweeView = itemView.findViewById(R.id.company_img)
        internal var user_name: TextView = itemView.findViewById(R.id.user_name)
        internal var company_name: TextView = itemView.findViewById(R.id.company_name)
        internal var country_city: TextView = itemView.findViewById(R.id.country_city)
        internal var no_of_co_workers_connected: TextView = itemView.findViewById(R.id.no_of_co_workers_connected)
        internal var icon: CustomFaView = itemView.findViewById(R.id.icon)
        internal var status_text: TextView = itemView.findViewById(R.id.status_text)
        internal var cancel_btn: View = itemView.findViewById(R.id.cancel_btn)
        internal var status_btn_container: View = itemView.findViewById(R.id.status_btn_container)

        init {
            cancel_btn.setOnClickListener {
                if(adapterPosition >= 0){
                    ApiUtils.excludeConnections(preference.getString(Constants.ACCESS_TOKEN),items!![adapterPosition].id,servicesUtil.api)
                    if(items.size == 2){
                        //call the listener
                        removeCallBack.act()
                    }
                    items.removeAt(adapterPosition)
                    notifyItemRemoved(adapterPosition)
                    notifyItemRangeChanged(adapterPosition, items.size)
                }
            }

            user_img.setOnClickListener {
                context.launchActivity<UserProfileView> {
                    putExtra(UserProfileView.INTENT_USER_ID, items!![adapterPosition].id)
                }
            }
            user_name.setOnClickListener {
                context.launchActivity<UserProfileView> {
                    putExtra(UserProfileView.INTENT_USER_ID, items!![adapterPosition].id)
                }
            }


            company_name.setOnClickListener {
                context.launchActivity<CompanyProfileView> {
                    putExtra(CompanyProfileView.INTENT_COMPANY_ID,items!![adapterPosition].company_id)
                }
            }
            company_img.setOnClickListener {
                context.launchActivity<CompanyProfileView> {
                    putExtra(CompanyProfileView.INTENT_COMPANY_ID,items!![adapterPosition].company_id)
                }
            }

            status_btn_container.setOnClickListener {
                if(adapterPosition < 0 || items?.get(adapterPosition)?.status == Constants.REQUEST_PENDING) return@setOnClickListener
                status_btn_container.isEnabled = false
                sendConnectionRequest(adapterPosition,status_btn_container)

            }
        }
    }

    inner class ManageViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView){
        private var view_all_btn: View = itemView.findViewById(R.id.view_all_btn)

        init {
            view_all_btn.setOnClickListener {
                val intent = Intent(context, DiscoverPeople::class.java)
                context.startActivity(intent)
            }
        }

    }

    private fun sendConnectionRequest(position: Int, status_btn_container: View){
        changeStatus(position,Constants.REQUEST_PENDING)

        serviceManager.api.sentConnectionRequest(preference.getString(Constants.ACCESS_TOKEN),items!![position].conId).enqueue(object : Callback<SentConnectionRequestResponse> {
            override fun onFailure(call: Call<SentConnectionRequestResponse>?, t: Throwable?) {
                showErrorToast()
                changeStatus(position,Constants.CONNECTION_NOT_CONNECTED)
                status_btn_container.isEnabled = true
            }

            override fun onResponse(call: Call<SentConnectionRequestResponse>?, response: Response<SentConnectionRequestResponse>?) {
                status_btn_container.isEnabled = true
                try {
                    if(response == null) return
                    if(response.isSuccessful){
                        if(response.body().status == Constants.SUCCESS_STATUS){

                        }else{
                            changeStatus(position,Constants.CONNECTION_NOT_CONNECTED)
                            showErrorToast(response.body().message)
                        }
                    }else{
                        changeStatus(position,Constants.CONNECTION_NOT_CONNECTED)
                        showErrorToast()
                    }
                }
                catch (e : Exception){

                }

            }
        })

    }
    private fun showErrorToast(message : String = Constants.ERROR_MSG_TOAST_1){
        Toast.makeText(context,message,Toast.LENGTH_SHORT).show()
    }

    private fun changeStatus(position: Int,status : String){
        if(items == null) return
        items[position].status = status
        notifyItemChanged(position)
    }


    override fun getItemViewType(position: Int): Int {
        return when (items!![position].viewType) {
            GetNetworkEmployeeData.NORMAL_VIEW -> 1
            GetNetworkEmployeeData.MANAGE_VIEW -> 2
            else -> 1
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View
        return when (viewType) {
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.suggested_connection_card_item, parent, false)
                SuggestedConnectionsCardsViewHolder(v)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.suggested_connection_manage_item, parent, false)
                ManageViewHolder(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.suggested_connection_card_item, parent, false)
                SuggestedConnectionsCardsViewHolder(v)
            }
        }
    }

    override fun getItemCount(): Int {
        return items?.size ?: 0
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items!![position]


        if(item.viewType == GetNetworkEmployeeData.NORMAL_VIEW){
            setItemView(holder as SuggestedConnectionsCardsViewHolder,item);
        }


    }

    private fun setItemView( holder: SuggestedConnectionsCardsViewHolder, item :GetNetworkEmployeeData ){

        holder.user_img.setImageURI("" + item.profilePic);
        holder.company_img.setImageURI("" + item.profilePic);
        holder.company_img.setImageURI("" + item.company_pic);
        holder.user_name.text = item.firstName + " " + item.lastName;
        holder.company_name.text = item.companyName;
        if(item.connected_users_count == 1){
            holder.no_of_co_workers_connected.text = item.connected_users_count.toString() + " co-worker connected";
        }else{
            holder.no_of_co_workers_connected.text = item.connected_users_count.toString() + " co-workers connected";
        }

        holder.country_city.text = item.location;


        if(item.status == Constants.CONNECTION_NOT_CONNECTED){
            holder.status_text.text = "Connect"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                holder.icon.text = Html.fromHtml("&#xf067;",Html.FROM_HTML_MODE_LEGACY)
            } else {
                holder.icon.text = Html.fromHtml("&#xf067;")
            }
        }else{
            //request pending
            holder.status_text.text = "Request Pending"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                holder.icon.text = Html.fromHtml("&#xf253;",Html.FROM_HTML_MODE_LEGACY)
            } else {
                holder.icon.text = Html.fromHtml("&#xf253;")
            }
        }
    }


}