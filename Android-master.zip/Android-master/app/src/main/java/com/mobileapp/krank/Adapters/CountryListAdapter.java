package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.mobileapp.krank.Activities.CustomDropDown.CountryListActivity;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CountryListAdapter extends RecyclerView.Adapter<CountryListAdapter.ViewHolder> implements Filterable {
    public List<CountyListData> items = new ArrayList<>();
    public List<CountyListData> filteredItems = new ArrayList<>();
    CountryListActivity countryListActivity;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView name;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            name = item.findViewById(R.id.name);
        }
    }

    public CountryListAdapter(List<CountyListData> items, CountryListActivity countryListActivity) {
        this.items = items;
        this.filteredItems = items;
        this.countryListActivity = countryListActivity;
    }

    public CountryListAdapter(CountyListData[] items, CountryListActivity countryListActivity) {

        this.items.addAll(Arrays.asList(items));
        this.filteredItems.addAll(Arrays.asList(items));
        this.countryListActivity = countryListActivity;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                Log.e("character ->", "" + charString);
                if (charString.isEmpty()) {
                    filteredItems = items;
                } else {
                    List<CountyListData> filteredList = new ArrayList<>();
                    for (CountyListData row : items) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    filteredItems = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = filteredItems;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filteredItems = (ArrayList<CountyListData>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.drop_adapter_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CountryListAdapter.ViewHolder holder, final int position) {
        final CountyListData item = filteredItems.get(position);

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setItemSelected(true);
                countryListActivity.selectedIndex = position;
                uncheckAllItems(item);
                notifyDataSetChanged();
            }
        });
        holder.name.setText("" + item.getName());
    }

    @Override
    public int getItemCount() {
        return filteredItems.size();
    }

    private void uncheckAllItems(CountyListData item){
        for(int i=0; i < items.size();i++){
            if(items.get(i).getCode().equals(item.getCode())){
                continue;
            }
            items.get(i).setItemSelected(false);
        }
    }
}






