package com.mobileapp.krank.CompanyProfileSettingsTabs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Activities.CompanySizeDropDownScreen;
import com.mobileapp.krank.Activities.MyCompanyProfileSettings;
import com.mobileapp.krank.Activities.CustomDropDown.PreferredTradingCurrencyDropDown;
import com.mobileapp.krank.Adapters.CompanyInterestListAdapter;
import com.mobileapp.krank.Base.BaseFragment;

import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CompanyInterestListResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInterestListData;
import com.mobileapp.krank.ResponseModels.DataModel.CompanySizeData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Field;

public class CompanyProfileSettingsPageTwo extends BaseFragment {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerAdapter;
    List<CompanyInterestListData> items;
    public EditText bio_edit_text, company_size_edit_text, website_edit_text, preferred_trading_currency;
    String bioText, websiteText;
    NestedScrollView scroll_view;
    public CompanySizeData selectedCompanySize;
    List<String> interest;

    String selectedCurrency;

    private static int COMPANY_SIZE_ACTIVITY_CODE = 100;
    private static int PREFERRED_CURRENCY_ACTIVITY_CODE = 200;

    MyCompanyProfileSettings activityRef;


    public CompanyProfileSettingsPageTwo() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.company_profile_settings_page_two, container, false);
        setFragmentView(me);


        init();


        initViews();

        setUpAdapter();

        setValues();


        company_size_edit_text.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), CompanySizeDropDownScreen.class);
           /* if (selectedCompanySize == null) {
                intent.putExtra("selectedCompanySize", "null");
            } else {
                intent.putExtra("selectedCompanySize", ((MyCompanyProfileSettings) getActivity()).appUtils.convertToJson(selectedCompanySize));
            }*/

            if (selectedCompanySize != null) {
                intent.putExtra("selectedCompanySize", ((MyCompanyProfileSettings) getActivity()).appUtils.convertToJson(selectedCompanySize));
            }
            startActivityForResult(intent, COMPANY_SIZE_ACTIVITY_CODE);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });


        preferred_trading_currency.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), PreferredTradingCurrencyDropDown.class);
           /* if (selectedCurrency == null) {
                intent.putExtra("selectedCurrency", "null");
            } else {
                intent.putExtra("selectedCurrency", selectedCurrency);
            }*/

            if (selectedCurrency != null) {
                intent.putExtra("selectedCurrency", selectedCurrency);
            }
            startActivityForResult(intent, PREFERRED_CURRENCY_ACTIVITY_CODE);
            getActivity().overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
        website_edit_text.setOnFocusChangeListener((view, b) -> {
            if (!b) {
                //   Log.e("Focus Yes","=> " + appUtils.isStringContainsHttpHttps(website_edit_text.getText().toString()));
                if (!(AppUtils.isStringContainsHttpHttps(website_edit_text.getText().toString()))) {
                    website_edit_text.setText("http://" + website_edit_text.getText().toString());
                }
            }
        });
        return me;
    }
    private void init() {
        activityRef = (MyCompanyProfileSettings) getActivity();
    }

    private void initViews(){
        bio_edit_text = (EditText) findViewById(R.id.bio_edit_text);
        company_size_edit_text = (EditText) findViewById(R.id.company_size_edit_text);
        website_edit_text = (EditText) findViewById(R.id.website_edit_text);
        preferred_trading_currency = (EditText) findViewById(R.id.preferred_trading_currency);
      //  error_view = (TextView) findViewById(R.id.error_view);
        scroll_view = (NestedScrollView) findViewById(R.id.scroll_view);
    }

    private void setUpAdapter() {
        recyclerView = (RecyclerView) findViewById(R.id.marketplace_recycler);
        items = new ArrayList<>();


        ((MyCompanyProfileSettings) getActivity()).getAPI().getCompanyInterestList(((MyCompanyProfileSettings) getActivity()).preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<CompanyInterestListResponse>() {
            @Override
            public void onResponse(Call<CompanyInterestListResponse> call, Response<CompanyInterestListResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                        items.addAll(response.body().getData());
                       /* if (interest != null) {
                            for (int i = 0; i < items.size(); i++) {
                                for (int j = 0; j < interest.size(); j++) {
                                    if (items.get(i).getCategoryId().equals(interest.get(j))) {
                                        items.get(i).setIscheckBoxSelected(true);
                                    }
                                }
                            }
                        }*/
                        recyclerAdapter = new CompanyInterestListAdapter(items, getActivity());
                        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                        recyclerView.setAdapter(recyclerAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<CompanyInterestListResponse> call, Throwable t) {

            }
        });
    }

    private void setValues() {
        if (bioText != null) {
            bio_edit_text.setText("" + bioText);

        }
        if (websiteText != null) {
            website_edit_text.setText("" + websiteText);
        }

        if (selectedCurrency != null) {
            preferred_trading_currency.setText("" + selectedCurrency);
        }
        if (selectedCompanySize != null) {
            company_size_edit_text.setText("" + selectedCompanySize.getCompanySize());
        }
    }

    public void setData(String bio_edit_text, String website_edit_text, CompanySizeData selectedCompanySize, List<String> interest, String selectedCurrency) {
        this.bioText = bio_edit_text;
        this.websiteText = website_edit_text;
        this.selectedCompanySize = selectedCompanySize;
        this.interest = interest;
        this.selectedCurrency = selectedCurrency;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COMPANY_SIZE_ACTIVITY_CODE) {
                selectedCompanySize = ((MyCompanyProfileSettings) getActivity()).gson.fromJson(data.getStringExtra("selectedCompanySize"), CompanySizeData.class);
                company_size_edit_text.setText("" + selectedCompanySize.getCompanySize());
            } else if (requestCode == PREFERRED_CURRENCY_ACTIVITY_CODE) {
                selectedCurrency = data.getStringExtra("selectedCurrency");
                preferred_trading_currency.setText("" + selectedCurrency);
            }

        }
    }

    public void updateProfile() {
        // if (!isErrorExists()) {
     //   error_view.setText("");
        CompanyProfileStepTwoPostParams params = new CompanyProfileStepTwoPostParams( bio_edit_text.getText().toString(),selectedCompanySize.getId(),website_edit_text.getText().toString(),getSelectedInterestList(),selectedCurrency);
        ((MyCompanyProfileSettings) getActivity()).getAPI().updateCompanyProfileStepTwo(((MyCompanyProfileSettings) getActivity()).preference.getString(Constants.ACCESS_TOKEN),params).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        showToast(response.body().getMessage());
                    } else {
                        showToast(response.body().getMessage());
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST);
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                showToast(Constants.ERROR_MSG_TOAST);
            }
        });
        //  }

    }
    private void showToast(String message){
        try {
            activityRef.showToast(message);
        }catch (Exception ex){

        }

    }

    public boolean isErrorExists() {

        boolean error = false;
        if (bio_edit_text.getText().toString().isEmpty()) {
            error = true;
          //  error_view.setText(Constants.ENTER_BIO_TEXT);
            focusToView(bio_edit_text,Constants.ENTER_BIO_TEXT);
        } else if (selectedCompanySize == null) {
            error = true;
           // error_view.setText(Constants.SELECT_COMPANY_SIZE);
            focusToView(company_size_edit_text,Constants.SELECT_COMPANY_SIZE);
        } else if (selectedCurrency == null || selectedCurrency.trim().isEmpty()) {
            error = true;
            //error_view.setText(Constants.SELECT_CURRENCY);
            focusToView(preferred_trading_currency,Constants.SELECT_CURRENCY);
        } else if (website_edit_text.getText().toString().isEmpty() || !AppUtils.validateWebSiteUrl(website_edit_text.getText().toString())) {
            error = true;
            //error_view.setText(Constants.CORRECT_WEBSITE_URL);
            focusToView(website_edit_text,Constants.CORRECT_WEBSITE_URL);
        } /*else if (getSelectedInterestList().size() <= 0) {
            error = true;
            error_view.setText(Constants.SELECT_MARKETPLACE);
        }*/
        return error;
    }

    private void focusToView(EditText mEditText,String errorMessage){
        scroll_view.scrollTo(0,mEditText.getTop());
        activityRef.showToast(errorMessage);
    }

    public ArrayList<String> getSelectedInterestList() {
        ArrayList<String> selectedData = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getIsSelected()) {
                selectedData.add(items.get(i).getCategoryId());
            }
        }
        return selectedData;
    }
    public class CompanyProfileStepTwoPostParams{
        @SerializedName("bio")
        private String bio;
        @SerializedName("size")
        private String size;
        @SerializedName("website_url")
        private String webiste_url;
        @SerializedName("marketplace_interest")
        private ArrayList<String> marketplace_interest;
        @SerializedName("currency_code")
        private String currency_code;

        public String getBio() {
            return bio;
        }

        public void setBio(String bio) {
            this.bio = bio;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getWebiste_url() {
            return webiste_url;
        }

        public void setWebiste_url(String webiste_url) {
            this.webiste_url = webiste_url;
        }

        public ArrayList<String> getMarketplace_interest() {
            return marketplace_interest;
        }

        public void setMarketplace_interest(ArrayList<String> marketplace_interest) {
            this.marketplace_interest = marketplace_interest;
        }

        public String getCurrency_code() {
            return currency_code;
        }

        public void setCurrency_code(String currency_code) {
            this.currency_code = currency_code;
        }

        public CompanyProfileStepTwoPostParams(String bio, String size, String webiste_url, ArrayList<String> marketplace_interest, String currency_code) {
            this.bio = bio;
            this.size = size;
            this.webiste_url = webiste_url;
            this.marketplace_interest = marketplace_interest;
            this.currency_code = currency_code;
        }
    }
}


