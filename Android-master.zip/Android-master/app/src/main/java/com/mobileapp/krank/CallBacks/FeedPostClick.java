package com.mobileapp.krank.CallBacks;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

public interface FeedPostClick {
    void act(NewsFeedArray item);
}
