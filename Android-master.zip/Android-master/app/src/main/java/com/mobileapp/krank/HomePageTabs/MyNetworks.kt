package com.mobileapp.krank.HomePageTabs

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView

import com.google.gson.Gson
import com.mobileapp.krank.Activities.MainPage
import com.mobileapp.krank.Activities.MyNetworksCard
import com.mobileapp.krank.Adapters.NetworksAdapter
import com.mobileapp.krank.Base.BaseFragment
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.CustomGson
import com.mobileapp.krank.Model.HomePageDataFlagContainer
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ResponseModels.NetworkListResponse

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import android.app.Activity.RESULT_OK
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import com.mobileapp.krank.Scroll.HidingPageScrollListener
import com.mobileapp.krank.Utils.ServiceManager

/**
 * Created by Ahmed on 4/20/2018.
 */

class MyNetworks : BaseFragment(), CallBackWithAdapterPosition {
    //for list items
    private lateinit var networksRecyclerView: RecyclerView
    private lateinit var networksRecyclerAdapter: RecyclerView.Adapter<*>
    internal lateinit var networksItems: MutableList<NetworkList>
    internal lateinit var layoutManager: LinearLayoutManager
    //views
    internal lateinit var swipeRefreshLayout: SwipeRefreshLayout
    internal lateinit var no_item_found_view: TextView
    private lateinit var search_box: EditText
    internal lateinit var cross_icon: View
    internal lateinit var header: View
    //for filter
    // String selectedUserId;

    internal lateinit var gson: Gson


    //flag
    private var homePageDataFlagContainer: HomePageDataFlagContainer? = null


    //update Listener
    internal lateinit var listener: MainPage.upDateListener


    //for pagination
    private var offset: Int = 0
    private var reminderCount: Int = 0

    //scroll flags
    internal var shouldScrollCall: Boolean = false

    //resume tab
    internal var isResume: Boolean = false

    internal lateinit var handler: Handler
    internal lateinit var runnable: Runnable


    //loader
    internal lateinit var loader: ProgressBar

    //typing events
    private lateinit var onTypingTimeout: Runnable

    internal lateinit var serviceManager: ServiceManager

    //api call
    private var call: Call<NetworkListResponse>? = null

    init {
        title = "My Networks"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val me = inflater.inflate(R.layout.my_networks_page, container, false)
        fragmentView = me

        Log.e("onCreateView", "Yes")

        init(savedInstanceState)


        runnable = Runnable { getNetworksData() }


        serviceManager = ServiceManager.getInstance()

        setUpTypingTimeoutRunnable()


        //views
        swipeRefreshLayout = findViewById(R.id.swipe_refresh) as SwipeRefreshLayout
        swipeRefreshLayout.setProgressViewOffset(false, 0, resources.getDimension(R.dimen.refresher_offset_end).toInt())


        no_item_found_view = findViewById(R.id.no_item_found_view) as TextView
        no_item_found_view.text = Constants.NO_NETWORK_FOUND_TEXT
        no_item_found_view.visibility = View.GONE
        loader = findViewById(R.id.loader) as ProgressBar
        header = findViewById(R.id.header)
        //search box
        search_box = findViewById(R.id.search_box) as EditText
        cross_icon = findViewById(R.id.cross_icon)

        search_box.hint = "Search Networks Here"

        //gson
        gson = CustomGson.getInstance()

        //adapter
        setUpNetworksAdapter()

        //get the data from API
        if (!homePageDataFlagContainer!!.isDataLoaded) {
            getNetworksData()
        } else {
            loader.visibility = View.GONE
        }


        //listeners
        binListeners()

        showViews()

        return me
    }

    private fun setUpTypingTimeoutRunnable() {
        onTypingTimeout = Runnable {
            //scroll
            offset = 0
            shouldScrollCall = false

            //reset the data
            networksItems.subList(1, networksItems.size).clear()
            networksItems.add(NetworkList(Constants.LOADER_VIEW))
            networksRecyclerAdapter.notifyDataSetChanged()


            //abort the request
            if (call != null && call!!.isExecuted) {
                call?.cancel()
            }

            //api data
            getNetworksData()


        }
    }

    private fun binListeners() {
        search_box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(onTypingTimeout)

            }

            override fun afterTextChanged(editable: Editable) {
                Log.e("afterTextChanged", "afterTextChanged");
                if (isResume) {
                    isResume = false
                    return
                }
                onTextChange()
            }
        })


        swipeRefreshLayout.setOnRefreshListener {

            //update data container
            homePageDataFlagContainer!!.isDataLoaded = false
            homePageDataFlagContainer!!.selectedId = null


            getDataAfterReset(false)


        }

        cross_icon.setOnClickListener {
            if (search_box.text.toString().isEmpty()) return@setOnClickListener
            search_box.setText("")

            // getDataAfterReset(true)
        }
    }

    private fun onTextChange() {
        handler.postDelayed(onTypingTimeout, Constants.TYPING_TIME_DELAY.toLong())

    }

    private fun getDataAfterReset(resetClick: Boolean) {
        //update the data
        offset = 0
        shouldScrollCall = false

        networksItems.subList(1, networksItems.size).clear()

        if (!resetClick) swipeRefreshLayout.isRefreshing = true else networksItems.add(NetworkList(Constants.LOADER_VIEW))


        networksRecyclerAdapter.notifyDataSetChanged()


        getNetworksData()
    }

    private fun setRecyclerViewScrollListener() {
        networksRecyclerView.addOnScrollListener(object : HidingPageScrollListener() {

            override fun onScrolledToEnd() {
                onScrollEnd()
            }

            override fun onHide() {
                hideViews()
            }

            override fun onShow() {
                showViews()
            }

        })
    }

    private fun hideViews() {
        header.animate().translationY((-(header.height + resources.getDimension(R.dimen.search_bar_padding)))).interpolator = AccelerateInterpolator(2F)
    }

    private fun showViews() {
        header.animate().translationY(0F).interpolator = DecelerateInterpolator(2F)
    }

    private fun init(savedInstanceState: Bundle?) {

        //getting data from activity
        val mainPage = activity as MainPage

        networksItems = mainPage.networksItems
        homePageDataFlagContainer = mainPage.networkTabData
        preference = mainPage.preference
        handler = mainPage.handler
        this.listener = mainPage.listener


        // get the save data
        if (savedInstanceState != null) {
            offset = savedInstanceState.getInt(OFFSET_KEY)
            shouldScrollCall = savedInstanceState.getBoolean(SCROLL_FLAG_KEY)
            reminderCount = savedInstanceState.getInt(NETWORK_REMAINDER_KEY)

            isResume = true


        } else {
            offset = 0
            shouldScrollCall = false

            isResume = false

        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        //saving the data
        outState.putInt(OFFSET_KEY, offset)
        outState.putBoolean(SCROLL_FLAG_KEY, shouldScrollCall)
        outState.putInt(NETWORK_REMAINDER_KEY, reminderCount)
    }

    private fun onScrollEnd() {

        if (shouldScrollCall) {
            shouldScrollCall = false
            offset += Constants.PAGE_LIMIT

          //  networksItems.add(NetworkList(Constants.LOADER_VIEW))
         //   networksRecyclerAdapter.notifyItemInserted(networksItems.size)



            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())
        }
    }

    private fun setUpNetworksAdapter() {
        networksRecyclerView = findViewById(R.id.my_networks_recycler_view) as RecyclerView
        networksRecyclerAdapter = NetworksAdapter(networksItems, context, this)
        layoutManager = LinearLayoutManager(activity)
        networksRecyclerView.layoutManager = layoutManager
        networksRecyclerView.adapter = networksRecyclerAdapter

        setRecyclerViewScrollListener()
    }

    private fun checkForData() {
        if (networksItems.size <= 1) {
            no_item_found_view.visibility = View.VISIBLE
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }


    private fun getNetworksData() {

        call = serviceManager.api.getNetworkByPage(preference.getString(Constants.ACCESS_TOKEN), offset, if (homePageDataFlagContainer!!.selectedId == null) "" else homePageDataFlagContainer!!.selectedId, search_box.text.toString(), Constants.PAGE_LIMIT)

        if (call == null) return
        call?.enqueue(object : Callback<NetworkListResponse> {
            override fun onResponse(call: Call<NetworkListResponse>, response: Response<NetworkListResponse>) {

                if (response.isSuccessful) {
                    val networkListResponse = response.body()
                    if (networkListResponse.status == "success") {


                        reminderCount = response.body().data.reminderCount



                        homePageDataFlagContainer!!.isDataLoaded = true


                        loader.visibility = View.GONE


                        removeLoader()

                        val oldSize = networksItems.size

                        networksItems.addAll(networkListResponse.data.networkList)


                        if (networkListResponse.data.networkList.size >= Constants.PAGE_LIMIT) {
                            networksItems.add(NetworkList(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }

                        networksRecyclerAdapter.notifyItemRangeInserted(oldSize, networksItems.size)

                        checkForData()
                    }
                }
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<NetworkListResponse>, t: Throwable) {
                homePageDataFlagContainer!!.isDataLoaded = true
                swipeRefreshLayout.isRefreshing = false
                loader.visibility = View.GONE
            }
        })
    }


    private fun removeLoader() {
        for (i in networksItems.indices.reversed()) {
            if (networksItems[i].type == Constants.LOADER_VIEW) {
                networksItems.removeAt(i)
                networksRecyclerAdapter.notifyItemRemoved(i)
                break
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == SORT_ACTIVITY_CODE) {

                if (data!!.getBooleanExtra("reset_click", false)) {
                    homePageDataFlagContainer!!.selectedId = null
                } else {
                    homePageDataFlagContainer!!.selectedId = data.getStringExtra("userId")
                }

                //clears the data
                networksItems.subList(1, networksItems.size).clear()
                networksRecyclerAdapter.notifyDataSetChanged()
                // get the new data
                swipeRefreshLayout.isRefreshing = true

                shouldScrollCall = false

                offset = 0
                getNetworksData()
            } else if (requestCode == CARDS_ACTIVITY_CODE) {
                if (data!!.getBooleanExtra("isDataDeleted", false)) {
                    val app = activity!!.applicationContext as CustomApplication
                    networksItems.subList(1, networksItems.size).clear()
                    networksItems.addAll(app.networksItems)
                    networksRecyclerAdapter.notifyDataSetChanged()
                    offset = data.getIntExtra("offset", 0)
                    listener.onConnectionUpdated()
                }
            }
        }
    }

    override fun act(position: Int) {
        if(networksItems.size <= 1) return
        val app = activity!!.applicationContext as CustomApplication
        app.networksItems = networksItems.subList(1, networksItems.size)
        val intent = Intent(context, MyNetworksCard::class.java)
        intent.putExtra("currentItem", position - 1)
        intent.putExtra("offset", offset)
        intent.putExtra("reminderCount", reminderCount)
        intent.putExtra("keyword", search_box.text.toString())
        startActivityForResult(intent, CARDS_ACTIVITY_CODE)
        activity!!.overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }

    companion object {

        //activity codes
        private const val SORT_ACTIVITY_CODE = 10
        const val CARDS_ACTIVITY_CODE = 500


        //header
        const val TYPE_HEADER = 2


        //save instance keys
        private const val OFFSET_KEY = "network_offset"
        private const val SCROLL_FLAG_KEY = "network_flag"
        private const val NETWORK_REMAINDER_KEY = "network_remainder_count"
    }
}