package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CompanyNewsFeedDataResponse {
    @SerializedName("company_feeds")
    @Expose
    private List<NewsFeedArray> feeds = null;

    @SerializedName("count")
    @Expose
    private int count;

    @SerializedName("last_num")
    @Expose
    private String last_num;


    public List<NewsFeedArray> getFeeds() {
        return feeds;
    }

    public void setFeeds(List<NewsFeedArray> feeds) {
        this.feeds = feeds;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getLast_num() {
        return last_num;
    }

    public void setLast_num(String last_num) {
        this.last_num = last_num;
    }
}

