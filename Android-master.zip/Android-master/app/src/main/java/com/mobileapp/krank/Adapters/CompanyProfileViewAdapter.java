
package com.mobileapp.krank.Adapters;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.CompanyProfileView;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.R;

import com.mobileapp.krank.ResponseModels.DataModel.CompanyProfileDetailDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsForCompanyProfileViewDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.DealersDataForCompanyProfileViewPage;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CompanyProfileFeed.CompanyProfileMessageView;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CompanyProfileFeed.OtherCompanyProfileHeader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.Loader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CompanyProfileFeed.PersonalCompanyProfileHeader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.OtherEmploysInnerRecyclerAdapter;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;

import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;


/**
 * Created by Yaseen on 05/05/2018.
 *//*
 * **/


public class CompanyProfileViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    //list items
    private List<NewsFeedArray> items;

    //activity Ref
    CompanyProfileView activity;
    DeviceInfo deviceInfo;

    //profile detail
    CompanyProfileDetailDataModel mCompanyProfileDataModel;


    public SaveInSharedPreference preference;

    //horizontal list
    List<ConnectionsForCompanyProfileViewDataModel> connectionsForCompanyProfileViewDataModels;
    List<DealersDataForCompanyProfileViewPage> dealersForCompanyProfileViewDataModels;
    //newsfeed post types
    NewsFeedFunctions newsFeedFunctions;

    //loader
    SweetAlertDialog progressDialog;

    //callBack
    CallBackWithPosTypeAndView callBack;
    CompanyProfileMessageView.SendMessageListener sendMessageCallBack;


    public void setListener(CallBackWithPosTypeAndView callBack) {
        this.callBack = callBack;
    }

    public void setSendMessageCallBack(CompanyProfileMessageView.SendMessageListener sendMessageCallBack) {
        this.sendMessageCallBack = sendMessageCallBack;
    }

    public class ProfileInfoViewHeader extends RecyclerView.ViewHolder {

        View item;
        TextView website_text_view;
        TextView company_size_text_view;
        TextView company_industry_text_view;
        TextView company_type_text_view;

        public ProfileInfoViewHeader(View itemView) {
            super(itemView);
            website_text_view = itemView.findViewById(R.id.website_text_view);
            company_size_text_view = itemView.findViewById(R.id.company_size_text_view);
            company_industry_text_view = itemView.findViewById(R.id.company_industry_text_view);
            company_type_text_view = itemView.findViewById(R.id.company_type_text_view);


            //website InApp WebView
            website_text_view.setOnClickListener(view -> {
                if (getAdapterPosition() < 0 || callBack == null) return;
                callBack.act(getAdapterPosition(), Constants.IN_APP_WEBVIEW, website_text_view);
            });
        }

    }


    public class OfficialDealerInnerRecyclerAdapter extends RecyclerView.ViewHolder {

        View item;
        RecyclerView otherEmploys;
        RecyclerView.Adapter horizontalAdapter;
        TextView official_dealer_text;

        public OfficialDealerInnerRecyclerAdapter(View itemView) {
            super(itemView);
            otherEmploys = itemView.findViewById(R.id.horizontal_recycler_official_dealer_list);
            official_dealer_text = itemView.findViewById(R.id.official_dealer_text);
            otherEmploys.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false));
            horizontalAdapter = new OfficialDealerHorizontalListAdapter(dealersForCompanyProfileViewDataModels, activity);
            otherEmploys.setNestedScrollingEnabled(false);
            otherEmploys.setAdapter(horizontalAdapter);
        }
    }

    public CompanyProfileViewAdapter(List<NewsFeedArray> items, CompanyProfileView activity, DeviceInfo deviceInfo) {
        this.items = items;
        this.activity = activity;
        this.deviceInfo = deviceInfo;
        preference = new SaveInSharedPreference(activity);
        newsFeedFunctions = new NewsFeedFunctions(activity, deviceInfo, false);
        progressDialog = new SweetAlertDialog(activity, SweetAlertDialog.PROGRESS_TYPE);
    }

    public void setUpdatedData(CompanyProfileDetailDataModel mCompanyProfileDataModel) {
        this.mCompanyProfileDataModel = mCompanyProfileDataModel;
        this.connectionsForCompanyProfileViewDataModels = mCompanyProfileDataModel.getMy_connections();
        this.dealersForCompanyProfileViewDataModels = mCompanyProfileDataModel.getMy_dealers();

    }

    public class EmptyNewsFeed extends RecyclerView.ViewHolder {
        TextView noNewsFeedText;

        public EmptyNewsFeed(View itemView) {
            super(itemView);
            noNewsFeedText = itemView.findViewById(R.id.no_post_text);

        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case Constants.PERSONAL_PROFILE_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.personal_company_profile_item, parent, false);
                return new PersonalCompanyProfileHeader(view,callBack);
            case Constants.OTHER_PROFILE_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.company_profile_collapse_header, parent, false);
                return new OtherCompanyProfileHeader(view,callBack);
            case Constants.INFO_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.collapseable_people_info_item_layout, parent, false);
                return new ProfileInfoViewHeader(view);
            case Constants.TEXT_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_post_item_layout, parent, false);
                return new TextPostHolder(view, callBack);
            case Constants.IMAGE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_post_item_layout, parent, false);
                return new ImageViewHolder(view, callBack);
            case  Constants.LINKED_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view, callBack);
            case Constants.LOADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case Constants.CHECK_IN:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkin_post_item_layout, parent, false);
                return new CheckInHolder(view, callBack);
            case Constants.NETWORK_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_post_item_layout, parent, false);
                return new NetworkPost(view, callBack);
            case Constants.LISTING_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.YOUTUBE_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.ARTICLE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view,callBack);
            case Constants.DEALER_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_post_item_layout, parent, false);
                return new DealerPost(view, callBack);
            case Constants.VIMEO_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.OTHER_CONNECTION_EMPLOYS_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.horizontal_people_list, parent, false);
                return new OtherEmploysInnerRecyclerAdapter(view,activity,connectionsForCompanyProfileViewDataModels);
            case Constants.OFFICIAL_DEALERS_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.official_dealer_horizontal_list, parent, false);
                return new OfficialDealerInnerRecyclerAdapter(view);
            case Constants.EMPTY_NEWS_FEED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_news_feed, parent, false);
                return new EmptyNewsFeed(view);
            case Constants.AUCTION_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view,callBack);
            case Constants.PROFILE_VIEW_LOADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_view_loader, parent, false);
                return new Loader(view);
            case Constants.COMPANY_PROFILE_MESSAGE_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.company_profile_msg_view, parent, false);
                return new CompanyProfileMessageView(view,sendMessageCallBack);
            default:
                return null;
        }

    }

    @Override
    public int getItemViewType(int position) {

        return items.get(position).getPostType();

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final NewsFeedArray item = items.get(position);


        item.setCallBackWithAdapterPosition((pos) -> {
            removeAt(pos);
        });

        item.setCommentClick((position1, item1, view) -> {
            if (callBack == null) return;
            callBack.act(position1, Constants.COMMENT_CALLBACK, view);
        });

        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        params.topMargin = 16;

        switch (item.getPostType()) {
            case Constants.PERSONAL_PROFILE_VIEW:
                params.topMargin = 0;
                ((PersonalCompanyProfileHeader)holder).setPersonalCompanyProfile(mCompanyProfileDataModel);
                break;
            case Constants.PROFILE_VIEW_LOADER:
                params.topMargin = 0;
                break;
            case Constants.IMAGE_POST:
                newsFeedFunctions.setTypeImgPost(holder, item);
                break;
            case Constants.LINKED_POST:
                newsFeedFunctions.setTypeLinkedPost(holder, item);
                break;
            case Constants.TEXT_POST:
                newsFeedFunctions.setTypeTextPost(holder, item);
                break;
            case Constants.LOADER:
                break;
            case Constants.CHECK_IN:
                newsFeedFunctions.setCheckInTypePost(holder, item);
                break;
            case Constants.NETWORK_POST:
                newsFeedFunctions.setNetworkPost(holder, item);
                break;
            case Constants.DEALER_POST:
                newsFeedFunctions.setDealerPost(holder, item);
                break;
            case Constants.LISTING_POST:
                newsFeedFunctions.setTypeListingPost(holder, item);
                break;
            case Constants.YOUTUBE_VIDEO:
                newsFeedFunctions.setTypeYoutubeVideoPost(holder, item);
                break;
            case Constants.ARTICLE_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Article");
                break;
            case Constants.AUCTION_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Auction");
                break;
            case Constants.VIMEO_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, item);
                break;
            case Constants.OTHER_POST:
                break;
            case Constants.INFO_POST:
                setTypeInfoPost(holder, item);
                break;
            case Constants.OTHER_PROFILE_VIEW:
                params.topMargin = 0;
                ((OtherCompanyProfileHeader)holder).onBind(mCompanyProfileDataModel,activity);
                break;
            case Constants.OFFICIAL_DEALERS_VIEW:
                setOfficialDealerView(holder);
                break;
            case Constants.OTHER_CONNECTION_EMPLOYS_VIEW:
                ((OtherEmploysInnerRecyclerAdapter) holder).setOtherCompanyEmploysView(mCompanyProfileDataModel.getCompanyName());
                break;
            case Constants.EMPTY_NEWS_FEED:
                setEmptyNewsFeedItem(holder, item, position);
                break;

        }
    }


    private void setTypeInfoPost(final RecyclerView.ViewHolder holder, final NewsFeedArray item) {
        ProfileInfoViewHeader profileInfoViewHeader = (ProfileInfoViewHeader) holder;
        if (mCompanyProfileDataModel.getWebsiteUrl() != null && !(mCompanyProfileDataModel.getWebsiteUrl().equals("0"))) {
            profileInfoViewHeader.website_text_view.setText(mCompanyProfileDataModel.getWebsiteUrl());
        } else {
            profileInfoViewHeader.website_text_view.setText("N/A");
        }

        if (mCompanyProfileDataModel.getIndustryValue() != null) {
            profileInfoViewHeader.company_industry_text_view.setText(mCompanyProfileDataModel.getIndustryValue());
        } else {
            profileInfoViewHeader.company_industry_text_view.setText("N/A");
        }

        if (mCompanyProfileDataModel.getBusinessValue() != null) {
            profileInfoViewHeader.company_type_text_view.setText(mCompanyProfileDataModel.getBusinessValue());
        } else {
            profileInfoViewHeader.company_type_text_view.setText("N/A");
        }

        if (mCompanyProfileDataModel.getCompanySizeName() != null && mCompanyProfileDataModel.getCompanySizeName().length() > 0 && !(mCompanyProfileDataModel.getCompanySizeName().equals("0"))) {
            profileInfoViewHeader.company_size_text_view.setText(mCompanyProfileDataModel.getCompanySizeName());
        } else {
            profileInfoViewHeader.company_size_text_view.setText("N/A");

        }
    }



    private void setEmptyNewsFeedItem(final RecyclerView.ViewHolder holder, final NewsFeedArray item, final int position) {
        final EmptyNewsFeed emptyNewsFeed = ((EmptyNewsFeed) holder);
        emptyNewsFeed.noNewsFeedText.setText("" + item.getNoNewsFeedMsg());
    }


    private void setOfficialDealerView(final RecyclerView.ViewHolder holder) {
        OfficialDealerInnerRecyclerAdapter officialDealerInnerRecyclerAdapter = (OfficialDealerInnerRecyclerAdapter) holder;
        officialDealerInnerRecyclerAdapter.official_dealer_text.setText("Official Dealers of " + mCompanyProfileDataModel.getCompanyName());
    }
}





