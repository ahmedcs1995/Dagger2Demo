package com.mobileapp.krank.Repository.Chat.group;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.util.Log;

import com.google.gson.Gson;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.Dao.GroupChatPeopleList;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.ResponseModels.GroupChatMembersResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GroupChatPeopleListRepository {
    AppExecutors executors;
    List<GroupChatMembersDataModel> peopleListItems;
    GroupChatPeopleList groupChatPeopleListDao;
    SaveInSharedPreference preference;
    ServiceManager serviceManager;
    Gson gson;
    String groupId;

    public GroupChatPeopleListRepository(Application application,String groupId) {
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(application);
        groupChatPeopleListDao = db.getGroupChatListDao();
        executors= AppExecutors.getInstance();
        peopleListItems = new ArrayList<>();
        serviceManager = ServiceManager.getInstance();
        gson = CustomGson.getInstance();
        preference = new SaveInSharedPreference(application.getApplicationContext());
        this.groupId=groupId;

    }

    public LiveData<List<GroupChatMembersDataModel>> getmAllPeopleList(String id) {
        return groupChatPeopleListDao.getPeopleList(id);
    }
    public void deleteMemberFromGroup(String grpUserId){
        executors.diskIO().execute(()->{
            groupChatPeopleListDao.deletePeople(grpUserId);
        });
    }
    public void requestFromSever(CustomCallBack customCallBack){
        serviceManager.getAPI().groupMembersList(preference.getString(Constants.ACCESS_TOKEN),groupId).enqueue(new Callback<GroupChatMembersResponse>() {
            @Override
            public void onResponse(Call<GroupChatMembersResponse> call, Response<GroupChatMembersResponse> response) {

                Log.e("people_list","" + gson.toJson(response.body()));
                Log.e("people_list","call -> " + gson.toJson(call.request()));
                if (response.isSuccessful()) {
                    peopleListItems.addAll(response.body().getData());
                    for(GroupChatMembersDataModel item : peopleListItems){
                        item.setGroupId(groupId);
                        item.setGroupIdUserId(groupId+item.getId());
                    }
                    executors.diskIO().execute(()->{
                        groupChatPeopleListDao.deleteAll();
                        groupChatPeopleListDao.bulkInsert(peopleListItems);
                    });
                    if(customCallBack!=null){
                        customCallBack.act();
                    }
                }
            }

            @Override
            public void onFailure(Call<GroupChatMembersResponse> call, Throwable t) {
                if(customCallBack!=null){
                    customCallBack.act();
                }
                Log.e("people_list","call -> " + gson.toJson(call.request()));
            }
        });

    }
}
