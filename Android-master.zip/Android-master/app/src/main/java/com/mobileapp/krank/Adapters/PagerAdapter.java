package com.mobileapp.krank.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.ViewGroup;

import com.mobileapp.krank.Base.BaseFragment;

import java.util.ArrayList;

/**
 * Created by Ahmed on 3/22/2018.
 */

public class PagerAdapter extends FragmentPagerAdapter {
//public class PagerAdapter extends FragmentStatePagerAdapter {
    ArrayList<BaseFragment> pages;

    public PagerAdapter(FragmentManager fm, ArrayList<BaseFragment> pgs) {
        super(fm);
        pages = pgs;
    }

    @Override
    public int getCount() {
        return pages.size();
    }

    @Override
    public Fragment getItem(int position) {
        return pages.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return (pages.get(position) != null ? pages.get(position).getTitle() : "");
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

    }
}
