package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.CustomViews.CustomFaView
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Model.DeviceInfo
import com.mobileapp.krank.Model.Enums.CardsListenerType
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList

class CarousalCardsAdapter<T>(private var viewToDisplay : Int,private var items: MutableList<T>?, internal var context: Context, internal var deviceInfo: DeviceInfo, private var cardsListeners: CardsListeners, private var itemListeners: ClickListeners) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    interface CardsListeners {
        fun onBind(holder: RecyclerView.ViewHolder, position: Int)

        fun getViewType(position: Int): Int
    }

    interface ClickListeners {
        fun itemClickListener(position: Int, type: CardsListenerType)
    }


    companion object {
        const val CONNECTION_NOT_TO_REMOVE = "69"
        const val COMPANY_NOT_TO_REMOVE = "23"
        const val USER_VIEW = 0
        const val COMPANY_VIEW = 1
        const val ITEM_VIEW = 1
        const val LOADER_VIEW = 2
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        val v: View
        return when (viewType) {
            1 -> {
                getViewToDisplay(parent)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.carosuel_loader_item, parent, false)
                CarouselLoader(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.connections_card_item_new, parent, false)
                ConnectionsCardsViewHolder(v)
            }
        }

    }

    private fun getViewToDisplay(parent: ViewGroup) : RecyclerView.ViewHolder{
        if(viewToDisplay ==USER_VIEW){
            return ConnectionsCardsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.connections_card_item_new, parent, false))
        }else{
            return CompanyCardsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.company_cards_item_new, parent, false))
        }
    }

    override fun getItemViewType(position: Int): Int {

        return cardsListeners.getViewType(position)

    }

    override fun getItemCount(): Int {
        return items?.size ?: 0
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        cardsListeners.onBind(holder, position)

    }

    fun setUserCardView(holder: ConnectionsCardsViewHolder, item: ConnectionsDataModel, position: Int) {
        holder.parent_layout.layoutParams.width = (deviceInfo.deviceWidth * 0.85).toInt()
        holder.parent_layout.layoutParams.height = (deviceInfo.deviceHeight * 0.80).toInt()

        /**
         *
         * Private Connection
         *
         * */

        if(item.isConnectionPrivate){
            holder.mark_as_private_btn.text = "Private Connection"
            holder.mark_as_private_btn.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
            holder.private_connection_icon.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
            holder.private_button_container.setBackgroundColor(ContextCompat.getColor(context, R.color.app_orange_color))
        }else{
            holder.mark_as_private_btn.text = "Mark As Private"
            holder.mark_as_private_btn.setTextColor(ContextCompat.getColor(context, R.color.drawer_background))
            holder.private_connection_icon.setTextColor(ContextCompat.getColor(context, R.color.drawer_background))
            holder.private_button_container.setBackgroundColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
        }


        if (item.companyData != null) {

            var companyData = item.companyData

            holder.profile_img.setImageURI(Constants.BASE_IMG_URL + companyData.userProfilePic)
            holder.company_image_view.setImageURI(Constants.BASE_IMG_URL + companyData.companyProfilePic)

            if (companyData.userId == CONNECTION_NOT_TO_REMOVE) {
                holder.delete_connection.setTextColor(ContextCompat.getColor(context, R.color.drawerGray))
            } else {
                holder.delete_connection.setTextColor(ContextCompat.getColor(context, R.color.drawer_background))
            }

            holder.employee_name_text_view.text = setDataLabel(companyData.firstName) + " " + setDataLabel(companyData.lastName)
            holder.company_name_text_view.text = AppUtils.getCompanyAndDesignation(companyData.companyName, companyData.jobTitle)
            holder.industry_text_view.text = setDataLabel(companyData.industryId)
            holder.website_text_view.text = setDataLabel(companyData.websiteUrl)
            holder.company_size_text_view.text = setDataLabel(companyData.companySizeName)
            holder.type_text_view.text = setDataLabel(companyData.business)

        }
    }

    fun setCompanyCardView(holder: CompanyCardsViewHolder, item: NetworkList, position: Int){
        holder.profile_img.setImageURI(Constants.BASE_IMG_URL + item.profilePic)


        if (item.isDelete != null) {
            if (item.isDelete == "0") {
                holder.remove_btn.setTextColor(ContextCompat.getColor(context, R.color.drawerGray))
            } else {
                holder.remove_btn.setTextColor(ContextCompat.getColor(context, R.color.drawer_background))
            }
        }

        holder.remove_btn.text = "Remove Network"

        if (item.dealerStatus != null) {
            when {
                item.dealerStatus == "Not a dealer" -> holder.official_dealer_image_view.visibility = View.INVISIBLE
                item.dealerStatus == "Request Pending" -> holder.official_dealer_image_view.visibility = View.INVISIBLE
                else -> holder.official_dealer_image_view.visibility = View.VISIBLE
            }
        }


        holder.network_name_text_view.text = setDataLabel(item.companyName)
        holder.industry_text_view.text = setDataLabel(item.industryId)

        // country_and_city_text_view.setText(setDataLabel(item.getIndustryId()));
        holder.type_text_view.text = setDataLabel(item.business)
        holder.website_text_view.text = setDataLabel(item.websiteUrl)
        holder.company_size_text_view.text = setDataLabel(item.companySize)
        holder.country_and_city_text_view.text = setDataLabel(item.cityName) + ", " + setDataLabel(item.countryName)
    }

    fun setDealerView(holder: CompanyCardsViewHolder, item: NetworkDealersData, position: Int){

        holder.profile_img.setImageURI(Constants.BASE_IMG_URL +  item.profilePic)


        holder.official_dealer_image_view.visibility = View.VISIBLE


        holder.network_name_text_view.text = setDataLabel(item.companyName)
        holder.industry_text_view.text = setDataLabel(item.industryId)

        // country_and_city_text_view.setText(setDataLabel(item.getIndustryId()));
        holder.type_text_view.text = setDataLabel(item.business)
        holder.website_text_view.text = setDataLabel(item.websiteUrl)
        holder.company_size_text_view.text = setDataLabel(item.companySizeName)
        holder.country_and_city_text_view.text = setDataLabel(item.cityName) + ", " + setDataLabel(item.countryName)


        holder.remove_btn.text = "Remove Dealer"

    }



    private fun setDataLabel(value: String?): String {
        return if (value != null && value != "0" && !value.trim { it <= ' ' }.isEmpty()) value else "N/A"
    }

    inner class CarouselLoader(itemView : View) : RecyclerView.ViewHolder(itemView){
        private var root_container: View = itemView.findViewById(R.id.root_container)

        init {
            root_container.layoutParams.width = (deviceInfo.deviceWidth * 0.85).toInt()

            root_container.layoutParams.height = (deviceInfo.deviceHeight * 0.80).toInt()
        }
    }

    inner class ConnectionsCardsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var parent_layout: View = itemView.findViewById(R.id.parent_layout)
        internal var view_profile_btn: View = itemView.findViewById(R.id.view_profile_btn)
        private var view_listing_btn: View = itemView.findViewById(R.id.view_listing_btn)
        internal var delete_connection: TextView = itemView.findViewById(R.id.delete_connection)
        private var send_msg_btn: View = itemView.findViewById(R.id.send_msg_btn)
        private var send_contact_btn: View = itemView.findViewById(R.id.send_contact_btn)


        /**
         * Private Connection
         * */
        internal var mark_as_private_btn: TextView = itemView.findViewById(R.id.mark_as_private_btn)
        internal var private_button_container: View = itemView.findViewById(R.id.private_button_container)
        internal var private_connection_icon: CustomFaView = itemView.findViewById(R.id.private_connection_icon)


        internal var profile_img: SimpleDraweeView = itemView.findViewById(R.id.profile_img)
        internal var company_image_view: SimpleDraweeView = itemView.findViewById(R.id.company_image_view)


        internal var employee_name_text_view: TextView = itemView.findViewById(R.id.employee_name_text_view)
        internal var company_name_text_view: TextView = itemView.findViewById(R.id.company_name_text_view)
        internal var website_text_view: TextView = itemView.findViewById(R.id.website_text_view)
        internal var industry_text_view: TextView = itemView.findViewById(R.id.industry_text_view)
        internal var company_size_text_view: TextView = itemView.findViewById(R.id.company_size_text_view)
        internal var type_text_view: TextView = itemView.findViewById(R.id.type_text_view)


        init {

            parent_layout.layoutParams.width = (deviceInfo.deviceWidth * 0.85).toInt()

            parent_layout.layoutParams.height = (deviceInfo.deviceHeight * 0.80).toInt()


            send_msg_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.SEND_MESSAGE)
            }

            view_profile_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_PROFILE)
            }
            view_listing_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_LISTING)
            }
            delete_connection.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.DELETE)
            }

            send_contact_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.SEND_CONTACT_CARD)
            }

            profile_img.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_PROFILE)
            }

            company_image_view.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.COMPANY_IMG)
            }

            mark_as_private_btn.setOnClickListener{
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.PRIVATE_CONNECTION)
            }
        }
    }


    inner class CompanyCardsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private var parent_layout: View = itemView.findViewById(R.id.parent_layout)

        //btns
        internal var view_profile_btn: View = itemView.findViewById(R.id.view_profile_btn)
        private var view_listing: View = itemView.findViewById(R.id.view_listing)
        private var view_employs: View = itemView.findViewById(R.id.view_employs)
        private var view_connections: View = itemView.findViewById(R.id.view_connections)
        internal var remove_btn: TextView = itemView.findViewById(R.id.remove_btn)

        //img
        internal var profile_img: SimpleDraweeView = itemView.findViewById(R.id.profile_img)
        internal var official_dealer_image_view: ImageView = itemView.findViewById(R.id.official_dealer_image_view)


        //labels
        internal var network_name_text_view: TextView = itemView.findViewById(R.id.network_name_text_view)
        internal var country_and_city_text_view: TextView = itemView.findViewById(R.id.country_and_city_text_view)
        internal var website_text_view: TextView = itemView.findViewById(R.id.website_text_view)
        internal var industry_text_view: TextView = itemView.findViewById(R.id.industry_text_view)
        internal var company_size_text_view: TextView = itemView.findViewById(R.id.company_size_text_view)
        internal var type_text_view: TextView = itemView.findViewById(R.id.type_text_view)


        init {

            parent_layout.layoutParams.width = (deviceInfo.deviceWidth * 0.85).toInt()

            parent_layout.layoutParams.height = (deviceInfo.deviceHeight * 0.80).toInt()




            view_profile_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_PROFILE)
            }
            view_listing.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_LISTING)
            }
            remove_btn.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.DELETE)
            }

            view_connections.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_YOUR_CONNECTIONS)
            }
            view_employs.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.VIEW_EMPLOYEES)
            }
            profile_img.setOnClickListener {
                itemListeners.itemClickListener(adapterPosition, CardsListenerType.COMPANY_IMG)
            }
        }
    }

}