package com.mobileapp.krank.Adapters;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mobileapp.krank.Functions.MarketPlaceFunctions;
import com.mobileapp.krank.ViewHolders.MarketPlaceViewHolder.MarketPlaceViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import java.util.List;

public class RentListingSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<ListingDataArray> items;
    MarketPlaceFunctions marketPlaceFunctions;

    public RentListingSearchAdapter(List<ListingDataArray> items, Fragment fragment) {
        this.items = items;
        marketPlaceFunctions = new MarketPlaceFunctions(fragment,this);
    }
    public MarketPlaceFunctions getMarketPlaceFunctions(){
        return marketPlaceFunctions;
    }

    @Override
    public MarketPlaceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.sale_listing_searched_item, parent, false);
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final ListingDataArray item = items.get(position);
        marketPlaceFunctions.setPostView(holder,position,item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}








