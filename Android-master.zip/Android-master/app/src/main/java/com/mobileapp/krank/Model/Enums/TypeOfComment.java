package com.mobileapp.krank.Model.Enums;

/**
 * Created by Yaseen on 25/04/2018.
 */

public enum
TypeOfComment {
    LINKED_POST,
    TEXT_POST,
    IMAGE_POST,
    COMMENT,
    SUB_COMMENT,
    CHECK_IN,
    OFFICIAL_DEALERS_VIEW,
    NETWORK_POST,
    DEALER_POST,
    LISTING_POST,
    YOUTUBE_VIDEO,
    VIMEO_VIDEO,
    AUCTION_POST,
    ARTICLE_POST,OTHER_POST
}
