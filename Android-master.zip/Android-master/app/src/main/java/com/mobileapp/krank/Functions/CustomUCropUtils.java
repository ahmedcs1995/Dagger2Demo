package com.mobileapp.krank.Functions;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;

import com.mobileapp.krank.R;
import com.yalantis.ucrop.UCrop;

public class CustomUCropUtils {


    private CustomUCropUtils(){

    }
    public static String getFileName(){
        return  System.currentTimeMillis() + ".jpg";
    }
    public static UCrop advancedConfig(@NonNull UCrop uCrop, Context context,String type) {
        UCrop.Options options = new UCrop.Options();

        options.setCompressionFormat(Bitmap.CompressFormat.JPEG);

        options.setCompressionQuality(100);

        options.setShowCropFrame(false);
        options.setShowCropGrid(false);

        options.setHideBottomControls(true);
        options.setStatusBarColor(ContextCompat.getColor(context, R.color.AppWhiteColor));
        options.setMaxScaleMultiplier(3);
        options.setCircleDimmedLayer(false);
        if(type.equals(Constants.USER_COVER_IMG) || type.equals(Constants.COMPANY_COVER_IMAGE)){
            options.withAspectRatio(5, 3);
        }
        else if(type.equals(Constants.COMPANY_PROFILE_IMG)){
            options.withAspectRatio(1, 1);
        }
        else{

            options.setCircleDimmedLayer(true);
            options.withAspectRatio(1, 1);
        }

        options.setDimmedLayerColor(ContextCompat.getColor(context,R.color.crop_dimmed_layer_color));

        /*
        If you want to configure how gestures work for all MyUCropActivity tabs

        options.setAllowedGestures(MyUCropActivity.SCALE, MyUCropActivity.ROTATE, MyUCropActivity.ALL);
        * */

        /*

        This sets max size for bitmap that will be decoded from source Uri.
        More size - more memory allocation, default implementation uses screen diagonal.

        options.setMaxBitmapSize(640);
        * */


       /*

        Tune everything (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧

        options.setMaxScaleMultiplier(5);
        options.setImageToCropBoundsAnimDuration(666);
        options.setDimmedLayerColor(Color.CYAN);
        options.setCircleDimmedLayer(true);
        options.setShowCropFrame(false);
        options.setCropGridStrokeWidth(20);
        options.setCropGridColor(Color.GREEN);
        options.setCropGridColumnCount(2);
        options.setCropGridRowCount(1);
        options.setToolbarCropDrawable(R.drawable.your_crop_icon);
        options.setToolbarCancelDrawable(R.drawable.your_cancel_icon);

        // Color palette
        options.setToolbarColor(ContextCompat.getColor(this, R.color.your_color_res));
        options.setStatusBarColor(ContextCompat.getColor(this, R.color.your_color_res));
        options.setActiveWidgetColor(ContextCompat.getColor(this, R.color.your_color_res));
        options.setToolbarWidgetColor(ContextCompat.getColor(this, R.color.your_color_res));
        options.setRootViewBackgroundColor(ContextCompat.getColor(this, R.color.your_color_res));

        // Aspect ratio options
        options.setAspectRatioOptions(1,
            new AspectRatio("WOW", 1, 2),
            new AspectRatio("MUCH", 3, 4),
            new AspectRatio("RATIO", CropImageView.DEFAULT_ASPECT_RATIO, CropImageView.DEFAULT_ASPECT_RATIO),
            new AspectRatio("SO", 16, 9),
            new AspectRatio("ASPECT", 1, 1));

       */

        return uCrop.withOptions(options);
    }

}
