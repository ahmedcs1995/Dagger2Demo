package com.mobileapp.krank.Adapters

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.ImageView
import android.widget.TextView
import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.Activities.ArticleDetail
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView
import com.mobileapp.krank.CustomViews.CustomFaView
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.ArticleDetailDataModel
import android.webkit.WebResourceRequest
import android.webkit.WebViewClient
import com.mobileapp.krank.Activities.PendingRequestActivity
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Model.Enums.ConNetStatus
import java.util.regex.Pattern


class ArticleDetailAdapter(private val items: MutableList<Int>?, internal var context: Context, internal var simpleCallBack: CallBackWithAdapterPosAndType, internal var callBackWithView: CallBackWithPosTypeAndView) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    var data: ArticleDetailDataModel? = null

    var appUtils = AppUtils.getInstance()


    inner class FooterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        //like
        internal var no_of_like: TextView = itemView.findViewById(R.id.no_of_like)
        internal var like_text: TextView = itemView.findViewById(R.id.like_text)
        internal var like_img: ImageView = itemView.findViewById(R.id.like_img)
        internal var like_container: View = itemView.findViewById(R.id.like_container)

        //comment
        internal var comment_container: View = itemView.findViewById(R.id.comment_container)

        //share
        internal var share_container: View = itemView.findViewById(R.id.share_container)


        internal var root_view: View = itemView.findViewById(R.id.root_view)

        init {
            val params = root_view.layoutParams as ViewGroup.MarginLayoutParams
            params.topMargin = 0

            share_container.setOnClickListener {
                callBackWithView.act(adapterPosition, ArticleDetail.SHARE_CLICK, share_container)
            }

            like_container.setOnClickListener {
                callBackWithView.act(adapterPosition, ArticleDetail.LIKE_CLICK, like_container)
            }
        }
    }

    inner class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal var category_text: TextView = itemView.findViewById(R.id.category_text)
        internal var title: TextView = itemView.findViewById(R.id.title)
    }


    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal var profile_img: SimpleDraweeView = itemView.findViewById(R.id.profile_img)
        internal var article_user_name: TextView = itemView.findViewById(R.id.article_user_name)
        internal var company_designation_name: TextView = itemView.findViewById(R.id.company_designation_name)
        internal var date_view: TextView = itemView.findViewById(R.id.date_view)

        //status
        internal var status_btn: View = itemView.findViewById(R.id.status_btn)
        internal var status_text: TextView = itemView.findViewById(R.id.status_text)
        internal var icon: CustomFaView = itemView.findViewById(R.id.icon)

        init {
            profile_img.setOnClickListener {
                onUserClick(adapterPosition)
            }

            article_user_name.setOnClickListener {
                onUserClick(adapterPosition)
            }

            company_designation_name.setOnClickListener {
                simpleCallBack.act(adapterPosition, ArticleDetail.COMPANY_PROFILE)
            }

            status_btn.setOnClickListener {
                simpleCallBack.act(adapterPosition, ArticleDetail.REQUEST)
            }
        }

    }

    private fun onUserClick(position: Int){
        if(data !=null && data!!.articleData!=null){
            if(data!!.articleData.isConnectionConnected()){
                simpleCallBack.act(position, ArticleDetail.GOTO_USER_PROFILE)
                return
            }
            simpleCallBack.act(position, ArticleDetail.COMPANY_PROFILE)
        }
    }
    inner class DescriptionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private var web_view: WebView = itemView.findViewById(R.id.web_view)


        init {
            web_view.loadData(data?.articleData?.article_text, "text/html", "UTF-8")
            // web_view.loadData(ArticleDetail.TEST,"text/html", "UTF-8")
            web_view.settings.javaScriptEnabled = true

            web_view.isVerticalScrollBarEnabled = false
            web_view.isHorizontalScrollBarEnabled = false


            web_view.setOnTouchListener { v, event ->
                val hr = (v as WebView).hitTestResult

                if(hr.type == WebView.HitTestResult.SRC_ANCHOR_TYPE && validAttachmentRegex(hr.extra)){
                    val uri = Uri.parse(hr.extra)
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    intent.setPackage("com.android.chrome")
                    context.startActivity(intent)
                }
                return@setOnTouchListener false
            }
        }

    }

    fun validAttachmentRegex(str: String): Boolean {
        val attachmentRegex = Pattern.compile("(http:\\/\\/|https:\\/\\/|)+[a-z0-9-]+\\.krank.com\\/uploads\\/articles", Pattern.CASE_INSENSITIVE)

        val matcher = attachmentRegex.matcher(str)
        return matcher.find()
    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View
        when (viewType) {
            ArticleDetail.HEADER -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.article_detail_header_item, parent, false)
                return HeaderViewHolder(v)
            }
            ArticleDetail.USER_VIEW -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.article_detail_user_view, parent, false)
                return UserViewHolder(v)
            }
            ArticleDetail.DESCRIPTION -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.article_description_view_item, parent, false)
                return DescriptionViewHolder(v)
            }
            ArticleDetail.FOOTER -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.post_item_footer, parent, false)
                return FooterViewHolder(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.article_description_view_item, parent, false)
                return DescriptionViewHolder(v)
            }
        }
    }

    override fun getItemCount(): Int {
        return items?.size ?: 0
    }

    override fun getItemViewType(position: Int): Int {
        return items!![position]
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        var item = items!![position]
        when (item) {
            ArticleDetail.HEADER -> {
                setUpHeaderView(holder as HeaderViewHolder)
            }
            ArticleDetail.USER_VIEW -> {
                setUpUserView(holder as UserViewHolder)
            }
            ArticleDetail.DESCRIPTION -> {
                setUpDescriptionView(holder as DescriptionViewHolder)
            }
            ArticleDetail.FOOTER -> {
                setUpFooterView(holder as FooterViewHolder)
            }
        }
    }

    private fun setUpHeaderView(viewHolder: HeaderViewHolder) {

        if (data != null) {
            if (data?.articleData != null) {
                viewHolder.category_text.text = "Category: " + data?.articleData?.categoryName
            }
            viewHolder.title.text = data?.page_title
        }
    }

    private fun setUpUserView(viewHolder: UserViewHolder) {
        if (data != null) {
            if (data?.articleData != null) {


                if(data!!.articleData.isConnectionConnected()){
                    viewHolder.article_user_name.text = data!!.articleData.first_name + " " + data!!.articleData.last_name
                    viewHolder.company_designation_name.text = AppUtils.getCompanyAndDesignation(data!!.articleData.company_name, data!!.articleData.designation)

                }else{
                    viewHolder.article_user_name.text = data!!.articleData.company_name
                    viewHolder.company_designation_name.text = AppUtils.concatenateCountryCity(data!!.articleData.country, data!!.articleData.city)
                }


                viewHolder.date_view.text = "Published on " + data!!.articleData.formattedDate


                //images
                viewHolder.profile_img.setImageURI("" + data!!.articleData.user_pic)



                /*connection status*/
                if (data?.articleData?.conStatus != null) {
                    when (AppUtils.getConNetStatus(data!!.articleData.conStatus)) {
                        ConNetStatus.REQUEST_PENDING -> {
                            viewHolder.status_text.text = "Request Pending"
                            viewHolder.icon.text = fromHtml("&#xf253;")
                            viewHolder.icon.visibility = View.VISIBLE
                            viewHolder.status_btn.background = ContextCompat.getDrawable(context, R.drawable.request_pending_text_view)
                            viewHolder.icon.setTextColor(ContextCompat.getColor(context, R.color.AppDarkGray))
                            viewHolder.status_text.setTextColor(ContextCompat.getColor(context, R.color.AppDarkGray))
                        }
                        ConNetStatus.CONNECTED -> {
                            viewHolder.status_text.text = "Connected"
                            viewHolder.status_text.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
                            viewHolder.icon.visibility = View.GONE
                            //viewHolder.icon.text = fromHtml("&#xf1f8;")
                            // viewHolder.status_btn.background = ContextCompat.getDrawable(context, R.drawable.status_custom_view_remove_background)
                            viewHolder.status_btn.background = ContextCompat.getDrawable(context, R.drawable.status_custom_connected_background)
                        }
                        ConNetStatus.INVITATION_RECEIVED -> {
                            viewHolder.status_text.text = "Accept Request"
                            viewHolder.icon.visibility = View.GONE
                            viewHolder.status_btn.background = ContextCompat.getDrawable(context, R.drawable.request_pending_text_view)
                            viewHolder.status_text.setTextColor(ContextCompat.getColor(context, R.color.AppDarkGray))
                            viewHolder.icon.setTextColor(ContextCompat.getColor(context, R.color.AppDarkGray))
                        }
                        ConNetStatus.NOT_CONNECTED -> {
                            viewHolder.status_text.text = "Connect"
                            viewHolder.icon.text = fromHtml("&#xf067;")
                            viewHolder.icon.visibility = View.VISIBLE
                            viewHolder.status_btn.background = ContextCompat.getDrawable(context, R.drawable.status_custom_connected_background)
                            viewHolder.status_text.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
                            viewHolder.icon.setTextColor(ContextCompat.getColor(context, R.color.AppWhiteColor))
                        }
                    }
                    /*connection status*/
                }
            }
        }
    }

    private fun fromHtml(html: String): Spanned {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml("" + html, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml("" + html)
        }
    }


    private fun setUpDescriptionView(viewHolder: DescriptionViewHolder) {
        /*if(data != null && data?.articleData != null){

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                viewHolder.description.text = fromHtml(data!!.articleData.article_text).trim()
            }else{
                viewHolder.description.text =fromHtml(data!!.articleData.article_text).trim()
            }
        }*/

    }

    private fun setUpFooterView(viewHolder: FooterViewHolder) {
        if (data != null && data?.articleData != null) {
            viewHolder.no_of_like.text = "" + data!!.articleData.likes

            viewHolder.comment_container.visibility = View.GONE

            /*like btn*/
            if (data!!.articleData.isLiked()) {
                viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.liked_img_new))
                viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawer_background))
            } else {
                viewHolder.like_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.like_img_new))
                viewHolder.like_text.setTextColor(ContextCompat.getColor(context, R.color.drawerGray))
            }
            /*like btn*/



            /*share privacy*/
           if(data?.articleData!!.isPublic()){
               viewHolder.share_container.visibility = View.VISIBLE
           }else{
               viewHolder.share_container.visibility = View.GONE
           }
            /*share privacy*/

        }

    }


}