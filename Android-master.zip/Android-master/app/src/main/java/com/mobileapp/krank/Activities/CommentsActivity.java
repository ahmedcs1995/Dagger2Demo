package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Adapters.CommentsAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.CustomViews.FeedImageOverlayView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Model.Enums.TypeOfComment;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CommentPostModel;
import com.mobileapp.krank.ResponseModels.CommentsResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsDataResponse;
import com.mobileapp.krank.ResponseModels.DataModel.CommentsReply;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.NewsFeedByIdResponse;
import com.mobileapp.krank.Utils.NewsFeed.NewsFeedUtils;
import com.mobileapp.krank.Utils.ShareBottomSheet;
import com.stfalcon.frescoimageviewer.ImageViewer;


import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommentsActivity extends BaseActivity {
    //list item
    public RecyclerView commentsRecyclerView;
    private CommentsAdapter commentsRecyclerAdapter;
    List<CommentsDataResponse> commentsItems;


    //feed
    NewsFeedArray feedItem;

    //loader
    private ShimmerFrameLayout mShimmerViewContainer;

    //edit comment
    public EditText commentAddText;
    View postBtn;
    CircleImageView profileImg;

    public long lastCommentId;
    public static int COMMENTS_REPLY_ACTIVITY_REQUEST_CODE = 800;
    public int clickIndex;

   //pulling
    Handler handler;
    Runnable runnable;
    private boolean exit;
    private int lastListSize;
    boolean isSendBtnClick;

    //share
    public static final int PRIVACY_ACTIVITY_CODE = 200;
    ShareBottomSheet shareBottomSheet;

    /*like comment Anim*/
    Animation myAnim;
    Animation commentShareAnim;
    /*like comment Anim*/



    NewsFeedUtils newsFeedUtils;


    //commentBox
    View commentBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commets);

        init();


        initViews();


        Glide.with(this).load(AppUtils.getImgUrl(preference.getString(Constants.PROFILE_PICTURE))).into(profileImg);



        getFeedDetail();


        postBtn.setOnClickListener(view -> {
            if (commentAddText.getText().length() > 0) {
                isSendBtnClick = true;
                postComment(feedItem.getId(), commentAddText.getText().toString());
                commentAddText.setText("");
            }
        });
    }

    private void init() {
        exit = false;
        isSendBtnClick = false;
        handler = new Handler();
        runnable = () -> getComments(false);
        lastCommentId = -1;

        setLikeCommentAnimation();

        shareBottomSheet = new ShareBottomSheet
                .Builder(CommentsActivity.this,preference)
                .setListeners( (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
                    Intent intent = new Intent(CommentsActivity.this, SelectPrivacyActivity.class);
                    intent.putExtra("selected_privacy", gson.toJson(selectedPrivacy));
                    intent.putExtra("selected_network_group", gson.toJson(tempNetworkGroup));
                    intent.putExtra("selected_dealer_group", gson.toJson(tempDealerGroup));
                    startActivityForResult(intent, PRIVACY_ACTIVITY_CODE);
                })
                .create();

        newsFeedUtils = NewsFeedUtils.getInstance();
    }

    private void setLikeCommentAnimation() {
        /*like comment button*/
        myAnim = AnimationUtils.loadAnimation(CommentsActivity.this, R.anim.bounce);
        commentShareAnim = AnimationUtils.loadAnimation(CommentsActivity.this, R.anim.bounce_for_comment_click);
        /*like comment button*/
    }


    /**
     *
     * Comment Box Privacy
     *
     * */
    private void commentBoxPrivacy(){
        if(feedItem.showCommentBox()){
            commentBox.setVisibility(View.VISIBLE);
        }else{
            commentBox.setVisibility(View.GONE);
        }
    }


    private void gotoReplyPage(View view, final CommentsDataResponse item, final int position) {

        if(view !=null){
            view.startAnimation(myAnim);

        }
        clickIndex = position;
        Intent intent = new Intent(this, CommentsReplyActivity.class);
        intent.putExtra(CommentsReplyActivity.COMMENT_ID, item.getCid());
        intent.putExtra(CommentsReplyActivity.COMMENT_DATA, gson.toJson(item));
        intent.putExtra(CommentsReplyActivity.IS_ACCESSIBLE, feedItem.showCommentBox());
        startActivityForResult(intent, COMMENTS_REPLY_ACTIVITY_REQUEST_CODE);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
    }


    /**
     * Fetch feed detail via server or from back screen
     * */
    private void getFeedDetail() {
        if (getIntent().getBooleanExtra("from_notification", false)) {
            getNewsFeedById();
        } else {
            if (getIntent().getParcelableExtra("CommentDataObj") != null) {
                feedItem = getIntent().getParcelableExtra("CommentDataObj");
            } else {
                final String commentData = getIntent().getStringExtra("CommentData");
                feedItem = gson.fromJson(commentData, NewsFeedArray.class);
            }


            setNormalPageToolbar( "" + feedItem.getFirst_name() + " " + feedItem.getLast_name() + "'s post");

            setUpCommentsAdapter();


            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
        }
    }

    private void initViews() {
        mShimmerViewContainer = findViewById(R.id.shimmer_view_container);
        mShimmerViewContainer.startShimmer();
        commentAddText = findViewById(R.id.comment_add_text);
        postBtn = findViewById(R.id.post_btn);
        profileImg = findViewById(R.id.profile_img);
        commentBox = findViewById(R.id.footer);

    }

    private void setCallBacks(NewsFeedArray feed) {
        if (feed.getPostType() == Constants.NETWORK_POST || feed.getPostType() == Constants.DEALER_POST || feed.getPostType() == Constants.KRANK_POST) {
            if (feed.getPostType() == Constants.KRANK_POST) {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, true, CommentsActivity.this));
            } else {
                feed.setHeaderSpannableString(newsFeedUtils.getPostHeaderForCompanyFeed(feed, false, CommentsActivity.this));
            }
        } else {
            feed.setHeaderSpannableString(newsFeedUtils.getSpannablePostHeader(feed, CommentsActivity.this, preference));
        }


        if (feed.getPostType() == Constants.CHECK_IN) {
            feed.setCheckInAddress(newsFeedUtils.getSpannableCheckInAddress(feed.getTitle(), feed.getDescription(), feed.getTime_difference(), CommentsActivity.this));
        }


    }



    private void setUpCommentsAdapter() {
        commentsRecyclerView = findViewById(R.id.comments_recycler);
        commentsItems = new ArrayList<>();


        feedItem.getNewsFeedType();

        commentsItems.add(new CommentsDataResponse( feedItem.getPostType()));

        setCallBacks(feedItem);

        commentsRecyclerAdapter = new CommentsAdapter(commentsItems, CommentsActivity.this, feedItem, getDeviceResolution(),preference);
        commentsRecyclerView.setLayoutManager(new LinearLayoutManager(CommentsActivity.this));
        commentsRecyclerView.setAdapter(commentsRecyclerAdapter);
        ((SimpleItemAnimator) commentsRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        setUpAdapterListener();

        commentBoxPrivacy();
    }

    private void addFocus(View view){
        view.startAnimation(commentShareAnim);
        commentAddText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

    }
    private void setUpAdapterListener(){
        commentsRecyclerAdapter.setCallBack((position, type, view) -> {
            switch (type){
                case Constants.LIKE_CALLBACK:
                    newsFeedUtils.sendLike(feedItem, position, view, commentsRecyclerAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),null);
                    break;
                case Constants.COMMENT_CALLBACK:
                    if(feedItem != null && !feedItem.showCommentBox()) return;
                    addFocus(view);
                    break;
                case Constants.SHARE_CALLBACK:
                    newsFeedUtils.openDialog(feedItem, feedItem.getPostType() == Constants.LISTING_POST ? Constants.LISTING_SHARE : Constants.POST_SHARE, view, shareBottomSheet, commentShareAnim);
                    break;
                case Constants.DELETE_CALLBACK:
                    newsFeedUtils.showDeletePopUpMenu(view, feedItem, position, this, preference);
                    break;
                case Constants.POST_CALLBACK:
                    if (feedItem.getPostType() == Constants.ARTICLE_POST) {
                        Intent articleIntent = new Intent(this, ArticleDetail.class);
                        articleIntent.putExtra("article_id", feedItem.getPost_track_id());
                        startActivity(articleIntent);
                    } else if (feedItem.getPostType() == Constants.AUCTION_POST) {
                        Intent inAppWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
                        inAppWebViewIntent.putExtra("feed_type", "auction");
                        inAppWebViewIntent.putExtra("web_view_url", appUtils.getUrlWithUid(feedItem.getShareUrl(), preference));
                        startActivity(inAppWebViewIntent);

                    } else if (feedItem.getPostType() == Constants.LINKED_POST) {
                        Intent linkWebViewIntent = new Intent(this, InAppWebViewCollapseActivity.class);
                        linkWebViewIntent.putExtra("web_view_url", feedItem.getShareUrl());
                        startActivity(linkWebViewIntent);

                    } else if (feedItem.getPostType() == Constants.LISTING_POST) {
                        Intent listingDetailIntent = new Intent(this, ListingDetail.class);
                        listingDetailIntent.putExtra("listing_id", "" + feedItem.getPost_track_id());
                        listingDetailIntent.putExtra("listing_pg_name", "" + feedItem.getHtmlParse().getTitle());
                        startActivity(listingDetailIntent);
                    }
                    break;
                case Constants.USER_PROFILE:
                    gotoUserProfile("" + feedItem.getUser_id());
                    break;
                case Constants.COMPANY_PROFILE:
                    gotoCompanyProfile("" + feedItem.getCompany_id());
                    break;
                case Constants.MY_COMPANY_PROFILE:
                    gotoCompanyProfile("" + preference.getString(Constants.MY_COMPANY_ID));
                    break;
                case Constants.GOTO_COMMENTS_REPLAY:
                   gotoReplyPage(view,commentsItems.get(position),position);
                    break;
                case Constants.OWNER_USER_PROFILE:
                    gotoUserProfile("" + feedItem.getOwner().getUser_id());
                    break;
                case Constants.COMMENTS_USER_ID:
                    gotoUserProfile(String.valueOf(commentsItems.get(position).getUser_id()));
                    break;
                case Constants.POST_IMAGE_CALLBACK:
                    animateImage(feedItem.getAsset(), feedItem.getDescription(), feedItem, position);
                    break;


            }
        });
    }

    private void animateImage(String imgPath, String description, NewsFeedArray item, final int position) {
        FeedImageOverlayView overlayView = new FeedImageOverlayView(this);
        String[] posters = new String[]{imgPath};
        new ImageViewer.Builder<>(this, posters)
                .setOverlayView(overlayView)
                .setImageChangeListener(getImageChangeListener(description, item, position, overlayView))
                .show();
    }

    private ImageViewer.OnImageChangeListener getImageChangeListener(final String description, NewsFeedArray item, final int adapterPos, FeedImageOverlayView overlayView) {
        return position -> {
            // CustomImage image = images.get(position);
            overlayView.setDescription(description);
            overlayView.setNo_of_like("" + item.getLike_count());
            overlayView.setNo_of_comments("" + item.getComment_count());

            overlayView.setLikeEffect(item.getIs_like(), this);

            item.setUpdateCommentCountForImageOverlay(() -> {
                overlayView.setNo_of_comments("" + item.getComment_count());
                overlayView.setNo_of_like("" + item.getLike_count());
                overlayView.setLikeEffect(item.getIs_like(), this);
            });


            /**
             *
             *
             * Feed Like
             *
             * */
            overlayView.getLike_container().setOnClickListener(view -> {
                newsFeedUtils.sendLike(item, position, view, commentsRecyclerAdapter, preference, AnimationUtils.loadAnimation(this, R.anim.bounce),(isLike) -> {
                    overlayView.setLikeEffect(isLike, this);
                    overlayView.setNo_of_like("" + item.getLike_count());
                });

            });

            /**
             * Comments
             * */
            overlayView.getComment_container().setOnClickListener(view -> {
                //gotoCommentActivity(overlayView.getComment_container(), adapterPos);
            });
        };
    }


    private void gotoCompanyProfile(String companyId) {
        Intent intent = new Intent(this, CompanyProfileView.class);
        intent.putExtra(CompanyProfileView.INTENT_COMPANY_ID, companyId);
        startActivity(intent);
    }

    private void gotoUserProfile(String userId) {
        Intent intent = new Intent(this, UserProfileView.class);
        intent.putExtra(UserProfileView.INTENT_USER_ID, userId);
        startActivity(intent);
    }

    private void getComments(boolean pullRequest) {
        getAPI().getComments(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(feedItem.getId())).enqueue(new Callback<CommentsResponse>() {
            @Override
            public void onResponse(Call<CommentsResponse> call, Response<CommentsResponse> response) {


                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        List<CommentsDataResponse> tempComments = response.body().getData();
                        for (CommentsDataResponse item : tempComments) {
                            item.setTypeOfComment(Constants.COMMENT);
                        }
                        final List<CommentsDataResponse> comments = response.body().getData();

                        if (comments.size() > 0) {
                            if (lastCommentId == -1) {
                                for (int i = 0; i < comments.size(); i++) {
                                    comments.get(i).setItemIndex(i + commentsItems.size());
                                }
                                lastListSize = commentsItems.size();
                                commentsItems.addAll(comments);
                                CommentsActivity.this.feedItem.setComment_count(commentsItems.size() - 1);
                                commentsRecyclerAdapter.notifyItemChanged(0);
                                commentsRecyclerAdapter.notifyItemRangeInserted(lastListSize, commentsItems.size());
                                if (isSendBtnClick) {
                                    isSendBtnClick = false;
                                    commentsRecyclerView.scrollToPosition(commentsRecyclerAdapter.getItemCount() - 1);
                                }
                                lastCommentId = Long.parseLong(comments.get(comments.size() - 1).getCid());

                                if (getIntent().getBooleanExtra("from_notification", false)) {
                                    highlightView();
                                }

                            } else {
                                int i = 0;
                                while (i < comments.size()) {
                                    if (Long.parseLong(comments.get(i).getCid()) == lastCommentId) {
                                        break;
                                    }
                                    i++;
                                }

                                if (i + 1 < comments.size()) {
                                    List<CommentsDataResponse> newComments = comments.subList(i + 1, comments.size());

                                    for (int j = 0; j < newComments.size(); j++) {
                                        newComments.get(j).setItemIndex(i + commentsItems.size());
                                        newComments.get(j).setTypeOfComment(Constants.COMMENT);
                                    }
                                    lastListSize = commentsItems.size();
                                    commentsItems.addAll(newComments);
                                    CommentsActivity.this.feedItem.setComment_count(commentsItems.size() - 1);
                                    commentsRecyclerAdapter.notifyItemChanged(0);
                                    commentsRecyclerAdapter.notifyItemRangeInserted(lastListSize, commentsItems.size());

                                    if (isSendBtnClick) {
                                        isSendBtnClick = false;
                                        commentsRecyclerView.scrollToPosition(commentsRecyclerAdapter.getItemCount() - 1);
                                    }
                                    lastCommentId = Long.parseLong(comments.get(comments.size() - 1).getCid());
                                }
                            }
                        }

                    }


                    else{
                        //show the error Message
                        if(!pullRequest){
                            onResponseFailure();
                        }
                    }
                }

                else{
                    //show the error Message
                    if(!pullRequest){
                        onResponseFailure();
                    }
                }

                //hide the shimmer
                hideLoader();

                // pull for new data
                if (!exit) {
                    pull();
                }

            }

            @Override
            public void onFailure(Call<CommentsResponse> call, Throwable t) {

                if(!pullRequest){
                    onResponseFailure();
                }

                hideLoader();

                if (!exit) {
                    pull();
                }

            }
        });
    }

    private void hideLoader() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        if (commentsRecyclerView != null) {
            commentsRecyclerView.setVisibility(View.VISIBLE);
        }

    }

    private void postComment(int postId, String comment) {

        comment = appUtils.replaceScriptString(comment);
        if (comment.length() <= 0) {
            Toast.makeText(getApplicationContext(), Constants.INVALID_INPUT, Toast.LENGTH_SHORT).show();
            return;
        }
        getAPI().postComment(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(postId), String.valueOf(comment)).enqueue(new Callback<CommentPostModel>() {
            @Override
            public void onResponse(Call<CommentPostModel> call, Response<CommentPostModel> response) {

            }

            @Override
            public void onFailure(Call<CommentPostModel> call, Throwable t) {

            }
        });
    }

    private void getNewsFeedById() {
        getAPI().newsFeedGetById(preference.getString(Constants.ACCESS_TOKEN), getIntent().getStringExtra("postId")).enqueue(new Callback<NewsFeedByIdResponse>() {
            @Override
            public void onResponse(Call<NewsFeedByIdResponse> call, Response<NewsFeedByIdResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        if (response.body().getData().size() > 0) {
                            feedItem = response.body().getData().get(0);
                            setNormalPageToolbar(getApplicationContext(), "" + feedItem.getFirst_name() + " " + feedItem.getLast_name() + "'s post");
                            setUpCommentsAdapter();
                            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD);
                            return;
                        }
                    }
                }
                hideLoader();
                appUtils.gotoHomePage(CommentsActivity.this);
            }

            @Override
            public void onFailure(Call<NewsFeedByIdResponse> call, Throwable t) {
                hideLoader();
                appUtils.gotoHomePage(CommentsActivity.this);
            }
        });
    }

    @Override
    public void onBackPressed() {
        // super.onBackPressed();

        if (isTaskRoot()) {
            appUtils.gotoHomePage(CommentsActivity.this);
        } else {
            Intent intent = new Intent();
            intent.putExtra("likeCount", feedItem.getLike_count());
            intent.putExtra("isLike", feedItem.getIs_like());
            intent.putExtra("commentCount", commentsItems.size() - 1);
            intent.putExtra("item_index", getIntent().getIntExtra("item_index",0));
            setResult(RESULT_OK, intent);
            finish();
            overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == RESULT_OK) {
            if (requestCode == COMMENTS_REPLY_ACTIVITY_REQUEST_CODE) {
                String firstReply = data.getStringExtra("first_reply");
                if (firstReply.equals("No Items")) {
                    commentsItems.get(clickIndex).getReply().clear();
                } else {
                    CommentsReply commentsReply = gson.fromJson(firstReply, CommentsReply.class);
                    List<CommentsReply> commentsReplies = commentsItems.get(clickIndex).getReply();
                    if (commentsItems.get(clickIndex).getReply().size() > 0) {
                        commentsItems.get(clickIndex).getReply().set(0, commentsReply);
                    } else {
                        commentsItems.get(clickIndex).getReply().add(commentsReply);
                    }


                }
                commentsItems.get(clickIndex).setTotalLikes("" + data.getStringExtra("likeCount"));
                commentsItems.get(clickIndex).setIsLike(data.getIntExtra("isLike", 0));
                commentsItems.get(clickIndex).setChildCount("" + data.getIntExtra("reply_count", 0));

                commentsRecyclerAdapter.notifyDataSetChanged();
                commentsRecyclerAdapter.notifyItemChanged(clickIndex);
            } else if (requestCode == PRIVACY_ACTIVITY_CODE) {
                shareBottomSheet.updateDialogOnActivityResult(data);
            }
        }
    }

    private void pull() {
        getComments(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        exit = true;
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exit = true;
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        exit = false;
        pull();
    }

    private void highlightView() {
        String commentId = getIntent().getStringExtra("commentId");
        for (int i = 1; i < commentsItems.size(); i++) {
            if (commentsItems.get(i).getCid().equals(commentId)) {
                commentsItems.get(i).setFocusComment(true);
                commentsRecyclerAdapter.notifyItemChanged(i);
                commentsRecyclerView.scrollToPosition(i);
            }
        }
    }
}
