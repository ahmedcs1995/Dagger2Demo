package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobileapp.krank.Activities.DealerGroupScreen;
import com.mobileapp.krank.Activities.NetworkGroupScreen;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;

import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.Model.PrivacyItem;
import com.mobileapp.krank.R;

import java.util.ArrayList;
import java.util.List;

public class SelectPrivacyAdapter extends RecyclerView.Adapter<SelectPrivacyAdapter.ViewHolder> {
    public List<PrivacyItem> items;
    public PrivacyItem prevItem;
    Context context;

    CallBackWithAdapterPosition callBack;



    public class ViewHolder extends RecyclerView.ViewHolder {
        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView name;
        TextView des;
        ImageView privacy_img;
        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            name = item.findViewById(R.id.name);
            des = item.findViewById(R.id.des);
            privacy_img = item.findViewById(R.id.privacy_img);

            item.setOnClickListener(view -> {
                PrivacyItem item = items.get(getAdapterPosition());
                if(prevItem == null){
                    item.setItemSelected(true);
                    prevItem = item;
                    callBack.act(getAdapterPosition());
                    return;
                }
                prevItem.setItemSelected(false);
                item.setItemSelected(true);
                prevItem = item;
                callBack.act(getAdapterPosition());
            });

        }
    }

    public SelectPrivacyAdapter(List<PrivacyItem> items, Context context, CallBackWithAdapterPosition callBack) {
        this.items = items;
        this.context = context;
        this.callBack = callBack;
    }
    @Override
    public SelectPrivacyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.privacy_list_item, parent, false);
        return new SelectPrivacyAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final SelectPrivacyAdapter.ViewHolder holder, final int position) {
        final PrivacyItem item = items.get(position);


        holder.des.setText("" + item.getDes());

        holder.privacy_img.setImageResource(item.getImg());

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }

        holder.name.setText("" + item.getPrivacy());
    }
    @Override
    public int getItemCount() {
        return items.size();
    }


}









