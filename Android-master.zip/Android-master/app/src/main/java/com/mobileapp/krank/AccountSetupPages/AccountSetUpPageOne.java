package com.mobileapp.krank.AccountSetupPages;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

/**
 * Created by Ahmed on 3/30/2018.
 */

public class AccountSetUpPageOne extends BaseFragment {
    TextView text_view_name;
    private SaveInSharedPreference preference;





    public AccountSetUpPageOne() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.account_setup_page_one, container, false);
        setFragmentView(me);


        //preferences
        preference = ((AccountSetupPage)getActivity()).preference;

        //views
        text_view_name = me.findViewById(R.id.text_view_name);
        text_view_name.setText(AppUtils.autoCapitalWord(preference.getString(Constants.FIRST_NAME)));


        return me;
    }
}
