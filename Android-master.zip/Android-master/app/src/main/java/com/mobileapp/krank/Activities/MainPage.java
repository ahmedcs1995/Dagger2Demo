package com.mobileapp.krank.Activities;

import android.Manifest;
import android.app.Dialog;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.CallBacks.PhoneCodeAutoReadListener;
import com.mobileapp.krank.Functions.AppSignatureHelper;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DateTimeUtils;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.FollowPeopleDialog;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.HomePageTabs.MyConnections;
import com.mobileapp.krank.HomePageTabs.MyDealers;
import com.mobileapp.krank.HomePageTabs.MyNetworks;
import com.mobileapp.krank.HomePageTabs.Newsfeed;
import com.mobileapp.krank.Listeners.SmsListener;
import com.mobileapp.krank.Model.HomePageDataFlagContainer;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkDealersData;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.NotificationMsgBadgeResponse;
import com.mobileapp.krank.ResponseModels.UserMetaModel;
import com.mobileapp.krank.ResponseModels.UserMetaModelBody;
import com.mobileapp.krank.ViewModels.NewsFeedViewModel;

import org.jetbrains.annotations.NotNull;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainPage extends BaseActivity {


    public interface upDateListener {
        void onConnectionUpdated();
    }

    public interface PhoneNumberUpdateListener {
        void onUpdate();
    }



    /**
     * Intent Extras Keys
     * */
    public static String CURRENT_PAGE = "currentItem";


    //tabs value
    public static int CONNECTION_TAB_INDEX = 2;
    public static int NETWORK_TAB_INDEX = 1;
    public static int DEALER_TAB_INDEX = 3;
    public static int FEED_TAB_INDEX = 0;



    //phoneNumber change
    public PhoneNumberUpdateListener mPhoneNumberUpdateListener;

    //activity codes
    public static final int EDIT_PROFILE_CODE = 5000;


    public PhoneCodeAutoReadListener phoneCodeListener;
    private static final int DEALERS_TAB_INDEX = 3;

    //type face
    private Typeface mTypefaceBold;
    private Typeface mTypefaceNormal;
    //view pager and tab layout
    private TabLayout mCustomTabLayout;
    public ViewPager mViewPager;

    //other views
    private SimpleDraweeView profile_pic;
    private SimpleDraweeView company_image_view;
    private TextView profile_name_text_view, profile_designation_text_view, profile_address_text_view, network_text_view, connections_text_view, listing_text_view, total_company_text_view;



    //connection fab
    public FloatingActionMenu sort_fab;


    //fab btns
    public FloatingActionMenu fab;

    public FloatingActionMenu quick_access_fab;
    public FloatingActionButton market_place_fab;
    public FloatingActionButton add_listing_fab;


    //dealer fab
    public FloatingActionButton network_fab_container;
    public FloatingActionButton existing_dealer_fab_container;



    //toolbar btns
    TextView msg_count;
    TextView notification_count;

    //for pull
    public Handler handler;
    Runnable runnable;
    private static int SECONDS_TO_REFRESH = 2000;
    private boolean isMsgCountShown;
    private boolean isNotificationCountShown;
    private boolean exit;

    //fragments
    Newsfeed newsfeed;
    MyDealers myDealers;
    MyNetworks myNetworks;
    MyConnections myConnections;

    //backBtn
    CustomCallBack backCallBack;

    //drawer views
    View connection_container;
    View network_container;
    View listing_container;


    //update Listener for network connection dealer
    public upDateListener listener;

    //data for newsfeed
    public List<NewsFeedArray> newsFeedItems;
    public List<NewsFeedArray> localDbFeedItems;
    public List<GetNetworkEmployeeData> suggestedPeoples;
    public HomePageDataFlagContainer feedTabData;
    //view model
    public NewsFeedViewModel newsFeedViewModel;

    //for connections
    public List<ConnectionsDataModel> connectionItems;
    public HomePageDataFlagContainer connectionTabData;

    //for networks
    public List<NetworkList> networksItems;
    public HomePageDataFlagContainer networkTabData;

    //for dealers
    public List<NetworkDealersData> myDealersItems;
    public HomePageDataFlagContainer dealerTabData;

    //no internet
    private CoordinatorLayout coordinatorLayout;
    Snackbar snackbar;

    //phone number verified recently
    public boolean notRemovedThread;

    //sms
    SmsListener mSmsListener;


    ArrayList<String> appSignatures;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);


        initViews();



        setUpdateCallBack();


        init();


        initNewsFeedData();

        initConnectionsTabData();

        initNetworkTabData();

        initDealerTabData();


        setUpToolbarButtons(this);

        setViewPagerAndTabLayout();

        setDrawer(this, mViewPager);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {


            }

            @Override
            public void onPageSelected(int position) {
                if (position == DEALERS_TAB_INDEX && myDealersItems.size() > 0) {
                    fab.showMenuButton(true);
                    sort_fab.hideMenuButton(false);
                   quick_access_fab.hideMenuButton(false);
                    //showDealerFab();
                } else if (position == 2) {
                    quick_access_fab.hideMenuButton(false);
                    sort_fab.showMenuButton(false);
                    fab.hideMenuButton(true);
                    // showConnectionSortFab();
                }
                else if(position == 0){
                    quick_access_fab.showMenuButton(false);
                    sort_fab.hideMenuButton(true);
                    fab.hideMenuButton(false);
                }
                else {
                    fab.hideMenuButton(true);
                    sort_fab.hideMenuButton(true);
                    quick_access_fab.hideMenuButton(true);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        checkOrAskForMultipleRunTimePermission(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        //Manifest.permission.READ_PHONE_STATE

        Log.e("FCM_TOKEN","==> " + preference.getString(Constants.FIREBASE_TOKEN));


        setDataOnDrawerMenu();

        drawerCallBacks();

        setUpQuickAccessFabListeners();

        showDiscoverPeopleDialog();

    }

    public void bindSmsListener() {
        startSMSListener();

        mSmsListener.initOTPListener(new SmsListener.OTPReceiveListener() {
            @Override
            public void onOTPReceived(@NotNull String otp) {
                if (phoneCodeListener == null) return;
                phoneCodeListener.onCodeReceived(otp);
            }

            @Override
            public void onOTPTimeOut() {

            }
        });


        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);

        registerReceiver(mSmsListener, intentFilter);


    }

    private void showDiscoverPeopleDialog(){
        try {
            /**
             *  If already sync from other devices
             **/
            if(getApplicationRef().getmTotalContactsCount() > 0 || !AppUtils.isSimAvailable(this)) return;

            if(!shouldShowPopUp()) return;

            FollowPeopleDialog dialog = (FollowPeopleDialog) DialogFactory.getDialog(DialogFactory.DialogType.FOLLOW_PEOPLE, this);
            dialog.setShowDontAskButton(true).setListener(new FollowPeopleDialog.DialogClickListener() {
                @Override
                public void onGetStartedClick(@NotNull Dialog dialog) {
                    //redirect to Discover people
                    Intent intent = new Intent(MainPage.this,DiscoverPeople.class);
                    intent.putExtra(DiscoverPeople.FROM_DASHBOARD,true);
                    startActivity(intent);

                }

                @Override
                public void onDontAskMeClick(@NotNull Dialog dialog) {
                    //show another pop up with message of discover people
                    setUserMeta(Constants.CONTACT_POP_UP_DONT_ASK_ME_VALUE);
                    dialog.dismiss();
                    showDontAskMeDialog();
                    //show another pop up
                }

                @Override
                public void onCloseClick(@NotNull Dialog dialog) {
                    //close the pop up
                    dialog.dismiss();
                    //set the current time stamp
                    preference.setString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN,DateTimeUtils.getCurrentUTCTime());

                    setUserMeta(DateTimeUtils.getCurrentUTCTime());
                }
            });


            dialog.show();
            preference.setString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN,DateTimeUtils.getCurrentUTCTime());

        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    private void setUserMeta(String metaVal){
        ArrayList<UserMetaModel> userMetaModel = new ArrayList<>();

        userMetaModel.add(new UserMetaModel(Constants.CONTACT_POPUP_META_KEY,metaVal));

        getAPI().setUserMeta(preference.getString(Constants.ACCESS_TOKEN),new UserMetaModelBody(userMetaModel)).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if(response.isSuccessful()){

                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                //t.getStackTrace();
            }
        });
    }

    private void showDontAskMeDialog(){
        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Information")
                .setDescription("You can find \"Discover People\" on top left menu")
                .setConfirmButtonText("OK")
                .hideCancelButton()
                .setCancelableDialog(false)
                .setConfirmButtonListener(dialog1 -> {
                    showHideDiscoverFocus(true);
                    dialog1.dismiss();
                });

        dialog.show();
    }


    /**
     * Date Difference
     */
    private boolean shouldShowPopUp() throws ParseException {
        return (!(preference.getString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN).equals(Constants.CONTACT_POP_UP_DONT_ASK_ME_VALUE))
                &&
                DateTimeUtils.getTimeDifference(preference.getString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN)) >= Constants.POP_UP_DURATION_TO_SHOW);
    }

    public String getAppSignature(){
        //Used to generate hash signature
        if(appSignatures == null){
            appSignatures = new AppSignatureHelper(MainPage.this).getAppSignatures();
        }
        if(appSignatures.size() > 0){
            return appSignatures.get(0);
        }

        return null;

    }

    private void startSMSListener() {

        SmsRetriever.getClient(this).startSmsRetriever()
                .addOnSuccessListener(aVoid -> {

                }).addOnFailureListener(e -> {

        });
    }

    /*
     * Connection Tab
     */
    private void initConnectionsTabData() {
        connectionItems = new ArrayList<>();
        connectionItems.add(new ConnectionsDataModel(MyConnections.TYPE_HEADER));
        connectionTabData = new HomePageDataFlagContainer(false, null);
    }

    /*
     * Network Tab
     */
    private void initNetworkTabData() {
        networksItems = new ArrayList<>();
        networksItems.add(new NetworkList(MyNetworks.TYPE_HEADER));
        networkTabData = new HomePageDataFlagContainer(false, null);
    }

    /*
     * Dealer Tab
     */
    private void initDealerTabData() {
        myDealersItems = new ArrayList<>();
        dealerTabData = new HomePageDataFlagContainer(false);
    }

    /*
     * NewsFeed Tab
     */
    private void initNewsFeedData() {
        newsFeedItems = new ArrayList<>();
        suggestedPeoples = new ArrayList<>();
        localDbFeedItems = new ArrayList<>();
        feedTabData = new HomePageDataFlagContainer(false);


        //adding data
        newsFeedItems.add(new NewsFeedArray(Constants.SHARE_UPDATE));

        if (!isPhoneNumberVerified()) {
            notRemovedThread = true;
            newsFeedItems.add(getPhoneNumberListItem());
        }


        newsFeedItems.add(new NewsFeedArray(Constants.INVITE_COMPANIES));


        if (isBussinessEmail()) {
            newsFeedItems.add(new NewsFeedArray(Constants.ADD_CO_WORKERS));
        }


        //view model
        newsFeedViewModel = ViewModelProviders.of(MainPage.this).get(NewsFeedViewModel.class);

        observeFeedData();
    }

    private NewsFeedArray getPhoneNumberListItem() {
        NewsFeedArray feedArray = new NewsFeedArray(Constants.VERIFY_PHONE_NUMBER_VIEW);
        feedArray.setPhoneNumber(preference.getString(Constants.MOBILE_NUMBER));
        feedArray.setPhoneNumberVerificationState(isMobileNumberEmpty() ? NewsFeedArray.ALREADY_IN_USE : NewsFeedArray.NOT_VERIFIED);
        return feedArray;
    }

    private boolean isMobileNumberEmpty() {
        return preference.getString(Constants.MOBILE_NUMBER).isEmpty();
    }

    /*
     * Update callBack
     */
    private void setUpdateCallBack() {
        listener = () -> {
            if (myConnections == null) return;
            myConnections.upDateConnectionsData();
            dealerTabData.setDataLoaded(false);
        };
    }


    private void drawerCallBacks() {
        profile_pic.setOnClickListener(view -> {
            //  appUtils.gotoUserProfile(getApplicationContext(), preference.getString(Constants.USER_ID), preference);
            gotoUserProfileActivityResult(MainPage.this);
        });

        company_image_view.setOnClickListener(view -> {
            appUtils.gotoCompanyProfile(getApplicationContext(), preference.getString(Constants.MY_COMPANY_ID), preference);

        });


        connection_container.setOnClickListener(view -> {
            mViewPager.setCurrentItem(CONNECTION_TAB_INDEX);
            closeDrawer();
        });

        network_container.setOnClickListener(view -> {
            mViewPager.setCurrentItem(NETWORK_TAB_INDEX);
            closeDrawer();
        });

        listing_container.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MyListingPage.class);
            startActivity(intent);
        });

        total_company_text_view.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MarketPlacePage.class);
            intent.putExtra("currentItem", 0);
            intent.putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE);
            startActivity(intent);
        });
    }


    private void init() {


        //fonts
        mTypefaceBold = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_BOLD);
        mTypefaceNormal = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_NORMAL);


        //fragment pages
        if (isBussinessEmail()) {
            myDealers = new MyDealers();
        }
        newsfeed = new Newsfeed();

        //setting network tab
        myNetworks = new MyNetworks();

        myConnections = new MyConnections();
        //fragment pages


        backCallBack = () -> {
            finishAffinity();
        };

        //flags
        isMsgCountShown = false;
        isNotificationCountShown = false;
        exit = false;

        //delay
        handler = new Handler();
        runnable = () -> getBadgeCount();

        //toolbar badges
        initBadgeCounts();

        //fab
        initMenuFab();

        mSmsListener = new SmsListener();
    }

    /*
     * Toolbar Badges
     */
    private void initBadgeCounts() {
        msg_count.setScaleX(0);
        msg_count.setScaleY(0);

        notification_count.setScaleX(0);
        notification_count.setScaleY(0);

    }

    /*
     * Floating Action Btn
     */
    private void initMenuFab() {
        fab.setClosedOnTouchOutside(false);
        //fab.setVisibility(View.GONE);
        fab.hideMenuButton(false);

        sort_fab.hideMenuButton(false);

    }





    /**
     * Views
     */
    private void initViews() {
        profile_pic = findViewById(R.id.profile_pic);
        company_image_view = findViewById(R.id.company_image_view);

        /*fab btns*/
        fab = findViewById(R.id.fab_menu);
        sort_fab = findViewById(R.id.sort_fab);

        network_fab_container = findViewById(R.id.network_fab_container);
        existing_dealer_fab_container = findViewById(R.id.existing_dealer_fab_container);

        quick_access_fab = findViewById(R.id.quick_access_fab);
        quick_access_fab.setClosedOnTouchOutside(true);

        market_place_fab = findViewById(R.id.market_place_fab);
        add_listing_fab = findViewById(R.id.add_listing_fab);

        /*fab btns*/

        profile_name_text_view = findViewById(R.id.profile_name_text_view);
        profile_designation_text_view = findViewById(R.id.profile_designation_text_view);
        profile_address_text_view = findViewById(R.id.profile_address_text_view);
        network_text_view = findViewById(R.id.networks_text_view);
        connections_text_view = findViewById(R.id.connections_text_view);
        listing_text_view = findViewById(R.id.listing_text_view);
        total_company_text_view = findViewById(R.id.total_company_text_view);


        connection_container = findViewById(R.id.connection_container);
        network_container = findViewById(R.id.network_container);
        listing_container = findViewById(R.id.listing_container);


        msg_count = findViewById(R.id.msg_count);
        notification_count = findViewById(R.id.notification_count);


        coordinatorLayout = findViewById(R.id.coordinatorlayout);


        if (!AppUtils.checkNetworkState(this)) {
            showNoInternetDialog();
        }
    }

    private void setUpQuickAccessFabListeners(){
        market_place_fab.setOnClickListener(view -> gotoMarketPlace(this));
        add_listing_fab.setOnClickListener(view -> gotoAddListings(this));
    }
    private void showNoInternetDialog() {
    /*    snackbar = Snackbar
                .make(coordinatorLayout, "No Internet Available", Snackbar.LENGTH_INDEFINITE)
                .setAction("Dismiss", view -> snackbar.dismiss());
        snackbar.show();*/
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == EDIT_PROFILE_CODE) {
                if (getApplicationRef().isNumberChange) {
                    if (mPhoneNumberUpdateListener != null) {
                        getApplicationRef().isNumberChange = false;
                        mPhoneNumberUpdateListener.onUpdate();
                    } else {
                        if (!isPhoneNumberVerified()) {
                            newsFeedItems.add(1, getPhoneNumberListItem());
                        }

                    }
                }

            }
        }
    }

    private void setViewPagerAndTabLayout() {
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mCustomTabLayout = findViewById(R.id.sliding_tabs);
        ArrayList<BaseFragment> pages = new ArrayList<>();

        pages.add(newsfeed);
        pages.add(myNetworks);
        pages.add(myConnections);

        //setupDealer Fragment
        if (isBussinessEmail()) {


            pages.add(myDealers);
        }

        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));

        mCustomTabLayout.setupWithViewPager(mViewPager);

        //  mViewPager.setOffscreenPageLimit(pages.size());
        mViewPager.setOffscreenPageLimit(1);


        setInitialTabLayoutConfig();

        if (getIntent().getExtras() != null) {
            mViewPager.setCurrentItem(getIntent().getIntExtra(CURRENT_PAGE, 0));
        }

        mCustomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
                TextView text = (TextView) tab.getCustomView();
                text.setTypeface(mTypefaceBold);
                text.setTextColor(getResources().getColor(R.color.AppDarkGray));
                text.setTextSize(Constants.TAB_TEXT_SIZE);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TextView text = (TextView) tab.getCustomView();

                text.setTypeface(mTypefaceNormal);
                text.setTextColor(getResources().getColor(R.color.drawerGray));
                text.setTextSize(Constants.TAB_TEXT_SIZE);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
              /*  if (tab.getPosition() == 0) {
                    newsfeed.scrollToTop();
                }*/
            }

        });
    }

    /*
     * ViewModel Observer
     */
    private void observeFeedData() {
        newsFeedViewModel.getAllConversaionList().observe(this, feed -> {
            try {
                localDbFeedItems.clear();
                for (int i = 0; i < feed.size(); i++) {
                    newsfeed.setDataInModel(feed.get(i));
                }
                localDbFeedItems.addAll(feed);
            } catch (Exception ex) {

            }

        });
    }


    private void setInitialTabLayoutConfig() {
        for (int i = 0; i < mCustomTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mCustomTabLayout.getTabAt(i);
            if (tab != null) {
                TextView tabTextView = new TextView(this);
                tab.setCustomView(tabTextView);

                tabTextView.getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
                tabTextView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;

                tabTextView.setTextColor(getResources().getColor(R.color.drawerGray));
                tabTextView.setTypeface(mTypefaceNormal);
                tabTextView.setTextSize(Constants.TAB_TEXT_SIZE);

                tabTextView.setText(tab.getText());

                // First tab is the selected tab, so if i==0 then set BOLD typeface
                if (i == getIntent().getIntExtra(CURRENT_PAGE, 0)) {
                    tabTextView.setTypeface(mTypefaceBold);
                    tabTextView.setTextColor(getResources().getColor(R.color.AppDarkGray));
                }

            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setDataOnDrawerMenu();
        exit = false;
        getBadgeCount();

    }

    /*
     * Drawer Data
     */
    private void setDataOnDrawerMenu() {

        profile_pic.setImageURI(Constants.BASE_IMG_URL + preference.getString(Constants.PROFILE_PICTURE));
        company_image_view.setImageURI(Constants.BASE_IMG_URL + preference.getString(Constants.COMPANY_PROFILE_PICTURE));

        profile_name_text_view.setText(preference.getString(Constants.FIRST_NAME) + " " + preference.getString(Constants.LAST_NAME));
        profile_designation_text_view.setText(preference.getString(Constants.JOB_TITLE) + " @ " + preference.getString(Constants.COMPANY_NAME));
        profile_address_text_view.setText(preference.getString(Constants.CITY) + " " + preference.getString(Constants.COUNTRY));

        network_text_view.setText(preference.getString(Constants.NETWORK_COUNT));
        connections_text_view.setText(preference.getString(Constants.CONNECTION_COUNT));
        listing_text_view.setText(preference.getString(Constants.LIST_COUNT));
        total_company_text_view.setText(preference.getString(Constants.TOTAL_COMPANY_LIST) + " / " + preference.getString(Constants.TOTAL_COMPANY_LIST_LIMIT));


    }

    @Override
    public void onBackPressed() {
        if (getIntent().getBooleanExtra("from_messaging", false)) {
            super.onBackPressed();
            return;
        }
        finishAffinity();
    }

    private void handleBackPress() {
        switch (mViewPager.getCurrentItem()) {
            case 0:
                newsfeed.focusToTop(backCallBack);
                break;
            case 1:
                mViewPager.setCurrentItem(0);
                break;
            case 2:
                mViewPager.setCurrentItem(0);
                break;
            case 3:
                mViewPager.setCurrentItem(0);
                break;

        }
    }

    private String concatenateCountryCity() {
        if (preference.getString(Constants.CITY).length() > 0 && preference.getString(Constants.COUNTRY).length() > 0) {
            return preference.getString(Constants.CITY) + " , " + preference.getString(Constants.COUNTRY);
        } else if (preference.getString(Constants.CITY).length() > 0) {
            return preference.getString(Constants.CITY);
        } else if (preference.getString(Constants.COUNTRY).length() > 0) {
            return preference.getString(Constants.COUNTRY);
        } else {
            return "";
        }
    }

    /*
     * Badge Count
     */
    private void getBadgeCount() {
        getAPI().notification_msg_badge(preference.getString(Constants.ACCESS_TOKEN)).enqueue(new Callback<NotificationMsgBadgeResponse>() {
            @Override
            public void onResponse(Call<NotificationMsgBadgeResponse> call, Response<NotificationMsgBadgeResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getData().getMessage_badge().equals("0")) {
                        if (isMsgCountShown) {
                            isMsgCountShown = false;
                            msg_count.animate()
                                    .scaleY(0).scaleX(0)
                                    .setDuration(200)
                                    .start();
                        }
                    } else {
                        if (!isMsgCountShown) {
                            isMsgCountShown = true;
                            msg_count.animate()
                                    .scaleY(1).scaleX(1)
                                    .setDuration(200)
                                    .start();
                        }
                    }
                    if (response.body().getData().getNotification_badge().equals("0")) {
                        if (isNotificationCountShown) {
                            isNotificationCountShown = false;
                            notification_count.animate()
                                    .scaleY(0).scaleX(0)
                                    .setDuration(200)
                                    .start();
                        }
                    } else {
                        if (!isNotificationCountShown) {
                            isNotificationCountShown = true;
                            notification_count.animate()
                                    .scaleY(1).scaleX(1)
                                    .setDuration(200)
                                    .start();
                        }
                    }

                    msg_count.setText("" + response.body().getData().getMessage_badge());
                    notification_count.setText("" + response.body().getData().getNotification_badge());

                    if (!exit) {
                        pull();
                    }

                }
            }

            @Override
            public void onFailure(Call<NotificationMsgBadgeResponse> call, Throwable t) {
                if (!exit) {
                    pull();
                }
            }
        });
    }

    private void pull() {
        handler.postDelayed(runnable, SECONDS_TO_REFRESH);
    }

    @Override
    public void onStop() {
        super.onStop();
        exit = true;
        unRegisterListener();
    }

    private void unRegisterListener(){
        try {
            unregisterReceiver(mSmsListener);
        }catch (Exception e){

        }

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        exit = true;
    }


}