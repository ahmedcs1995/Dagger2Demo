package com.mobileapp.krank.MyListingTabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.MyListingPage;
import com.mobileapp.krank.Adapters.MyListingAdapter;
import com.mobileapp.krank.Base.BaseFragment;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Model.Enums.TypeOfListing;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.PublicMarketPlaceResponse;
import com.mobileapp.krank.Scroll.EndlessOnScrollListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class MyListingSale extends BaseFragment {

    private RecyclerView listingRecyclerView;
    private MyListingAdapter listingRecyclerAdapter;
    List<ListingDataArray> items;


    int offset;

    Handler handler;
    Runnable runnable;
    private static int SECONDS_TO_LOAD = 500;
    boolean firstTimeInit;
    boolean isItemsAdded;
    SwipeRefreshLayout swipeRefreshLayout;
    boolean isSwipeRefreshCall;

    String keyword;
    String search_type;
    String category_id;
    String sub_category_id;
    String type_id;

    String sort_by;
    String sort_by_network;
    String sort_by_connection;

    public int clickIndex;
    public static int LISTING_DETAIL_CODE = 500;

    private static String RENT_LISTING_CODE = "1";

    TextView no_item_found_view;

    public MyListingSale() {
        setTitle("Sale");
    }

    AppUtils appUtils;

    Gson gson;

    //shimmer loader
    ShimmerFrameLayout shimmerFrameLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View me = inflater.inflate(R.layout.listing_page, container, false);
        setFragmentView(me);


        init();

        initViews();

        initValues();


        setUpAdapter();

        //getPublicMarketPlace();


        // start the loader
        startShimmer();

        //request the api
        handler.postDelayed(runnable, SECONDS_TO_LOAD);
        return me;
    }

   /* public void setListingCode(int code){
        this.listingCode = code;
    }*/


    private void initViews() {

        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);

        shimmerFrameLayout = (ShimmerFrameLayout) findViewById(R.id.shimmer_layout);

        no_item_found_view = (TextView) findViewById(R.id.no_item_found_view);
        no_item_found_view.setText(Constants.NO_LISTING_FOUND_TEXT);
        no_item_found_view.setVisibility(View.GONE);
    }


    private void startShimmer() {
        shimmerFrameLayout.startShimmer();
    }

    private void stopShimmer() {
        shimmerFrameLayout.stopShimmer();
        shimmerFrameLayout.setVisibility(View.GONE);
    }


    private void init() {
        handler = new Handler();
        runnable = () -> getData();

        keyword = "0";
        category_id = "0";
        sub_category_id = "0";
        type_id = "0";
        sort_by = "0";
        sort_by_network = "0";
        sort_by_connection = "0";
        gson = CustomGson.getInstance();
        appUtils = AppUtils.getInstance();
    }

    private void setUpAdapter() {


        listingRecyclerView = (RecyclerView) findViewById(R.id.sale_listing_result_recycler);


        items = new ArrayList<>();

        // items.add(new ListingDataArray(TypeOfListing.LOADER));


        listingRecyclerAdapter = new MyListingAdapter(items, this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        listingRecyclerView.setLayoutManager(layoutManager);
        listingRecyclerView.setAdapter(listingRecyclerAdapter);


        ((SimpleItemAnimator) listingRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


        listingRecyclerView.addOnScrollListener(new EndlessOnScrollListener(layoutManager) {
            @Override
            public void onScrolledToEnd() {
                if (!firstTimeInit && !isSwipeRefreshCall && isItemsAdded) {
                    isItemsAdded = false;
                    offset += Constants.PAGE_LIMIT_1;
                    handler.postDelayed(runnable, SECONDS_TO_LOAD);
                }
            }
        });

        swipeRefreshLayout.setOnRefreshListener(() -> {
            isSwipeRefreshCall = true;
            items.clear();
            offset = 0;
            listingRecyclerView.getRecycledViewPool().clear();
            listingRecyclerAdapter.notifyDataSetChanged();
            swipeRefreshLayout.setRefreshing(true);
            handler.postDelayed(runnable, SECONDS_TO_LOAD);
        });

    }

    private void removeLoader() {
        for (int i = (items.size() - 1); i >= 0; i--) {
            if (items.get(i).getTypeOfListing() == TypeOfListing.LOADER) {
                removeAt(i);
                break;
            }
        }
    }

    public void removeAt(int position) {
        items.remove(position);
        listingRecyclerAdapter.notifyItemRemoved(position);
        listingRecyclerAdapter.notifyItemRangeChanged(position, items.size());
    }

    private void handleFailure() {
        if (firstTimeInit) {
            stopShimmer();
        } else {
            removeLoader();
        }
        firstTimeInit = false;
        // Toast.makeText(getContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
        try{
            ((MyListingPage)getActivity()).onResponseFailure();
        }catch (Exception ex){

        }
    }

    private void handleResponse(List<ListingDataArray> tempData) {

        if (firstTimeInit) {
            stopShimmer();
        } else {
            removeLoader();
        }


        for (ListingDataArray item : tempData) {
            item.setTypeOfListing(TypeOfListing.POST);
        }
        firstTimeInit = false;
        isSwipeRefreshCall = false;
        swipeRefreshLayout.setRefreshing(false);

        if (tempData.size() <= 0) {
            isItemsAdded = false;
        } else if (tempData.size() < 9) {
            isItemsAdded = false;
            insertIntoList(tempData);
        } else {
            isItemsAdded = true;
            tempData.add(new ListingDataArray(TypeOfListing.LOADER));
            insertIntoList(tempData);
        }

        if (items.size() <= 0) {
            no_item_found_view.setVisibility(View.VISIBLE);
        } else {
            no_item_found_view.setVisibility(View.GONE);
        }
    }

    private void insertIntoList(List<ListingDataArray> data) {
        int lastListSize = items.size();
        items.addAll(data);
        listingRecyclerAdapter.notifyItemRangeInserted(lastListSize, items.size());
    }

    private void getData() {
        ((MyListingPage) getActivity()).getAPI().getMyListingData(((MyListingPage) getActivity()).preference.getString(Constants.ACCESS_TOKEN), "" + RENT_LISTING_CODE, category_id, sub_category_id, type_id, keyword, search_type, sort_by, sort_by_network, sort_by_connection, offset,Constants.PAGE_LIMIT_1).enqueue(new Callback<PublicMarketPlaceResponse>() {
            @Override
            public void onResponse(Call<PublicMarketPlaceResponse> call, Response<PublicMarketPlaceResponse> response) {
                if (response.isSuccessful()) {
                    handleResponse(response.body().getData().getListing());
                }
            }

            @Override
            public void onFailure(Call<PublicMarketPlaceResponse> call, Throwable t) {
                handleFailure();
            }
        });
    }

    private void initValues() {
        offset = 0;
        firstTimeInit = true;
        isSwipeRefreshCall = false;
        isItemsAdded = true;
    }

    public void performSearchFilterization(String keyword, String search_type) {
        this.keyword = keyword;
        this.search_type = search_type;
        initValues();
        items.clear();
        listingRecyclerView.getRecycledViewPool().clear();
        listingRecyclerAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(true);
        handler.postDelayed(runnable, SECONDS_TO_LOAD);
    }

    public void performCategoryFilterization(String category_id, String sub_category_id, String type_id) {
        this.category_id = category_id;
        this.sub_category_id = sub_category_id;
        this.type_id = type_id;
        initValues();
        items.clear();
        listingRecyclerView.getRecycledViewPool().clear();
        listingRecyclerAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(true);
        handler.postDelayed(runnable, SECONDS_TO_LOAD);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == Constants.LISTING_DETAIL_CODE) {
                items.get(data.getIntExtra("item_index", 0)).setIsFav(data.getStringExtra("isFavValue"));
                listingRecyclerAdapter.notifyItemChanged(data.getIntExtra("item_index", 0));
            } else if (requestCode == Constants.PRIVACY_ACTIVITY_CODE) {
                listingRecyclerAdapter.getShareBottomSheet().updateDialogOnActivityResult(data);
            } else if (requestCode == MyListingAdapter.ASSIGN_REP_ACTIVITY_CODE) {
                boolean removeItem = data.getBooleanExtra("remove_item_from_list", false);
                int itemIndex = data.getIntExtra("item_index", 0);
                if (removeItem) {
                    items.remove(itemIndex);
                    listingRecyclerAdapter.notifyItemRemoved(itemIndex);
                    listingRecyclerAdapter.notifyItemRangeChanged(itemIndex, items.size());
                } else {
                    items.get(itemIndex).setRepresentativeData(getAssignData(data.getStringExtra("assign_data")));
                    listingRecyclerAdapter.notifyItemChanged(itemIndex);
                }

            }
        }
    }

    public List<GetNetworkEmployeeData> getAssignData(String data) {
        return Arrays.asList(gson.fromJson(data, GetNetworkEmployeeData[].class));
    }

}
