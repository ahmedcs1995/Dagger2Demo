package com.mobileapp.krank.Model;

public class PrivacyItem {
    String privacy;
    String des;
    boolean isItemSelected;
    int img;


    public PrivacyItem(String privacy) {
        this.privacy = privacy;
    }

    public PrivacyItem(String privacy, String des, int img) {
        this.privacy = privacy;
        this.des = des;
        this.img = img;
    }

    public String getPrivacy() {
        return privacy;
    }

    public void setPrivacy(String privacy) {
        this.privacy = privacy;
    }

    public boolean isItemSelected() {
        return isItemSelected;
    }

    public void setItemSelected(boolean itemSelected) {
        isItemSelected = itemSelected;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
