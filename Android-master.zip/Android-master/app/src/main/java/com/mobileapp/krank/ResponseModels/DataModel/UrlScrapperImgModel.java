package com.mobileapp.krank.ResponseModels.DataModel;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class UrlScrapperImgModel {
    @SerializedName("img")
    @Expose
    private String img;
    @SerializedName("width")
    @Expose
    private Integer width;
    @SerializedName("height")
    @Expose
    private Integer height;
    @SerializedName("area")
    @Expose
    private Integer area;
    @SerializedName("offset")
    @Expose
    private Integer offset;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getArea() {
        return area;
    }

    public void setArea(Integer area) {
        this.area = area;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

}



