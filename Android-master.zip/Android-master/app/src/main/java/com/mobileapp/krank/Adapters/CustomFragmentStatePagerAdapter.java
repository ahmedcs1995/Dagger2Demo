package com.mobileapp.krank.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.mobileapp.krank.Base.BaseFragment;

import java.util.ArrayList;

public class CustomFragmentStatePagerAdapter extends FragmentStatePagerAdapter {
    ArrayList<BaseFragment> pages;

    public CustomFragmentStatePagerAdapter(FragmentManager fm, ArrayList<BaseFragment> pgs) {
        super(fm);
        pages = pgs;
    }

    @Override
    public int getCount() {
        return pages.size();
    }

    @Override
    public Fragment getItem(int position) {
        return pages.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return (pages.get(position) != null ? pages.get(position).getTitle() : "");
    }
}
