package com.mobileapp.krank.ResponseModels

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlin.collections.ArrayList

data class ContactsPostDataModel(
        @SerializedName("country_code") @Expose val country_code: String?,
        @SerializedName("offset") @Expose val offset: Int,
        @SerializedName("limit") @Expose val limit: Int,
        @SerializedName("sim_id") @Expose val sim_id: String?,
        @SerializedName("contacts") @Expose val contacts: ArrayList<ContactsDataModel>,
        @SerializedName("delete_contacts") @Expose val delete_contacts: ArrayList<DeleteContactDataModel>)

data class ContactsDataModel(
        @SerializedName("number") @Expose val number: String,
        @SerializedName("name") @Expose val name: String,
        @SerializedName("local_contact_id") @Expose val local_contact_id: String
)
data class DeleteContactDataModel(
        @SerializedName("id") @Expose val id: String
)