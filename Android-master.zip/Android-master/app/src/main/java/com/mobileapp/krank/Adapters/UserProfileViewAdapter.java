package com.mobileapp.krank.Adapters;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.CallBacks.CallBackWithPosTypeAndView;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.NewsFeedFunctions;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.CheckInHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.DealerPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.EmptyNewsFeed;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ImageViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.LinkViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ListingArticleViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.Loader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkNotConnectedViewHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.NetworkPost;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.OtherEmploysInnerRecyclerAdapter;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.PersonalProfileFeed.OtherProfileViewHeader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.PersonalProfileFeed.ProfileViewHeader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.ProfileInfoViewHeader;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.TextPostHolder;
import com.mobileapp.krank.ViewHolders.NewsFeedViewHolders.VideoPostViewHolder;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsForCompanyProfileViewDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;
import com.mobileapp.krank.ResponseModels.DataModel.PublicProfileData;
import com.mobileapp.krank.Utils.SaveInSharedPreference;


import java.util.ArrayList;
import java.util.List;
/**
 * Created by Ahmed on 5/10/2018.
 */

public class UserProfileViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    //list
    private List<NewsFeedArray> items;

    //activity Ref
    UserProfileView activity;

    //my profile data
    public PublicProfileData myProfileData;



    SaveInSharedPreference preference;
    DeviceInfo deviceInfo;
    //horizontal list
    List<ConnectionsForCompanyProfileViewDataModel> connectionsForCompanyProfileViewDataModels;
    //newsfeed post type functions
    NewsFeedFunctions newsFeedFunctions;


    //callBack
    CallBackWithPosTypeAndView callBack;


    public void setListener(CallBackWithPosTypeAndView callBack) {
        this.callBack = callBack;
    }




    public void setUpdatedData(PublicProfileData myProfileData) {
        this.myProfileData = myProfileData;
        this.connectionsForCompanyProfileViewDataModels = myProfileData.getMyConnections();

    }

    public UserProfileViewAdapter(List<NewsFeedArray> items, UserProfileView activity, DeviceInfo deviceInfo) {
        this.items = items;
        this.activity = activity;
        preference = new SaveInSharedPreference(activity);
        this.deviceInfo = deviceInfo;
        newsFeedFunctions = new NewsFeedFunctions(activity, deviceInfo, false);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case Constants.PERSONAL_PROFILE_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_collapse_header, parent, false);
                return new ProfileViewHeader(view,callBack);
            case Constants.OTHER_PROFILE_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.other_personal_profile_view_item, parent, false);
                return new OtherProfileViewHeader(view,callBack);
            case Constants.INFO_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.collapseable_people_info_item_layout, parent, false);
                return new ProfileInfoViewHeader(view,callBack);
            case Constants.TEXT_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_post_item_layout, parent, false);
                return new TextPostHolder(view, callBack);
            case Constants.IMAGE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_post_item_layout, parent, false);
                return new ImageViewHolder(view, callBack);
            case Constants.LINKED_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.link_post_item_layout, parent, false);
                return new LinkViewHolder(view, callBack);
            case Constants.LOADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case Constants.CHECK_IN:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkin_post_item_layout, parent, false);
                return new CheckInHolder(view, callBack);
            case Constants.NETWORK_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_post_item_layout, parent, false);
                return new NetworkPost(view, callBack);
            case Constants.LISTING_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.YOUTUBE_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.ARTICLE_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view, callBack);
            case Constants.DEALER_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_post_item_layout, parent, false);
                return new DealerPost(view, callBack);
            case Constants.VIMEO_VIDEO:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_post_item_layout, parent, false);
                return new VideoPostViewHolder(view, callBack);
            case Constants.OTHER_CONNECTION_EMPLOYS_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.horizontal_people_list, parent, false);
                return new OtherEmploysInnerRecyclerAdapter(view,activity,connectionsForCompanyProfileViewDataModels);
            case Constants.OFFICIAL_DEALERS_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case Constants.EMPTY_NEWS_FEED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_news_feed, parent, false);
                return new EmptyNewsFeed(view);
            case Constants.PROFILE_VIEW_LOADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_view_loader, parent, false);
                return new Loader(view);
            case Constants.AUCTION_POST:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.type_listing_article_post_item_layout, parent, false);
                return new ListingArticleViewHolder(view,callBack);
            case Constants.NETWORK_NOT_CONNECTED_VIEW:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.network_not_connected_view, parent, false);
                return new NetworkNotConnectedViewHolder(view);
            default:
                return null;

        }
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).getPostType();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public NewsFeedFunctions getNewsFeedFunctions() {
        return newsFeedFunctions;
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, items.size());

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final NewsFeedArray item = items.get(position);


        item.setCallBackWithAdapterPosition((pos) -> {
            removeAt(pos);
        });

        item.setCommentClick((position1, item1, view) -> {
            if (callBack == null) return;
            callBack.act(position1, Constants.COMMENT_CALLBACK, view);
        });


        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        params.topMargin = 16;

        switch (item.getPostType()) {
            case Constants.PERSONAL_PROFILE_VIEW:
                params.topMargin = 0;
                ((ProfileViewHeader)holder).setProfileViewHeader(myProfileData);
                break;
            case Constants.PROFILE_VIEW_LOADER:
                params.topMargin = 0;
                break;
            case Constants.IMAGE_POST:
                newsFeedFunctions.setTypeImgPost(holder, item);
                break;
            case Constants.LINKED_POST:
                newsFeedFunctions.setTypeLinkedPost(holder, item);
                break;
            case Constants.TEXT_POST:
                newsFeedFunctions.setTypeTextPost(holder, item);
                break;
            case Constants.LOADER:
                break;
            case Constants.CHECK_IN:
                newsFeedFunctions.setCheckInTypePost(holder, item);
                break;
            case Constants.NETWORK_POST:
                newsFeedFunctions.setNetworkPost(holder, item);
                break;
            case Constants.DEALER_POST:
                newsFeedFunctions.setDealerPost(holder, item);
                break;
            case Constants.LISTING_POST:
                newsFeedFunctions.setTypeListingPost(holder, item);
                break;
            case Constants.YOUTUBE_VIDEO:
                newsFeedFunctions.setTypeYoutubeVideoPost(holder, item);
                break;
            case Constants.ARTICLE_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Article");
                break;
            case Constants.AUCTION_POST:
                newsFeedFunctions.setTypeArticleAuctionPost(holder, item, "Auction");
                break;
            case Constants.VIMEO_VIDEO:
                newsFeedFunctions.setTypeVimeoVideoPost(holder, item);
                break;
            case Constants.OTHER_POST:
                break;
            case Constants.INFO_POST:
                ((ProfileInfoViewHeader)holder).onBindUserInfo(myProfileData);
                break;
            case Constants.OTHER_PROFILE_VIEW:
                params.topMargin = 0;
                ((OtherProfileViewHeader)holder).setProfileViewHeader(myProfileData,activity,deviceInfo);
                break;
            case Constants.OTHER_CONNECTION_EMPLOYS_VIEW:
                ((OtherEmploysInnerRecyclerAdapter) holder).setOtherCompanyEmploysView( myProfileData.getCompanyName());
                break;
            case Constants.EMPTY_NEWS_FEED:
                ((EmptyNewsFeed)holder).setEmptyNewsFeedItem(item);
                break;


        }
    }
}




