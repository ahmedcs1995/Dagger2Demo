package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupChatMessagesGroupDataModel {
    @SerializedName("group_id")
    @Expose
    private String groupId;
    @SerializedName("group_name")
    @Expose
    private String groupName;
    @SerializedName("group_user_id")
    @Expose
    private String groupUserId;
    @SerializedName("group_added")
    @Expose
    private String groupAdded;
    @SerializedName("group_updated")
    @Expose
    private String groupUpdated;
    @SerializedName("group_is_auction")
    @Expose
    private String groupIsAuction;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupUserId() {
        return groupUserId;
    }

    public void setGroupUserId(String groupUserId) {
        this.groupUserId = groupUserId;
    }

    public String getGroupAdded() {
        return groupAdded;
    }

    public void setGroupAdded(String groupAdded) {
        this.groupAdded = groupAdded;
    }

    public String getGroupUpdated() {
        return groupUpdated;
    }

    public void setGroupUpdated(String groupUpdated) {
        this.groupUpdated = groupUpdated;
    }

    public String getGroupIsAuction() {
        return groupIsAuction;
    }

    public void setGroupIsAuction(String groupIsAuction) {
        this.groupIsAuction = groupIsAuction;
    }

}
