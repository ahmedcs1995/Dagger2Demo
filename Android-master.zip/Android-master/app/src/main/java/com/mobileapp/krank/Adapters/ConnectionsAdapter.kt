package com.mobileapp.krank.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.chauthai.swipereveallayout.SwipeRevealLayout
import com.chauthai.swipereveallayout.ViewBinderHelper

import com.facebook.drawee.view.SimpleDraweeView
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType
import com.mobileapp.krank.CustomViews.VerticalFaView
import com.mobileapp.krank.CustomViews.VerticalTextView
import com.mobileapp.krank.HomePageTabs.MyConnections
import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader
import com.mobileapp.krank.Functions.AppUtils

import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel
import com.mobileapp.krank.ViewHolders.CommonViewHolder.RecyclerHeaderViewHolder

/**
 * Created by Yaseen on 25/04/2018.
 */


class ConnectionsAdapter(private val items: List<ConnectionsDataModel>, internal var context: Context?, internal var callBack: CallBackWithAdapterPosAndType) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val binderHelper = ViewBinderHelper()



    private var swipeOpenId : String?=null


    init {
        binderHelper.setOpenOnlyOne(true)
    }


    inner class ConnectionViewHolder(internal var item: View) : RecyclerView.ViewHolder(item) {
        internal var profile_image_view: SimpleDraweeView = item.findViewById(R.id.profile_image_view)
        internal var employee_name_text_view: TextView = item.findViewById(R.id.employee_name_text_view)
        internal var company_designation_name: TextView = item.findViewById(R.id.company_designation_name)
        internal var country_and_city_text_view: TextView = item.findViewById(R.id.country_and_city_text_view)
        internal var company_image_view: SimpleDraweeView = item.findViewById(R.id.company_image_view)
        internal var private_connection_line: View = item.findViewById(R.id.private_connection_line)
        internal var icon: VerticalFaView = item.findViewById(R.id.icon)
        internal var swipeLayout: SwipeRevealLayout = item.findViewById(R.id.swipe_layout)
        private var content_view: View = item.findViewById(R.id.content_view)
        private var private_connection_btn: View = item.findViewById(R.id.private_connection_btn)

        init {

            content_view.setOnClickListener { callBack.act(adapterPosition, ITEM_CLICK) }

            company_image_view.setOnClickListener { callBack.act(adapterPosition, COMPANY_IMG_CLICK) }

            content_view.setOnLongClickListener {
                if(adapterPosition < 0) return@setOnLongClickListener false

                if(items[adapterPosition].isConnectionPrivate) return@setOnLongClickListener false

                swipeLayout.open(true)
                swipeOpenId = items[adapterPosition].companyData.userId
                return@setOnLongClickListener true
            }

            private_connection_btn.setOnClickListener {
                swipeLayout.close(true)
                swipeOpenId = null
                callBack.act(adapterPosition, MARK_AS_PRIVATE_CLICK)
            }
        }
    }

    fun closeLastOpenLayout(){
        if(swipeOpenId == null) return

        binderHelper.closeLayout(swipeOpenId)
        swipeOpenId=null
    }


    override fun getItemViewType(position: Int): Int {
        return when (items[position].type) {
            Constants.LOADER_VIEW -> 1
            Constants.ITEM_VIEW -> 2
            MyConnections.TYPE_HEADER -> 0
            else -> Constants.LOADER_VIEW
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View
        return when (viewType) {
            0 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.recycler_header, parent, false)
                RecyclerHeaderViewHolder(v)
            }
            2 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.my_connections_list_item, parent, false)
                ConnectionViewHolder(v)
            }
            1 -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.chat_loader_item, parent, false)
                AppListItemLoader(v)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {


        val item = items[position]

        if (item.type == Constants.ITEM_VIEW) {
            setItemView(item, holder as ConnectionViewHolder)
        } else {

        }


    }


    private fun setItemView(item: ConnectionsDataModel, holder: ConnectionViewHolder) {




        /**
         * Private Connection
         * */

        if(item.isConnectionPrivate){
            holder.private_connection_line.visibility = View.VISIBLE
            holder.icon.text = AppUtils.fromHtml("&#xf070;")

        }else{
            holder.private_connection_line.visibility = View.GONE
        }


        if (item.companyData != null) {


            binderHelper.bind(holder.swipeLayout, "" + item.companyData.userId)


            holder.swipeLayout.setLockDrag(true)


            holder.employee_name_text_view.text = item.companyData.firstName + " " + item.companyData.lastName

            val city = if (item.companyData.userCityName != null) item.companyData.userCityName else "N/A"
            val country = if (item.companyData.userCountryName != null) item.companyData.userCountryName else "N/A"

            holder.country_and_city_text_view.text = "$city, $country"
            holder.company_designation_name.text = AppUtils.getCompanyAndDesignation(item.companyData.companyName,item.companyData.jobTitle)

            holder.profile_image_view.setImageURI(Constants.BASE_IMG_URL + item.companyData.userProfilePic)
            holder.company_image_view.setImageURI(Constants.BASE_IMG_URL + item.companyData.companyProfilePic)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    companion object {

        const val ITEM_CLICK = 1
        const val COMPANY_IMG_CLICK = 2
        const val MARK_AS_PRIVATE_CLICK = 3
    }

}





