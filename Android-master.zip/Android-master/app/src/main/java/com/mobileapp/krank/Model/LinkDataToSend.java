package com.mobileapp.krank.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LinkDataToSend {
    @SerializedName("link_title")
    @Expose
    private String link_title;
    @SerializedName("link_description")
    @Expose
    private String link_description;
    @SerializedName("link_image")
    @Expose
    private String link_image;
    @SerializedName("link_url")
    @Expose
    private String link_url;

    @SerializedName("video_url")
    @Expose
    private String video_url;


    public LinkDataToSend(String link_title, String link_description, String link_image, String link_url,String video_url) {
        this.link_title = link_title;
        this.link_description = link_description;
        this.link_image = link_image;
        this.link_url = link_url;
        this.video_url = video_url;
    }

    public String getLink_title() {
        return link_title;
    }

    public void setLink_title(String link_title) {
        this.link_title = link_title;
    }

    public String getLink_description() {
        return link_description;
    }

    public void setLink_description(String link_description) {
        this.link_description = link_description;
    }

    public String getLink_image() {
        return link_image;
    }

    public void setLink_image(String link_image) {
        this.link_image = link_image;
    }

    public String getLink_url() {
        return link_url;
    }

    public void setLink_url(String link_url) {
        this.link_url = link_url;
    }
}
