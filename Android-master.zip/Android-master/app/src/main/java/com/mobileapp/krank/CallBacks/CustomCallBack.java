package com.mobileapp.krank.CallBacks;


/**
 * Created by Yaseen on 13/04/2018.
 */

public interface CustomCallBack {
    void act();
}
