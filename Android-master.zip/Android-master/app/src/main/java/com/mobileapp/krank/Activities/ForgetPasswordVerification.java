package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.GeneralResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPasswordVerification extends BaseActivity {

    String finalCode = "";

    //views
    Button setPasswordBtn;
    TextView resend_code;
    PinView pinView;
    private SweetAlertDialog showProgressAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password_verification);

        //views
        setPasswordBtn = (Button) findViewById(R.id.setPasswordBtn);
        pinView = findViewById(R.id.pinView);

        //pin view listener
        pinView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                finalCode = charSequence.toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        //loader
        showProgressAlert = showAlert("Checking please wait...", SweetAlertDialog.PROGRESS_TYPE, false);

        //enable bottom links
        gotoLinkPage();


        resend_code = findViewById(R.id.resend_code);


        resend_code.setOnClickListener(v -> {
            onResendCodeClickListener();
        });


        setScreenHeader("Forgot Password");
        setImageIntermsOfDeviceResolution();
        setKrankLogoForUserProfiling();


        setPasswordBtn.setOnClickListener(view -> {
            //finalCode = editTextStop.getText().toString() + editTextStop2.getText().toString() + editTextStop3.getText().toString() + editTextStop4.getText().toString();
            confirm(finalCode);
        });
    }


    private void onResendCodeClickListener() {

        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("Code Not Received")
                .setDescription("Didn't receive the code?")
                .setConfirmButtonText("Yes")
                .setCancelButtonText("No")
                .setConfirmButtonListener(dialog1 -> {
                    dialog1.dismiss();
                })
                .setCancelButtonListener(dialog1 -> {
                    resendCode();
                    dialog1.dismiss();
                });

        dialog.show();
    }

    private void resendCode(){
        //set loader text
        showProgressAlert.setContentText("Resending please wait...");
        showProgressAlert.show();

        getAPI().forgotPassword(getIntent().getStringExtra("USER_EMAIL")).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ForgetPasswordVerification.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    showProgressAlert.dismiss();
                } else {
                    onResponseFailure();
                    showProgressAlert.dismiss();
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                onResponseFailure();
            }
        });
    }

    private void confirm(final String code) {
        if (code.length() != 4) {
            showToast("Please enter code correctly");
        } else {
            //set loader text
            showProgressAlert.setContentText("Checking please wait...");
            showProgressAlert.show();


            getAPI().forgotPasswordVerification(getIntent().getStringExtra("USER_EMAIL"), code).enqueue(new Callback<GeneralResponse>() {
                @Override
                public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                    showProgressAlert.dismiss();

                    GeneralResponse codeVerificationResponse = response.body();
                    if (response.isSuccessful()) {

                        showToast(codeVerificationResponse.getMessage());

                        if (codeVerificationResponse.getStatus().equals("success")) {
                            //proceed
                            Intent intent = new Intent(ForgetPasswordVerification.this, ForgetPasswordNewPassword.class);
                            intent.putExtra("USER_EMAIL", getIntent().getStringExtra("USER_EMAIL"));
                            intent.putExtra("FORGOT_VERIFY_CODE", code);
                            startActivity(intent);
                            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                        }
                    }else{
                        onResponseFailure();
                    }
                }

                @Override
                public void onFailure(Call<GeneralResponse> call, Throwable t) {
                    showProgressAlert.dismiss();
                    onResponseFailure();

                }
            });
        }
    }

}
