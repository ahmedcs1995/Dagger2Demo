package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.mobileapp.krank.Adapters.CarousalCardsAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.Base.CustomApplication
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Functions.DialogFactory
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog
import com.mobileapp.krank.Model.Enums.CardsListenerType
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ResponseModels.GeneralResponse
import com.mobileapp.krank.ResponseModels.NetworkListResponse
import com.yarolegovich.discretescrollview.DiscreteScrollView
import com.yarolegovich.discretescrollview.transform.ScaleTransformer
import kotlinx.android.synthetic.main.activity_my_networks_card2.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception
import java.util.ArrayList

class MyNetworksCard : BaseActivity() {

    //list items
    lateinit var items: MutableList<NetworkList>
    private var cardsAdapter: CarousalCardsAdapter<NetworkList>? = null

    //current index
    private var currentItem: Int = 0
    private var reminderCount: Int = 0

    //pagination
    internal var offset: Int = 0

    //flags
    var isDataDeleted: Boolean = false
    internal var shouldScrollCall = true

    val handler = Handler()
    var runnable: Runnable? = null
    lateinit var app: CustomApplication


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_networks_card2)


        runnable = Runnable {
            getData()
        }
        init()

        setUpAdapter()
    }

    private fun init() {
        items = ArrayList()

        currentItem = intent.getIntExtra("currentItem", 0)


        offset = intent.getIntExtra("offset", 0)
        reminderCount = intent.getIntExtra("reminderCount", 0)


        shouldScrollCall = reminderCount > 0


        app = applicationContext as CustomApplication


    }

    private fun setUpAdapter() {


        items.addAll(app.networksItems)

        cardsAdapter = CarousalCardsAdapter(CarousalCardsAdapter.COMPANY_VIEW, items, this, deviceResolution, object : CarousalCardsAdapter.CardsListeners {
            override fun onBind(holder: RecyclerView.ViewHolder, position: Int) {
                if (items[position].type == Constants.ITEM_VIEW) {

                    cardsAdapter?.setCompanyCardView(holder as CarousalCardsAdapter<NetworkList>.CompanyCardsViewHolder, items[position], position)
                }
            }

            override fun getViewType(position: Int): Int {
                var item: NetworkList = items[position]
                return when (item.type) {
                    Constants.ITEM_VIEW -> CarousalCardsAdapter.ITEM_VIEW
                    Constants.LOADER_VIEW -> CarousalCardsAdapter.LOADER_VIEW
                    else -> CarousalCardsAdapter.LOADER_VIEW
                }
            }

        }, object : CarousalCardsAdapter.ClickListeners {
            override fun itemClickListener(position: Int, type: CardsListenerType) {
                when (type) {
                    CardsListenerType.DELETE -> {
                        if (items[position].isDelete != "0") {
                            showRemoveDialog(items[position].companyId.toInt(), position)
                        } else {
                            showToast("Can't remove this network")
                        }
                    }

                    CardsListenerType.VIEW_LISTING -> {
                        viewListing(items[position])
                    }
                    CardsListenerType.VIEW_PROFILE -> {
                        profileView(items[position])
                    }
                    CardsListenerType.COMPANY_IMG -> {
                        profileView(items[position])
                    }
                    CardsListenerType.VIEW_EMPLOYEES -> {
                        viewConnections(items[position], false)
                    }

                    CardsListenerType.VIEW_YOUR_CONNECTIONS -> {
                        viewConnections(items[position], true)
                    }


                }
            }

        })

        carosuel_view.adapter = cardsAdapter

        carosuel_view.setItemTransitionTimeMillis(130)

        carosuel_view.setItemTransformer(ScaleTransformer.Builder().setMinScale(0.90f)
                .build())

        carosuel_view.scrollToPosition(currentItem)
        setCompanyNameOnToolbar(items[currentItem].companyName)


        carosuel_view.addScrollStateChangeListener(object : DiscreteScrollView.ScrollStateChangeListener<RecyclerView.ViewHolder> {
            override fun onScrollStart(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {

            }

            override fun onScrollEnd(currentItemHolder: RecyclerView.ViewHolder, adapterPosition: Int) {

                if (items[adapterPosition].type == Constants.ITEM_VIEW) {
                    setCompanyNameOnToolbar(items[adapterPosition].companyName)
                }


                if (adapterPosition == items.size - 1 && shouldScrollCall) {
                    shouldScrollCall = false

                    items.add(NetworkList(Constants.LOADER_VIEW))
                    cardsAdapter!!.notifyItemInserted(items.size)


                    offset += Constants.PAGE_LIMIT

                    handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong() * 2)

                }
            }

            override fun onScroll(scrollPosition: Float, currentPosition: Int, newPosition: Int, currentHolder: RecyclerView.ViewHolder?, newCurrent: RecyclerView.ViewHolder?) {
                /*if (items[newPosition].type == Constants.ITEM_VIEW) {
                    setCompanyNameOnToolbar(items[newPosition].companyName)
                }*/
            }
        })
    }

    private fun showRemoveDialog(companyId: Int, position: Int) {


        val dialog: NormalAppDialog = (DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this) as NormalAppDialog)
                .setHeading("Are you sure you want to remove this network?")
                .setDescription("You will also be removed from this user's network list.")
                .setConfirmButtonText("Confirm")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener {
                    isDataDeleted = true

                    removeNetwork(companyId)

                    it.dismiss()

                    //remove the thread
                    items.removeAt(position)
                    cardsAdapter!!.notifyDataSetChanged()


                    if (items.size == 0) {
                        onBackPressed()
                        return@setConfirmButtonListener
                    }

                    if (position < items.size && items[position].type == Constants.ITEM_VIEW) {
                        setCompanyNameOnToolbar(items[position].companyName)
                    } else if (position - 1 >= 0 && position - 1 < items.size && items[position - 1].type == Constants.ITEM_VIEW) {
                        setCompanyNameOnToolbar(items[position - 1].companyName)
                    } else {
                        setCompanyNameOnToolbar("")
                    }
                }
        dialog.show()


    }

    private fun setCompanyNameOnToolbar(companyName: String) {
        setNormalPageToolbar( "$companyName's Card")
    }

    private fun getData() {

        api.getNetworkByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "", intent.getStringExtra("keyword"), Constants.PAGE_LIMIT).enqueue(object : Callback<NetworkListResponse> {
            override fun onResponse(call: Call<NetworkListResponse>, response: Response<NetworkListResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == "success") {
                        if (response.body().data.networkList.size > 0) {

                            //setting toolbar name
                            if (carosuel_view.currentItem == items.size - 1) {
                                setCompanyNameOnToolbar(response.body().data.networkList[0].companyName)
                            }

                            items[items.size - 1] = response.body().data.networkList[0]
                            cardsAdapter!!.notifyItemChanged(items.size - 1)


                            if (response.body().data.networkList.size > 2) {
                                val oldSize = items.size

                                items.addAll(response.body().data.networkList.subList(1, response.body().data.networkList.size))


                                cardsAdapter!!.notifyItemRangeInserted(oldSize, items.size)

                                //enable the scroll
                                shouldScrollCall = response.body().data.reminderCount > 0


                            }
                        }
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                }
            }

            override fun onFailure(call: Call<NetworkListResponse>, t: Throwable) {
                showToast(Constants.ERROR_MSG_TOAST_1)
            }
        })
    }

    private fun viewConnections(item: NetworkList, viewYourConnection: Boolean) {
        val intent = Intent(this, ListOfEmployeesAndConnections::class.java)
        with(intent) {
            putExtra(ListOfEmployeesAndConnections.NAME_KEY, item.companyName)
            putExtra(ListOfEmployeesAndConnections.COMPANY_ID, item.companyId)
            putExtra(ListOfEmployeesAndConnections.IS_VIEW_YOUR_CONNECTION_CLICK, viewYourConnection)
        }

        startActivity(intent)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun profileView(item: NetworkList) {

        appUtils.gotoCompanyProfile(this, item.companyId, preference)
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2)
    }

    private fun viewListing(item: NetworkList) {
        val intent = Intent(this, MarketPlacePage::class.java)
        with(intent) {
            putExtra("currentItem", 0)
            putExtra("networkId", item.companyId)
            putExtra("connectionId", "0")
            putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE)
            putExtra(MarketPlacePage.TOOLBAR_NAME, item.companyName)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }


    private fun removeNetwork(companyId: Int) {
        api.removeNetwork(preference.getString(Constants.ACCESS_TOKEN), companyId).enqueue(object : Callback<GeneralResponse> {
            override fun onFailure(call: Call<GeneralResponse>?, t: Throwable?) {
                showToast(Constants.ERROR_MSG_TOAST_1)
            }

            override fun onResponse(call: Call<GeneralResponse>?, response: Response<GeneralResponse>?) {

                if (response!!.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        showToast("Successfully removed network")
                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                }
            }

        })
    }


    override fun onBackPressed() {
        if (isDataDeleted) {
            app.networksItems = items
            val intent = Intent()
            intent.putExtra("isDataDeleted", isDataDeleted)
            intent.putExtra("offset", offset)
            setResult(RESULT_OK, intent)
            finish()
            overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
            return
        }
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down)
    }
}
