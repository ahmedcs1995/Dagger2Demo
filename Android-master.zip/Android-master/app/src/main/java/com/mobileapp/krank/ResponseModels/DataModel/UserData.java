package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 5/19/2018.
 */

public class UserData {


    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("tmp_user_id")
    @Expose
    private String tmpUserId;
    @SerializedName("new_company")
    @Expose
    private boolean newCompany;
    @SerializedName("verify_code")
    @Expose
    private String verifyCode;
    @SerializedName("old_company_name")
    @Expose
    private String oldCompanyName;
    @SerializedName("company_info")
    @Expose
    private CompanyInfoCodeVerification companyInfo;

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getTmpUserId() {
        return tmpUserId;
    }

    public void setTmpUserId(String tmpUserId) {
        this.tmpUserId = tmpUserId;
    }

    public boolean isNewCompany() {
        return newCompany;
    }

    public void setNewCompany(boolean newCompany) {
        this.newCompany = newCompany;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public String getOldCompanyName() {
        return oldCompanyName;
    }

    public void setOldCompanyName(String oldCompanyName) {
        this.oldCompanyName = oldCompanyName;
    }

    public CompanyInfoCodeVerification getCompanyInfo() {
        return companyInfo;
    }

    public void setCompanyInfo(CompanyInfoCodeVerification companyInfo) {
        this.companyInfo = companyInfo;
    }

}