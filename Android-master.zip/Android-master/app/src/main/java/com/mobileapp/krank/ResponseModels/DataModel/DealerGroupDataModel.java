package com.mobileapp.krank.ResponseModels.DataModel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.CallBacks.CustomCallBack;

import java.util.List;

public class DealerGroupDataModel{
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("group_name")
    @Expose
    private String groupName;
    @SerializedName("date_added")
    @Expose
    private String dateAdded;
    @SerializedName("date_updated")
    @Expose
    private String dateUpdated;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("created_by")
    @Expose
    private String createdBy;
    @SerializedName("companyData")
    @Expose
    private List<DealerGroupCompanyDataModel> companyData = null;

    private boolean isItemChecked;

    public boolean isItemChecked() {
        return isItemChecked;
    }

    public void setItemChecked(boolean itemChecked) {
        isItemChecked = itemChecked;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(String dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public List<DealerGroupCompanyDataModel> getCompanyData() {
        return companyData;
    }

    public void setCompanyData(List<DealerGroupCompanyDataModel> companyData) {
        this.companyData = companyData;
    }

    public DealerGroupDataModel(){}
}

