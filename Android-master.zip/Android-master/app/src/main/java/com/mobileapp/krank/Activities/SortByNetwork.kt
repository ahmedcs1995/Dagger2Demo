package com.mobileapp.krank.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.SimpleItemAnimator
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

import com.mobileapp.krank.Adapters.SortByNetworkAdapter
import com.mobileapp.krank.Base.BaseActivity
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.R
import com.mobileapp.krank.ResponseModels.DataModel.NetworkList
import com.mobileapp.krank.ResponseModels.NetworkListResponse
import com.mobileapp.krank.Scroll.EndlessOnScrollListener

import java.util.ArrayList

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SortByNetwork : BaseActivity(), CallBackWithAdapterPosition {

    //list
    private var sortRecyclerView: RecyclerView? = null
    private var sortRecyclerAdapter: RecyclerView.Adapter<*>? = null
    internal lateinit var Items: MutableList<NetworkList>
    internal lateinit var layoutManager: LinearLayoutManager


    var checkIndex: Int = 0

    //views
    internal lateinit var loader: ProgressBar
    internal lateinit var no_item_found_view: TextView
    internal lateinit var reset_btn: View
    internal lateinit var done_btn: View

    //pagination
    private var offset: Int = 0
    private var shouldScrollCall: Boolean = false


    //delay
    internal lateinit var handler: Handler
    internal lateinit var runnable: Runnable
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_sort_by_network)

        shouldScrollCall = false
        checkIndex = -1
        offset = 0

        //delay
        handler = Handler()
        runnable = Runnable {
            getData()
        }

        //views
        loader = findViewById(R.id.loader)
        reset_btn = findViewById(R.id.reset_btn)
        done_btn = findViewById(R.id.done_btn)

        no_item_found_view = findViewById<View>(R.id.no_item_found_view) as TextView
        no_item_found_view.text = Constants.NO_NETWORK_FOUND_TEXT
        no_item_found_view.visibility = View.GONE

        setNormalPageToolbar("Sort By Network")

        if (intent.extras != null && intent.getBooleanExtra("show_reset_btn", false)) {
            reset_btn.visibility = View.VISIBLE
        } else {
            reset_btn.visibility = View.GONE
        }


        reset_btn.setOnClickListener {
            val intent = Intent()
            intent.putExtra("reset_click", true)
            setResult(RESULT_OK, intent)
            finish()
        }

        setUpAdapter()

        getData()

        addOnDoneBtnListener()

    }

    private fun addOnDoneBtnListener() {
        done_btn.setOnClickListener {
            if(checkIndex < 0) {
                showToast(Constants.SELECT_OPTION)
                return@setOnClickListener
            }
            val intent = Intent()
            intent.putExtra("companyId", "" + Items[checkIndex].companyId)
            intent.putExtra("companyName", "" + Items[checkIndex].companyName)
            Log.e("sending com Id", "" + Items[checkIndex].companyId)
            setResult(RESULT_OK, intent)
            finish()
        }
    }

    private fun setUpAdapter() {

        sortRecyclerView = findViewById(R.id.sort_recycler)
        Items = ArrayList()

        layoutManager = LinearLayoutManager(this@SortByNetwork)
        sortRecyclerAdapter = SortByNetworkAdapter(Items, this@SortByNetwork, this)
        sortRecyclerView!!.layoutManager = layoutManager
        sortRecyclerView!!.adapter = sortRecyclerAdapter
        (sortRecyclerView!!.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false

        addOnRecyclerViewScrollListener()
    }

    private fun onScrollEnd() {
        if (shouldScrollCall) {
            shouldScrollCall = false
            offset += Constants.PAGE_LIMIT
            handler.postDelayed(runnable, Constants.SECONDS_TO_LOAD.toLong())
        }
    }

    private fun checkForData() {
        if (Items.size <= 0) {
            no_item_found_view.visibility = View.VISIBLE
        } else {
            no_item_found_view.visibility = View.GONE
        }
    }

    private fun addOnRecyclerViewScrollListener() {
        sortRecyclerView!!.addOnScrollListener(object : EndlessOnScrollListener(layoutManager) {
            override fun onScrolledToEnd() {
                onScrollEnd()
            }
        })
    }

    private fun getData() {
        api.getNetworkByPage(preference.getString(Constants.ACCESS_TOKEN), offset, "","",Constants.PAGE_LIMIT).enqueue(object : Callback<NetworkListResponse> {
            override fun onResponse(call: Call<NetworkListResponse>, response: Response<NetworkListResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {


                        val tempList = response.body().data.networkList

                        removeLoader()

                        loader.visibility = View.GONE



                        if (intent.extras != null && intent.getStringExtra("selected_network_group") != null) {
                            for (i in tempList.indices) {
                                if (tempList[i].companyId == intent.getStringExtra("selected_network_group")) {
                                    tempList[i].isItemCheck = true
                                    checkIndex = Items.size + i
                                }
                            }
                        }
                        val oldSize = Items.size




                        Items.addAll(tempList)

                        if (tempList.size >= Constants.PAGE_LIMIT) {
                            Items.add(NetworkList(Constants.LOADER_VIEW))
                            shouldScrollCall = true
                        }


                        sortRecyclerAdapter!!.notifyItemRangeInserted(oldSize, Items.size)
                        checkForData()
                    }
                }
            }

            override fun onFailure(call: Call<NetworkListResponse>, t: Throwable) {

            }
        })
    }


    private fun removeLoader() {
        for (i in Items.indices.reversed()) {
            if (Items[i].type == Constants.LOADER_VIEW) {
                Items.removeAt(i)
                sortRecyclerAdapter!!.notifyItemRemoved(i)
                break
            }
        }
    }

    override fun act(position: Int) {
        Items[position].isItemCheck = !Items[position].isItemCheck

        sortRecyclerAdapter!!.notifyItemChanged(position)


        if (checkIndex != -1 && checkIndex != position && Items.size > checkIndex) {
            Items[checkIndex].isItemCheck = false
            sortRecyclerAdapter!!.notifyItemChanged(checkIndex)
        }
        checkIndex = position

    }
}
