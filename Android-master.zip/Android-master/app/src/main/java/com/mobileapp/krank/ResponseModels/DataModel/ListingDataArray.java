package com.mobileapp.krank.ResponseModels.DataModel;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Model.Enums.TypeOfListing;

public class ListingDataArray implements Parcelable {

    public enum TypeOfView{
        DEALER,
        COMPANY,
        USER,
        NONE
    }


    TypeOfListing typeOfListing;
    @SerializedName("companyName")
    @Expose
    private String companyName;
    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("user_slug")
    @Expose
    private String userSlug;
    @SerializedName("list_slug")
    @Expose
    private String listSlug;
    @SerializedName("lu_id")
    @Expose
    private String luId;
    @SerializedName("companyId")
    @Expose
    private String companyId;
    @SerializedName("isFav")
    @Expose
    private String isFav;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("lid")
    @Expose
    private String lid;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("listing")
    @Expose
    private String listing;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("listing_name")
    @Expose
    private String listingName;
    @SerializedName("category")
    @Expose
    private String category;
    @SerializedName("sub_category")
    @Expose
    private String subCategory;
    @SerializedName("cat_type")
    @Expose
    private String catType;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("manufacturer")
    @Expose
    private String manufacturer;
    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("equipment_number")
    @Expose
    private String equipmentNumber;
    @SerializedName("s_no")
    @Expose
    private String sNo;
    @SerializedName("lengths")
    @Expose
    private String lengths;
    @SerializedName("cylinders")
    @Expose
    private String cylinders;
    @SerializedName("capacity")
    @Expose
    private String capacity;
    @SerializedName("drive")
    @Expose
    private String drive;
    @SerializedName("min_amp")
    @Expose
    private String minAmp;
    @SerializedName("max_amp")
    @Expose
    private String maxAmp;
    @SerializedName("year_of_manf")
    @Expose
    private String yearOfManf;
    @SerializedName("power_fuel")
    @Expose
    private String powerFuel;
    @SerializedName("power")
    @Expose
    private String power;
    @SerializedName("transmission")
    @Expose
    private String transmission;
    @SerializedName("max_lifting")
    @Expose
    private String maxLifting;
    @SerializedName("flow_rate")
    @Expose
    private String flowRate;
    @SerializedName("condition")
    @Expose
    private String condition;
    @SerializedName("weight")
    @Expose
    private String weight;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("modified_date")
    @Expose
    private String modifiedDate;
    @SerializedName("available")
    @Expose
    private Object available;
    @SerializedName("available_distance")
    @Expose
    private String availableDistance;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("price_privacy")
    @Expose
    private String pricePrivacy;
    @SerializedName("listing_privacy")
    @Expose
    private String listingPrivacy;
    @SerializedName("latlng")
    @Expose
    private String latlng;
    @SerializedName("max_lifting_unit")
    @Expose
    private String maxLiftingUnit;
    @SerializedName("flow_rate_unit")
    @Expose
    private String flowRateUnit;
    @SerializedName("energy")
    @Expose
    private String energy;
    @SerializedName("registration_number")
    @Expose
    private String registrationNumber;
    @SerializedName("number_of_seats")
    @Expose
    private String numberOfSeats;
    @SerializedName("listing_flight_rules")
    @Expose
    private String listingFlightRules;
    @SerializedName("total_time")
    @Expose
    private String totalTime;
    @SerializedName("av_condition")
    @Expose
    private String avCondition;
    @SerializedName("zip")
    @Expose
    private String zip;
    @SerializedName("hash")
    @Expose
    private String hash;
    @SerializedName("price_per_day")
    @Expose
    private Object pricePerDay;
    @SerializedName("views")
    @Expose
    private String views;
    @SerializedName("ref_num")
    @Expose
    private String refNum;
    @SerializedName("inventory_id")
    @Expose
    private String inventoryId;
    @SerializedName("show_in_marketplace")
    @Expose
    private int showInMarketplace;
    @SerializedName("is_deleted")
    @Expose
    private String isDeleted;
    @SerializedName("watermark")
    @Expose
    private String watermark;
    @SerializedName("wm_type")
    @Expose
    private String wmType;
    @SerializedName("wm_position")
    @Expose
    private String wmPosition;
    @SerializedName("wm_image")
    @Expose
    private String wmImage;
    @SerializedName("wm_text")
    @Expose
    private String wmText;
    @SerializedName("wm_image_type")
    @Expose
    private String wmImageType;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("u_profile_pic")
    @Expose
    private String uProfilePic;
    @SerializedName("listing_url")
    @Expose
    private String listing_url;
    @SerializedName("IMAGE_NAME")
    @Expose
    private String iMAGENAME;
    @SerializedName("cu_id")
    @Expose
    private int cuId;
    @SerializedName("user_url")
    @Expose
    private String userUrl;
    @SerializedName("companyUrl")
    @Expose
    private String companyUrl;
    @SerializedName("user_badge")
    @Expose
    private String userBadge;
    @SerializedName("conStatus")
    @Expose
    private String conStatus;
    @SerializedName("netStatus")
    @Expose
    private String netStatus;
    @SerializedName("assignments")
    @Expose
    private List<PublicMarketPlaceAssignment> assignments = null;
    @SerializedName("assignCount")
    @Expose
    private int assignCount;
    @SerializedName("dealers")
    @Expose
    private List<DealerDataListing> dealers = null;
    @SerializedName("dealersCount")
    @Expose
    private int dealersCount;
    @SerializedName("compCity")
    @Expose
    private String compCity;
    @SerializedName("compCountry")
    @Expose
    private String compCountry;
    @SerializedName("desc")
    @Expose
    private String desc;
    @SerializedName("is_acc")
    @Expose
    private int isAcc;
    @SerializedName("is_acc_type")
    @Expose
    private int isAccType;

    @SerializedName("pricePrivacy")
    @Expose
    private String price_Privacy;

    @SerializedName("currency_code")
    @Expose
    private String currency_code;

    @SerializedName("show_name")
    @Expose
    private String show_name;

    @SerializedName("isRepAdmin")
    @Expose
    private int isRepAdmin;

    @SerializedName("dealerStatus")
    @Expose
    private int dealerStatus;

    @SerializedName("RepresentativeData")
    @Expose
    private List<GetNetworkEmployeeData> RepresentativeData=null;

    @SerializedName("inMyNetwork")
    @Expose
    private String inMyNetwork;


    @SerializedName("isPrivate")
    @Expose
    private boolean isPrivate;

    public ListingDataArray(TypeOfListing typeOfListing) {
        this.typeOfListing = typeOfListing;
    }

    protected ListingDataArray(Parcel in) {
        companyName = in.readString();
        companySlug = in.readString();
        userSlug = in.readString();
        listSlug = in.readString();
        luId = in.readString();
        companyId = in.readString();
        isFav = in.readString();
        userId = in.readString();
        lid = in.readString();
        id = in.readString();
        listing = in.readString();
        slug = in.readString();
        type = in.readString();
        listingName = in.readString();
        category = in.readString();
        subCategory = in.readString();
        catType = in.readString();
        country = in.readString();
        city = in.readString();
        manufacturer = in.readString();
        model = in.readString();
        equipmentNumber = in.readString();
        sNo = in.readString();
        lengths = in.readString();
        cylinders = in.readString();
        capacity = in.readString();
        drive = in.readString();
        minAmp = in.readString();
        maxAmp = in.readString();
        yearOfManf = in.readString();
        powerFuel = in.readString();
        power = in.readString();
        transmission = in.readString();
        maxLifting = in.readString();
        flowRate = in.readString();
        condition = in.readString();
        weight = in.readString();
        description = in.readString();
        status = in.readString();
        createdDate = in.readString();
        modifiedDate = in.readString();
        availableDistance = in.readString();
        price = in.readString();
        currency = in.readString();
        pricePrivacy = in.readString();
        listingPrivacy = in.readString();
        latlng = in.readString();
        maxLiftingUnit = in.readString();
        flowRateUnit = in.readString();
        energy = in.readString();
        registrationNumber = in.readString();
        numberOfSeats = in.readString();
        listingFlightRules = in.readString();
        totalTime = in.readString();
        avCondition = in.readString();
        zip = in.readString();
        hash = in.readString();
        views = in.readString();
        refNum = in.readString();
        inventoryId = in.readString();
        showInMarketplace = in.readInt();
        isDeleted = in.readString();
        watermark = in.readString();
        wmType = in.readString();
        wmPosition = in.readString();
        wmImage = in.readString();
        wmText = in.readString();
        wmImageType = in.readString();
        emailAddress = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        designation = in.readString();
        profilePic = in.readString();
        uProfilePic = in.readString();
        listing_url = in.readString();
        iMAGENAME = in.readString();
        cuId = in.readInt();
        userUrl = in.readString();
        companyUrl = in.readString();
        userBadge = in.readString();
        conStatus = in.readString();
        netStatus = in.readString();
        assignCount = in.readInt();
        dealersCount = in.readInt();
        compCity = in.readString();
        compCountry = in.readString();
        desc = in.readString();
        isAcc = in.readInt();
        isAccType = in.readInt();
        price_Privacy = in.readString();
        currency_code = in.readString();
        show_name = in.readString();
        isRepAdmin = in.readInt();
        dealerStatus = in.readInt();
        inMyNetwork = in.readString();
    }

    public static final Creator<ListingDataArray> CREATOR = new Creator<ListingDataArray>() {
        @Override
        public ListingDataArray createFromParcel(Parcel in) {
            return new ListingDataArray(in);
        }

        @Override
        public ListingDataArray[] newArray(int size) {
            return new ListingDataArray[size];
        }
    };

    public TypeOfListing getTypeOfListing() {
        return typeOfListing;
    }

    public void setTypeOfListing(TypeOfListing typeOfListing) {
        this.typeOfListing = typeOfListing;
    }

    public String getPrice_Privacy() {
        return price_Privacy;
    }

    public void setPrice_Privacy(String price_Privacy) {
        this.price_Privacy = price_Privacy;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getListSlug() {
        return listSlug;
    }

    public void setListSlug(String listSlug) {
        this.listSlug = listSlug;
    }

    public String getLuId() {
        return luId;
    }

    public void setLuId(String luId) {
        this.luId = luId;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getIsFav() {
        return isFav;
    }

    public void setIsFav(String isFav) {
        this.isFav = isFav;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLid() {
        return lid;
    }

    public void setLid(String lid) {
        this.lid = lid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getListing() {
        return listing;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getListingName() {
        return listingName;
    }

    public void setListingName(String listingName) {
        this.listingName = listingName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getCatType() {
        return catType;
    }

    public void setCatType(String catType) {
        this.catType = catType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getEquipmentNumber() {
        return equipmentNumber;
    }

    public void setEquipmentNumber(String equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }

    public String getSNo() {
        return sNo;
    }

    public void setSNo(String sNo) {
        this.sNo = sNo;
    }

    public String getLengths() {
        return lengths;
    }

    public void setLengths(String lengths) {
        this.lengths = lengths;
    }

    public String getCylinders() {
        return cylinders;
    }

    public void setCylinders(String cylinders) {
        this.cylinders = cylinders;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public String getDrive() {
        return drive;
    }

    public void setDrive(String drive) {
        this.drive = drive;
    }

    public String getMinAmp() {
        return minAmp;
    }

    public void setMinAmp(String minAmp) {
        this.minAmp = minAmp;
    }

    public String getMaxAmp() {
        return maxAmp;
    }

    public void setMaxAmp(String maxAmp) {
        this.maxAmp = maxAmp;
    }

    public String getYearOfManf() {
        return yearOfManf;
    }

    public void setYearOfManf(String yearOfManf) {
        this.yearOfManf = yearOfManf;
    }

    public String getPowerFuel() {
        return powerFuel;
    }

    public void setPowerFuel(String powerFuel) {
        this.powerFuel = powerFuel;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getMaxLifting() {
        return maxLifting;
    }

    public void setMaxLifting(String maxLifting) {
        this.maxLifting = maxLifting;
    }

    public String getFlowRate() {
        return flowRate;
    }

    public void setFlowRate(String flowRate) {
        this.flowRate = flowRate;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Object getAvailable() {
        return available;
    }

    public void setAvailable(Object available) {
        this.available = available;
    }

    public String getAvailableDistance() {
        return availableDistance;
    }

    public void setAvailableDistance(String availableDistance) {
        this.availableDistance = availableDistance;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPricePrivacy() {
        return pricePrivacy;
    }

    public void setPricePrivacy(String pricePrivacy) {
        this.pricePrivacy = pricePrivacy;
    }

    public String getListingPrivacy() {
        return listingPrivacy;
    }

    public void setListingPrivacy(String listingPrivacy) {
        this.listingPrivacy = listingPrivacy;
    }

    public String getLatlng() {
        return latlng;
    }

    public void setLatlng(String latlng) {
        this.latlng = latlng;
    }

    public String getMaxLiftingUnit() {
        return maxLiftingUnit;
    }

    public void setMaxLiftingUnit(String maxLiftingUnit) {
        this.maxLiftingUnit = maxLiftingUnit;
    }

    public String getFlowRateUnit() {
        return flowRateUnit;
    }

    public void setFlowRateUnit(String flowRateUnit) {
        this.flowRateUnit = flowRateUnit;
    }

    public String getEnergy() {
        return energy;
    }

    public void setEnergy(String energy) {
        this.energy = energy;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(String numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public String getListingFlightRules() {
        return listingFlightRules;
    }

    public void setListingFlightRules(String listingFlightRules) {
        this.listingFlightRules = listingFlightRules;
    }

    public String getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(String totalTime) {
        this.totalTime = totalTime;
    }

    public String getAvCondition() {
        return avCondition;
    }

    public void setAvCondition(String avCondition) {
        this.avCondition = avCondition;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public Object getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(Object pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getViews() {
        return views;
    }

    public void setViews(String views) {
        this.views = views;
    }

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public int getShowInMarketplace() {
        return showInMarketplace;
    }

    public void setShowInMarketplace(int showInMarketplace) {
        this.showInMarketplace = showInMarketplace;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getWatermark() {
        return watermark;
    }

    public void setWatermark(String watermark) {
        this.watermark = watermark;
    }

    public String getWmType() {
        return wmType;
    }

    public void setWmType(String wmType) {
        this.wmType = wmType;
    }

    public String getWmPosition() {
        return wmPosition;
    }

    public void setWmPosition(String wmPosition) {
        this.wmPosition = wmPosition;
    }

    public String getWmImage() {
        return wmImage;
    }

    public void setWmImage(String wmImage) {
        this.wmImage = wmImage;
    }

    public String getWmText() {
        return wmText;
    }

    public void setWmText(String wmText) {
        this.wmText = wmText;
    }

    public String getWmImageType() {
        return wmImageType;
    }

    public void setWmImageType(String wmImageType) {
        this.wmImageType = wmImageType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getUProfilePic() {
        return uProfilePic;
    }

    public void setUProfilePic(String uProfilePic) {
        this.uProfilePic = uProfilePic;
    }

    public String getIMAGENAME() {
        return iMAGENAME;
    }

    public void setIMAGENAME(String iMAGENAME) {
        this.iMAGENAME = iMAGENAME;
    }

    public int getCuId() {
        return cuId;
    }

    public void setCuId(int cuId) {
        this.cuId = cuId;
    }

    public String getUserUrl() {
        return userUrl;
    }

    public void setUserUrl(String userUrl) {
        this.userUrl = userUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getUserBadge() {
        return userBadge;
    }

    public void setUserBadge(String userBadge) {
        this.userBadge = userBadge;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getNetStatus() {
        return netStatus;
    }

    public void setNetStatus(String netStatus) {
        this.netStatus = netStatus;
    }

    public List<PublicMarketPlaceAssignment> getAssignments() {
        return assignments;
    }

    public void setAssignments(List<PublicMarketPlaceAssignment> assignments) {
        this.assignments = assignments;
    }

    public int getAssignCount() {
        return assignCount;
    }

    public void setAssignCount(int assignCount) {
        this.assignCount = assignCount;
    }

    public List<DealerDataListing> getDealers() {
        return dealers;
    }

    public void setDealers(List<DealerDataListing> dealers) {
        this.dealers = dealers;
    }

    public int getDealersCount() {
        return dealersCount;
    }

    public void setDealersCount(int dealersCount) {
        this.dealersCount = dealersCount;
    }

    public String getCompCity() {
        return compCity;
    }

    public void setCompCity(String compCity) {
        this.compCity = compCity;
    }

    public String getCompCountry() {
        return compCountry;
    }

    public void setCompCountry(String compCountry) {
        this.compCountry = compCountry;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getIsAcc() {
        return isAcc;
    }

    public void setIsAcc(int isAcc) {
        this.isAcc = isAcc;
    }

    public int getIsAccType() {
        return isAccType;
    }

    public void setIsAccType(int isAccType) {
        this.isAccType = isAccType;
    }

    public String getListing_url() {
        return listing_url;
    }

    public void setListing_url(String listing_url) {
        this.listing_url = listing_url;
    }



    public String getCurrency_code() {
        return currency_code;
    }

    public void setCurrency_code(String currency_code) {
        this.currency_code = currency_code;
    }

    public String getShow_name() {
        return show_name;
    }

    public void setShow_name(String show_name) {
        this.show_name = show_name;
    }

    public int getIsRepAdmin() {
        return isRepAdmin;
    }

    public void setIsRepAdmin(int isRepAdmin) {
        this.isRepAdmin = isRepAdmin;
    }

    public int getDealerStatus() {
        return dealerStatus;
    }

    public void setDealerStatus(int dealerStatus) {
        this.dealerStatus = dealerStatus;
    }

    public List<GetNetworkEmployeeData> getRepresentativeData() {
        return RepresentativeData;
    }

    public void setRepresentativeData(List<GetNetworkEmployeeData> representativeData) {
        RepresentativeData = representativeData;
    }

    public String getInMyNetwork() {
        return inMyNetwork;
    }

    public void setInMyNetwork(String inMyNetwork) {
        this.inMyNetwork = inMyNetwork;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(companyName);
        parcel.writeString(companySlug);
        parcel.writeString(userSlug);
        parcel.writeString(listSlug);
        parcel.writeString(luId);
        parcel.writeString(companyId);
        parcel.writeString(isFav);
        parcel.writeString(userId);
        parcel.writeString(lid);
        parcel.writeString(id);
        parcel.writeString(listing);
        parcel.writeString(slug);
        parcel.writeString(type);
        parcel.writeString(listingName);
        parcel.writeString(category);
        parcel.writeString(subCategory);
        parcel.writeString(catType);
        parcel.writeString(country);
        parcel.writeString(city);
        parcel.writeString(manufacturer);
        parcel.writeString(model);
        parcel.writeString(equipmentNumber);
        parcel.writeString(sNo);
        parcel.writeString(lengths);
        parcel.writeString(cylinders);
        parcel.writeString(capacity);
        parcel.writeString(drive);
        parcel.writeString(minAmp);
        parcel.writeString(maxAmp);
        parcel.writeString(yearOfManf);
        parcel.writeString(powerFuel);
        parcel.writeString(power);
        parcel.writeString(transmission);
        parcel.writeString(maxLifting);
        parcel.writeString(flowRate);
        parcel.writeString(condition);
        parcel.writeString(weight);
        parcel.writeString(description);
        parcel.writeString(status);
        parcel.writeString(createdDate);
        parcel.writeString(modifiedDate);
        parcel.writeString(availableDistance);
        parcel.writeString(price);
        parcel.writeString(currency);
        parcel.writeString(pricePrivacy);
        parcel.writeString(listingPrivacy);
        parcel.writeString(latlng);
        parcel.writeString(maxLiftingUnit);
        parcel.writeString(flowRateUnit);
        parcel.writeString(energy);
        parcel.writeString(registrationNumber);
        parcel.writeString(numberOfSeats);
        parcel.writeString(listingFlightRules);
        parcel.writeString(totalTime);
        parcel.writeString(avCondition);
        parcel.writeString(zip);
        parcel.writeString(hash);
        parcel.writeString(views);
        parcel.writeString(refNum);
        parcel.writeString(inventoryId);
        parcel.writeInt(showInMarketplace);
        parcel.writeString(isDeleted);
        parcel.writeString(watermark);
        parcel.writeString(wmType);
        parcel.writeString(wmPosition);
        parcel.writeString(wmImage);
        parcel.writeString(wmText);
        parcel.writeString(wmImageType);
        parcel.writeString(emailAddress);
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(designation);
        parcel.writeString(profilePic);
        parcel.writeString(uProfilePic);
        parcel.writeString(listing_url);
        parcel.writeString(iMAGENAME);
        parcel.writeInt(cuId);
        parcel.writeString(userUrl);
        parcel.writeString(companyUrl);
        parcel.writeString(userBadge);
        parcel.writeString(conStatus);
        parcel.writeString(netStatus);
        parcel.writeInt(assignCount);
        parcel.writeInt(dealersCount);
        parcel.writeString(compCity);
        parcel.writeString(compCountry);
        parcel.writeString(desc);
        parcel.writeInt(isAcc);
        parcel.writeInt(isAccType);
        parcel.writeString(price_Privacy);
        parcel.writeString(currency_code);
        parcel.writeString(show_name);
        parcel.writeInt(isRepAdmin);
        parcel.writeInt(dealerStatus);
        parcel.writeString(inMyNetwork);
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean aPrivate) {
        isPrivate = aPrivate;
    }


    public TypeOfView getTypeOfView(){
        if (getDealers().size() > 0) {
            return TypeOfView.DEALER;
        }
        else if (getInMyNetwork().equals("1")  || (getListingPrivacy().equals("1") && getShow_name().equals("Yes")) || isPrivate()) {
            if(getAssignments().size() > 0){
                return TypeOfView.COMPANY;
            }else{
                return TypeOfView.USER;
            }

        }  else {
            return TypeOfView.NONE;
        }
    }
}


