package com.mobileapp.krank.CallBacks

import retrofit2.Call
import retrofit2.Response

interface ResponseCallBacks<T>{
    fun success(call: Call<T>, response: Response<T>)
    fun failure(call: Call<T>, response: Response<T>)
    fun failure(call: Call<T>, t: Throwable )
}
