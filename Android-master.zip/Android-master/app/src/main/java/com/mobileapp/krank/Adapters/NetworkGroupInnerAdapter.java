package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.facebook.drawee.view.SimpleDraweeView;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosAndType;
import com.mobileapp.krank.Functions.AppUtils;

import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerGroupCompanyDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkGroupCompanyDataModel;
import com.mobileapp.krank.ViewHolders.NetworkDealerGroupViewHolder;
import java.util.List;

public class NetworkGroupInnerAdapter<T> extends RecyclerView.Adapter<NetworkGroupInnerAdapter.ItemViewHolder> {
    private List<T> items;
    AppUtils appUtils;
    CallBackWithAdapterPosAndType callBack;

    private static final int MAX_SIZE = 3;
    private boolean showViewMoreBtn;

    private int moreBtnCount;
    private int position;

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        View item;
        SimpleDraweeView company_img;
        TextView company_name;
        TextView more_text_view;
        View more_text_view_container;

        public ItemViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            company_img = itemView.findViewById(R.id.company_img);
            company_name = itemView.findViewById(R.id.company_name);
            more_text_view = itemView.findViewById(R.id.more_text_view);
            more_text_view_container = itemView.findViewById(R.id.more_text_view_container);

            more_text_view.setOnClickListener(view -> {
                if(callBack == null || getAdapterPosition() < 0) return;
                callBack.act(position, NetworkDealerGroupViewHolder.MORE_BTN_CLICK);
            });
        }
    }



    public NetworkGroupInnerAdapter(List<T> items,CallBackWithAdapterPosAndType callBack,int position) {
        if(items.size() < MAX_SIZE){
            this.items = items;
        }else{
            this.items = items.subList(0,MAX_SIZE);
            moreBtnCount =    items.size() - this.items .size();
        }

        showViewMoreBtn = items.size() > MAX_SIZE;


        this.callBack = callBack;
        appUtils = AppUtils.getInstance();
        this.position = position;
    }

    @Override
    public NetworkGroupInnerAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.dealer_group_inner_item, parent, false);
        return new ItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(NetworkGroupInnerAdapter.ItemViewHolder holder, int position) {

        onBind(items.get(position),holder,position);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void onBind(T item,NetworkGroupInnerAdapter.ItemViewHolder holder,int position) {
        if (item instanceof NetworkGroupCompanyDataModel) {
            NetworkGroupCompanyDataModel listItem = (NetworkGroupCompanyDataModel)item;
            holder.company_name.setText("" + listItem.getCompanyName());

            holder.company_img.setImageURI("" + listItem.getProfilePic());

            if(showViewMoreBtn && items.size()-1 == position){
                holder.more_text_view_container.setVisibility(View.VISIBLE);
                holder.more_text_view.setText(moreBtnCount + " ");
            }else{
                holder.more_text_view_container.setVisibility(View.GONE);
            }
        }
        else if (item instanceof DealerGroupCompanyDataModel){
            DealerGroupCompanyDataModel listItem = (DealerGroupCompanyDataModel)item;
            holder.company_name.setText("" + listItem.getCompanyName());

            holder.company_img.setImageURI("" + listItem.getProfilePic());

            if(showViewMoreBtn && items.size()-1 == position){
                holder.more_text_view_container.setVisibility(View.VISIBLE);
                holder.more_text_view.setText(moreBtnCount + " ");
            }else{
                holder.more_text_view_container.setVisibility(View.GONE);
            }
        }

    }


}







