package com.mobileapp.krank.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.mobileapp.krank.Activities.CustomDropDown.CityListActivity;
import com.mobileapp.krank.Activities.CustomDropDown.CountryListActivity;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.CustomViews.CheckView;
import com.mobileapp.krank.CustomViews.CustomScrollView;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CityListData;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.CountyListData;
import com.mobileapp.krank.ResponseModels.DataModel.SigninData;
import com.mobileapp.krank.ResponseModels.SigninResponse;
import com.mobileapp.krank.Utils.ApiUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpPage5 extends BaseActivity implements View.OnClickListener {

    //activity codes
    private static int COUNTRY_LIST_ACTIVITY_CODE = 100;
    private static int CITY_LIST_ACTIVITY_CODE = 200;

    //selected country and city
    CountyListData selectedCountryData;
    CityListData selectedCityData;

    //country city views
    EditText city_text;
    EditText country_text;

    //bottom info
    TextView info_text;

    // invite model
    CompanyInvitationDataModel companyInvitationDataModel;

    //views

    private View content;
    private TextView error;
    private TextView termsAndConditionsText;
    private Button createAccountBtn;

    //view 2
    private Button continueBtn;
    private View content2;
    private View successContent;

    //loader
    private ProgressBar loader;

    // input fields
    private EditText email_edit_text, company_name_edit_text, password_edit_text, confirm_password_edit_text;
    private CustomScrollView root_scroll_view;

    //invitee
    TextView invitee_msg;

    //checkView
    CheckView check_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page5);


        init();

        initViews();

        setKrankLogoForUserProfiling();


        //country city
        if (!(preference.getString(Constants.COMPANY_COUNTRY_DATA).isEmpty())) {
            selectedCountryData = gson.fromJson(preference.getString(Constants.COMPANY_COUNTRY_DATA), CountyListData.class);
            country_text.setText("" + selectedCountryData.getName());
        }
        if (!(preference.getString(Constants.COMPANY_CITY_DATA).isEmpty())) {
            selectedCityData = gson.fromJson(preference.getString(Constants.COMPANY_CITY_DATA), CityListData.class);
            city_text.setText("" + selectedCityData.getCityName());
        }


        //invitation
        if (!(isInviteLinkDataExists())) {
            info_text.setVisibility(View.GONE);
        } else {
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }


        email_edit_text.setText(preference.getString(Constants.USER_EMAIL));

        /*for new company*/
        if (!preference.getBoolean(Constants.NEW_COMPANY)) {
            company_name_edit_text.setText(preference.getString(Constants.OLD_COMPANY));
            company_name_edit_text.setEnabled(false);
            company_name_edit_text.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.lock_img, 0);
        }
        /*for new company*/


        setScreenHeader("Sign Up");


        setSpannableString();


        setCallBacks();

    }

    private void setCallBacks() {

        createAccountBtn.setOnClickListener(this);

        continueBtn.setOnClickListener(this);

        country_text.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), CountryListActivity.class);
           /* if (selectedCountryData == null) {
                intent.putExtra("countryData", "null");
            } else {
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
            }*/

            if (selectedCountryData != null) {
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
            }
            startActivityForResult(intent, COUNTRY_LIST_ACTIVITY_CODE);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });

        city_text.setOnClickListener(view -> {
            if (selectedCountryData != null) {
                Intent intent = new Intent(getApplicationContext(), CityListActivity.class);
                intent.putExtra("countryData", appUtils.convertToJson(selectedCountryData));
                startActivityForResult(intent, CITY_LIST_ACTIVITY_CODE);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            } else {
                Toast.makeText(getApplicationContext(), "Please Select Country", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void init() {
        selectedCountryData = null;
        selectedCityData = null;
    }

    private void initViews() {
        //country city views
        country_text = findViewById(R.id.country_text);
        city_text = findViewById(R.id.city_text);


        //content 1
        termsAndConditionsText = findViewById(R.id.terms_and_conditions_text);
        createAccountBtn = findViewById(R.id.create_account_btn);
        content = findViewById(R.id.content_1);

        //content 2
        continueBtn = findViewById(R.id.continue_btn);
        content2 = findViewById(R.id.content_2);
        successContent = findViewById(R.id.success_content);

        //loader
        loader = findViewById(R.id.loader);

        error = findViewById(R.id.error_view);


        info_text = findViewById(R.id.info_text);

        //input fields
        email_edit_text = findViewById(R.id.email_edit_text);
        company_name_edit_text = findViewById(R.id.company_name_edit_text);
        password_edit_text = findViewById(R.id.password_edit_text);
        confirm_password_edit_text = findViewById(R.id.confirm_password_edit_text);


        root_scroll_view = findViewById(R.id.root_scroll_view);

        //checkView
        check_view = findViewById(R.id.check_view);

        //invitee
        invitee_msg = findViewById(R.id.invitee_msg);

    }

    private void disableViews() {
        if (preference.getBoolean(Constants.NEW_COMPANY)) {
            company_name_edit_text.setEnabled(false);
        }
        createAccountBtn.setEnabled(false);
        continueBtn.setEnabled(false);
        country_text.setEnabled(false);
        city_text.setEnabled(false);
        password_edit_text.setEnabled(false);
        confirm_password_edit_text.setEnabled(false);
        termsAndConditionsText.setEnabled(false);
        root_scroll_view.setEnableScrolling(false);
    }

    private void enableViews() {
        if (preference.getBoolean(Constants.NEW_COMPANY)) {
            company_name_edit_text.setEnabled(true);
        }
        createAccountBtn.setEnabled(true);
        continueBtn.setEnabled(true);
        country_text.setEnabled(true);
        city_text.setEnabled(true);
        password_edit_text.setEnabled(true);
        confirm_password_edit_text.setEnabled(true);
        termsAndConditionsText.setEnabled(true);
        root_scroll_view.setEnableScrolling(true);
    }

    private void setSpannableString() {
        String text_1 = "By creating an account, you are agreeing to Krank’s ";
        String text_2 = "Terms of Use, ";
        String text_3 = "Privacy Policy, ";
        String text_4 = "Cookie Policy.";
        String text_5 = "Please take time to review each of them before agreeing.";


        SpannableStringBuilder ssb = new SpannableStringBuilder();
        ssb.append(text_1);
        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_2, () -> {
            openWebViewPages(getApplicationContext(), Constants.TERMS_CONDITION);
        }, this);

        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_3, () -> {
            openWebViewPages(getApplicationContext(), Constants.PRIVACY);
        }, this);
        ssb.append("and ");
        AppUtils.addClickableTextWithClick(ssb, ssb.length(), text_4, () -> {
            openWebViewPages(getApplicationContext(), Constants.COOKIES_POLICY);
        }, this);
        ssb.append(text_5);


        termsAndConditionsText.setMovementMethod(LinkMovementMethod.getInstance());   // make our spans selectable
        termsAndConditionsText.setText(ssb);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.create_account_btn:
                hideKeyBoard();
                handleCreateAccountBtn();
                break;
            case R.id.continue_btn:
                Intent intent = new Intent(SignUpPage5.this, AccountSetupPage.class);
                startActivity(intent);
                overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                finishAffinity();
                break;
        }
    }

    private void handleCreateAccountBtn() {
        final String email = email_edit_text.getText().toString().trim();
        final String tempId = preference.getString(Constants.TEMP_USER_ID);
        final String verifyCode = preference.getString(Constants.VERIFY_CODE);
        final Boolean isNewCompany = preference.getBoolean(Constants.NEW_COMPANY);
        final String company = company_name_edit_text.getText().toString().trim();
//        final String country = country_edit_text.getText().toString();
        final String password = password_edit_text.getText().toString().trim();
        final String confirmPassword = confirm_password_edit_text.getText().toString().trim();


        //  if (email.isEmpty() && company.isEmpty() && password.isEmpty() && selectedCityData == null && selectedCountryData == null && confirmPassword.isEmpty() && password.equals(confirmPassword)) {

        if (company.isEmpty()) {
            error.setText(Constants.ENTER_COMPANY_NAME);
        } else if (selectedCountryData == null) {
            error.setText(Constants.SELECT_COUNTRY);
        } else if (selectedCityData == null) {
            error.setText(Constants.SELECT_CITY);
        } else if (password.isEmpty()) {
            error.setText(Constants.ENTER_PASSWORD_TEXT);
        } else if (confirmPassword.isEmpty()) {
            error.setText(Constants.ENTER_CONFIRM_PASSWORD);
        } else if (password.length() < getResources().getInteger(R.integer.pass_confirm_pass_min_limit)) {
            error.setText(Constants.MINIMUM_PASSWORD_LENGTH_ERROR);
        } else if (!(password.equals(confirmPassword))) {
            error.setText(Constants.EQUAL_PASSWORD_TEXT);
        } else {

            disableViews();

            content2.setVisibility(View.VISIBLE);

            //hide the form view
            content.setVisibility(View.GONE);


            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(task -> {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        final String token = task.getResult().getToken();
                        createAccount(email, company, password, confirmPassword, tempId, verifyCode, isNewCompany, token);

                    });

        }
    }





    private void createAccount(String email, String company, String password, String confirmPassword, String tempId, String verifyCode, boolean isNewCompany, String device_id) {


        try {
            getAPI().createAccount(
                    email,
                    tempId,
                    verifyCode,
                    isNewCompany,
                    company,
                    selectedCountryData.getCode(),
                    selectedCityData.getCityId(),
                    password,
                    confirmPassword,
                    device_id,
                    AppUtils.getDeviceVersion(),
                    AppUtils.getModel(),
                    AppUtils.getManufacturer(),
                    AppUtils.getDeviceId(this),
                    Constants.ANDROID_DEVICE,
                    getInviteUserId(),
                    preference.getString(Constants.TYPE_OF_INVITATION)).enqueue(new Callback<SigninResponse>() {
                @Override
                public void onResponse(Call<SigninResponse> call, Response<SigninResponse> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                            onSuccess(response);

                        } else {
                            error.setText(response.body().getMessage());
                            enableViews();
                            content2.setVisibility(View.GONE);
                            content.setVisibility(View.VISIBLE);
                        }
                    } else {
                        onSignUpFailure();
                    }

                }

                @Override
                public void onFailure(Call<SigninResponse> call, Throwable t) {
                    onSignUpFailure();
                }
            });
        } catch (Exception e) {
            onSignUpFailure();
        }


    }

    private void onSuccess(Response<SigninResponse> response) {
        /*clear temp User Id*/
        preference.removeValue(Constants.TEMP_USER_ID);
        /*clear temp User Id*/

        //store country city for wizard
        preference.setString(Constants.USER_COUNTRY_DATA, gson.toJson(selectedCountryData));
        preference.setString(Constants.USER_CITY_DATA, gson.toJson(selectedCityData));

        //wizard flag
        preference.setString(Constants.IS_PHONE_NUMBER_ON_WIZARD_ENTERED, "no");

        //set data in cache
        setUserDataInSharedPreferences(response.body());


        proceedAfterUserSuccessFullLogin(AppUtils.getDeviceName(), () -> {
            loader.setVisibility(View.GONE);
            successContent.setVisibility(View.VISIBLE);
            content2.setVisibility(View.VISIBLE);
            successContent.animate().alpha(1).setDuration(2000);
            continueBtn.setEnabled(true);
            check_view.check();
        });

        setInviteeMessage(response.body().getData());

    }

    private void setInviteeMessage(SigninData data) {
        if (data.getInvitedByUser() == null || data.getInvitedByUser().isEmpty()) return;
        data.setInvitedByUser(data.getInvitedByUser().replace(data.getInvitedByUserName(), getBlueBoldText(data.getInvitedByUserName())));
        invitee_msg.setText(AppUtils.fromHtml(getBlueBoldText("Note : ") + data.getInvitedByUser()));
    }

    private String getBlueBoldText(String text) {
        return "<font color='#1578FC'><b>" + text + "</b></font>";
    }

    private void onSignUpFailure() {
        onResponseFailure();
        content2.setVisibility(View.GONE);
        //hide the form view
        content.setVisibility(View.VISIBLE);
        enableViews();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == COUNTRY_LIST_ACTIVITY_CODE) {
                selectedCountryData = gson.fromJson(data.getStringExtra("selectedCountry"), CountyListData.class);
                city_text.setText("");
                selectedCityData = null;
                country_text.setText("" + selectedCountryData.getName());
            } else if (requestCode == CITY_LIST_ACTIVITY_CODE) {
                selectedCityData = gson.fromJson(data.getStringExtra("cityData"), CityListData.class);
                city_text.setText("" + selectedCityData.getCityName());
            }

        }
    }
}