package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.TypeConverters;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mobileapp.krank.Functions.StringListTypeConverter;

import java.util.List;

public class AutoPostPera implements Parcelable {
    @SerializedName("0")
    @Expose
    @ColumnInfo(name = "auto_post_pera_0")
    private String _0;

    @SerializedName("1")
    @Expose
    @ColumnInfo(name = "auto_post_pera_1")
    private String _1;

    @SerializedName("2")
    @Expose
    @ColumnInfo(name = "auto_post_pera_2")
    private String _2;

    @SerializedName("email")
    @Expose
    @ColumnInfo(name = "auto_post_pera_email")
    @TypeConverters(StringListTypeConverter.class)
    private List<String> email = null;

    protected AutoPostPera(Parcel in) {
        _0 = in.readString();
        _1 = in.readString();
        _2 = in.readString();
        email = in.createStringArrayList();
    }

    public static final Creator<AutoPostPera> CREATOR = new Creator<AutoPostPera>() {
        @Override
        public AutoPostPera createFromParcel(Parcel in) {
            return new AutoPostPera(in);
        }

        @Override
        public AutoPostPera[] newArray(int size) {
            return new AutoPostPera[size];
        }
    };

    public String get0() {
        return _0;
    }

    public void set0(String _0) {
        this._0 = _0;
    }

    public String get1() {
        return _1;
    }

    public void set1(String _1) {
        this._1 = _1;
    }

    public String get2() {
        return _2;
    }

    public void set2(String _2) {
        this._2 = _2;
    }

    public List<String> getEmail() {
        return email;
    }

    public void setEmail(List<String> email) {
        this.email = email;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(_0);
        parcel.writeString(_1);
        parcel.writeString(_2);
        parcel.writeStringList(email);
    }

    public AutoPostPera() {
    }
}
