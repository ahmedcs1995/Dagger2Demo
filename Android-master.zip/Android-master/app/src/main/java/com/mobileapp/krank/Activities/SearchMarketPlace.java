package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Model.ListingSearchModel;
import com.mobileapp.krank.R;

public class SearchMarketPlace extends BaseActivity {

    View keyword_search_container;
    View exact_phrase_container;

    boolean isKeywordSelected;
    boolean isPhraseSelected;

    View keyword_search_uncheck_view;
    View keyword_search_check_view;


    View exact_phrase_uncheck_view;
    View exact_phrase_check_view;
    View search_btn;

    EditText search_edit_text;


    ListingSearchModel listingSearchModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_market_place);

        isKeywordSelected = true;
        isPhraseSelected = false;



        setNormalPageToolbar( "Search Marketplace");

        keyword_search_container = findViewById(R.id.keyword_search_container);
        exact_phrase_container = findViewById(R.id.exact_phrase_container);


        keyword_search_uncheck_view = findViewById(R.id.keyword_search_uncheck_view);
        keyword_search_check_view = findViewById(R.id.keyword_search_check_view);


        exact_phrase_uncheck_view = findViewById(R.id.exact_phrase_uncheck_view);
        exact_phrase_check_view = findViewById(R.id.exact_phrase_check_view);

        search_btn = findViewById(R.id.search_btn);

        search_edit_text = findViewById(R.id.search_edit_text);


        keyword_search_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setKeywordCheck();
            }
        });
        exact_phrase_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setExactPhraseCheck();
            }
        });

        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("search_keyword", "" + search_edit_text.getText().toString());
                listingSearchModel.setSearchKeyword("" + search_edit_text.getText().toString());
                if (isKeywordSelected) {
                    listingSearchModel.setSearchType("Keyword");
                } else {
                    listingSearchModel.setSearchType("exact_phrase");
                }
                intent.putExtra("search_data", appUtils.convertToJson(listingSearchModel));
                setResult(RESULT_OK, intent);
                finish();
            }
        });



        listingSearchModel = gson.fromJson(getIntent().getStringExtra("search_data"),ListingSearchModel.class);
        search_edit_text.setText("" + listingSearchModel.getSearchKeyword());
        if (listingSearchModel.getSearchType().equals("Keyword")) {
            setKeywordCheck();
        } else {
            setExactPhraseCheck();
        }
    }

    private void setExactPhraseCheck() {
        isKeywordSelected = false;
        isPhraseSelected = true;

        keyword_search_check_view.setVisibility(View.GONE);
        keyword_search_uncheck_view.setVisibility(View.VISIBLE);


        exact_phrase_check_view.setVisibility(View.VISIBLE);
        exact_phrase_uncheck_view.setVisibility(View.GONE);
    }

    private void setKeywordCheck() {
        isKeywordSelected = true;
        isPhraseSelected = false;

        keyword_search_check_view.setVisibility(View.VISIBLE);
        keyword_search_uncheck_view.setVisibility(View.GONE);


        exact_phrase_check_view.setVisibility(View.GONE);
        exact_phrase_uncheck_view.setVisibility(View.VISIBLE);
    }
}
