package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.SignupOneResponse;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InvitationRecievePage extends BaseActivity {

    //views
    View login_btn;
    View sign_up_btn;
    TextView info_text;
    EditText signupEditText;
    TextView error;

    //invite data model
    CompanyInvitationDataModel companyInvitationDataModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitation_recieve_page);

        //views
        login_btn = findViewById(R.id.login_btn);
        sign_up_btn = findViewById(R.id.sign_up_btn);
        info_text = findViewById(R.id.info_text);
        error = findViewById(R.id.error_view);
        signupEditText = findViewById(R.id.sigunp_edit_text);

        //loader
        showAlert = showAlert("Checking please wait...", SweetAlertDialog.PROGRESS_TYPE, false);


        //invite text
        companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
        setInfoText(companyInvitationDataModel, info_text);

        //listeners
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(InvitationRecievePage.this, SignIn.class);
                startActivity(intent);
            }
        });
        sign_up_btn.setOnClickListener(view -> {

            String email = signupEditText.getText().toString();
            if (email.isEmpty()) {
                error.setText(Constants.ENTER_EMAIL_TEXT);
            }
            else if(!(AppUtils.validateEmail(email))){
                error.setText(Constants.ENTER_VALID_EMAIL_TEXT);
            }
            else {
                error.setText("");
                firstSignupStep(email);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    private void firstSignupStep(final String email) {
        showAlert.show();
        getAPI().signupStepOne(email,getInviteUserId()).enqueue(new Callback<SignupOneResponse>() {
            @Override
            public void onResponse(Call<SignupOneResponse> call, Response<SignupOneResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {



                        error.setText("");
                       onSignStepOneSuccess(InvitationRecievePage.this,response,email);

                    } else {
                        error.setText(response.body().getMessage());
                        showAlert.dismiss();
                        // handle request errors depending on status code
                    }
                } else {
                    showAlert.dismiss();
                }

            }

            @Override
            public void onFailure(Call<SignupOneResponse> call, Throwable t) {
                showAlert.dismiss();
                Log.e("getappcont", "error loading from API");
                Log.e("getappcont", t.getLocalizedMessage());
            }
        });

    }


    @Override
    public void onBackPressed() {

        finishAffinity();
    }
}
