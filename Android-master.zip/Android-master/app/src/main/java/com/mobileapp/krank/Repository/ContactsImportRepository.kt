package com.mobileapp.krank.Repository

import android.app.Application
import android.arch.lifecycle.MutableLiveData
import android.widget.Toast
import com.mobileapp.krank.CustomViews.SwitchButton
import com.mobileapp.krank.Database.AppExecutors
import com.mobileapp.krank.Database.Dao.ContactsImportDao
import com.mobileapp.krank.Database.KrankRoomDataBase
import com.mobileapp.krank.Functions.AppUtils
import com.mobileapp.krank.Functions.Constants
import com.mobileapp.krank.Model.Enums.NetworkState
import com.mobileapp.krank.ResponseModels.*
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData
import com.mobileapp.krank.Utils.SaveInSharedPreference
import com.mobileapp.krank.Utils.ServiceManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.arch.lifecycle.LiveData
import android.util.Log
import com.mobileapp.krank.CallBacks.CustomCallBack


class ContactsImportRepository(internal var application: Application) {


    companion object{
        const val CONNECT_TYPE = "Phone Contacts"
    }


    private var preference: SaveInSharedPreference = SaveInSharedPreference.getInstance(application)

    private var serviceManager: ServiceManager = ServiceManager.getInstance()

    private val mContactsImportDao: ContactsImportDao


    private var networkState: MutableLiveData<NetworkState>

    internal var executors: AppExecutors = AppExecutors.getInstance()

    init {
        val db = KrankRoomDataBase.getDatabase(application)
        mContactsImportDao = db.contactsDao
        networkState = MutableLiveData()


    }

    fun getOnKrankUsersCount() = mContactsImportDao.getAllCounts()

    fun getNetworkState(): LiveData<NetworkState> {
        return networkState
    }

    fun sendContactToServerSync(contactList: ArrayList<ContactsDataModel>, countryCode: String?, deivceId: String?, deleteContacts: ArrayList<DeleteContactDataModel> = ArrayList()) {

        //networkState.postValue(NetworkState.LOADING)

        var rawData = ContactsPostDataModel(countryCode, 0, 0, deivceId, contactList, deleteContacts)

        var call = serviceManager.api.mobileContactsConnect(preference.getString(Constants.ACCESS_TOKEN), rawData)

        val response = call.execute()

        if (response.isSuccessful) {
            if (response.body().status.toLowerCase() == Constants.SUCCESS_STATUS) {
                Log.e("onPerformSync", "sendContactToServerSync")

                onContactDataRecieved(response, contactList.size)


            } else {
                revertTimeStamps(contactList, deleteContacts)
            }
        } else {
            revertTimeStamps(contactList, deleteContacts)
        }

    }

    private fun revertTimeStamps(contactList: ArrayList<ContactsDataModel>, deleteContacts: ArrayList<DeleteContactDataModel>) {
        if (deleteContacts.size > 0) {
            /**
             *Contact Delete
             *
             */
            setPreferenceValue(Constants.LAST_CONTACT_DELETE_TIME_STAMP, getPreferenceValue(Constants.TEMP_LAST_CONTACT_DELETE_TIME_STAMP))
        }

        if (contactList.size > 0) {

            /**
             *Contact Import
             *
             */
            setPreferenceValue(Constants.LAST_CONTACT_UPDATE_TIME_STAMP, getPreferenceValue(Constants.TEMP_LAST_CONTACT_UPDATE_TIME_STAMP))
        }
    }

    private fun setPreferenceValue(key: String, value: Long) {
        preference.setLong(key, value)
    }

    private fun getPreferenceValue(key: String) = preference.getLong(Constants.TEMP_LAST_CONTACT_DELETE_TIME_STAMP)

    private fun updateContactsCountCache(response: Response<ContactsImportResponseModel>){
        preference.setInt(Constants.MY_CONTACT_COUNT, response.body().data.my_contacts)
        preference.setInt(Constants.TOTAL_CONTACTS_COUNT, response.body().data.total_contacts)

        if(response.body().data.my_contacts <= 0){
            preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED,false)
        }else{
            preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED,true)
        }
    }

    private fun onContactDataRecieved(response: Response<ContactsImportResponseModel>, contactSize: Int) {
        if (response.body().data == null) return


        // preference.setInt(Constants.MY_CONTACT_COUNT,contactSize + preference.getInt(Constants.MY_CONTACT_COUNT))
        //   preference.setInt(Constants.TOTAL_CONTACTS_COUNT,contactSize + preference.getInt(Constants.TOTAL_CONTACTS_COUNT))

        updateContactsCountCache(response)


        val tempList: MutableList<GetNetworkEmployeeData> = ArrayList()
        tempList.addAll(setType(response.body().data.connected_users, GetNetworkEmployeeData.CONNECTED_CONTACTS_VIEW, response.body().data.totalUsersCount))
        tempList.addAll(setType(response.body().data.non_connected_users, GetNetworkEmployeeData.NOT_CONNECTED_CONTACTS_VIEW, response.body().data.totalUsersCount))
        tempList.addAll(setType(response.body().data.no_users, GetNetworkEmployeeData.INVITE_CONTACTS_VIEW, response.body().data.totalUsersCount))


        executors.diskIO().execute {
            mContactsImportDao.deleteAll()
            mContactsImportDao.bulkInsert(tempList)
        }
    }

    fun sendContactsToServer(contacts: ArrayList<ContactsDataModel> = ArrayList(), deleteContacts: ArrayList<DeleteContactDataModel> = ArrayList()) {


        networkState.postValue(NetworkState.LOADING)

        var rawData = ContactsPostDataModel(AppUtils.getCountryCode(application.applicationContext), 0, 0, AppUtils.getDeviceId(application.applicationContext), contacts, deleteContacts)

        serviceManager.api.mobileContactsConnect(preference.getString(Constants.ACCESS_TOKEN), rawData).enqueue(object : Callback<ContactsImportResponseModel> {
            override fun onResponse(call: Call<ContactsImportResponseModel>, response: Response<ContactsImportResponseModel>) {
                if (response.isSuccessful) {
                    if (response.body().status.toLowerCase() == Constants.SUCCESS_STATUS) {

                        onContactDataRecieved(response, contacts.size)

                        networkState.postValue(NetworkState.LOADED)


                        /**
                         * Flag for Pop Up on NewsFeed
                         */
                        preference.setString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN, Constants.CONTACT_POP_UP_DONT_ASK_ME_VALUE)
                    } else {


                        updateContactsCountCache(response)

                        executors.diskIO().execute {
                            mContactsImportDao.deleteAll()
                        }

                        networkState.postValue(NetworkState(NetworkState.Status.FAILED, response.body().message))


                        showToast(response.body().message)
                    }
                } else {
                    revertTimeStamps(contacts, deleteContacts)


                    networkState.postValue(NetworkState(NetworkState.Status.FAILED, Constants.ERROR_MSG_TOAST_1))


                    showToast(Constants.ERROR_MSG_TOAST_1)
                }

            }

            override fun onFailure(call: Call<ContactsImportResponseModel>?, t: Throwable?) {

                networkState.postValue(NetworkState(NetworkState.Status.FAILED, Constants.ERROR_MSG_TOAST_1))

                revertTimeStamps(contacts, deleteContacts)
                showToast(Constants.ERROR_MSG_TOAST_1)
            }

        })
    }

    fun deleteAllRecords() {
        executors.diskIO().execute {
            mContactsImportDao.deleteAll()
        }
    }

    fun unSyncToServer(checkBox: SwitchButton?, unSyncFlag: Int) {
        serviceManager.api.unSyncMobileContacts(preference.getString(Constants.ACCESS_TOKEN), AppUtils.getDeviceId(application.applicationContext), unSyncFlag).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {
                if (checkBox != null) {
                    checkBox.isEnabled = true
                }
                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {
                        preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, false)

                        //delete
                        setPreferenceValue(Constants.TEMP_LAST_CONTACT_DELETE_TIME_STAMP, 0)
                        setPreferenceValue(Constants.LAST_CONTACT_DELETE_TIME_STAMP, 0)
                        //update
                        setPreferenceValue(Constants.LAST_CONTACT_UPDATE_TIME_STAMP, 0)
                        setPreferenceValue(Constants.TEMP_LAST_CONTACT_UPDATE_TIME_STAMP, 0)

                        if (unSyncFlag == Constants.UNSYNC_ALL) {
                            //delete all
                            deleteAllRecords()
                        } else {
                            //delete contacts
                            executors.diskIO().execute {
                                mContactsImportDao.deleteCurrentDevice(AppUtils.getDeviceId(application.applicationContext))
                            }
                        }

                        showToast(response.body().message)

                    } else {
                        showToast(response.body().message)
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                }
            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                showToast(Constants.ERROR_MSG_TOAST_1)
                checkBox?.isEnabled = true
            }

        })
    }

    private fun showToast(message: String) {
        Toast.makeText(application, message, Toast.LENGTH_SHORT).show()
    }

    private fun setType(listItems: ArrayList<GetNetworkEmployeeData>, viewType: Int, userCount: Int): List<GetNetworkEmployeeData> {
        if (listItems == null) return ArrayList()


        //  listItems.sortBy { emp -> emp.firstName}

        // val sortedList = listItems.sortedWith(compareBy<GetNetworkEmployeeData> { it.firstName }.thenBy { it.contact_id })

        //sortedList = listItems.sortedWith(compareBy({ it.firstName }, { it.contact_id }))


        for (i in listItems.indices) {
            //    listItems[i].show_section_type = if (i == 0) sectionType else GetNetworkEmployeeData.HIDE_SECTION
            listItems[i].viewType = viewType
            listItems[i].totalUsersCount = userCount
            listItems[i].firstName = AppUtils.autoCapitalWord(listItems[i].firstName)
        }
        /*listItems.forEach {
            it.viewType = viewType
            it.totalUsersCount = userCount
        }*/
        return listItems
    }


    fun sendConnectionRequest(item: GetNetworkEmployeeData?) {
        if (item == null) return

        updateRecord(Constants.REQUEST_PENDING, item.contact_id)

        serviceManager.api.doNetworkRequest(preference.getString(Constants.ACCESS_TOKEN), item.id, CONNECT_TYPE).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == "success") {

                    } else {
                        showToast(response.body().message)
                        updateRecord(Constants.CONNECTION_NOT_CONNECTED, item.contact_id)
                    }

                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                    updateRecord(Constants.CONNECTION_NOT_CONNECTED, item.contact_id)
                }
            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                showToast(Constants.ERROR_MSG_TOAST_1)
                updateRecord(Constants.CONNECTION_NOT_CONNECTED, item.contact_id)
            }
        })
    }


    fun acceptInvite(item: GetNetworkEmployeeData?) {
        if (item == null) return

        updateRecord(Constants.CONNECTED_TEXT, item.contact_id)


        serviceManager.api.acceptConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), item.conId.toString()).enqueue(object : Callback<GeneralResponse> {
            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {

            }

            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {

                    } else {
                        showToast(response.body().message)
                        updateRecord(Constants.INVITATION_RECEIVED, item.contact_id)
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                    updateRecord(Constants.INVITATION_RECEIVED, item.contact_id)
                }
            }
        })
    }


    fun removeConnection(item: GetNetworkEmployeeData?) {
        if (item == null) return
        updateRecord(Constants.CONNECTION_NOT_CONNECTED, item.contact_id)

        serviceManager.api.removeConnectionRequest(preference.getString(Constants.ACCESS_TOKEN), item.id.toInt()).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == "success") {
                    } else {
                        showToast(response.body().message)
                        updateRecord(Constants.CONNECTED_TEXT, item.contact_id)
                    }

                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                    updateRecord(Constants.CONNECTED_TEXT, item.contact_id)
                }
            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                showToast(Constants.ERROR_MSG_TOAST_1)
                updateRecord(Constants.CONNECTED_TEXT, item.contact_id)
            }
        })

    }


    fun connectAll() {
        executors.diskIO().execute {
            var conId = mContactsImportDao.getNotConnectedUsers()
            if (conId.isEmpty()) return@execute
            connectAllApi(conId, CustomCallBack {
                // mContactsImportDao.undoConnectAll(Constants.REQUEST_PENDING)
            })
            mContactsImportDao.connectAll(Constants.REQUEST_PENDING)
        }
    }

    private fun connectAllApi(conIds: List<String?>, failureCallBack: CustomCallBack) {
        serviceManager.api.connectAllRequest(preference.getString(Constants.ACCESS_TOKEN), conIds as java.util.ArrayList<String>?, CONNECT_TYPE).enqueue(object : Callback<GeneralResponse> {
            override fun onResponse(call: Call<GeneralResponse>, response: Response<GeneralResponse>) {

                if (response.isSuccessful) {
                    if (response.body().status == Constants.SUCCESS_STATUS) {


                    } else {
                        showToast(response.body().message)
                        failureCallBack.act()
                    }
                } else {
                    showToast(Constants.ERROR_MSG_TOAST_1)
                    failureCallBack.act()
                }
            }

            override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                showToast(Constants.ERROR_MSG_TOAST_1)
                failureCallBack.act()
            }

        })


    }

    private fun updateRecord(type: String, id: Int) {
        executors.diskIO().execute {
            mContactsImportDao.changeConnectionStatus(type, id)
        }
    }
}