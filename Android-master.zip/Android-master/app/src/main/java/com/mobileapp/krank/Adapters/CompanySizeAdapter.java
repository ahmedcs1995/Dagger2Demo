package com.mobileapp.krank.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobileapp.krank.Activities.CompanySizeDropDownScreen;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.CompanySizeData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompanySizeAdapter extends RecyclerView.Adapter<CompanySizeAdapter.ViewHolder> {
    public List<CompanySizeData> items = new ArrayList<>();
    CompanySizeDropDownScreen companySizeDropDownScreen;
    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        View unCheckView;
        View checkedView;
        View checkb;
        TextView name;


        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            unCheckView = item.findViewById(R.id.uncheck_view);
            checkedView = item.findViewById(R.id.check_view);
            checkb = item.findViewById(R.id.checkb);
            name = item.findViewById(R.id.name);
        }
    }

    public CompanySizeAdapter(List<CompanySizeData> items,  CompanySizeDropDownScreen companySizeDropDownScreen) {
        this.items = items;
        this.companySizeDropDownScreen = companySizeDropDownScreen;
    }

    public CompanySizeAdapter(CompanySizeData[] items,  CompanySizeDropDownScreen companySizeDropDownScreen) {

        this.items.addAll(Arrays.asList(items));
        this.companySizeDropDownScreen = companySizeDropDownScreen;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.drop_adapter_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CompanySizeAdapter.ViewHolder holder, final int position) {
        final CompanySizeData item = items.get(position);

        if (item.isItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setItemSelected(true);
                companySizeDropDownScreen.selectedIndex = position;
                uncheckAllItems(item);
                notifyDataSetChanged();
            }
        });
        holder.name.setText("" + item.getCompanySize());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void uncheckAllItems(CompanySizeData item){
        for(int i=0; i < items.size();i++){
            if(items.get(i).getId().equals(item.getId())){
                continue;
            }
            items.get(i).setItemSelected(false);
        }
    }
}







