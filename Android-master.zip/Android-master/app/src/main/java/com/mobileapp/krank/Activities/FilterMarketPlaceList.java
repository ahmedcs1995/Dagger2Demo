package com.mobileapp.krank.Activities;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.mobileapp.krank.Adapters.FilterMarketPlaceListAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingFilterDataModel;
import com.mobileapp.krank.ResponseModels.ListingFilterDataResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FilterMarketPlaceList extends BaseActivity {


    private RecyclerView filterRecyclerView;
    private RecyclerView.Adapter filterRecyclerAdapter;
    List<ListingFilterDataModel> Items;
    LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter_market_place_list);

        setNormalPageToolbar("Filter Marketplace");

        setUpList();
    }

    private void setUpList() {
        filterRecyclerView = findViewById(R.id.filter_recycler);
        Items = new ArrayList<>();

        getAPI().getListingFilterData(preference.getString(Constants.ACCESS_TOKEN), getIntent().getStringExtra("category_id"), getIntent().getStringExtra("sub_category_id")).enqueue(new Callback<ListingFilterDataResponse>() {
            @Override
            public void onResponse(Call<ListingFilterDataResponse> call, Response<ListingFilterDataResponse> response) {


                if (response.isSuccessful()) {

                    Items.addAll(response.body().getData());
                    if(getIntent().getIntExtra("selected_item",-1) != -1){
                        Items.get(getIntent().getIntExtra("selected_item",0)).setItemCheck(true);
                    }
                    layoutManager = new LinearLayoutManager(FilterMarketPlaceList.this);
                    filterRecyclerAdapter = new FilterMarketPlaceListAdapter(Items, FilterMarketPlaceList.this);
                    filterRecyclerView.setLayoutManager(layoutManager);
                    filterRecyclerView.setAdapter(filterRecyclerAdapter);


                }
            }

            @Override
            public void onFailure(Call<ListingFilterDataResponse> call, Throwable t) {

            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }
}
