package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationMsgBadgeDataModel {
    @SerializedName("notification_badge")
    @Expose
    private String notification_badge;
    @SerializedName("message_badge")
    @Expose
    private String message_badge;
    @SerializedName("chat_count")
    @Expose
    private String chat_count;
    @SerializedName("group_count")
    @Expose
    private String group_count;

    public String getNotification_badge() {
        return notification_badge;
    }

    public void setNotification_badge(String notification_badge) {
        this.notification_badge = notification_badge;
    }

    public String getMessage_badge() {
        return message_badge;
    }

    public void setMessage_badge(String message_badge) {
        this.message_badge = message_badge;
    }

    public String getChat_count() {
        return chat_count;
    }

    public void setChat_count(String chat_count) {
        this.chat_count = chat_count;
    }

    public String getGroup_count() {
        return group_count;
    }

    public void setGroup_count(String group_count) {
        this.group_count = group_count;
    }
}
