package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ListingDetailUserData {
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("user_slug")
    @Expose
    private String userSlug;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("user_country")
    @Expose
    private String userCountry;
    @SerializedName("user_city")
    @Expose
    private String userCity;
    @SerializedName("mobile_number")
    @Expose
    private Object mobileNumber;
    @SerializedName("hash")
    @Expose
    private Object hash;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("user_profile_pic")
    @Expose
    private String userProfilePic;
    @SerializedName("user_cover_pic")
    @Expose
    private String userCoverPic;
    @SerializedName("company_id")
    @Expose
    private String companyId;
    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("company_country")
    @Expose
    private String companyCountry;
    @SerializedName("company_city")
    @Expose
    private String companyCity;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("company_cover_pic")
    @Expose
    private String companyCoverPic;
    @SerializedName("telephone_number")
    @Expose
    private Object telephoneNumber;

    @SerializedName("price_privacy")
    @Expose
    private String price_privacy;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getUserCountry() {
        return userCountry;
    }

    public void setUserCountry(String userCountry) {
        this.userCountry = userCountry;
    }

    public String getUserCity() {
        return userCity;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public Object getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(Object mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Object getHash() {
        return hash;
    }

    public void setHash(Object hash) {
        this.hash = hash;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public String getUserCoverPic() {
        return userCoverPic;
    }

    public void setUserCoverPic(String userCoverPic) {
        this.userCoverPic = userCoverPic;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCountry() {
        return companyCountry;
    }

    public void setCompanyCountry(String companyCountry) {
        this.companyCountry = companyCountry;
    }

    public String getCompanyCity() {
        return companyCity;
    }

    public void setCompanyCity(String companyCity) {
        this.companyCity = companyCity;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getCompanyCoverPic() {
        return companyCoverPic;
    }

    public void setCompanyCoverPic(String companyCoverPic) {
        this.companyCoverPic = companyCoverPic;
    }

    public Object getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(Object telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getPrice_privacy() {
        return price_privacy;
    }

    public void setPrice_privacy(String price_privacy) {
        this.price_privacy = price_privacy;
    }
}