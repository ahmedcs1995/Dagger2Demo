package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by arbaz on 6/1/2018.
 */

public class ProfileMenuData {

    @SerializedName("user_data")
    @Expose
    private ProfileMenuUserData userData;
    @SerializedName("user_total_connections")
    @Expose
    private String userTotalConnections;
    @SerializedName("user_total_networks")
    @Expose
    private String userTotalNetworks;
    @SerializedName("user_total_listings")
    @Expose
    private String userTotalListings;
    @SerializedName("user_total_company_listings")
    @Expose
    private String userTotalCompanyListings;
    @SerializedName("user_total_listing_limit")
    @Expose
    private String userTotalListingLimit;
    @SerializedName("company_invitation")
    @Expose
    private String company_invitation;

    @SerializedName("total_contacts")
    @Expose
    private int total_contacts;

    @SerializedName("my_contacts")
    @Expose
    private int my_contacts;

    @SerializedName("last_sync_date")
    @Expose
    private String last_sync_date;

    @SerializedName("contact_popup_meta_key")
    @Expose
    private String contact_popup_meta_key;

    public ProfileMenuUserData getUserData() {
        return userData;
    }

    public void setUserData(ProfileMenuUserData userData) {
        this.userData = userData;
    }

    public String getUserTotalConnections() {
        return userTotalConnections;
    }

    public void setUserTotalConnections(String userTotalConnections) {
        this.userTotalConnections = userTotalConnections;
    }

    public String getUserTotalNetworks() {
        return userTotalNetworks;
    }

    public void setUserTotalNetworks(String userTotalNetworks) {
        this.userTotalNetworks = userTotalNetworks;
    }

    public String getUserTotalListings() {
        return userTotalListings;
    }

    public void setUserTotalListings(String userTotalListings) {
        this.userTotalListings = userTotalListings;
    }

    public String getUserTotalCompanyListings() {
        return userTotalCompanyListings;
    }

    public void setUserTotalCompanyListings(String userTotalCompanyListings) {
        this.userTotalCompanyListings = userTotalCompanyListings;
    }

    public String getUserTotalListingLimit() {
        return userTotalListingLimit;
    }

    public void setUserTotalListingLimit(String userTotalListingLimit) {
        this.userTotalListingLimit = userTotalListingLimit;
    }
    public String getCompany_invitation() {
        return company_invitation;
    }

    public void setCompany_invitation(String company_invitation) {
        this.company_invitation = company_invitation;
    }

    public int getTotal_contacts() {
        return total_contacts;
    }

    public void setTotal_contacts(int total_contacts) {
        this.total_contacts = total_contacts;
    }

    public int getMy_contacts() {
        return my_contacts;
    }

    public void setMy_contacts(int my_contacts) {
        this.my_contacts = my_contacts;
    }

    public String getLast_sync_date() {
        return last_sync_date;
    }

    public void setLast_sync_date(String last_sync_date) {
        this.last_sync_date = last_sync_date;
    }

    public String getContact_popup_meta_key() {
        return contact_popup_meta_key;
    }

    public void setContact_popup_meta_key(String contact_popup_meta_key) {
        this.contact_popup_meta_key = contact_popup_meta_key;
    }
}
