package com.mobileapp.krank.Chat;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.mobileapp.krank.Adapters.AppGeneralAdapter;
import com.mobileapp.krank.Adapters.PeopleListAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChatConversationActivity;
import com.mobileapp.krank.Database.Dao.GroupChatListDao;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Database.MyViewModelFactory;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ConnectionsDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationGroupModel;
import com.mobileapp.krank.ResponseModels.DataModel.GroupChatMembersDataModel;
import com.mobileapp.krank.ResponseModels.GroupConversationCreateResponse;
import com.mobileapp.krank.ResponseModels.GroupConversationMemberAddResponseModel;
import com.mobileapp.krank.ViewHolders.ConnectionViewHolderCircle;
import com.mobileapp.krank.ViewModels.GroupChatMemberListViewModel;


import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPeopleInPrivateChat extends BaseActivity {
    private RecyclerView peopleListRecyclerView;
    private RecyclerView chips_recycler;


    private RecyclerView.Adapter peopleListRecyclerAdapter;
    private AppGeneralAdapter<ConnectionsDataModel> selectedContactChipAdapter;

    List<GroupChatMembersDataModel> peopleListItems;


    List<ConnectionsDataModel> connectionsItems;
    List<ConnectionsDataModel> selectedContacts;

    View connection_edit_text;
    View add_people_btn;
    private SweetAlertDialog showProgressAlert;
    private static final int SELECT_PEOPLE_PAGE_CODE = 200;
    GroupChatMemberListViewModel groupChatMemberListViewModel;
    View loader;
    GroupChatConversationGroupModel groupChatConversationGroupModel;


    private CallBackWithAdapterPosition removeCallBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_people_in_private_chat);
        showProgressAlert = showAlert("Please wait...", SweetAlertDialog.PROGRESS_TYPE, false);

        init();


        initViews();


        setUpRemoveCallBack();

        setUpSelectedConnectionsAdapter();

        bindListeners();

        setNormalPageToolbar("Add People");

        setUpPeopleListAdapter();


    }

    private void setUpRemoveCallBack(){
        removeCallBack = position -> {
            selectedContactChipAdapter.removeAt(position);
        };
    }

    private void init(){
        connectionsItems = new ArrayList<>();
        selectedContacts = new ArrayList<>();
    }

    private void initViews(){
        connection_edit_text = findViewById(R.id.connection_edit_text);
        add_people_btn = findViewById(R.id.add_people_btn);
        loader = findViewById(R.id.loader);
    }


    private void setUpSelectedConnectionsAdapter(){
        chips_recycler = findViewById(R.id.chips_recycler);
        selectedContactChipAdapter = new AppGeneralAdapter<ConnectionsDataModel>(selectedContacts) {
            @Override
            public void onBind(@NonNull @NotNull RecyclerView.ViewHolder viewHolder, ConnectionsDataModel item, int position) {
                ((ConnectionViewHolderCircle)viewHolder).onBind(item);
            }

            @NotNull
            @Override
            public RecyclerView.ViewHolder onCreate(@NonNull @NotNull ViewGroup parent, int i) {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.people_view_with_circle, parent, false);
                return new ConnectionViewHolderCircle(v,removeCallBack);
            }
        };
        chips_recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        chips_recycler.setAdapter(selectedContactChipAdapter);

    }



    private void bindListeners(){
        connection_edit_text.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AddConnectionInChat.class);
            intent.putExtra("selectedArray", "" + appUtils.convertToJson(selectedContacts));
            intent.putExtra("already_added_people", "" + appUtils.convertToJson(peopleListItems));
            Log.e("already_added_people", "" + appUtils.convertToJson(peopleListItems));
            startActivityForResult(intent, SELECT_PEOPLE_PAGE_CODE);
        });

        add_people_btn.setOnClickListener(view -> {
            // if (selectedContacts.size() > 0) {

            if (getIntent().getBooleanExtra("isPersonalChat", false)) {
                createGroup();
                return;
            }
            addPeople();
            //}
        });
    }

    private void setUpPeopleListAdapter() {
        peopleListRecyclerView = findViewById(R.id.people_list_recycler);
        peopleListItems = new ArrayList<>();
        peopleListRecyclerAdapter = new PeopleListAdapter(peopleListItems, this,preference);
        peopleListRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        peopleListRecyclerView.setAdapter(peopleListRecyclerAdapter);

        if (getIntent().getBooleanExtra("isPersonalChat", false)) {
            peopleListItems.addAll(Arrays.asList(gson.fromJson(getIntent().getStringExtra("people_list_in_chat"), GroupChatMembersDataModel[].class)));
            peopleListRecyclerAdapter.notifyDataSetChanged();
        } else {
            loader.setVisibility(View.VISIBLE);
            peopleListRecyclerView.setVisibility(View.GONE);
            CustomCallBack customCallBack = () -> {
                loader.setVisibility(View.GONE);
                peopleListRecyclerView.setVisibility(View.VISIBLE);
            };
            groupChatMemberListViewModel = ViewModelProviders.of(AddPeopleInPrivateChat.this, new MyViewModelFactory(this.getApplication(), getIntent().getStringExtra("group_id"))).get(GroupChatMemberListViewModel.class);
            observeList();
            groupChatMemberListViewModel.getmRepository().requestFromSever(customCallBack);
        }
    }

    private void observeList() {
        groupChatMemberListViewModel.getmPeopleList().observe(this, peopleListItems -> {
            this.peopleListItems.clear();
            this.peopleListItems.addAll(peopleListItems);
            peopleListRecyclerAdapter.notifyDataSetChanged();
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PEOPLE_PAGE_CODE) {
                selectedContacts.clear();
                selectedContacts.addAll(Arrays.asList(gson.fromJson(data.getStringExtra("selected_connections"), ConnectionsDataModel[].class)));
                selectedContactChipAdapter.notifyDataSetChanged();
            }
        }
    }

    private void addPeople() {


        if(selectedContacts.size() <= 0){
            showToast("Please select atleast one new group member");
            return;
        }

        /**
         * Adding People
         * */
        showProgressAlert.show();
        ArrayList<String> conIds = new ArrayList<>();
        for (int i = 0; i < selectedContacts.size(); i++) {
            conIds.add(selectedContacts.get(i).getCompanyData().getUserId());
        }
        getAPI().addFurtherPeopleInGroupChat(preference.getString(Constants.ACCESS_TOKEN), getIntent().getStringExtra("group_id"), conIds).enqueue(new Callback<GroupConversationMemberAddResponseModel>() {
            @Override
            public void onResponse(Call<GroupConversationMemberAddResponseModel> call, Response<GroupConversationMemberAddResponseModel> response) {
                showProgressAlert.dismiss();
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        //goto Chat
                        Intent intent = new Intent(AddPeopleInPrivateChat.this, GroupChatConversationActivity.class);
                        intent.putExtra("member_id", "" +response.body().getData());
                        startActivity(intent);
                        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                        finish();

                    } else {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GroupConversationMemberAddResponseModel> call, Throwable t) {
                showProgressAlert.dismiss();
                Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void createGroup() {
        String group_name = "" + preference.getString(Constants.FIRST_NAME) + "" + preference.getString(Constants.LAST_NAME) + ", ";
        String group_name_to_send;
        String group_message = "Conversation Started";
        ArrayList<String> con_ids = new ArrayList<>();

        for (int i = 0; i < peopleListItems.size(); i++) {
            group_name += peopleListItems.get(i).getFirstName() + " " + peopleListItems.get(i).getLastName() + ", ";
            con_ids.add(peopleListItems.get(i).getId());
        }

        for (int i = 0; i < selectedContacts.size(); i++) {
            group_name += selectedContacts.get(i).getCompanyData().getFirstName() + " " + selectedContacts.get(i).getCompanyData().getLastName() + ", ";
            con_ids.add(selectedContacts.get(i).getCompanyData().getUserId());
        }

        group_name = group_name.trim().substring(0, group_name.length() - 2);


        if (group_name.length() > 254) {
            group_name_to_send = group_name.substring(0, 254);
        } else {
            group_name_to_send = group_name;
        }


        getAPI().createGroup(preference.getString(Constants.ACCESS_TOKEN), group_name_to_send, group_message, con_ids).enqueue(new Callback<GroupConversationCreateResponse>() {
            @Override
            public void onResponse(Call<GroupConversationCreateResponse> call, Response<GroupConversationCreateResponse> response) {
                showProgressAlert.dismiss();
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        groupChatConversationGroupModel = new GroupChatConversationGroupModel(response.body().getData().getGroup_name(),response.body().getData().getMember_id(),response.body().getData().getGroup_id(),GroupChatConversationActivity.UN_MUTE_NOTIFICATIONS,GroupChatConversationActivity.MEMBER_EXISTS_TIME,GroupChatConversationActivity.MEMBER_STATUS,preference.getString(Constants.USER_ID));
                        new InsertMemberIdInParentTable(KrankRoomDataBase.getDatabase(getApplicationContext()).groupchatConversationListDao()).execute();

                    } else {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GroupConversationCreateResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class InsertMemberIdInParentTable extends AsyncTask<Void, Void, Void> {

        private GroupChatListDao mAsyncTaskDao;

        InsertMemberIdInParentTable(GroupChatListDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Void... params) {
            mAsyncTaskDao.insert(groupChatConversationGroupModel);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            showProgressAlert.dismiss();
            Intent intent = new Intent(AddPeopleInPrivateChat.this, GroupChatConversationActivity.class);
            intent.putExtra("member_id", "" +groupChatConversationGroupModel.getMemberId());
            intent.putExtra("recipient_name", groupChatConversationGroupModel.getGroupName());
            startActivity(intent);
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
            finish();
        }
    }

}
