package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SecondUserChatDataModel {
    @SerializedName("id")
    @Expose
    @ColumnInfo(name = "second_user_id")
    private String id;


    @SerializedName("user_name")
    @Expose
    @ColumnInfo(name = "second_user_name")
    private String user_name;


    @SerializedName("profile_pic")
    @Expose
    @ColumnInfo(name = "second_user_profile_pic")
    private String profile_pic;


    @SerializedName("designation")
    @Expose
    @ColumnInfo(name = "second_user_designation")
    private String designation;


    @SerializedName("company")
    @Expose
    @ColumnInfo(name = "second_user_company")
    private String company;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(String profile_pic) {
        this.profile_pic = profile_pic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
