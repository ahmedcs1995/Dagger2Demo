package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.DealerEmployeeSelect;
import com.mobileapp.krank.Activities.DealersSelectFromListing;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.DealerDataListing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DealerListingAdapter extends RecyclerView.Adapter<DealerListingAdapter.ViewHolder>  {
    private List<DealerDataListing> items;
    DealersSelectFromListing dealersSelectFromListing;


    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        ImageView company_image_view;
        TextView company_name_text_view;
        TextView country_and_city_text_view;
        TextView status_text;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            company_image_view = item.findViewById(R.id.company_image_view);
            company_name_text_view = item.findViewById(R.id.company_name_text_view);
            country_and_city_text_view = item.findViewById(R.id.country_and_city_text_view);
            status_text = item.findViewById(R.id.status_text);

            item.setOnClickListener(view -> {
                Intent intent = new Intent(dealersSelectFromListing.getApplicationContext(),DealerEmployeeSelect.class);
                intent.putExtra("companyId","" + items.get(getAdapterPosition()).getId());
                intent.putExtra("company_name","" + items.get(getAdapterPosition()).getCompanyName());
                intent.putExtra("dealer_item_index",getAdapterPosition());
                intent.putExtra("selected_employee","" + dealersSelectFromListing.getIntent().getStringExtra("selected_employee"));
                intent.putExtra("listing_id","" + dealersSelectFromListing.getIntent().getStringExtra("listing_id"));
                dealersSelectFromListing.startActivityForResult(intent,dealersSelectFromListing.EMPLOYEES_ACTIVITY_CODE);
            });
        }
    }

    public DealerListingAdapter(List<DealerDataListing> items, DealersSelectFromListing dealersSelectFromListing) {
        this.items = items;
        this.dealersSelectFromListing = dealersSelectFromListing;

    }


    @Override
    public DealerListingAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.employee_select_from_dealer_list, parent, false);
        return new DealerListingAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final DealerListingAdapter.ViewHolder holder, int position) {
        final DealerDataListing item = items.get(position);

        holder.company_name_text_view.setText(item.getCompanyName());
        String country = item.getCountryName() != null ? item.getCountryName() : "N/A";
        String city = item.getCityName() != null ? item.getCityName() : "N/A";

        holder.country_and_city_text_view.setText(city + ", " + country);


        Glide.with(dealersSelectFromListing.getApplicationContext()).load(item.getCompanyProfilePic()).into(holder.company_image_view);
       /* holder.item.setOnClickListener(view -> {
            Intent intent = new Intent(dealersSelectFromListing.getApplicationContext(),DealerEmployeeSelect.class);
            intent.putExtra("companyId","" + item.getUserId());
            intent.putExtra("company_name","" + item.getCompanyName());
            intent.putExtra("dealer_item_index",position);
            intent.putExtra("selected_employee","" + dealersSelectFromListing.getIntent().getStringExtra("selected_employee"));
            intent.putExtra("listing_id","" + dealersSelectFromListing.getIntent().getStringExtra("listing_id"));
            dealersSelectFromListing.startActivityForResult(intent,dealersSelectFromListing.EMPLOYEES_ACTIVITY_CODE);
        });*/
        holder.status_text.setText("" + item.getNetworkStatus());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}





