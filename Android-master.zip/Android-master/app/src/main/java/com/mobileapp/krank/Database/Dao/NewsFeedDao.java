package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.mobileapp.krank.ResponseModels.DataModel.NewsFeedArray;

import java.util.List;
@Dao
public interface NewsFeedDao {

    @Query("SELECT * from news_feed_table order by id desc")
    LiveData<List<NewsFeedArray>> getAllRecords();


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<NewsFeedArray> feed);

    @Query("DELETE FROM news_feed_table")
    void deleteAll();


    @Query("update news_feed_table set like_count=:likeCount, is_like=:isLike where id=:id")
    void updateLikeByFeedId(int id,int isLike,int likeCount);

    @Query("update news_feed_table set like_count=:likeCount, is_like=:isLike,comment_count=:commentCount where id=:id")
    void updateLikeCommentByFeedId(int id,int isLike,int likeCount,int commentCount);

    @Query("DELETE FROM news_feed_table where id=:id")
    void deleteById(int id);
}
