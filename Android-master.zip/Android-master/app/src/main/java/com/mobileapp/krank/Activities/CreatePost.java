package com.mobileapp.krank.Activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.Adapters.AppGeneralAdapter;
import com.mobileapp.krank.Adapters.DealerGroupChipAdapter;
import com.mobileapp.krank.Adapters.NetworkGroupChipAdapter;
import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.CustomImagePicker.CustomImagePicker;
import com.mobileapp.krank.CustomViews.RobotoRegularEditText;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.Functions.ImageUtils;
import com.mobileapp.krank.Model.CreatePostData;
import com.mobileapp.krank.Model.LinkDataToSend;
import com.mobileapp.krank.Model.PrivacyItem;
import com.mobileapp.krank.Model.Enums.TypeOfShare;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.CreatePostResponse;
import com.mobileapp.krank.ResponseModels.DataModel.DealerGroupDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkGroupDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.TagConnectionsNewsFeedPostDataModel;
import com.mobileapp.krank.ResponseModels.UploadImageResponse;
import com.mobileapp.krank.ResponseModels.UrlScrapperResponse;
import com.mobileapp.krank.ViewHolders.ChipViewHolder;


import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cn.pedant.SweetAlert.SweetAlertDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CreatePost extends BaseActivity {


    //permissions
    private static final int REQUEST_PERMISSION_CAMERA = 4;
    private static final int REQUEST_PERMISSION_GALLERY = 4;

    View tagPeopleView;
    View locationView;
    View updateStatus;

    //share types enum
    TypeOfShare typeOfShare;
    RobotoRegularEditText postDescription;

    //check box
    CheckBox checkBox;
    boolean checkBoxCheck;

    //loader
    private SweetAlertDialog showProgressAlert;

    //map
    private MarkerOptions markerOption;
    private Marker mMarker;

    //img post
    View cameraPick;
    View galleryPick;
    ImageView imgForPost;

    //request
    private static int REQUEST_CAMERA = 500;
    private static int REQUEST_GALLERY = 400;


    //for image
    Uri imageUri;
    private String mediaPath;
    Bitmap thumbnail;
    boolean isImgSelected;
    boolean isMapSelected;
    boolean isLinkVisible;
    View imgContainer;
    CircleImageView userImg;
    TextView usernmae;
    TextView companyName;
    View crossBtn;


    private int privacyId;

    //chip
    List<TagConnectionsNewsFeedPostDataModel> taggedConnections;
    ArrayList<DealerGroupDataModel> selectedDealerGroup;
    ArrayList<DealerGroupDataModel> tempDealerGroup;
    ArrayList<NetworkGroupDataModel> selectedNetworkGroup;
    ArrayList<NetworkGroupDataModel> tempNetworkGroup;

    //call backs for chip View
    CallBackWithAdapterPosition tagConnectionsCallBack;
    CallBackWithAdapterPosition networkGroupCallBack;
    CallBackWithAdapterPosition dealerGroupCallBack;

    //address
    String address;
    double latitude;
    double longitude;

    //chip adapter
    AppGeneralAdapter<TagConnectionsNewsFeedPostDataModel> tagConnectionsChipAdapter;
    RecyclerView.Adapter networkGroupChipAdapter;
    RecyclerView.Adapter dealerGroupChipAdapter;

    //chip recycler
    RecyclerView tagConnectionsChipRecyclerView;
    RecyclerView networkGroupChipRecycler;
    RecyclerView dealerGroupChipRecycler;

    //chip Views
    TextView tagConnectionsChipText;
    TextView networkGroupChipText;
    TextView dealerGroupChipText;
    View tagConnectionsContainer;
    View networkGroupContainer;
    View textboxContainer;
    View dealerContainer;

    //map
    private GoogleMap map;
    private MapView mapView;
    View mapContainer;
    View mapCross;
    TextView checkInAddress;

    //url scraper
    TextView urlExtractorTitle;
    TextView urlExtractorDes;
    ImageView urlExtractorImg;
    View urlExtractorContainer;
    ProgressBar urlLoader;
    View urlExtractorCard;
    View link_cross_btn;
    String extractedImg;
    String urlToSend;

    //privacy
    View selector;
    PrivacyItem selectedPrivacy;
    TextView share_with_text;

    //activity codes
    private static int PRIVACY_ACTIVITY_CODE = 100;
    private static int TAGGED_ACTIVITY_REQUEST_CODE = 10;
    private static int CHECK_IN_REQUEST_CODE = 20;
    private static int DEALER_GROUP_REQUEST_CODE = 15;
    private static int NETWORK_GROUP_REQUEST_CODE = 18;

    CustomImagePicker imagePicker;




    private void init(){
        //chip view list
        taggedConnections = new ArrayList<>();
        selectedDealerGroup = new ArrayList<>();
        selectedNetworkGroup = new ArrayList<>();
        tempNetworkGroup = new ArrayList<>();
        tempDealerGroup = new ArrayList<>();


        //map
        address = null;
        latitude = 0;
        longitude = 0;

        urlToSend = "";


        /**
         * Image Picker
         * */
        imagePicker = new CustomImagePicker();

        /**
         * Drop Down
         * */
        selectedPrivacy = new PrivacyItem("Connections");

        /**
         *
         * Default Privacy
         * */
        typeOfShare = TypeOfShare.CONNECTIONS;
        privacyId = 1;

        /**
         * Flags
         * */
        isImgSelected = false;
        isMapSelected = false;
        isLinkVisible = false;
        checkBoxCheck = false;

        /**
         * Loader
         * */
        showProgressAlert = showAlert("Posting Please wait...", SweetAlertDialog.PROGRESS_TYPE, false);
    }


    private void initViews(){
        //views

        /**
         * link Post
         * */
        urlExtractorImg = findViewById(R.id.url_extractor_img);
        urlExtractorCard = findViewById(R.id.url_card_view);
        link_cross_btn = findViewById(R.id.link_cross_btn);
        urlLoader = findViewById(R.id.url_loader);
        urlExtractorContainer = findViewById(R.id.url_extractor_container);
        urlExtractorTitle = findViewById(R.id.url_extractor_title);
        urlExtractorDes = findViewById(R.id.url_extractor_des);

        //header
        selector = findViewById(R.id.selector);
        share_with_text = findViewById(R.id.share_with_text);
        userImg = findViewById(R.id.profile_img);
        usernmae = findViewById(R.id.user_name);
        companyName = findViewById(R.id.company_name);


        //image
        imgContainer = findViewById(R.id.img_container);
        imgForPost = findViewById(R.id.img_for_post);
        crossBtn = findViewById(R.id.cross_btn);


        //privacy check box
        checkBox = findViewById(R.id.checkb);

        //bottom buttons
        locationView = findViewById(R.id.location_view);
        cameraPick = findViewById(R.id.camera_pick);
        galleryPick = findViewById(R.id.gallery_pick);
        tagPeopleView = findViewById(R.id.tag_people_page);


        //button
        updateStatus = findViewById(R.id.update_status);
        updateStatus.setAlpha(0.6f);

        //post Edit text
        postDescription = findViewById(R.id.post_description);

    }

    private void initmMap(Bundle savedInstanceState){
        /*google map*/
        mapView = (MapView) findViewById(R.id.map_view);
        mapView.onCreate(savedInstanceState);
        mapView.onResume();
        try {
            MapsInitializer.initialize(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        mapView.getMapAsync(googleMap -> {
            map = googleMap;
            map.getUiSettings().setScrollGesturesEnabled(false);
            map.getUiSettings().setZoomGesturesEnabled(false);


        });
        /*google map*/
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);


        setUpAdapterCallBacks();



        init();



        initViews();


        initmMap(savedInstanceState);


        /**
         *
         * Map
         *
         * */
        checkInAddress = findViewById(R.id.map_text);
        mapCross = findViewById(R.id.map_cross);

        mapCross.setOnClickListener(view -> removeCheckInMap());
        /*Map*/


        /**
         *
         * Chip Recycler
         *
         * */
        tagConnectionsChipRecyclerView = (RecyclerView) findViewById(R.id.tag_connections_chip);
        networkGroupChipRecycler = (RecyclerView) findViewById(R.id.network_group_chip_recycler_view);
        dealerGroupChipRecycler = (RecyclerView) findViewById(R.id.dealer_chip_recycler_view);
        /*Chip Recycler*/


        /**
         *
         * Chip View
         *
         * */
        tagConnectionsChipText = findViewById(R.id.tag_connection_chip_text);
        networkGroupChipText = findViewById(R.id.network_group_chip_text);
        dealerGroupChipText = findViewById(R.id.dealer_group_chip_text);
        tagConnectionsContainer = findViewById(R.id.tag_connections_container);
        mapContainer = findViewById(R.id.map_container);
        networkGroupContainer = findViewById(R.id.network_group_container);
        textboxContainer = findViewById(R.id.textbox_container);
        dealerContainer = findViewById(R.id.dealer_container);
        /*Chip View*/


        CustomCallBack customCallBack = () -> {
                taggedConnections.clear();
                tagConnectionsChipAdapter.notifyDataSetChanged();
                checkTagConnectionsContainerVisibility();
                checkNetworkContainerVisibility();
                checkDealerContainerVisibility();

        };


        /**
        * Chip Adapters
        */
        setUpTagConnectionsChipAdapter();

        //setUpTagNetworkGroupChipAdapter();

        networkGroupChipAdapter = new NetworkGroupChipAdapter(selectedNetworkGroup, tempNetworkGroup, this, networkGroupChipText, networkGroupContainer,customCallBack);
        networkGroupChipRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        networkGroupChipRecycler.setAdapter(networkGroupChipAdapter);



        dealerGroupChipAdapter = new DealerGroupChipAdapter(selectedDealerGroup, tempDealerGroup, this, dealerGroupChipText, dealerContainer,customCallBack);
        dealerGroupChipRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        dealerGroupChipRecycler.setAdapter(dealerGroupChipAdapter);

        /*
         * Chip Adapters
         */


        checkTagConnectionsContainerVisibility();
        checkNetworkContainerVisibility();
        checkDealerContainerVisibility();



        postDescription.requestFocus();





        setUpDesListeners();



        /**
         *
         * Header
         * */
        Glide.with(getApplicationContext()).load(AppUtils.getImgUrl(preference.getString(Constants.PROFILE_PICTURE))).into(userImg);
        usernmae.setText(preference.getString(Constants.FIRST_NAME) + " " + preference.getString(Constants.LAST_NAME));
        companyName.setText(preference.getString(Constants.JOB_TITLE) + "@" + preference.getString(Constants.COMPANY_NAME));


        setUpListeners();


        setNormalPageToolbar("Create Post");


    }

    private void onNetworkDealerGroupClick(){
        taggedConnections.clear();
        tagConnectionsChipAdapter.notifyDataSetChanged();
        checkTagConnectionsContainerVisibility();
        checkNetworkContainerVisibility();
        checkDealerContainerVisibility();
    }

    private void setUpTagConnectionsChipAdapter() {
        tagConnectionsChipAdapter = new AppGeneralAdapter<TagConnectionsNewsFeedPostDataModel>(taggedConnections) {
            @Override
            public void onBind(@NonNull @NotNull RecyclerView.ViewHolder viewHolder, TagConnectionsNewsFeedPostDataModel item, int position) {
                ((ChipViewHolder)viewHolder).onBind(item);
            }

            @NotNull
            @Override
            public RecyclerView.ViewHolder onCreate(@NonNull @NotNull ViewGroup parent, int i) {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chip_view_item, parent, false);
                return new ChipViewHolder(v,tagConnectionsCallBack);
            }
        };
        tagConnectionsChipRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        tagConnectionsChipRecyclerView.setAdapter(tagConnectionsChipAdapter);
    }


    private void setUpDesListeners(){
        postDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


                if (charSequence.toString().length() > 0) {
                    if ((charSequence.toString().charAt(charSequence.toString().length() - 1) == '\n' || charSequence.toString().charAt(charSequence.toString().length() - 1) == ' ') && !isImgSelected) {
                        List<String> extractedUrls = extractUrls("" + charSequence.toString());
                        if (extractedUrls.size() > 0) {
                            urlExtractorCard.setVisibility(View.GONE);
                            link_cross_btn.setVisibility(View.GONE);
                            urlLoader.setVisibility(View.VISIBLE);
                            String url = extractedUrls.get(0);
                            urlExtractorContainer.setVisibility(View.VISIBLE);
                            isLinkVisible = true;
                            setThumbnailForLinkPost(url);

                            return;
                        }

                    }
                    enableBtnAlpha();
                    return;
                }
                disableBtnAlpha();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        postDescription.setOnPasteListener(() -> {
            List<String> extractedUrls = extractUrls("" + postDescription.getText().toString());
            if (extractedUrls.size() > 0) {
                urlExtractorCard.setVisibility(View.GONE);
                link_cross_btn.setVisibility(View.GONE);
                urlLoader.setVisibility(View.VISIBLE);
                String url = extractedUrls.get(0);
                urlExtractorContainer.setVisibility(View.VISIBLE);
                setThumbnailForLinkPost(url);
            }
        });
    }

    private void enableBtnAlpha(){
        updateStatus.setAlpha(1f);
    }

    private void disableBtnAlpha(){
        updateStatus.setAlpha(0.6f);
    }


    private void setUpListeners(){

        link_cross_btn.setOnClickListener(view -> removeLinkView());


        crossBtn.setOnClickListener(view -> {
           /* imgForPost.setImageBitmap(null);
            imgContainer.setVisibility(View.GONE);
            isImgSelected = false;*/
            removeImg();
        });


        checkBox.setOnCheckedChangeListener((compoundButton, b) -> {
            checkBoxCheck = b;
            if (checkBoxCheck) {


                typeOfShare = TypeOfShare.PUBLIC_COMPANY_NEWS_FEED;
                share_with_text.setText("Public");
                selectedPrivacy.setPrivacy("Public");

                selectedDealerGroup.clear();
                selectedNetworkGroup.clear();
                taggedConnections.clear();


                tagConnectionsChipAdapter.notifyDataSetChanged();
                networkGroupChipAdapter.notifyDataSetChanged();
                dealerGroupChipAdapter.notifyDataSetChanged();


                checkNetworkContainerVisibility();
                checkDealerContainerVisibility();
                checkTagConnectionsContainerVisibility();
            } else {
                typeOfShare = TypeOfShare.CONNECTIONS;
                share_with_text.setText("Connections");
                selectedPrivacy.setPrivacy("Connections");
            }
        });


        galleryPick.setOnClickListener(view -> {
            if (isMapSelected) {
                showDeleteDialogBox("GALLERY", "Your checkin will be removed");
                return;
            } else if (isLinkVisible) {
                showDeleteDialogBox("GALLERY", "Your Link will be removed");
                return;
            }
            openGallery();


        });



        selector.setOnClickListener(view -> {
            Intent intent = new Intent(CreatePost.this, SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", gson.toJson(selectedPrivacy));
            intent.putExtra("selected_network_group", gson.toJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", gson.toJson(tempDealerGroup));
            startActivityForResult(intent, PRIVACY_ACTIVITY_CODE);
        });


        cameraPick.setOnClickListener(view -> {
            if (isMapSelected) {
                showDeleteDialogBox("CAMERA", "Your checkin will be removed");
                return;
            } else if (isLinkVisible) {
                showDeleteDialogBox("CAMERA", "Your Link will be removed");
                return;
            }
            openCamera();
        });

        tagPeopleView.setOnClickListener(view -> {
            Intent intent = new Intent(CreatePost.this, TagConnections.class);
            Log.e("privacyId", "" + privacyId);
            intent.putExtra("privacyId", privacyId);
            intent.putExtra("Network_ids", appUtils.convertToJson(getNetworkIds()));
            intent.putExtra("Dealer_ids", appUtils.convertToJson(getDealerIds()));

            intent.putExtra("selectedArray", "" + appUtils.convertToJson(taggedConnections));
            startActivityForResult(intent, TAGGED_ACTIVITY_REQUEST_CODE);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        });
        locationView.setOnClickListener(view -> {
            if (postDescription.getText().toString().length() > 0 && isImgSelected) {
                showDeleteDialogBox("CHECKIN_WITH_IMAGE_TEXT", "Your text & image will be removed");
                return;
            } else if (postDescription.getText().toString().length() > 0 && !isImgSelected) {
                showDeleteDialogBox("CHECKIN_WITH_TEXT", "Your text will be removed");
                return;

            } else if (postDescription.getText().toString().length() == 0 && isImgSelected) {
                showDeleteDialogBox("CHECKIN_WITH_IMAGE", "Your image will be removed");
                return;
            } else if (isLinkVisible) {
                showDeleteDialogBox("CHECKIN_WITH_LINK", "Your link will be removed");
                return;
            }
            gotoCheckInActivity();
        });
        updateStatus.setOnClickListener(view -> {
            if (isLinkVisible) {
                // stopping from post while link is visible.........
                if(urlToSend == null || urlToSend.isEmpty()) return;
                createPost("");
                return;
            }
            if (!isMapSelected) {
                if (postDescription.getText().toString().length() > 0) {
                    showProgressAlert.show();
                    if (isImgSelected) {

                        mediaPath = ImageUtils.compressImage(thumbnail ,this);

                        uploadImage("news-feed");
                    } else {
                        createPost("");
                    }
                }
            } else {
                showProgressAlert.show();
                createPost("");
            }
        });
    }

    private void setUpAdapterCallBacks(){
        tagConnectionsCallBack = position -> {
            taggedConnections.remove(position);
            checkTagConnectionsContainerVisibility();
            tagConnectionsChipAdapter.notifyDataSetChanged();
        };
        networkGroupCallBack = position -> {
            selectedNetworkGroup.remove(position);
            networkGroupChipAdapter.notifyDataSetChanged();

            tempNetworkGroup.remove(position);

            checkNetworkContainerVisibility();

            onNetworkDealerGroupClick();
        };
        dealerGroupCallBack = position -> {
            selectedDealerGroup.remove(position);
            dealerGroupChipAdapter.notifyDataSetChanged();

            tempDealerGroup.remove(position);

            checkDealerContainerVisibility();

            onNetworkDealerGroupClick();
        };
    }

    private void removeImg() {
        imgForPost.setImageBitmap(null);
        imgContainer.setVisibility(View.GONE);
        isImgSelected = false;
    }

    private void gotoCheckInActivity() {
        Intent intent = new Intent(CreatePost.this, CheckInActivity.class);
        intent.putExtra("address", address);
        intent.putExtra("lat", latitude);
        intent.putExtra("long", longitude);
        startActivityForResult(intent, CHECK_IN_REQUEST_CODE);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    private void removeCheckInMap() {
        mapContainer.setVisibility(View.GONE);
        address = null;
        latitude = 0;
        longitude = 0;
        isMapSelected = false;
        textboxContainer.setVisibility(View.VISIBLE);
        updateStatus.setAlpha(0.6f);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
          //  ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA}, REQUEST_PERMISSION_CAMERA);
            AppUtils.requestPermissions(REQUEST_PERMISSION_CAMERA,this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA});
            return;
        }
        imagePicker.pickImageFromCameraOnly(CreatePost.this,REQUEST_CAMERA);
       // ImagePicker.pickImageCameraOnly(CreatePost.this,REQUEST_CAMERA);
    }

    private void openGallery(){

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            //  ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA}, REQUEST_PERMISSION_CAMERA);
            AppUtils.requestPermissions(REQUEST_PERMISSION_GALLERY,this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE});
            return;
        }
        imagePicker.pickImageFromGalleryOnly(this,REQUEST_GALLERY);
      //  ImagePicker.pickImage(CreatePost.this, "Select Img", REQUEST_GALLERY, true);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        if (requestCode == REQUEST_PERMISSION_CAMERA && grantResults.length > 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
        else  if (requestCode == REQUEST_PERMISSION_GALLERY && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            }
        }
    }
    private void setMarker(final LatLng latLng) {
        if (markerOption == null) {
            markerOption = new MarkerOptions().position(latLng).draggable(false);

            mMarker = map.addMarker(markerOption);
            zoomToLocation(latLng);
            return;
        }
        mMarker.setPosition(latLng);
        zoomToLocation(latLng);


    }

    private void zoomToLocation(LatLng loc) {
        map.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition.Builder().target(loc).zoom(10f).build()));
    }



    private void checkTagConnectionsContainerVisibility() {
        if (taggedConnections.size() <= 0) {
            tagConnectionsContainer.setVisibility(View.GONE);
            return;
        }
        tagConnectionsChipText.setText("You have selected " + taggedConnections.size() + " tagged people");
        tagConnectionsContainer.setVisibility(View.VISIBLE);
    }

    private void checkNetworkContainerVisibility() {
        if (selectedNetworkGroup.size() <= 0) {
            networkGroupContainer.setVisibility(View.GONE);
            return;
        }
        networkGroupChipText.setText("You have selected " + selectedNetworkGroup.size() + " network group");
        networkGroupContainer.setVisibility(View.VISIBLE);
    }

    private void checkDealerContainerVisibility() {
        if (selectedDealerGroup.size() <= 0) {
            dealerContainer.setVisibility(View.GONE);
            return;
        }
        dealerGroupChipText.setText("You have selected " + selectedDealerGroup.size() + " dealer group");
        dealerContainer.setVisibility(View.VISIBLE);
    }

    private List<String> getDealerIds() {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < selectedDealerGroup.size(); i++) {
            ids.add(selectedDealerGroup.get(i).getId());
        }
        return ids;
    }

    private List<String> getNetworkIds() {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < selectedNetworkGroup.size(); i++) {
            ids.add(selectedNetworkGroup.get(i).getId());
        }
        return ids;
    }

    public void createPost(String imgUrl) {
        Log.e("Access Token", "" + preference.getString(Constants.ACCESS_TOKEN));

        LinkDataToSend linkDataToSend = null;
        String desc = null;
        int isCompanyNews;
        if (checkBoxCheck) {
            isCompanyNews = 2;
        } else {
            isCompanyNews = 1;
        }
        int postType;
        if (!isMapSelected && isImgSelected) {
            postType = 1;
          //  desc = postDescription.getText().toString();
            desc = appUtils.replaceScriptString(postDescription.getText().toString());
            if(desc.length() < 0){

                return;
            }
        } else if (isMapSelected) {
            postType = 11;
            desc = "" + latitude + "," + longitude;
        } else if (isLinkVisible) {
            postType = 0;
            if (urlToSend.contains("https://www.youtube.com")) {
                desc = "share_link_youtube_post";
            } else if (urlToSend.contains("https://player.vimeo.com")) {
                desc = "share_link_vimeo_post";
            } else {
                desc = "share_link_content_post";
            }
            linkDataToSend = new LinkDataToSend(urlExtractorTitle.getText().toString(), urlExtractorDes.getText().toString(), extractedImg, urlToSend, urlToSend);
        } else {
            postType = 0;
          //  desc = postDescription.getText().toString();
            desc = appUtils.replaceScriptString(postDescription.getText().toString());
            if(desc.length() < 0 && !(desc.equals(Constants.NBSP))){
                return;
            }
        }
        int privacyId = 5;


        switch (typeOfShare) {
            case PUBLIC_COMPANY_NEWS_FEED:
                privacyId = 1;
                break;
            case CONNECTIONS:
                privacyId = 5;
                break;
            case CO_WORKERS:
                privacyId = 6;
                break;
            case NETWORK:
                privacyId = 7;
                break;
            case NETWORK_GROUP:
                privacyId = 8;
                break;
            case DEALER_GROUP:
                privacyId = 9;
                break;
            case PRIVATE_CONNECTION:
                privacyId = 55;
                break;
        }
        Log.e("sending privacy", " = " + privacyId);


        ArrayList<String> tag_id = new ArrayList<>();
        for (int i = 0; i < taggedConnections.size(); i++) {
            tag_id.add(taggedConnections.get(i).getUserId());
        }
        ArrayList<String> groups = new ArrayList<>();

        for (int i = 0; i < selectedDealerGroup.size(); i++) {
            Log.e("dealer Group Id", "" + selectedDealerGroup.get(i).getId());
            groups.add(selectedDealerGroup.get(i).getId());
        }
        for (int i = 0; i < selectedNetworkGroup.size(); i++) {
            Log.e("network Group Id", "" + selectedNetworkGroup.get(i).getId());
            groups.add(selectedNetworkGroup.get(i).getId());
        }

        try {
            CreatePostData createPostData = new CreatePostData(String.valueOf(isCompanyNews), String.valueOf(postType), imgUrl, String.valueOf(privacyId), tag_id, groups, desc, address, linkDataToSend);

            getAPI().createPost(preference.getString(Constants.ACCESS_TOKEN), createPostData).enqueue(new Callback<CreatePostResponse>() {
                @Override
                public void onResponse(Call<CreatePostResponse> call, Response<CreatePostResponse> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            showProgressAlert.dismiss();
                            Intent intent = new Intent();
                            setResult(RESULT_OK, intent);
                            finish();
                        }
                    }
                    showProgressAlert.dismiss();


                    Log.e("response success ->", "" + response.toString());

                    //finish();
                }

                @Override
                public void onFailure(Call<CreatePostResponse> call, Throwable t) {
                    Toast.makeText(CreatePost.this,Constants.ERROR_MSG_TOAST_1,Toast.LENGTH_SHORT).show();
                    showProgressAlert.dismiss();
                }
            });

        } catch (Exception ex) {

        }

    }

    public List<String> extractUrls(String text) {
        List<String> containedUrls = new ArrayList<String>();
        //  String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
        // String urlRegex = "[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)\n";
        String urlRegex = "[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)";
        Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
        Matcher urlMatcher = pattern.matcher(text);

        while (urlMatcher.find()) {
            containedUrls.add(text.substring(urlMatcher.start(0),
                    urlMatcher.end(0)));
        }

        return containedUrls;
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    public void uploadImage(final String uploadType) {
        File file = new File(mediaPath);

        RequestBody requestBodyid = RequestBody.create(MediaType.parse("image/jpeg"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("upload_file", file.getName(), requestBodyid);

        getAPI().uploadNewsFeedImg(preference.getString(Constants.ACCESS_TOKEN), uploadType, body).enqueue(new Callback<UploadImageResponse>() {
            @Override
            public void onResponse(Call<UploadImageResponse> call, Response<UploadImageResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        //Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        createPost(response.body().getData().getFileName());
                    }

                } else {
                    int statusCode = response.code();
                     showProgressAlert.dismiss();
                    // handle request errors depending on status code

                }
            }

            @Override
            public void onFailure(Call<UploadImageResponse> call, Throwable t) {
                showProgressAlert.dismiss();

            }
        });
    }

    private void showDeleteDialogBox(final String actionToPerform, String title) {


        NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, this))
                .setHeading("This erases the entire conversation history, which cannot be undone")
                .setDescription(title)
                .setConfirmButtonText("OK")
                .setCancelButtonText("Cancel")
                .setConfirmButtonListener(dialog1 -> {
                    if (actionToPerform.equals("CAMERA")) {
                        removeCheckInMap();
                        removeLinkView();
                        openCamera();
                    } else if (actionToPerform.equals("GALLERY")) {
                        removeCheckInMap();
                        removeLinkView();
                        openGallery();
                    } else if (actionToPerform.equals("CHECKIN_WITH_IMAGE_TEXT")) {
                        postDescription.setText("");
                        removeImg();
                        gotoCheckInActivity();
                    } else if (actionToPerform.equals("CHECKIN_WITH_IMAGE")) {
                        removeImg();
                        gotoCheckInActivity();
                    } else if (actionToPerform.equals("CHECKIN_WITH_TEXT")) {
                        postDescription.setText("");
                        gotoCheckInActivity();
                    } else if (actionToPerform.equals("CHECKIN_WITH_LINK")) {
                        removeLinkView();
                        gotoCheckInActivity();
                    }
                    dialog1.dismiss();
                });

        dialog.show();

    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                imgContainer.setVisibility(View.VISIBLE);
                isImgSelected = true;
                thumbnail = imagePicker.handleImagePick(requestCode, this, data);
                //thumbnail = ImagePicker.getImageFromResult(CreatePost.this,requestCode,resultCode,data);
                imgForPost.setImageBitmap(thumbnail);
            } else if (requestCode == REQUEST_GALLERY) {
                imgContainer.setVisibility(View.VISIBLE);
                isImgSelected = true;
               // thumbnail = ImagePicker.getImageFromResult(this, REQUEST_GALLERY, resultCode, data);
                thumbnail = imagePicker.handleImagePick(requestCode, this, data);
                imgForPost.setImageBitmap(thumbnail);
            } else if (requestCode == TAGGED_ACTIVITY_REQUEST_CODE) {
                Log.e("Tagged Activiy", "yes");

                String dataReceived = data.getStringExtra("taggedIds");
                taggedConnections.clear();
                taggedConnections.addAll(Arrays.asList(gson.fromJson(dataReceived.toString(), TagConnectionsNewsFeedPostDataModel[].class)));

                tagConnectionsChipAdapter.notifyDataSetChanged();
                checkTagConnectionsContainerVisibility();
                Log.e("Tag Connection dataRec", "" + dataReceived);

            } else if (requestCode == DEALER_GROUP_REQUEST_CODE) {
                Log.e("Dealer Group On Ac", "yes");

                String dataReceived = data.getStringExtra("SelectedDealerGroup");

                selectedDealerGroup.clear();
                selectedNetworkGroup.clear();
                taggedConnections.clear();


                tagConnectionsChipAdapter.notifyDataSetChanged();
                networkGroupChipAdapter.notifyDataSetChanged();
                dealerGroupChipAdapter.notifyDataSetChanged();


                selectedDealerGroup.addAll(Arrays.asList(gson.fromJson(dataReceived.toString(), DealerGroupDataModel[].class)));

                checkNetworkContainerVisibility();
                checkDealerContainerVisibility();
                checkTagConnectionsContainerVisibility();
                Log.e("dataRec", "" + dataReceived);

            } else if (requestCode == NETWORK_GROUP_REQUEST_CODE) {
                Log.e("Network Group On Ac", "yes");

                String dataReceived = data.getStringExtra("SelectedDealerGroup");

                selectedDealerGroup.clear();
                selectedNetworkGroup.clear();
                taggedConnections.clear();


                selectedNetworkGroup.addAll(Arrays.asList(gson.fromJson(dataReceived.toString(), NetworkGroupDataModel[].class)));

                networkGroupChipAdapter.notifyDataSetChanged();
                dealerGroupChipAdapter.notifyDataSetChanged();
                tagConnectionsChipAdapter.notifyDataSetChanged();

                checkNetworkContainerVisibility();
                checkDealerContainerVisibility();
                checkTagConnectionsContainerVisibility();
                Log.e("dataRec", "" + dataReceived);
            } else if (requestCode == CHECK_IN_REQUEST_CODE) {
                isMapSelected = true;
                address = data.getStringExtra("address");
                latitude = data.getDoubleExtra("lat", 0);
                longitude = data.getDoubleExtra("long", 0);
                Log.e("latLong Recve ", "" + latitude + ", " + longitude);
                textboxContainer.setVisibility(View.GONE);
                mapContainer.setVisibility(View.VISIBLE);
                setMarker(new LatLng(latitude, longitude));
                checkInAddress.setText(address);
                updateStatus.setAlpha(1f);

            } else if (requestCode == PRIVACY_ACTIVITY_CODE) {
                selectedPrivacy = gson.fromJson(data.getStringExtra("selected_privacy"), PrivacyItem.class);
                checkBox.setChecked(false);
                handlePrivacyDropDown(selectedPrivacy.getPrivacy(), data.getStringExtra("SelectedNetworkGroup"), data.getStringExtra("SelectedDealerGroup"));
            }
        }
    }

    private void handlePrivacyDropDown(String data, String selectedNetworkGrp, String selectedDealerGrp) {

        share_with_text.setText(data);

        switch (data) {
            case Constants.CONNECTIONS_PRIVACY:
                taggedConnections.clear();
                typeOfShare = TypeOfShare.CONNECTIONS;
                //    privacyId = 5;
                privacyId = 1;
                break;
            case Constants.CO_WORKER_PRIVACY:
                taggedConnections.clear();
                typeOfShare = TypeOfShare.CO_WORKERS;
                privacyId = 6;
                break;
            case Constants.NETWORK_PRIVACY:
                taggedConnections.clear();
                typeOfShare = TypeOfShare.NETWORK;
                privacyId = 7;
                break;
            case Constants.PUBLIC_PRIVACY:
                privacyId = 1;
                taggedConnections.clear();
                typeOfShare = TypeOfShare.PUBLIC_COMPANY_NEWS_FEED;
                checkBox.setChecked(true);
                break;
            case Constants.NETWORK_GROUPS_PRIVACY:
                typeOfShare = TypeOfShare.NETWORK_GROUP;
                privacyId = 8;
                handleNetworkGroup(selectedNetworkGrp);
                break;
            case Constants.DEALER_GROUPS_PRIVACY:
                typeOfShare = TypeOfShare.DEALER_GROUP;
                privacyId = 9;
                handleDealerGroups(selectedDealerGrp);
                break;
            case Constants.PRIVATE_CONNECTIONS_PRIVACY:
                taggedConnections.clear();
                typeOfShare = TypeOfShare.PRIVATE_CONNECTION;
                privacyId = 55;
                break;
        }
    }

    private void handleDealerGroups(String data) {
        selectedNetworkGroup.clear();
        tempNetworkGroup.clear();
        networkGroupChipAdapter.notifyDataSetChanged();

        selectedDealerGroup.clear();
        tempDealerGroup.clear();


        taggedConnections.clear();
        tagConnectionsChipAdapter.notifyDataSetChanged();


        selectedDealerGroup.addAll(Arrays.asList(gson.fromJson(data, DealerGroupDataModel[].class)));
        tempDealerGroup.addAll(Arrays.asList(gson.fromJson(data, DealerGroupDataModel[].class)));

        dealerGroupChipAdapter.notifyDataSetChanged();

        checkNetworkContainerVisibility();
        checkDealerContainerVisibility();
        checkTagConnectionsContainerVisibility();

    }

    private void handleNetworkGroup(String data) {

        selectedNetworkGroup.clear();
        tempNetworkGroup.clear();



        selectedDealerGroup.clear();
        tempDealerGroup.clear();
        dealerGroupChipAdapter.notifyDataSetChanged();


        taggedConnections.clear();
        tagConnectionsChipAdapter.notifyDataSetChanged();



        selectedNetworkGroup.addAll(Arrays.asList(gson.fromJson(data, NetworkGroupDataModel[].class)));
        tempNetworkGroup.addAll(Arrays.asList(gson.fromJson(data, NetworkGroupDataModel[].class)));

        networkGroupChipAdapter.notifyDataSetChanged();

        checkNetworkContainerVisibility();
        checkDealerContainerVisibility();
        checkTagConnectionsContainerVisibility();

    }




    private void setThumbnailForLinkPost(String url) {
        getAPI().urlScrapper(url).enqueue(new Callback<UrlScrapperResponse>() {
            @Override
            public void onResponse(Call<UrlScrapperResponse> call, Response<UrlScrapperResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {

                        isLinkVisible = true;
                        enableBtnAlpha();
                        urlExtractorCard.setVisibility(View.VISIBLE);
                        link_cross_btn.setVisibility(View.VISIBLE);
                        urlLoader.setVisibility(View.GONE);
                        urlToSend = response.body().getData().getUrl();
                        urlExtractorTitle.setText("" + response.body().getData().getTitle());
                        urlExtractorDes.setText("" + response.body().getData().getDescription());
                        RequestOptions requestOptions = new RequestOptions()
                                .diskCacheStrategy(DiskCacheStrategy.NONE) // because file name is always same
                                .skipMemoryCache(true)
                                .error(R.drawable.no_img_found);

                        Glide.with(CreatePost.this).load(R.drawable.no_img_found).apply(requestOptions).into(urlExtractorImg);

                        if (response.body().getData().getUrlScrapperImgModels().size() > 0) {
                            String img = response.body().getData().getUrlScrapperImgModels().get(0).getImg();
                            extractedImg = response.body().getData().getUrlScrapperImgModels().get(0).getImg();
                            Glide.with(CreatePost.this).load(img).apply(requestOptions).into(urlExtractorImg);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<UrlScrapperResponse> call, Throwable t) {

            }
        });
    }

    private void removeLinkView() {
        isLinkVisible = false;
        urlExtractorCard.setVisibility(View.GONE);
        link_cross_btn.setVisibility(View.GONE);
        urlExtractorContainer.setVisibility(View.GONE);
        urlExtractorTitle.setText("");
        urlExtractorDes.setText("");
        extractedImg = "";
        urlToSend = "";
    }

}
