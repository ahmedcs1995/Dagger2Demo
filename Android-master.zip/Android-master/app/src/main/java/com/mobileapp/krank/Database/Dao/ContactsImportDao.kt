package com.mobileapp.krank.Database.Dao

import android.arch.lifecycle.LiveData
import android.arch.paging.DataSource
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Query
import com.mobileapp.krank.ResponseModels.DataModel.GetNetworkEmployeeData

@Dao
interface ContactsImportDao {
    @Query("SELECT * from contact_import_table group by number,id,country_code order by view_type asc,first_name ASC,contact_id ASC")
    fun getAllRecords(): DataSource.Factory<Int, GetNetworkEmployeeData>


    //   @Query("SELECT * from contact_import_table group by number,id,country_code order by view_type asc,first_name ASC,contact_id ASC")
    @Query("SELECT COUNT(*) from contact_import_table  where view_type=1 OR view_type=2 group by number,id,country_code")
    fun getCount(): LiveData<List<Int>>

    @Query("SELECT (SELECT Count(*) FROM (SELECT DISTINCT number,id,country_code FROM contact_import_table where view_type=1)) as Connected,(SELECT Count(*) FROM (SELECT DISTINCT number,id,country_code FROM contact_import_table where view_type=2)) as NotConnected,(SELECT Count(*) FROM (SELECT DISTINCT number,id,country_code FROM contact_import_table where view_type=3)) as NotOnKrank,(SELECT Count(*) FROM (SELECT DISTINCT number,id,country_code FROM contact_import_table where conStatus == 'Not Connected' OR conStatus == 'No Connection')) as NotConnectedRequestPendingCounts FROM contact_import_table LIMIT 1")
    fun getAllCounts(): LiveData<CountDataModel>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun bulkInsert(data: List<GetNetworkEmployeeData>)

    @Query("Delete from contact_import_table")
    fun deleteAll()

    @Query("Delete from contact_import_table where device_id=:deviceId")
    fun deleteCurrentDevice(deviceId: String)

   /* @Query("SELECT Count(*) from contact_import_table where device_id=:deviceId")
    fun getMyContacts(deviceId: String)*/

    @Query("UPDATE contact_import_table set conStatus=:conStatus where contact_id=:contact_id")
    fun changeConnectionStatus(conStatus: String, contact_id: Int)

    @Query("UPDATE contact_import_table set conStatus=:conStatus where conStatus='Not Connected' OR conStatus='No Connection'")
    fun connectAll(conStatus: String)

    @Query("UPDATE contact_import_table set conStatus=:conStatus where conStatus='Request Pending'")
    fun undoConnectAll(conStatus: String)

    @Query("SELECT id from contact_import_table where conStatus='Not Connected' OR conStatus='No Connection'")
    fun getNotConnectedUsers(): List<String?>
}



data class CountDataModel(val Connected: Int,
                          val NotConnected: Int,
                          val NotOnKrank: Int,
                          val NotConnectedRequestPendingCounts: Int)