package com.mobileapp.krank.ResponseModels.DataModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CountryForPublicCompanyProfileData {
    @SerializedName("country_code")
    @Expose
    private String countryCode;
    @SerializedName("country_name")
    @Expose
    private String countryName;
    @SerializedName("country_dial_code")
    @Expose
    private String countryDialCode;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryDialCode() {
        return countryDialCode;
    }

    public void setCountryDialCode(String countryDialCode) {
        this.countryDialCode = countryDialCode;
    }

    public CountryForPublicCompanyProfileData(String countryCode, String countryName, String countryDialCode) {
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.countryDialCode = countryDialCode;
    }
}
