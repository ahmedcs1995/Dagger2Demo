package com.mobileapp.krank.Database.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.mobileapp.krank.ResponseModels.DataModel.GroupChatConversationMessageModel;

import java.util.List;

@Dao
public interface GroupChatConversationDao {
     /*@Query("SELECT * from group_chat_conversation_table WHERE member_id=:conId  order by timeStamp desc")
    LiveData<List<GroupChatConversationMessageModel>> getAllRecords(String conId);*/

    //@Query("SELECT * from group_chat_conversation_table WHERE member_id=:member_id order by timeStamp desc")

    @Query("SELECT * from group_chat_conversation_table gc WHERE gc.msg_group_id = (SELECT t.msg_group_id FROM group_chat_conversation_table t WHERE t.member_id =:member_id LIMIT 1) order by timeStamp desc")
    LiveData<List<GroupChatConversationMessageModel>> getAllRecords(int member_id);

    @Query("SELECT * from group_chat_conversation_table where member_id=:conId AND msg_id < :msgId order by timeStamp desc")
    List<GroupChatConversationMessageModel> getPreviousMsgsById(String conId,String msgId);

    @Query("SELECT * from group_chat_conversation_table where msg_id > :msgId order by timeStamp desc")
    LiveData<List<GroupChatConversationMessageModel>> getNewMsgsById(String msgId);
    @Insert
    long insert(GroupChatConversationMessageModel GroupChatConversationMessageModel);

    @Query("DELETE FROM group_chat_conversation_table")
    void deleteAll();

    @Query("DELETE FROM group_chat_conversation_table where mid=:mId")
    void deleteByMid(long mId);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void bulkInsert(List<GroupChatConversationMessageModel> GroupChatConversationMessageModels);

    @Query("select msg_id from group_chat_conversation_table WHERE member_id=:member_id and msg_id is not null order by msg_id desc limit 1")
    int getLatestMsgId(int member_id);




    @Query("select timeStamp from group_chat_conversation_table WHERE member_id=:member_id  order by timeStamp desc limit 1")
    long getLastMsgTime(String member_id);

    @Query("select mid from group_chat_conversation_table WHERE member_id=:member_id  order by timeStamp desc limit 1")
    int getLatestMsgMId(String member_id);

    @Query("select msg_id from group_chat_conversation_table WHERE member_id=:memberId and msg_id is not null order by msg_id asc limit 1")
    int getFirstMsgId(int memberId);




    @Query("update group_chat_conversation_table SET  msg_id=:msg_id, msg_text=:msg_text, msg_user_id=:msg_user_id, msg_group_id=:msg_group_id, msg_type=:msg_type, msg_added=:msg_added, msg_updated=:msg_updated,id=:id ,profile_pic=:profile_pic,first_name=:first_name,last_name=:last_name,sentTime=:sentTime,sentByme=:sentByme,type=:type,reply=:reply,senderImg=:senderImg,system_message=:system_message,msgStatus=:msg_status WHERE mid=:mid AND member_id=:member_id")
    void updateMsgByMid(String member_id,long mid,long msg_id,String msg_text,int msg_user_id,int msg_group_id,String msg_type,String msg_added,String msg_updated,int id,String profile_pic,String first_name,String last_name,String sentTime,int sentByme,String type,String reply,String senderImg,String system_message,int msg_status);

    @Query("update group_chat_conversation_table SET msgStatus=:msgStatus WHERE mid=:mid AND member_id=:member_id")
    void updateStatusMsgByMid(String member_id,long mid,int msgStatus);


    @Query("SELECT * from group_chat_conversation_table where member_id=:member_id AND msg_id > :msgId order by timeStamp desc")
    List<GroupChatConversationMessageModel> getMsgsByLatestId(String member_id,long msgId);

    @Query("update group_chat_conversation_table SET msg_id=:msg_id, msg_text=:msg_text, msg_user_id=:msg_user_id, msg_group_id=:msg_group_id, msg_type=:msg_type, msg_added=:msg_added, msg_updated=:msg_updated, id=:id, profile_pic=:profile_pic, first_name=:first_name, last_name=:last_name, sentTime=:sentTime,sentByme=:sentByme, type=:type, reply=:reply, senderImg=:senderImg, system_message=:system_message,  file_name='', file_thumb='', file_path='', file_ext='', user_slug='', company_slug='', online='', company_id='', package_id='', email_address='', vcard_id='', firstName='', lastName='', profilePic='', designation='', company_profile_pic='', companyName='', country='', city='', user_url='', companyUrl='' WHERE id=:mid")
    void updateMsgByMidForVCard(String mid,String msg_id,String msg_text,String msg_user_id,String msg_group_id,String msg_type,String msg_added,String msg_updated,String id,String profile_pic,String first_name,String last_name,String sentTime,String sentByme,String type,String reply,String senderImg,String system_message);

    //@Query("DELETE FROM group_chat_conversation_table where member_id=:member_id AND msgStatus=2")
    @Query("DELETE FROM group_chat_conversation_table WHERE msg_group_id = (SELECT t.msg_group_id FROM group_chat_conversation_table t WHERE t.member_id =:member_id LIMIT 1) AND msgStatus=2")
    void deleteByMemberId(int member_id);

}

