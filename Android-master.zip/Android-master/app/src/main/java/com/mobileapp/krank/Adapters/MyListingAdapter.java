package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.drawee.controller.ControllerListener;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.image.ImageInfo;
import com.google.gson.Gson;
import com.mobileapp.krank.Activities.AssignRepresentativeForMyListing;
import com.mobileapp.krank.Activities.EditListing;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.Activities.CustomDropDown.SelectPrivacyActivity;
import com.mobileapp.krank.CallBacks.CustomShareCallBack;
import com.mobileapp.krank.CustomViews.SwitchButton;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.DialogFactory;
import com.mobileapp.krank.Functions.Dialogs.NormalAppDialog;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.ListingDataArray;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;
import com.mobileapp.krank.Utils.ShareBottomSheet;


import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyListingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<ListingDataArray> items;
    Context context;
    public SaveInSharedPreference preference;
    ServiceManager serviceManager;

    Fragment fragment;
    Gson gson;


    ShareBottomSheet shareBottomSheet;

    public static final int ASSIGN_REP_ACTIVITY_CODE = 800;

    public class ViewHolder extends RecyclerView.ViewHolder {

        View item;
        SimpleDraweeView img;
        SimpleDraweeView company_image_view;
        SimpleDraweeView profile_image_view;
        TextView people_name;
        TextView designation;
        TextView listing_name;
        TextView description;
        TextView time_ago;
        TextView price;
        TextView label_text_view;


        //bottom btns
        View delete_btn;
        View edit_btn;
        View share_btn;
        View assign_co_workers_icon;
        View request_pending_view;

        SwitchButton switch_btn;

        boolean isTouched = false;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView;
            img = item.findViewById(R.id.img);
            profile_image_view = item.findViewById(R.id.profile_image_view);
            people_name = item.findViewById(R.id.people_name);
            designation = item.findViewById(R.id.designation);
            listing_name = item.findViewById(R.id.listing_name);
            description = item.findViewById(R.id.description);
            time_ago = item.findViewById(R.id.time_ago);
            price = item.findViewById(R.id.price);
            label_text_view = item.findViewById(R.id.label_text_view);
            company_image_view = item.findViewById(R.id.company_image_view);

            //bottom btns
            delete_btn = item.findViewById(R.id.delete_btn);
            request_pending_view = item.findViewById(R.id.request_pending_view);
            switch_btn = item.findViewById(R.id.switch_btn);
            edit_btn = item.findViewById(R.id.edit_btn);
            share_btn = item.findViewById(R.id.share_btn);
            assign_co_workers_icon = item.findViewById(R.id.assign_co_workers_icon);


            //listeners
            edit_btn.setOnClickListener(view -> {
                Intent intent = new Intent(context, EditListing.class);
                intent.putExtra("hashCode", "" + items.get(getAdapterPosition()).getHash());
                context.startActivity(intent);
            });

            delete_btn.setOnClickListener(view -> {

                NormalAppDialog dialog = ((NormalAppDialog) DialogFactory.getDialog(DialogFactory.DialogType.NORMAL_DIALOG, context))
                        .setHeading("Are you sure?")
                        .setDescription("Are you sure you want to delete the Listing")
                        .setConfirmButtonText("OK")
                        .setCancelButtonText("Cancel")
                        .setConfirmButtonListener(dialog1 -> {
                            deleteListing(items.get(getAdapterPosition()), getAdapterPosition());
                        });

                dialog.show();
            });
            share_btn.setOnClickListener(view -> shareBottomSheet.openBottomSheetDialog(Integer.parseInt(items.get(getAdapterPosition()).getId()), items.get(getAdapterPosition()).getListingName(), items.get(getAdapterPosition()).getListing_url(), Constants.LISTING_SHARE));


            item.setOnClickListener(view -> {
                Intent intent = new Intent(context, ListingDetail.class);
                intent.putExtra("listingName", items.get(getAdapterPosition()).getListSlug());
                intent.putExtra("listing_pg_name", items.get(getAdapterPosition()).getListingName());
                intent.putExtra("item_index", getAdapterPosition());
                fragment.startActivityForResult(intent, Constants.LISTING_DETAIL_CODE);
            });


            assign_co_workers_icon.setOnClickListener(view -> {
                Intent intent = new Intent(context, AssignRepresentativeForMyListing.class);
                //intent.putExtra("assign_rep_list",)
                intent.putExtra("listing_item", gson.toJson(items.get(getAdapterPosition())));
                intent.putExtra("item_index", getAdapterPosition());
                fragment.startActivityForResult(intent, ASSIGN_REP_ACTIVITY_CODE);
            });


            /*Switch btn*/
            switch_btn.setEnableEffect(false);

            switch_btn.setOnTouchListener((view, motionEvent) -> {
                switch_btn.setEnableEffect(true);
                isTouched = true;
                return false;
            });

            switch_btn.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isTouched) {
                    isTouched = false;
                    changeStatus(items.get(getAdapterPosition()), getAdapterPosition(), switch_btn);
                }
            });
            /*Switch btn*/

        }
    }

    public class Loader extends RecyclerView.ViewHolder {
        View item;

        public Loader(View itemView) {
            super(itemView);
            item = itemView;

        }
    }

    public MyListingAdapter(List<ListingDataArray> items, Fragment fragment) {
        this.items = items;
        this.context = fragment.getContext();
        preference = new SaveInSharedPreference(context);
        serviceManager = ServiceManager.getInstance();
        this.fragment = fragment;
        gson = CustomGson.getInstance();

        initDialog(preference);
    }

    private void initDialog(SaveInSharedPreference preference) {
        shareBottomSheet = new ShareBottomSheet
                .Builder(fragment, preference)
                .setListeners(getShareCallBack())
                .create();
    }

    private CustomShareCallBack getShareCallBack() {
        CustomShareCallBack customShareCallBack = (selectedPrivacy, tempDealerGroup, tempNetworkGroup) -> {
            Intent intent = new Intent(fragment.getContext(), SelectPrivacyActivity.class);
            intent.putExtra("selected_privacy", gson.toJson(selectedPrivacy));
            intent.putExtra("selected_network_group", gson.toJson(tempNetworkGroup));
            intent.putExtra("selected_dealer_group", gson.toJson(tempDealerGroup));
            fragment.startActivityForResult(intent, Constants.PRIVACY_ACTIVITY_CODE);
        };
        return customShareCallBack;
    }

    @Override
    public int getItemViewType(int position) {

        switch (items.get(position).getTypeOfListing()) {
            case LOADER:
                return 1;
            case POST:
                return 2;
            default:
                return -1;
        }
    }

    public ShareBottomSheet getShareBottomSheet() {
        return shareBottomSheet;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
            case 2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_listing_list_item, parent, false);
                return new ViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_feed_shimmer_loader, parent, false);
                return new Loader(view);
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final ListingDataArray item = items.get(position);
        switch (item.getTypeOfListing()) {
            case POST:
                setPostView(holder, position, item);
                break;
            case LOADER:
                break;
        }
    }

    private void setProfileClickActionsForSaleListingAdapter(TextView Name, final ListingDataArray item) {
        Name.setOnClickListener(view -> {
            Intent intent = new Intent(context, UserProfileView.class);
            if (String.valueOf(item.getUserId()).equals(preference.getString(Constants.USER_ID))) {
                intent.putExtra("IsPersonalProfile", true);
            }
            intent.putExtra("userId", "" + item.getUserId());
            intent.putExtra("userName", item.getFirstName());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void setPostView(@NonNull RecyclerView.ViewHolder holder, final int position, final ListingDataArray item) {

        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.time_ago.setText("" + item.getCreatedDate());

        viewHolder.description.setText("" + Html.fromHtml("" + item.getDescription()));

        viewHolder.designation.setText(AppUtils.getCompanyAndDesignation(item.getCompanyName(), item.getDesignation()));

        viewHolder.price.setText(item.getCurrency_code() + " " + item.getPrice_Privacy());

        viewHolder.listing_name.setText("" + item.getListingName());


        viewHolder.img.setImageURI(Uri.parse("" + item.getIMAGENAME()));


        setProfileClickActionsForSaleListingAdapter(viewHolder.people_name, item);


        /**
         *
         * switch btn privacy
         *
         * */
        if (item.getIsRepAdmin() == 0 && item.getShowInMarketplace() == 1) {
            viewHolder.switch_btn.setVisibility(View.VISIBLE);

            if (item.getStatus().equals("1")) {
                viewHolder.switch_btn.setChecked(true);
            } else {
                viewHolder.switch_btn.setChecked(false);
            }
        } else {
            viewHolder.switch_btn.setChecked(false);
            viewHolder.switch_btn.setVisibility(View.GONE);
        }



        /**
         *
         * show hide delete and switch btn
         *
         * */
        if (item.getUserId().equals(String.valueOf(item.getCuId())) && item.getShowInMarketplace() == 1) {
            viewHolder.delete_btn.setVisibility(View.VISIBLE);

        } else {
            viewHolder.delete_btn.setVisibility(View.GONE);
        }


        /**
         *
         * label conditions
         *
         * */
        if (item.getShowInMarketplace() == 0) {
            // In Auction Listing
            viewHolder.label_text_view.setText("In Auction");
            viewHolder.label_text_view.setVisibility(View.VISIBLE);
            viewHolder.edit_btn.setVisibility(View.GONE);
        } else if (item.getShowInMarketplace() == 2) {
            // sold label
            viewHolder.label_text_view.setText("Sold");
            viewHolder.label_text_view.setVisibility(View.VISIBLE);
            viewHolder.edit_btn.setVisibility(View.GONE);
        } else if (item.getShowInMarketplace() == 1) {
            viewHolder.edit_btn.setVisibility(View.VISIBLE);
            viewHolder.label_text_view.setVisibility(View.GONE);

        } else {
            viewHolder.edit_btn.setVisibility(View.GONE);
            viewHolder.label_text_view.setVisibility(View.GONE);
        }



        /**
         *
         * Only public listing will be share
         *
         * */
        if (item.getListingPrivacy().equals("1")) {
            viewHolder.share_btn.setVisibility(View.VISIBLE);
        } else {
            viewHolder.share_btn.setVisibility(View.GONE);
        }



        // privacy for my listing
        if (item.getIsRepAdmin() == 1) {

            viewHolder.company_image_view.setVisibility(View.VISIBLE);
            viewHolder.profile_image_view.setVisibility(View.GONE);

            viewHolder.company_image_view.setImageURI(Uri.parse("" + item.getProfilePic()));
            viewHolder.people_name.setText(item.getCompanyName() + "(DEALERS)");

            if (item.getDealerStatus() == 0) {
                viewHolder.request_pending_view.setVisibility(View.VISIBLE);
                viewHolder.edit_btn.setVisibility(View.GONE);
                viewHolder.assign_co_workers_icon.setVisibility(View.GONE);

            } else {
                viewHolder.assign_co_workers_icon.setVisibility(View.VISIBLE);
                viewHolder.edit_btn.setVisibility(View.GONE);
                viewHolder.request_pending_view.setVisibility(View.GONE);
            }
        }

        // privacy for my listing

        else {
            viewHolder.request_pending_view.setVisibility(View.GONE);
            viewHolder.assign_co_workers_icon.setVisibility(View.GONE);

            viewHolder.company_image_view.setVisibility(View.GONE);
            viewHolder.profile_image_view.setVisibility(View.VISIBLE);


            viewHolder.people_name.setText("" + item.getFirstName() + " " + item.getLastName());
            viewHolder.profile_image_view.setImageURI(Uri.parse("" + item.getUProfilePic()));
        }

    }

    private void deleteListing(final ListingDataArray item, final int position) {
        serviceManager.getAPI().listingDelete(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(item.getId())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        items.remove(position);
                        notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });
    }

    private void changeStatus(final ListingDataArray item, final int position, SwitchButton switchButton) {
        serviceManager.getAPI().listingStatus(preference.getString(Constants.ACCESS_TOKEN), String.valueOf(item.getId()), String.valueOf(item.getStatus())).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals(Constants.SUCCESS_STATUS)) {
                        if (item.getStatus().equals("1")) {
                            items.get(position).setStatus("2");
                            notifyItemChanged(position);
                            switchButton.setChecked(false);
                            switchButton.setEnableEffect(false);
                            return;
                        }
                        items.get(position).setStatus("1");
                        switchButton.setChecked(true);
                        switchButton.setEnableEffect(false);
                        notifyItemChanged(position);
                    }

                }
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
            }
        });
    }
}











