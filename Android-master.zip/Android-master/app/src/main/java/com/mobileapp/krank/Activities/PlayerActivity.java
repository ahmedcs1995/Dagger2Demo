package com.mobileapp.krank.Activities;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

import com.mobileapp.krank.Base.BaseActivity;
import com.mobileapp.krank.R;

public class PlayerActivity extends BaseActivity {

    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        //   String html = "<iframe width=\"100%\" height=\"400\" src=\"https://www.youtube.com/embed/Pcv0aoOlsLM\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen=\"true\"></iframe>";
        webview = (WebView) findViewById(R.id.web_view);
        String videoId = getIntent().getStringExtra("videoId");
        String html = "<iframe style=\"background: #000000;\" src=\"https://player.vimeo.com/video/" + videoId + "\" width=\"100%\" height=\"400\" frameborder=\"0\" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>";
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setBackgroundColor(Color.TRANSPARENT);
        //    webview.getSettings().;

        webview.loadData(html, "text/html", null);

        setToolbar();
    }

    private void setToolbar(){
        View back_btn = findViewById(R.id.back_btn);
        back_btn.setOnClickListener(view -> {
            onBackPressed();
        });
    }
}
