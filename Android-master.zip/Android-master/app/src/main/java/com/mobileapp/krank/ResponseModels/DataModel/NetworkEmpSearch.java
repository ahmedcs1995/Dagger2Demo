package com.mobileapp.krank.ResponseModels.DataModel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NetworkEmpSearch implements Parcelable {


    public static final int PROGRESS_BAR = 1;
    public static final int ITEM_VIEW = 0;

    @SerializedName("user_slug")
    @Expose
    private String userSlug;
    @SerializedName("company_slug")
    @Expose
    private String companySlug;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("companyID")
    @Expose
    private String companyID;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("companyPic")
    @Expose
    private String companyPic;
    @SerializedName("countryName")
    @Expose
    private Object countryName;
    @SerializedName("cityName")
    @Expose
    private Object cityName;
    @SerializedName("count")
    @Expose
    private List<Count> count = null;
    @SerializedName("company_profile_pic")
    @Expose
    private String companyProfilePic;
    @SerializedName("user_profile_pic")
    @Expose
    private String userProfilePic;
    @SerializedName("user_url")
    @Expose
    private String userUrl;
    @SerializedName("company_url")
    @Expose
    private String companyUrl;
    @SerializedName("conStatus")
    @Expose
    private String conStatus;
    @SerializedName("status")
    @Expose
    private String status;


    private int itemType;

    protected NetworkEmpSearch(Parcel in) {
        userSlug = in.readString();
        companySlug = in.readString();
        id = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        emailAddress = in.readString();
        profilePic = in.readString();
        designation = in.readString();
        companyID = in.readString();
        companyName = in.readString();
        companyPic = in.readString();
        companyProfilePic = in.readString();
        userProfilePic = in.readString();
        userUrl = in.readString();
        companyUrl = in.readString();
        conStatus = in.readString();
        status = in.readString();
        itemType = in.readInt();
    }

    public static final Creator<NetworkEmpSearch> CREATOR = new Creator<NetworkEmpSearch>() {
        @Override
        public NetworkEmpSearch createFromParcel(Parcel in) {
            return new NetworkEmpSearch(in);
        }

        @Override
        public NetworkEmpSearch[] newArray(int size) {
            return new NetworkEmpSearch[size];
        }
    };

    public String getUserSlug() {
        return userSlug;
    }

    public void setUserSlug(String userSlug) {
        this.userSlug = userSlug;
    }

    public String getCompanySlug() {
        return companySlug;
    }

    public void setCompanySlug(String companySlug) {
        this.companySlug = companySlug;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompanyID() {
        return companyID;
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyPic() {
        return companyPic;
    }

    public void setCompanyPic(String companyPic) {
        this.companyPic = companyPic;
    }

    public Object getCountryName() {
        return countryName;
    }

    public void setCountryName(Object countryName) {
        this.countryName = countryName;
    }

    public Object getCityName() {
        return cityName;
    }

    public void setCityName(Object cityName) {
        this.cityName = cityName;
    }

    public List<Count> getCount() {
        return count;
    }

    public void setCount(List<Count> count) {
        this.count = count;
    }

    public String getCompanyProfilePic() {
        return companyProfilePic;
    }

    public void setCompanyProfilePic(String companyProfilePic) {
        this.companyProfilePic = companyProfilePic;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public String getUserUrl() {
        return userUrl;
    }

    public void setUserUrl(String userUrl) {
        this.userUrl = userUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getConStatus() {
        return conStatus;
    }

    public void setConStatus(String conStatus) {
        this.conStatus = conStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public NetworkEmpSearch(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(userSlug);
        parcel.writeString(companySlug);
        parcel.writeString(id);
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(emailAddress);
        parcel.writeString(profilePic);
        parcel.writeString(designation);
        parcel.writeString(companyID);
        parcel.writeString(companyName);
        parcel.writeString(companyPic);
        parcel.writeString(companyProfilePic);
        parcel.writeString(userProfilePic);
        parcel.writeString(userUrl);
        parcel.writeString(companyUrl);
        parcel.writeString(conStatus);
        parcel.writeString(status);
        parcel.writeInt(itemType);
    }
}



