package com.mobileapp.krank.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.ViewHolders.CommonViewHolder.AppListItemLoader;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.NetworkEmpSearch;
import com.mobileapp.krank.ViewHolders.SearchViewHolders.NetworkEmployeeViewHolder;
import com.mobileapp.krank.Utils.SaveInSharedPreference;

import java.util.Arrays;
import java.util.List;

public class PeopleSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private List<NetworkEmpSearch> items;
    Context context;

    public SaveInSharedPreference preference;

    AppUtils appUtils;


    public PeopleSearchAdapter(List<NetworkEmpSearch> items, Context context,SaveInSharedPreference preference) {
        this.items = items;
        this.context = context;
        this.preference = preference;
        appUtils = AppUtils.getInstance();

    }

    public PeopleSearchAdapter(NetworkEmpSearch[] items, Context context) {

        this.items.addAll(Arrays.asList(items));
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        switch (items.get(position).getItemType()) {
            case NetworkEmpSearch.PROGRESS_BAR:
                return 1;
            case NetworkEmpSearch.ITEM_VIEW:
                return 2;
            default:
                return 2;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        if (viewType == 1) {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_loader_item, parent, false);
            return new AppListItemLoader(v);
        } else if (viewType == 2) {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.connection_view, parent, false);
            return new NetworkEmployeeViewHolder(v);
        } else {
            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_loader_item, parent, false);
            return new AppListItemLoader(v);
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {

        final NetworkEmpSearch item = items.get(position);


        switch (item.getItemType()) {
            case NetworkEmpSearch.ITEM_VIEW:
                ((NetworkEmployeeViewHolder) holder).onBind(item, context,preference);
                break;
            case NetworkEmpSearch.PROGRESS_BAR:
                break;
        }
    }




    @Override
    public int getItemCount() {
        return items.size();
    }

}






