package com.mobileapp.krank.ResponseModels.DataModel;

import android.arch.persistence.room.ColumnInfo;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class HtmlParse implements Parcelable {

    @SerializedName("title")
    @Expose
    @ColumnInfo(name = "html_parse_title")
    private String title;

    @SerializedName("image")
    @Expose
    @ColumnInfo(name = "image")
    private String image;

    @SerializedName("description")
    @Expose
    @ColumnInfo(name = "html_parse_description")
    private String description;

    @SerializedName("video_url")
    @Expose
    @ColumnInfo(name = "video_url")
    private String videoUrl;

    @SerializedName("link")
    @Expose
    @ColumnInfo(name = "link")
    private String link;

    @SerializedName("image_width")
    @Expose
    @ColumnInfo(name = "html_parse_image_width")
    private int image_width;

    @SerializedName("image_height")
    @Expose
    @ColumnInfo(name = "html_parse_image_height")
    private int image_height;

    protected HtmlParse(Parcel in) {
        title = in.readString();
        image = in.readString();
        description = in.readString();
        videoUrl = in.readString();
        link = in.readString();
        image_width = in.readInt();
        image_height = in.readInt();
    }

    public static final Creator<HtmlParse> CREATOR = new Creator<HtmlParse>() {
        @Override
        public HtmlParse createFromParcel(Parcel in) {
            return new HtmlParse(in);
        }

        @Override
        public HtmlParse[] newArray(int size) {
            return new HtmlParse[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getImage_width() {
        return image_width;
    }

    public void setImage_width(int image_width) {
        this.image_width = image_width;
    }

    public int getImage_height() {
        return image_height;
    }

    public void setImage_height(int image_height) {
        this.image_height = image_height;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeString(image);
        parcel.writeString(description);
        parcel.writeString(videoUrl);
        parcel.writeString(link);
        parcel.writeInt(image_width);
        parcel.writeInt(image_height);
    }

    public HtmlParse() {

    }
}
