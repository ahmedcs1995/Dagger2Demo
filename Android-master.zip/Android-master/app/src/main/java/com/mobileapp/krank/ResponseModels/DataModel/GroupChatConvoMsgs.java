package com.mobileapp.krank.ResponseModels.DataModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GroupChatConvoMsgs {
    @SerializedName("msg_id")
    @Expose
    private String msgId;
    @SerializedName("msg_text")
    @Expose
    private String msgText;
    @SerializedName("msg_user_id")
    @Expose
    private String msgUserId;
    @SerializedName("msg_group_id")
    @Expose
    private String msgGroupId;
    @SerializedName("msg_type")
    @Expose
    private String msgType;
    @SerializedName("msg_added")
    @Expose
    private String msgAdded;
    @SerializedName("msg_updated")
    @Expose
    private String msgUpdated;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("profile_pic")
    @Expose
    private String profilePic;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("sentTime")
    @Expose
    private String sentTime;
    @SerializedName("sentByme")
    @Expose
    private int sentByme;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("reply")
    @Expose
    private String reply;
    @SerializedName("senderImg")
    @Expose
    private String senderImg;

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }

    public String getMsgUserId() {
        return msgUserId;
    }

    public void setMsgUserId(String msgUserId) {
        this.msgUserId = msgUserId;
    }

    public String getMsgGroupId() {
        return msgGroupId;
    }

    public void setMsgGroupId(String msgGroupId) {
        this.msgGroupId = msgGroupId;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getMsgAdded() {
        return msgAdded;
    }

    public void setMsgAdded(String msgAdded) {
        this.msgAdded = msgAdded;
    }

    public String getMsgUpdated() {
        return msgUpdated;
    }

    public void setMsgUpdated(String msgUpdated) {
        this.msgUpdated = msgUpdated;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSentTime() {
        return sentTime;
    }

    public void setSentTime(String sentTime) {
        this.sentTime = sentTime;
    }

    public int getSentByme() {
        return sentByme;
    }

    public void setSentByme(int sentByme) {
        this.sentByme = sentByme;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getSenderImg() {
        return senderImg;
    }

    public void setSenderImg(String senderImg) {
        this.senderImg = senderImg;
    }

}
