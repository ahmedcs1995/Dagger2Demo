package com.mobileapp.krank.Base;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.mobileapp.chatapp.Activities.ChatConversations;
import com.mobileapp.krank.Activities.AccountSetupPage;
import com.mobileapp.krank.Activities.AddListing;
import com.mobileapp.krank.Activities.AppSettings;
import com.mobileapp.krank.Activities.ArticleDetail;
import com.mobileapp.krank.Activities.ChangePassword;
import com.mobileapp.krank.Activities.CompanyProfileView;
import com.mobileapp.krank.Activities.DiscoverPeople;
import com.mobileapp.krank.Activities.FirstPage;
import com.mobileapp.krank.Activities.InAppWebViewCollapseActivity;
import com.mobileapp.krank.Activities.InviteCompaniesAndCoWorker;
import com.mobileapp.krank.Activities.ListOfEmployeesAndConnections;
import com.mobileapp.krank.Activities.ListingDetail;
import com.mobileapp.krank.Activities.MainPage;
import com.mobileapp.krank.Activities.MyListingPage;
import com.mobileapp.krank.Activities.SignUpPage2;
import com.mobileapp.krank.Activities.SignUpPage3;
import com.mobileapp.krank.Activities.UserProfileView;
import com.mobileapp.krank.Activities.NotificationsScreen;
import com.mobileapp.krank.Activities.PendingRequestActivity;
import com.mobileapp.krank.Activities.MarketPlacePage;
import com.mobileapp.krank.Activities.SearchKrank;
import com.mobileapp.krank.Activities.HelpAndSupportWebViews;
import com.mobileapp.krank.Adapters.AnimatedListViewAdapter;
import com.mobileapp.krank.Adapters.CustomFragmentStatePagerAdapter;
import com.mobileapp.krank.CallBacks.CustomCallBack;
import com.mobileapp.krank.Chat.ChatMainPage;
import com.mobileapp.krank.Chat.GroupChatPakage.GroupChatConversationActivity;
import com.mobileapp.krank.Chat.PrivateChat.PrivateChatConversationActivity;
import com.mobileapp.krank.CustomViews.AnimatedExpandableListView;
import com.mobileapp.krank.Database.AppExecutors;
import com.mobileapp.krank.Database.KrankRoomDataBase;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.Functions.CustomGson;
import com.mobileapp.krank.Functions.DateTimeUtils;
import com.mobileapp.krank.Model.Enums.SplashLinkReceived;
import com.mobileapp.krank.Network.ApiInterface;
import com.mobileapp.krank.Model.DeviceInfo;
import com.mobileapp.krank.Model.DrawerMenu;
import com.mobileapp.krank.Model.DrawerSubItem;
import com.mobileapp.krank.R;
import com.mobileapp.krank.Repository.ContactsImportRepository;
import com.mobileapp.krank.ResponseModels.DataModel.CompanyInvitationDataModel;
import com.mobileapp.krank.ResponseModels.DataModel.ProfileMenuUserData;
import com.mobileapp.krank.ResponseModels.GeneralResponse;
import com.mobileapp.krank.ResponseModels.ProfileMenuResponse;
import com.mobileapp.krank.ResponseModels.SigninResponse;
import com.mobileapp.krank.ResponseModels.SignupOneResponse;
import com.mobileapp.krank.SynchronizationFromServer.SyncUtils;
import com.mobileapp.krank.Utils.AnimationUtils;
import com.mobileapp.krank.Utils.ApiUtils;
import com.mobileapp.krank.Utils.SaveInSharedPreference;
import com.mobileapp.krank.Utils.ServiceManager;

import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Ahmed on 3/25/2018.
 */

public class BaseActivity extends AppCompatActivity {

    public final static int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 789;
    public final static int CONTACTS_PERMISSION = 200;


    public ImageView footerImg;

    AnimatedListViewAdapter listAdapter;
    AnimatedExpandableListView expListView;
    List<DrawerMenu> drawerMenuList;

    private View expandCollapseBtn;
    private View expandableContent;
    private ImageView expandableImg;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private View contentView;
    private ImageView iconImg;

    View backBtn;
    TextView pageName;
    public SweetAlertDialog showAlert;

    public SaveInSharedPreference preference;
    private static final float END_SCALE = 0.7f;

    public AppUtils appUtils;


    ServiceManager serviceManager;
    public ApiUtils apiUtils;

    public Gson gson;

    View terms_and_conditions_text;
    View privacy_policy_text;


    //type face
    private Typeface mTypefaceBold;
    private Typeface mTypefaceNormal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //  setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        preference = SaveInSharedPreference.getInstance(getApplicationContext());

        appUtils = AppUtils.getInstance();

        serviceManager = ServiceManager.getInstance();

        gson = CustomGson.getInstance();

        apiUtils = ApiUtils.getInstance();

    }


    public SweetAlertDialog showAlert(String content, int type, boolean isCancelable) {
        SweetAlertDialog getAlert = new SweetAlertDialog(this, type);
        getAlert.setContentText(content);
        getAlert.setCancelable(isCancelable);
        return getAlert;
    }

    public SweetAlertDialog showAlert(int type, boolean isCancelable) {
        SweetAlertDialog getAlert = new SweetAlertDialog(this, type);
        getAlert.setCancelable(isCancelable);
        return getAlert;
    }

    public ApiInterface getAPI() {
        return serviceManager.getAPI();
    }

    /**
     * For Authorization page
     * */
    public void setScreenHeader(String screenName) {

        TextView screenNameTextView = findViewById(R.id.screen_name);
        ImageView backBtn = findViewById(R.id.back_btn);
        screenNameTextView.setText(screenName);

        backBtn.setOnClickListener(view -> onBackPressed());

    }

    public void setKrankLogoForUserProfiling() {
        DeviceInfo deviceInfo = getDeviceResolution();
        ImageView krankLogo = findViewById(R.id.krank_logo);
        krankLogo.getLayoutParams().height = (int) ((deviceInfo.getDeviceHeight() / 2) / 6.5);
        krankLogo.requestLayout();
    }

    public void setImageIntermsOfDeviceResolution() {
        footerImg = findViewById(R.id.footer_img);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        if (height == 800) {
            footerImg.getLayoutParams().height = (int) (height * 0.20);
        } else {
            footerImg.getLayoutParams().height = (int) (height * 0.24);
        }
        footerImg.requestLayout();
        // return new DeviceInfo(width,height);

    }

    public void gotoLinkPage() {
        terms_and_conditions_text = findViewById(R.id.terms_and_conditions_text);

        privacy_policy_text = findViewById(R.id.privacy_policy_text);

        terms_and_conditions_text.setOnClickListener(view -> openWebViewPages(getApplicationContext(), Constants.TERMS_CONDITION));

        privacy_policy_text.setOnClickListener((view) -> {
            openWebViewPages(getApplicationContext(), Constants.PRIVACY);
        });
    }


    public DeviceInfo getDeviceResolution() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        return new DeviceInfo(width, height);
    }

    /**
     * DashBoard Toolbar
     */
    public void setUpToolbarButtons(final Context context) {
        View msgClick = findViewById(R.id.msg_click);
        View notificationClick = findViewById(R.id.notification_click);

        View search_click = findViewById(R.id.search_click);
        search_click.setOnClickListener(view -> {
            Intent intent = new Intent(context, SearchKrank.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);

        });
        msgClick.setOnClickListener(view -> {


            Intent intent = new Intent(context, ChatConversations.class);
            intent.putExtra(ChatConversations.ACCESS_TOKEN,preference.getString(Constants.ACCESS_TOKEN));
            intent.putExtra(ChatConversations.USER_ID,preference.getString(Constants.USER_ID));
            intent.putExtra(ChatConversations.ENRYPTED_USER_ID,preference.getString(Constants.USER_ID_ENCRYPTED));
            intent.putExtra(ChatConversations.BASE_URL_KEY,Constants.BASE_URL);
            intent.putExtra(ChatConversations.CHAT_BASE_URL_KEY,Constants.CHAT_SERVER_URL);
            startActivity(intent);
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });
        notificationClick.setOnClickListener(view -> {
            Intent intent = new Intent(context, NotificationsScreen.class);
            startActivity(intent);
            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        });
    }

    /**
     * Permission
     */
    public boolean checkOrAskForMultipleRunTimePermission(String... permission) {
        List<String> permissionsNeeded = new ArrayList<String>();

        for (String getPermission : permission) {
            int askPermission = ActivityCompat.checkSelfPermission(getApplicationContext(),
                    getPermission);

            if (askPermission != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(getPermission);
            }

        }
        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissionsNeeded.toArray(new String[permissionsNeeded.size()]),
                    REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;

    }

    /**
     * Sign In,Sign Up and forget pass
     */

    public void setUserDataInSharedPreferences(SigninResponse signinResponse) {

        //name
        preference.setString(Constants.FIRST_NAME, signinResponse.getData().getFirstName());
        preference.setString(Constants.LAST_NAME, signinResponse.getData().getLastName());
        preference.setString(Constants.COMPANY_NAME, signinResponse.getData().getCompanyName());
        //id
        preference.setString(Constants.USER_ID, signinResponse.getData().getUserId());
        preference.setString(Constants.MY_COMPANY_ID, signinResponse.getData().getCompanyId());
        preference.setInt(Constants.HISTORY_ID, signinResponse.getData().getHistory_id());

        //access token
        preference.setString(Constants.ACCESS_TOKEN, signinResponse.getAccessToken());
        preference.setString(Constants.REFRESH_TOKEN, signinResponse.getRefreshToken());

        //free and domain email
        preference.setString(Constants.PACKAGE_ID, signinResponse.getData().getPackageId());
        preference.setString(Constants.USER_UID, signinResponse.getData().getUId());
        preference.setString(Constants.USER_ID_ENCRYPTED, signinResponse.getData().getUIdAes());

        preference.setString(Constants.USER_EMAIL, signinResponse.getData().getEmail_address());
        preference.setString(Constants.JOB_TITLE, signinResponse.getData().getJobTitle());
        preference.setString(Constants.DEPARTMENT, signinResponse.getData().getDepartment_name());
        preference.setString(Constants.USER_SLUG, signinResponse.getData().getUser_slug());

        //country city
        preference.setString(Constants.CITY, signinResponse.getData().getCityName());
        preference.setString(Constants.CITY_ID_KEY, signinResponse.getData().getCityId());

        //country
        preference.setString(Constants.COUNTRY, signinResponse.getData().getCountryName());
        preference.setString(Constants.COUNTRY_CODE, signinResponse.getData().getCountryCode());
        preference.setString(Constants.COUNTRY_DIAL_CODE, signinResponse.getData().getCountryDialCode());

        //pics
        preference.setString(Constants.PROFILE_PICTURE, signinResponse.getData().getUserProfilePic());
        preference.setString(Constants.COMPANY_PROFILE_PICTURE, signinResponse.getData().getCompanyProfilePic());
        preference.setString(Constants.COVER_PICTURE, signinResponse.getData().getUserCoverPic());
        preference.setString(Constants.COMPANY_COVER_PICTURE, signinResponse.getData().getCompanyCoverPic());

        //count
        preference.setString(Constants.NETWORK_COUNT, signinResponse.getData().getUserTotalNetworks());
        preference.setString(Constants.CONNECTION_COUNT, signinResponse.getData().getUserTotalConnections());
        preference.setString(Constants.LIST_COUNT, signinResponse.getData().getUserTotalListings());
        preference.setString(Constants.TOTAL_COMPANY_LIST, signinResponse.getData().getUserTotalCompanyListings());
        preference.setString(Constants.TOTAL_COMPANY_LIST_LIMIT, signinResponse.getData().getUserTotalListingLimit());


        //phone num
        preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, signinResponse.getData().getVerify_status());
        preference.setString(Constants.MOBILE_NUMBER, signinResponse.getData().getMobileNumber());

        //invite
        preference.setString(Constants.INVITE_COMPANIES_URL, signinResponse.getData().getCompany_invitation());


        //contact pop up
        preference.setString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN, signinResponse.getData().getContact_popup_meta_key());

        updateContactsPreference(signinResponse.getData().getTotal_contacts(), signinResponse.getData().getMy_contacts(), signinResponse.getData().getLast_sync_date());


    }

    private void updateContactsPreference(int mTotalContactsCount, int mMyContactsCount, String lastSyncDate) {
        //time stamps
        updateSyncTimeStamps(lastSyncDate);

        //update cache
        preference.setInt(Constants.TOTAL_CONTACTS_COUNT, mTotalContactsCount);
        preference.setInt(Constants.MY_CONTACT_COUNT, mMyContactsCount);

        //flag
        if (mMyContactsCount > 0) {
            SyncUtils.createSyncAccount(getApplicationContext(), false, new CustomCallBack() {
                @Override
                public void act() {
                    preference.setBoolean(Constants.SYNC_ADAPTER_SETUP_COMPLETE, true);
                }
            });
            preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, true);
        } else {
            //disable sync
            preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, false);
            SyncUtils.disableSync();
        }

        //if total sim count is zero, clear the local Db
        if (mTotalContactsCount == 0) {
            preference.setBoolean(Constants.CONTACTS_SYNC_ENABLED, false);

            if (isContactDbEmpty()) {
                new ContactsImportRepository((Application) getApplicationContext()).deleteAllRecords();
                preference.setString(Constants.IS_CONTACT_DB_EMPTY, "yes");
            }

        }
    }

    private boolean isContactDbEmpty() {
        return (!(preference.getString(Constants.IS_CONTACT_DB_EMPTY).isEmpty())) && preference.getString(Constants.IS_CONTACT_DB_EMPTY).equals("no");
    }

    /**
     * update cache
     */
    public void updateUserData(Response<ProfileMenuResponse> response) {
        ProfileMenuUserData profileMenuUserData = response.body().getData().getUserData();
        /*update the user data*/

        //name
        preference.setString(Constants.FIRST_NAME, profileMenuUserData.getFirstName());
        preference.setString(Constants.LAST_NAME, profileMenuUserData.getLastName());
        preference.setString(Constants.COMPANY_NAME, profileMenuUserData.getCompanyName());

        //id
        preference.setString(Constants.MY_COMPANY_ID, profileMenuUserData.getCompanyId());

        //other
        preference.setString(Constants.DEPARTMENT, profileMenuUserData.getDepartmentName());
        preference.setString(Constants.WEBSITE_URL, profileMenuUserData.getWebsiteUrl());
        preference.setString(Constants.COMPANY_SIZE, profileMenuUserData.getCompanySizeName());
        preference.setString(Constants.USER_EMAIL, profileMenuUserData.getEmailAddress());
        preference.setString(Constants.JOB_TITLE, profileMenuUserData.getJobTitle());
        preference.setString(Constants.USER_SLUG, profileMenuUserData.getUser_slug());

        //country city

        //city
        preference.setString(Constants.CITY, profileMenuUserData.getCityName());
        preference.setString(Constants.CITY_ID_KEY, profileMenuUserData.getCity_id());

        //country
        preference.setString(Constants.COUNTRY, profileMenuUserData.getCountryName());
        preference.setString(Constants.COUNTRY_CODE, profileMenuUserData.getCountry_code());
        preference.setString(Constants.COUNTRY_DIAL_CODE, profileMenuUserData.getCountry_dial_code());

        //pics
        preference.setString(Constants.PROFILE_PICTURE, profileMenuUserData.getProfilePic());
        preference.setString(Constants.COMPANY_PROFILE_PICTURE, profileMenuUserData.getCompany_profile_pic());
        preference.setString(Constants.COVER_PICTURE, profileMenuUserData.getCoverPic());
        preference.setString(Constants.COMPANY_COVER_PICTURE, profileMenuUserData.getCompany_cover_pic());

        //counts
        preference.setString(Constants.NETWORK_COUNT, response.body().getData().getUserTotalNetworks());
        preference.setString(Constants.CONNECTION_COUNT, response.body().getData().getUserTotalConnections());
        preference.setString(Constants.LIST_COUNT, response.body().getData().getUserTotalListings());
        preference.setString(Constants.TOTAL_COMPANY_LIST, response.body().getData().getUserTotalCompanyListings());
        preference.setString(Constants.TOTAL_COMPANY_LIST_LIMIT, response.body().getData().getUserTotalListingLimit());
        preference.setString(Constants.TOTAL_COMPANY_LIST_LIMIT, response.body().getData().getUserTotalListingLimit());

        //phone Number
        preference.setString(Constants.VERIFY_PHONE_NUM_STATUS, response.body().getData().getUserData().getVerify_status());
        preference.setString(Constants.MOBILE_NUMBER, profileMenuUserData.getMobileNumber());

        //invite
        preference.setString(Constants.INVITE_COMPANIES_URL, response.body().getData().getCompany_invitation());
        /*update the user data*/

        //contact pop up
        preference.setString(Constants.CONTACT_POP_UP_LAST_DURATION_SHOWN, response.body().getData().getContact_popup_meta_key());

        updateContactsPreference(response.body().getData().getTotal_contacts(), response.body().getData().getMy_contacts(), response.body().getData().getLast_sync_date());

    }

    public Intent getIntentToRedirectNextPage(Context context, String url, SplashLinkReceived pageToRedirect) {
        Intent mainIntent = null;

        if (pageToRedirect != null) {
            switch (pageToRedirect) {
                case LISTING_PAGE:
                    mainIntent = new Intent(context, ListingDetail.class);
                    mainIntent.putExtra("listingName", url);
                    break;
                case PEOPLE_YOU_MAY_KNOW:
                    mainIntent = new Intent(context, DiscoverPeople.class);
                    break;
                case PENDING_REQUEST:
                    mainIntent = new Intent(context, PendingRequestActivity.class);
                    break;
                case DEFAULT_WEB_VIEW:
                    mainIntent = new Intent(context, InAppWebViewCollapseActivity.class);
                    mainIntent.putExtra("web_view_url", url);
                    mainIntent.putExtra("from_external_app", true);
                    break;
                case APP_VIEW:
                    mainIntent = new Intent(context, MainPage.class);
                    break;
                case USER_PROFILE:
                    mainIntent = new Intent(context, UserProfileView.class);
                    mainIntent.putExtra("user_slug", url);
                    break;
                case COMPANY_PROFILE:
                    mainIntent = new Intent(context, CompanyProfileView.class);
                    mainIntent.putExtra("company_slug", url);
                    break;
                case ARTICLE:
                    mainIntent = new Intent(context, ArticleDetail.class);
                    mainIntent.putExtra("slug", url);
                    break;
                case CHAT:
                    mainIntent = new Intent(context, PrivateChatConversationActivity.class);
                    mainIntent.putExtra("conv_id", url);
                    mainIntent.putExtra("from_notification", true);
                    break;
                case GROUP_CHAT:
                    mainIntent = new Intent(context, GroupChatConversationActivity.class);
                    mainIntent.putExtra("from_notification", true);
                    mainIntent.putExtra("member_id", "" + url);
                    break;
                case WIZARD:
                    mainIntent = new Intent(context, AccountSetupPage.class);
                    break;
                case DISCOVER:
                    mainIntent = new Intent(context, DiscoverPeople.class);
                    mainIntent.putExtra(DiscoverPeople.CURRENT_ITEM_KEY, 1);
                    break;
                default:
                    mainIntent = new Intent(context, MainPage.class);
                    break;
            }
        } else {
            mainIntent = new Intent(context, MainPage.class);
        }


        return mainIntent;
    }

    public void setNormalPageToolbar(final Context context, String pgName) {
        backBtn = findViewById(R.id.back_btn);
        pageName = findViewById(R.id.page_name);
        pageName.setText(pgName);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    public void setNormalPageToolbar(String pgName) {
        backBtn = findViewById(R.id.back_btn);
        pageName = findViewById(R.id.page_name);
        pageName.setText(pgName);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    public void setNormalPageToolbar(final Context context) {
        backBtn = findViewById(R.id.back_btn);
        backBtn.setOnClickListener(view -> onBackPressed());
    }




    /**
     * For contacts PopUp
     */
    public void showHideDiscoverFocus(boolean show) {
        int index = 7;
        int childIndex = 3;
        if(show){
            drawerLayout.openDrawer(navigationView);
            drawerMenuList.get(index).setSign("-");
            drawerMenuList.get(index).getItems().get(childIndex).setFocusView(true);
            expListView.expandGroup(index);
            expListView.setSelectedGroup(index);
        }else{
            if(drawerMenuList.get(index).getItems().get(childIndex).isFocusView()){
                //hide here
                drawerMenuList.get(index).setSign("+");
                drawerMenuList.get(index).getItems().get(childIndex).setFocusView(false);
                expListView.collapseGroup(index);
            }
        }
    }

    public void setDrawer(Context context, ViewPager viewPager) {
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        iconImg = findViewById(R.id.menu_icon_img);

        contentView = findViewById(R.id.content);
        setDrawerNavigation();
        expListView = findViewById(R.id.drawer_expandable_adapter);
        prepareAnimatedListViewData(context, viewPager);

        listAdapter = new AnimatedListViewAdapter(this);
        listAdapter.setData(drawerMenuList);
        expListView.setAdapter(listAdapter);

        expListView.setOnGroupExpandListener(i -> {

        });

        expListView.setOnGroupClickListener((parent, v, groupPosition, id) -> {

            /**
             * Expandable Click
             * */
            if (expListView.isGroupExpanded(groupPosition)) {
                expListView.collapseGroupWithAnimation(groupPosition);
                drawerMenuList.get(groupPosition).setSign("+");
            } else {
                expListView.expandGroupWithAnimation(groupPosition);
                drawerMenuList.get(groupPosition).setSign("-");
            }

            /**
             * Hide the discover Focus
             */
            showHideDiscoverFocus(false);

            return true;
        });

        setDrawerActions(context);

    }


    protected void setInviteText(TextView info_text) {
        CompanyInvitationDataModel companyInvitationDataModel;
        if (!(isInviteLinkDataExists())) {
            info_text.setVisibility(View.GONE);
        } else {
            info_text.setVisibility(View.VISIBLE);
            companyInvitationDataModel = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
            setInfoText(companyInvitationDataModel, info_text);
        }
    }


    public void closeDrawer() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    private void prepareAnimatedListViewData(final Context context, final ViewPager viewPager) {

        drawerMenuList = new ArrayList<>();


        /**
         * Profile
         * */
        List<DrawerSubItem> profileListItems = new ArrayList<>();
        profileListItems.add(new DrawerSubItem("My Profile", () -> {
            gotoUserProfileActivityResult(context);

        }));
        profileListItems.add(new DrawerSubItem("Company Profile", () -> {
            Intent intent = new Intent(context, CompanyProfileView.class);
            intent.putExtra("companyId", preference.getString(Constants.MY_COMPANY_ID));
            intent.putExtra("IsPersonalCompanyProfile", true);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);

        }));

        profileListItems.add(new DrawerSubItem("Update Password", () -> {
            Intent intent = new Intent(context, ChangePassword.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));


        profileListItems.add(new DrawerSubItem("Contact Settings", () -> {
            Intent intent = new Intent(context, AppSettings.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));


        /**
         * Manage accounts
         * */

        List<DrawerSubItem> manageAccountsItems = new ArrayList<>();

        if (isBussinessEmail()) {
            manageAccountsItems.add(new DrawerSubItem("Add Co-workers", () -> {
                Intent intent = new Intent(context, InviteCompaniesAndCoWorker.class);
                intent.putExtra(InviteCompaniesAndCoWorker.PAGE_NAME_INTENT_KEY, "Add Co Workers");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
            }));
        }

        manageAccountsItems.add(new DrawerSubItem("Invite Contacts/Companies", () -> {
            Intent intent = new Intent(context, InviteCompaniesAndCoWorker.class);
            intent.putExtra(InviteCompaniesAndCoWorker.PAGE_NAME_INTENT_KEY, "Invite Companies");
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));

        manageAccountsItems.add(new DrawerSubItem("Invite Private Connections", () -> {
            Intent intent = new Intent(context, InviteCompaniesAndCoWorker.class);
            intent.putExtra(InviteCompaniesAndCoWorker.PAGE_NAME_INTENT_KEY, "Invite Private Connections");
            intent.putExtra(InviteCompaniesAndCoWorker.IS_PRIVATE_CONNECTION_KEY, true);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));

        manageAccountsItems.add(new DrawerSubItem("Pending Requests", () -> {
            Intent intent = new Intent(context, PendingRequestActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);

        }));

        manageAccountsItems.add(new DrawerSubItem("Discover People", () -> {
            Intent intent = new Intent(context, DiscoverPeople.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));


        /**
         * Help And Support
         * */
        List<DrawerSubItem> helpAndSupportItems = new ArrayList<>();

        helpAndSupportItems.add(new DrawerSubItem("Contact Krank", () -> {
            openWebViewPages(context, Constants.CONTACT_KRANK);
        }));
        helpAndSupportItems.add(new DrawerSubItem("FAQs", () -> {
            openWebViewPages(context, Constants.FAQS);
        }));
        helpAndSupportItems.add(new DrawerSubItem("Privacy", () -> {
            openWebViewPages(context, Constants.PRIVACY);
        }));
        helpAndSupportItems.add(new DrawerSubItem("Cookies Policy", () -> {
            openWebViewPages(context, Constants.COOKIES_POLICY);
        }));
        helpAndSupportItems.add(new DrawerSubItem("Terms and Conditions", () -> {
            openWebViewPages(context, Constants.TERMS_CONDITION);
        }));


        drawerMenuList.add(new DrawerMenu("NewsFeed", R.drawable.news_feed_icon, () -> {
            viewPager.setCurrentItem(MainPage.FEED_TAB_INDEX);
            closeDrawer();
        }));

        drawerMenuList.add(new DrawerMenu("My Connections", R.drawable.my_connections_icon_1, () -> {
            viewPager.setCurrentItem(MainPage.CONNECTION_TAB_INDEX);
            closeDrawer();
        }));

        drawerMenuList.add(new DrawerMenu("My Networks", R.drawable.my_network_icon, () -> {
            viewPager.setCurrentItem(MainPage.NETWORK_TAB_INDEX);
            closeDrawer();
        }));

        if (isBussinessEmail()) {
            drawerMenuList.add(new DrawerMenu("My Dealers", R.drawable.my_dealers_icon_1, () -> {
                viewPager.setCurrentItem(MainPage.DEALER_TAB_INDEX);
                closeDrawer();
            }));
        }


        drawerMenuList.add(new DrawerMenu("Marketplace", R.drawable.market_place_icon_menu, () -> {
            gotoMarketPlace(context);
        }));


        drawerMenuList.add(new DrawerMenu("My Listings", R.drawable.my_listings_icon, () -> {
            Intent intent = new Intent(context, MyListingPage.class);
            intent.putExtra("currentItem", 0);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        }));

        drawerMenuList.add(new DrawerMenu("Add Listings", R.drawable.add_listing_icon, () -> {
            gotoAddListings(context);
        }));


        drawerMenuList.add(new DrawerMenu("Invite/Manage Connections", "+", R.drawable.invite_connections_icon, manageAccountsItems));
        drawerMenuList.add(new DrawerMenu("Settings", "+", R.drawable.settings_icon, profileListItems));
        // drawerMenuList.add(new DrawerMenu("Notification Settings", "", new ArrayList<DrawerSubItem>()));
        drawerMenuList.add(new DrawerMenu("Help & Support", "+", R.drawable.help_and_support_icon, helpAndSupportItems));


        drawerMenuList.add(new DrawerMenu("Log out", R.drawable.logout_icon, () -> logOut()));
    }

    public void gotoMarketPlace(Context context) {
        Intent intent = new Intent(context, MarketPlacePage.class);
        intent.putExtra("currentItem", 0);
        intent.putExtra("TypeOfMarketPlace", Constants.NETWORK_MARKET_PLACE);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    public void gotoAddListings(Context context){
        Intent intent = new Intent(context, AddListing.class);
        intent.putExtra("currentItem", 0);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    public void gotoUserProfileActivityResult(Context context) {
        Intent intent = new Intent(context, UserProfileView.class);
        intent.putExtra("userId", preference.getString(Constants.USER_ID));
        intent.putExtra("userName", preference.getString(Constants.FIRST_NAME));
        intent.putExtra("IsPersonalProfile", true);
        intent.putExtra("shouldUpdateBackScreen", true);
        startActivityForResult(intent, MainPage.EDIT_PROFILE_CODE);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    public void openWebViewPages(Context context, String type) {
        Intent intent = new Intent(context, HelpAndSupportWebViews.class);
        intent.putExtra("web_view_type", type);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    public void setDrawerNavigation() {
        DeviceInfo deviceInfo = getDeviceResolution();
        navigationView.getLayoutParams().width = (int) (deviceInfo.getDeviceWidth() * 0.76);
        // toolbar = (Toolbar) findViewById(R.id.toolbar);


        //  toolbar.setNavigationIcon(new DrawerArrowDrawable(this));
        iconImg.setOnClickListener(v -> {
            Log.e("Drawer Open", "yes");
            if (drawerLayout.isDrawerOpen(navigationView)) {
                drawerLayout.closeDrawer(navigationView);
            } else {
                drawerLayout.openDrawer(navigationView);
            }
        }
        );
        drawerLayout.setScrimColor(Color.TRANSPARENT);
        drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                contentView.setScaleX(offsetScale);
                contentView.setScaleY(offsetScale);

                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView.setTranslationX(xTranslation);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                showHideDiscoverFocus(false);
            }
        });
    }

    private void setDrawerActions(final Context context) {
        expandCollapseBtn = findViewById(R.id.expand_collapse_btn);
        expandableContent = findViewById(R.id.expandable_content);
        expandableImg = findViewById(R.id.expand_img);

        expandCollapseBtn.setOnClickListener(view -> {
            if (expandableContent.getVisibility() == View.INVISIBLE || expandableContent.getVisibility() == View.GONE) {
                AnimationUtils.expand(expandableContent);
                expandableImg.setImageDrawable(context.getResources().getDrawable(R.drawable.minus_img));
                expandableImg.getLayoutParams().width = (int) AppUtils.convertDpToPixel(15f, context);
            } else {

                AnimationUtils.collapse(expandableContent);
                expandableImg.setImageDrawable(context.getResources().getDrawable(R.drawable.plus_img));
                expandableImg.getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
            }
        });
    }


    /**
     * keyboard
     */
    public void hideKeyBoard() {
        try {
            InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        } catch (Exception ex) {

        }


    }


    public void hideFocusKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    /**
     * Log out with cache clear
     */
    public void logOut() {


        getAPI().logOut(preference.getString(Constants.ACCESS_TOKEN), preference.getInt(Constants.HISTORY_ID)).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                if (response.isSuccessful()) {
                    //  if (response.body().getStatus().equals("success")) {

                    //notification clear
                    NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.cancelAll();

                    clearCache();

                    //new page
                    Intent mainIntent = new Intent(getApplicationContext(), FirstPage.class);
                    startActivity(mainIntent);
                    finish();
                    //    }
                }
                // Toast.makeText(context, "logout", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {

            }
        });

    }

    public void clearCache() {
        //preferences clear
        preference.clearSavedInSharedPreference();//for logout

        //clear the database
        KrankRoomDataBase db = KrankRoomDataBase.getDatabase(BaseActivity.this.getApplication());
        AppExecutors.getInstance().diskIO().execute(() -> {
            db.clearAllTables();
        });

        //flags
        Constants.USER_IMG = false;
        Constants.COVER_IMG = false;
        Constants.COMPANY_COVER_IMG = false;
        Constants.COMPANY_IMG = false;

        //disable sync
        SyncUtils.disableSync();
        SyncUtils.removeAccount(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //overridePendingTransition(R.anim.activity_close_translate,R.anim.activity_open_scale);
        overridePendingTransition(R.anim.right_to_left1, R.anim.right_to_left2);
    }

    /**
     * Api Response
     */
    public void onResponseFailure() {
        Toast.makeText(getApplicationContext(), Constants.ERROR_MSG_TOAST_1, Toast.LENGTH_SHORT).show();
    }

    /**
     * Toast
     */
    public void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    public AlertDialog getLogOutDialog() {
        return makeDialog(BaseActivity.this, "Logout", "You are Logout", "logout", (dialogInterface, i) -> {
            logOut();
        });
    }

    public AlertDialog makeDialog(@NonNull Context context, @NonNull String title, @NonNull String msg,
                                  @NonNull String positiveBtnText, @Nullable
                                  @NonNull DialogInterface.OnClickListener positiveBtnClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(positiveBtnText, positiveBtnClickListener);

        AlertDialog alert = builder.create();
        return alert;
    }

    /*
     * Keyboard
     */
    public void showKeyboard(EditText editText) {
        editText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
    }

    /*
     * Invite Link
     */
    public void setInfoText(CompanyInvitationDataModel companyInvitationDataModel, TextView info_text) {

        String inviteString;

        if (preference.getString(Constants.TYPE_OF_INVITATION).equals("p")) {
            inviteString = "You have been privately invited by ";
        }else{
            inviteString = "You have been invited by ";
        }


        String fromString = " from ";

        SpannableStringBuilder builder = new SpannableStringBuilder();

        SpannableString inviteText = new SpannableString(inviteString);
        inviteText.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.AppDarkGray)), 0, inviteString.length(), 0);
        builder.append(inviteText);

        SpannableString username = new SpannableString(companyInvitationDataModel.getUser_name());
        username.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.drawer_background)), 0, companyInvitationDataModel.getUser_name().length(), 0);
        builder.append(username);

        SpannableString fromText = new SpannableString(fromString);
        fromText.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.AppDarkGray)), 0, fromString.length(), 0);
        builder.append(fromText);

        //SpannableString companytxt = new SpannableString("\n" + companyInvitationDataModel.getCompany_name());
        SpannableString companytxt = new SpannableString(companyInvitationDataModel.getCompany_name());
        companytxt.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.drawer_background)), 0, companytxt.length(), 0);
        builder.append(companytxt);


        if (preference.getString(Constants.TYPE_OF_INVITATION).equals("d")) {

            SpannableString asAString = new SpannableString(" As a ");
            asAString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.AppDarkGray)), 0, asAString.length(), 0);
            builder.append(asAString);

            //company name
            SpannableString companytxt_1 = new SpannableString(companyInvitationDataModel.getCompany_name());
            companytxt_1.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.drawer_background)), 0, companytxt_1.length(), 0);
            builder.append(companytxt_1);

            SpannableString dealerString = new SpannableString(" Dealer");
            dealerString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.AppDarkGray)), 0, dealerString.length(), 0);
            builder.append(dealerString);
        }

        info_text.setText(builder, TextView.BufferType.SPANNABLE);
    }

    /*
     * Phone verification
     */
    public boolean isPhoneNumberVerified() {
        if (preference.getString(Constants.VERIFY_PHONE_NUM_STATUS) == null) return false;
        return preference.getString(Constants.VERIFY_PHONE_NUM_STATUS).toLowerCase().equals("yes");
    }

    /**
     * Free Account
     */
    public boolean isBussinessEmail() {
        return preference.getString(Constants.PACKAGE_ID).equals(Constants.BUSSINESS_EMAIL);
    }

    public CustomApplication getApplicationRef() {
        return (CustomApplication) getApplicationContext();
    }

    public void setViewPagerAndTabLayout(ViewPager mViewPager, TabLayout mCustomTabLayout, ArrayList<BaseFragment> pages, int offscreenLimit,int initialPage) {
        //fonts
        mTypefaceBold = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_BOLD);
        mTypefaceNormal = Typeface.createFromAsset(this.getAssets(), Constants.ROBOTO_NORMAL);


        mViewPager.setAdapter(new CustomFragmentStatePagerAdapter(getSupportFragmentManager(), pages));
        mCustomTabLayout.setupWithViewPager(mViewPager);

        mViewPager.setOffscreenPageLimit(offscreenLimit);

        //config
        setInitialTabLayoutConfig(mCustomTabLayout,initialPage);

        //listener
        mCustomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
                TextView text = (TextView) tab.getCustomView();
                text.setTypeface(mTypefaceBold);
                text.setTextColor(getResources().getColor(R.color.AppDarkGray));
                text.setTextSize(Constants.TAB_TEXT_SIZE);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TextView text = (TextView) tab.getCustomView();

                text.setTypeface(mTypefaceNormal);
                text.setTextColor(getResources().getColor(R.color.drawerGray));
                text.setTextSize(Constants.TAB_TEXT_SIZE);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

        });
    }

    private void setInitialTabLayoutConfig(TabLayout mCustomTabLayout,int initialPage) {
        for (int i = 0; i < mCustomTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mCustomTabLayout.getTabAt(i);
            if (tab != null) {
                TextView tabTextView = new TextView(this);
                tab.setCustomView(tabTextView);

                tabTextView.getLayoutParams().width = ViewGroup.LayoutParams.WRAP_CONTENT;
                tabTextView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;

                tabTextView.setTextColor(getResources().getColor(R.color.drawerGray));
                tabTextView.setTypeface(mTypefaceNormal);
                tabTextView.setTextSize(Constants.TAB_TEXT_SIZE);

                tabTextView.setText(tab.getText());

                // First tab is the selected tab, so if i==0 then set BOLD typeface
                if (i == initialPage) {
                    tabTextView.setTypeface(mTypefaceBold);
                    tabTextView.setTextColor(getResources().getColor(R.color.AppDarkGray));
                }

            }

        }
    }


    public String getQueryStringUrl(String url) {
        return url + "?android_app=1";
    }


    public Boolean isReadContactsPermissionAllowed() {
        return (AppUtils.isPermissionAllowed(this, Manifest.permission.READ_CONTACTS));
    }

    public void requestContactsPermission() {
        AppUtils.requestPermissions(CONTACTS_PERMISSION, this, new String[]{Manifest.permission.READ_CONTACTS});
    }

    public int getInviteUserId() {
        if (!isInviteLinkDataExists()) {
            return 0;
        }
        CompanyInvitationDataModel obj = gson.fromJson(preference.getString(Constants.INVITATION_RESPONSE_DATA), CompanyInvitationDataModel.class);
        return obj.getUser_id();

    }

    public boolean isInviteLinkDataExists(){
        return !(preference.getString(Constants.INVITATION_RESPONSE_DATA).isEmpty());
    }
    public void proceedAfterUserSuccessFullLogin(String device_name, CustomCallBack callBack) {

        getApplicationRef().assignDeviceId();

        sendPushNotificationToken(device_name);

        if (isInviteLinkDataExists()) {
            companyAcceptInvitation(preference.getString(Constants.INVITATION_CODE), preference.getString(Constants.TYPE_OF_INVITATION), callBack);
            return;
        }
        callBack.act();
        return;
    }

    private void sendPushNotificationToken(String device_name) {
        final String device_id = device_name;


        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }
                    final String token = task.getResult().getToken();
                    getAPI().sendPushNotificationToken(preference.getString(Constants.ACCESS_TOKEN), device_id, token, "", Constants.ANDROID_DEVICE).enqueue(new Callback<GeneralResponse>() {
                        @Override
                        public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                            if (response.isSuccessful()) {
                                preference.setString(Constants.FIREBASE_TOKEN, token);
                            }
                        }

                        @Override
                        public void onFailure(Call<GeneralResponse> call, Throwable t) {

                        }
                    });
                });
    }

    public void clearInviteLocalCache(){
        preference.removeValue(Constants.TYPE_OF_INVITATION);
        preference.removeValue(Constants.INVITATION_CODE);
        preference.removeValue(Constants.INVITATION_RESPONSE_DATA);
    }

    private void companyAcceptInvitation(String code, String dealerString, CustomCallBack customCallBack) {
        getAPI().companyAcceptInvitation(preference.getString(Constants.ACCESS_TOKEN), code, dealerString).enqueue(new Callback<GeneralResponse>() {
            @Override
            public void onResponse(Call<GeneralResponse> call, Response<GeneralResponse> response) {
                clearInviteLocalCache();
                customCallBack.act();
            }

            @Override
            public void onFailure(Call<GeneralResponse> call, Throwable t) {
                clearInviteLocalCache();
                customCallBack.act();
            }
        });
    }

    private void updateSyncTimeStamps(String last_sync_date) {

        //  if (preference.getLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP) <= 0) {
        preference.setLong(Constants.LAST_CONTACT_UPDATE_TIME_STAMP, DateTimeUtils.convertUTCToLocalDeviceTime(last_sync_date));
        preference.setLong(Constants.LAST_CONTACT_DELETE_TIME_STAMP, DateTimeUtils.convertUTCToLocalDeviceTime(last_sync_date));
        // }
    }

    public void onSignStepOneSuccess(Activity activity,Response<SignupOneResponse> response,String email){
        Intent intent = new Intent(activity, SignUpPage2.class);
        preference.setString(Constants.COMPANY_NAME, response.body().getCompanyName());




        intent.putExtra("user_email",email);


        if(response.body().getAccout_type().equals(Constants.FREE_COMPANY)){

            intent.putExtra("res_message",response.body().getMessage());
            intent.putExtra("email_template",response.body().getUrl_string());
            intent.putExtra("free_company",true);

        }
        else if(response.body().getAccout_type().equals(Constants.GENERIC_INVITE)){
            intent = new Intent(activity, SignUpPage3.class);
            preference.setBoolean(Constants.NEW_COMPANY, true);
            intent.putExtra("user_email",email);
        }
        else if (response.body().getAccout_type().equals(Constants.ALREADY_COMPANY)) {
            preference.setBoolean(Constants.NEW_COMPANY, false);
        } else {

            /**
             * First Company
             * */

            preference.setBoolean(Constants.NEW_COMPANY, true);
        }

        startActivity(intent);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        showAlert.dismiss();
    }

}
