package com.mobileapp.krank.Adapters;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobileapp.krank.Activities.CoWorkerAssignmentPage;
import com.mobileapp.krank.CallBacks.CallBackWithAdapterPosition;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.DataModel.PublicMarketPlaceAssignment;
import com.mobileapp.krank.ViewHolders.CommonViewHolder.ConnectionsListItemViewHolder;

import java.util.List;

public class CoWorkerListAdapter extends RecyclerView.Adapter<ConnectionsListItemViewHolder> implements CallBackWithAdapterPosition {
    private List<PublicMarketPlaceAssignment> items;
    CoWorkerAssignmentPage coWorkerAssignmentPage;
    public PublicMarketPlaceAssignment prevData;

    @Override
    public void act(int position) {
        if(prevData==null){
            coWorkerAssignmentPage.selectedIndex=position;
            prevData=items.get(position);
            items.get(position).setIsItemSelected(true);
            notifyDataSetChanged();
            return;
        }
        coWorkerAssignmentPage.selectedIndex=position;
        prevData.setIsItemSelected(false);
        items.get(position).setIsItemSelected(true);
        prevData = items.get(position);
        notifyDataSetChanged();
    }


    public CoWorkerListAdapter(List<PublicMarketPlaceAssignment> items, CoWorkerAssignmentPage coWorkerAssignmentPage) {
        this.items = items;
        this.coWorkerAssignmentPage = coWorkerAssignmentPage;
        prevData=null;
    }

    @Override
    public ConnectionsListItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_by_connection_dealer_item, parent, false);
        return new ConnectionsListItemViewHolder(v,this);
    }

    @Override
    public void onBindViewHolder(final ConnectionsListItemViewHolder holder, final int position) {
        final PublicMarketPlaceAssignment item = items.get(position);

       /* holder.item.setOnClickListener(v -> {
            if(prevData==null){
                coWorkerAssignmentPage.selectedIndex=position;
                prevData=item;
                item.setIsItemSelected(true);
                notifyDataSetChanged();
                return;
            }
            coWorkerAssignmentPage.selectedIndex=position;
            prevData.setIsItemSelected(false);
            item.setIsItemSelected(true);
            prevData = item;
            notifyDataSetChanged();
        });*/
        if (item.getIsItemSelected()) {
            holder.unCheckView.setVisibility(View.GONE);
            holder.checkedView.setVisibility(View.VISIBLE);
        } else {
            holder.unCheckView.setVisibility(View.VISIBLE);
            holder.checkedView.setVisibility(View.GONE);
        }
       // Glide.with(coWorkerAssignmentPage.getApplicationContext()).load(Constants.BASE_IMG_URL + item.getProfilePic()).into(holder.profile_image_view);
        holder.profile_image_view.setImageURI("" + item.getProfilePic());
        holder.people_name.setText( item.getFirstName()  + " " + item.getLastName());
        holder.company_name_text_view.setText(AppUtils.getCompanyAndDesignation(item.getCompanyName(),item.getDesignation()));

        holder.status_text.setVisibility(View.VISIBLE);

        if(item.getConnectionStatus().equals(Constants.CONNECTION_NOT_CONNECTED)){
            holder.status_text.setTextColor(ContextCompat.getColor(coWorkerAssignmentPage,R.color.redColor));
        }else{
            holder.status_text.setTextColor(ContextCompat.getColor(coWorkerAssignmentPage,R.color.drawer_background));
        }
        holder.status_text.setText("" + item.getConnectionStatus());

    }
    @Override
    public int getItemCount() {
        return items.size();
    }

}







