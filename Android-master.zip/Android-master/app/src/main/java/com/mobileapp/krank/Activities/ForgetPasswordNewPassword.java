package com.mobileapp.krank.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.mobileapp.krank.Base.BaseActivity;

import com.mobileapp.krank.Base.CustomApplication;
import com.mobileapp.krank.Functions.AppUtils;
import com.mobileapp.krank.Functions.Constants;
import com.mobileapp.krank.R;
import com.mobileapp.krank.ResponseModels.SigninResponse;
import com.mobileapp.krank.Utils.ApiUtils;

import cn.pedant.SweetAlert.SweetAlertDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPasswordNewPassword extends BaseActivity {

    private Button setPasswordBtn;
    //input fields
    private EditText password_edit_text, confirm_password_edit_text;
    private TextView error;
    //loader
    private SweetAlertDialog showProgressAlert;

    //invite text
    TextView info_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password_new_password);

        setScreenHeader("Forgot Password");
        setImageIntermsOfDeviceResolution();
        setKrankLogoForUserProfiling();

        //bottom links
        gotoLinkPage();

        //views
        setPasswordBtn = (Button) findViewById(R.id.setPasswordBtn);
        info_text = findViewById(R.id.info_text);
        //input fields
        password_edit_text = findViewById(R.id.password_edit_text);
        confirm_password_edit_text = findViewById(R.id.confirm_password_edit_text);

        error = findViewById(R.id.error_view);

        setPasswordBtn.setOnClickListener(view -> {

            setPasswordOnClickListener();
        });


        /*invitation text*/
        setInviteText(info_text);
        /*invitation text*/
    }

    private void setPasswordOnClickListener() {

        String pass = password_edit_text.getText().toString().trim();
        String cPass = confirm_password_edit_text.getText().toString().trim();

        if (pass.isEmpty()) {
            error.setText(Constants.ENTER_NEW_PASSWORD_TEXT);
        } else if (cPass.isEmpty()) {
            error.setText(Constants.RE_ENTER_NEW_PASSWORD_TEXT);
        } else if (!(pass.equals(cPass))) {
            error.setText(Constants.EQUAL_PASSWORD_TEXT);
        } else {
            showProgressAlert = showAlert(Constants.LOADING, SweetAlertDialog.PROGRESS_TYPE, false);
            showProgressAlert.show();

            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(task -> {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        final String token = task.getResult().getToken();
                        changePassword(getIntent().getStringExtra("USER_EMAIL"), getIntent().getStringExtra("FORGOT_VERIFY_CODE"), pass, cPass, token);

                    });
        }
    }

    private void changePassword(final String email, String code, final String pass, String cPass, String device_id) {
        getAPI().changePassword(email, code, pass, cPass, device_id,  AppUtils.getDeviceVersion(), AppUtils.getModel(), AppUtils.getManufacturer(), AppUtils.getDeviceId(this)).enqueue(new Callback<SigninResponse>() {
            @Override
            public void onResponse(Call<SigninResponse> call, Response<SigninResponse> response) {
                if (response.isSuccessful()) {
                    SigninResponse changePasswordResponse = response.body();
                    if (changePasswordResponse.getStatus().equals(Constants.SUCCESS_STATUS)) {
                        //set data in cache
                        setUserDataInSharedPreferences(changePasswordResponse);


                        CustomApplication app  = (CustomApplication)getApplicationContext();

                        proceedAfterUserSuccessFullLogin(AppUtils.getDeviceName(), () -> {
                            showProgressAlert.dismiss();
                            //goto main page
                            startActivity(getIntentToRedirectNextPage(ForgetPasswordNewPassword.this, app.listingUrl, app.pageToRedirect));
                            overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
                            finishAffinity();
                        });

                    } else {
                        showProgressAlert.dismiss();
                        error.setText(changePasswordResponse.getMessage());
                    }
                } else {
                    showProgressAlert.dismiss();
                    onResponseFailure();
                }
            }

            @Override
            public void onFailure(Call<SigninResponse> call, Throwable t) {
                showProgressAlert.dismiss();
                onResponseFailure();
            }
        });
    }

    private void proceed() {
        Intent intent = new Intent(ForgetPasswordNewPassword.this, MainPage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.left_to_right1, R.anim.left_to_right2);
        finishAffinity();
    }
}
