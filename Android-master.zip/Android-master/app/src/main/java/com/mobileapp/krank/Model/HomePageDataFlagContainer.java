package com.mobileapp.krank.Model;

public class HomePageDataFlagContainer {
    boolean isDataLoaded;
    String selectedId;

    public HomePageDataFlagContainer(boolean isDataLoaded) {
        this.isDataLoaded = isDataLoaded;
    }

    public HomePageDataFlagContainer(boolean isDataLoaded, String selectedId) {
        this.isDataLoaded = isDataLoaded;
        this.selectedId = selectedId;
    }

    public String getSelectedId() {
        return selectedId;
    }

    public void setSelectedId(String selectedId) {
        this.selectedId = selectedId;
    }

    public boolean isDataLoaded() {
        return isDataLoaded;
    }

    public void setDataLoaded(boolean dataLoaded) {
        isDataLoaded = dataLoaded;
    }
}
