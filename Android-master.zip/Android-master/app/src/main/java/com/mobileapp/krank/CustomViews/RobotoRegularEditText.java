package com.mobileapp.krank.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.mobileapp.krank.Functions.Constants;

/**
 * Created by ahmed on 7/18/2017.
 */

public class RobotoRegularEditText extends android.support.v7.widget.AppCompatEditText {
    Context context;
    InputMethodManager imm;

    public interface onPasteListener {
        void onPaste();
    }

    private onPasteListener onPasteListener;
    public RobotoRegularEditText(Context cntx) {
        super(cntx);
        context = cntx;
        this.setCustomFont(cntx);
        imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    public void requestFocus(Context cntx) {
        super.requestFocus();
        try {
            imm = (InputMethodManager) cntx.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);

        }catch (Exception e){}
    }

    public RobotoRegularEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setCustomFont(context);
    }

    public RobotoRegularEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        this.setCustomFont(context);
    }

    public void setCustomFont(Context context) {

        String fontName = "Roboto-Regular.ttf";
        if (getTypeface() != null && getTypeface().getStyle() == Typeface.BOLD) {
            fontName = "Roboto-Regular.ttf";
        }
        Typeface face1 = Typeface.createFromAsset(context.getAssets(), "fonts/" + fontName);
        setTypeface(face1);
    }

    public void closeKeyboard(Context cntx){
        InputMethodManager imm =  (InputMethodManager) cntx.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(this.getWindowToken(),0);
    }

    @Override
    public boolean onTextContextMenuItem(int id) {
        // Do your thing:
        boolean consumed = super.onTextContextMenuItem(id);
        // React:
        switch (id){
            case android.R.id.cut:
                onTextCut();
                break;
            case android.R.id.paste:
                onTextPaste();
                break;
            case android.R.id.copy:
                onTextCopy();
        }
        return consumed;
    }

    public void onTextCut(){

    }

    /**
     * Text was copied from this EditText.
     */
    public void onTextCopy(){


    }

    /**
     * Text was pasted into the EditText.
     */
    public void onTextPaste(){
        if(onPasteListener!=null){
            onPasteListener.onPaste();
        }
    }

    public void setOnPasteListener(onPasteListener listener) {
        onPasteListener = listener;
    }

    @Override
    public void setError(CharSequence error) {
        super.setError(error,null);
    }
}

