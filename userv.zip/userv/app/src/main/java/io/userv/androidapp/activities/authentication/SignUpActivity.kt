package io.userv.androidapp.activities.authentication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import io.userv.androidapp.R
import io.userv.androidapp.activities.MainActivity
import kotlinx.android.synthetic.main.activity_sign_up.*

class SignUpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        sign_up_btn.setOnClickListener{
            startActivity(Intent(this, PhoneVerificationActivity::class.java))
        }
    }
}
