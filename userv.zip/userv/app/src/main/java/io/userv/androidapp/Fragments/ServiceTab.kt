package io.userv.androidapp.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.adapters.ServiceAdapter
import io.userv.androidapp.base.BaseFragment
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R
import io.userv.androidapp.activities.ServiceDetail
import java.util.ArrayList

class ServiceTab(title2 : String) : BaseFragment(){

    private var listItems  = ArrayList<String>()

    init {
        title=title2
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =  inflater.inflate(R.layout.service_tab, container, false)
        fragmentView = view

        prepareListItems()
        setUpAdapter()


        return view
    }

    private fun prepareListItems(){
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
    }

    private fun setUpAdapter(){
        var mRecyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        var mAdapter  = ServiceAdapter(listItems, object:AdapterItemClickListener<String>{
            override fun <V : View> act(item: String?, type: Int, view: V?) {
                startActivity(Intent (activity, ServiceDetail::class.java))
            }
        })
        mRecyclerView.adapter = mAdapter
        mRecyclerView.layoutManager = GridLayoutManager(context,2)
    }
}