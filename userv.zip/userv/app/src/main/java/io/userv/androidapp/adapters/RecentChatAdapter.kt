package io.userv.androidapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R
import io.userv.androidapp.ViewHolders.RecentChatViewHolder

class RecentChatAdapter(private var list: MutableList<String>, private var callBack: AdapterItemClickListener<String>) :
    RecyclerViewBaseAdapter<String>(list) {
    override fun onBind(viewHolder: RecyclerView.ViewHolder, item: String, position: Int) {
        if (viewHolder is RecentChatViewHolder) {
            viewHolder.onBind(item)
        }
    }

    override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.recent_chat_item, parent, false)
        return RecentChatViewHolder(v, callBack)
    }

}