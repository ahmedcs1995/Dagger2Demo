package io.userv.androidapp.activities.Profile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import io.userv.androidapp.Fragments.ServiceTab
import io.userv.androidapp.R
import io.userv.androidapp.adapters.CustomFragmentStatePagerAdapter
import io.userv.androidapp.base.BaseFragment
import java.util.ArrayList

class UserProfile : AppCompatActivity() {

    private lateinit var mViewPager : ViewPager
    private lateinit var mTabLayout : TabLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        setViewPagerAndTabLayout()
    }

    private fun setViewPagerAndTabLayout() {
        mViewPager = findViewById(R.id.viewPager)
        mTabLayout = findViewById(R.id.tabs)
        val pages = ArrayList<BaseFragment>()


        pages.add(ServiceTab("My Posts"))
        pages.add(ServiceTab("Liked"))


        mViewPager.adapter = CustomFragmentStatePagerAdapter(supportFragmentManager, pages)

        mTabLayout.setupWithViewPager(mViewPager)

        mViewPager.offscreenPageLimit = pages.size
    }
}
