package io.userv.androidapp.CallBacks

import android.view.View

@FunctionalInterface
interface AdapterItemClickListener<D>{
    fun <V : View> act(item : D?,type : Int,view : V?)
}