package io.userv.androidapp.activities.chat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.adapters.MessageAdapter
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R
import java.util.ArrayList

class ChatActivity : AppCompatActivity() , AdapterItemClickListener<String> {
    override fun <V : View> act(item: String?, type: Int, view: V?) {
        //
    }

    private var listItems  = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        prepareListItems()
        setUpAdapter()

    }
    private fun prepareListItems(){
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
    }

    private fun setUpAdapter(){
        var mRecyclerView = findViewById<RecyclerView>(R.id.recyclerview_chat_log)
        var mAdapter  = MessageAdapter(listItems,this@ChatActivity)
        mRecyclerView.adapter = mAdapter
        mRecyclerView.layoutManager = LinearLayoutManager(this@ChatActivity)
    }
}
