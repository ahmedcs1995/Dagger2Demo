package io.userv.androidapp.activities.authentication

import android.content.Intent
import android.os.Bundle
import io.userv.androidapp.R
import io.userv.androidapp.activities.MainActivity
import io.userv.androidapp.base.BaseActivity
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        login_btn.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finishAffinity()
        }

        sign_up_btn.setOnClickListener{
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        fb_login_btn.setOnClickListener {
            showToast("Not Implemented Yet")
        }
    }
}
