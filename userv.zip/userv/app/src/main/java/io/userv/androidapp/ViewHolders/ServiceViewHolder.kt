package io.userv.androidapp.ViewHolders

import android.net.Uri
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.facebook.drawee.view.SimpleDraweeView
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import com.facebook.common.util.UriUtil
import io.userv.androidapp.R


internal class ServiceViewHolder(var item: View,callBack : AdapterItemClickListener<String>) : RecyclerView.ViewHolder(item) {


    private var service_img : SimpleDraweeView = item.findViewById(R.id.service_img)
    init {
        item.setOnClickListener {
            if(adapterPosition < 0 || callBack == null) return@setOnClickListener
            callBack.act(null,1,item)
        }
    }

    fun onBind(item : String?){
        val uri = Uri.Builder()
            .scheme(UriUtil.LOCAL_RESOURCE_SCHEME) // "res"
            .path((R.drawable.professional_workout_trainer).toString())
            .build()
        service_img.setImageURI(uri)
    }
}