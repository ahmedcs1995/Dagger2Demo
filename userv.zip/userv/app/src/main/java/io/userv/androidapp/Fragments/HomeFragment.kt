package io.userv.androidapp.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import io.userv.androidapp.adapters.CustomFragmentStatePagerAdapter
import io.userv.androidapp.base.BaseFragment
import io.userv.androidapp.R
import java.util.ArrayList

class HomeFragment : BaseFragment() {

    private lateinit var mViewPager : ViewPager
    private lateinit var mTabLayout : TabLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =  inflater.inflate(R.layout.home_fragment, container, false)


        fragmentView = view

        setViewPagerAndTabLayout()


        return view
    }


    companion object {
        fun newInstance(): HomeFragment = HomeFragment()
    }

    private fun setViewPagerAndTabLayout() {
        mViewPager = findViewById(R.id.viewPager)
        mTabLayout = findViewById(R.id.tabs)
        val pages = ArrayList<BaseFragment>()


        pages.add(ServiceTab("Providing Service"))
        pages.add(ServiceTab("Seeking Service"))


        mViewPager.adapter = CustomFragmentStatePagerAdapter(this.childFragmentManager, pages)

        mTabLayout.setupWithViewPager(mViewPager)

        mViewPager.offscreenPageLimit = pages.size
    }
}