package io.userv.androidapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R
import io.userv.androidapp.ViewHolders.Chat.MessageLeft
import io.userv.androidapp.ViewHolders.Chat.MessageRight
import io.userv.androidapp.ViewHolders.RecentChatViewHolder

class MessageAdapter(private var list: MutableList<String>, private var callBack: AdapterItemClickListener<String>) :
    RecyclerViewBaseAdapter<String>(list) {
    companion object{
        const val MESSAGE_LEFT = 1
        const val MESSAGE_RIGHT = 2
    }
    override fun onBind(viewHolder: RecyclerView.ViewHolder, item: String, position: Int) {
        if (viewHolder is RecentChatViewHolder) {
            viewHolder.onBind(item)
        }
    }

    override fun onCreate(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
        if(i == MESSAGE_LEFT){
            return MessageLeft(LayoutInflater.from(parent.context).inflate(R.layout.message_left, parent, false), callBack)
        }

        return MessageRight(LayoutInflater.from(parent.context).inflate(R.layout.message_right, parent, false), callBack)
    }

    override fun getItemViewType(position: Int): Int {
        if(position%2 == 0){
            return MESSAGE_LEFT
        }
        return MESSAGE_RIGHT
    }

}