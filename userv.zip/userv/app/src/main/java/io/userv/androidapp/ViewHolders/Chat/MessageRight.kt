package io.userv.androidapp.ViewHolders.Chat


import android.view.View
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.CallBacks.AdapterItemClickListener


internal class MessageRight(var item: View, callBack : AdapterItemClickListener<String>) : RecyclerView.ViewHolder(item) {



    fun onBind(item : String?){
    }
}