package io.userv.androidapp.CustomViews

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.widget.TextView


class CustomFaView : TextView {
    constructor(context: Context) : super(context) {
        this.setCustomFont(context)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        this.setCustomFont(context)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        this.setCustomFont(context)
    }

    fun setCustomFont(context: Context) {
        val fontName = "fontawesome-webfont.ttf"
        val face1 = Typeface.createFromAsset(context.assets, "fonts/$fontName")
        typeface = face1
    }

}
