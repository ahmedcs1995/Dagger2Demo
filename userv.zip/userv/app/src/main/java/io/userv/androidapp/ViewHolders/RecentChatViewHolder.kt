package io.userv.androidapp.ViewHolders

import android.net.Uri
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.facebook.common.util.UriUtil
import com.facebook.drawee.view.SimpleDraweeView
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R

internal class RecentChatViewHolder(var item: View, callBack : AdapterItemClickListener<String>) : RecyclerView.ViewHolder(item) {


    private var user_img : SimpleDraweeView = item.findViewById(R.id.user_img)
    init {
        item.setOnClickListener {
            if(adapterPosition < 0 || callBack == null) return@setOnClickListener
            callBack.act(null,1,item)
        }
    }

    fun onBind(item : String?){
        val uri = Uri.Builder()
            .scheme(UriUtil.LOCAL_RESOURCE_SCHEME) // "res"
            .path((R.drawable.profile_img).toString())
            .build()
        user_img.setImageURI(uri)
    }
}