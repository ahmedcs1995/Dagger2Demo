package io.userv.androidapp.CustomViews

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.widget.Button


class AppButton : Button {
    constructor(context: Context) : super(context) {
        this.setCustomFont(context)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        this.setCustomFont(context)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        this.setCustomFont(context)
    }

    fun setCustomFont(context: Context) {
        var fontName = "AvenirLTStd-Heavy.otf"
        if (typeface != null && typeface.style == Typeface.BOLD) {
            fontName = "AvenirLTStd-Heavy.otf"
        }
        val face1 = Typeface.createFromAsset(context.assets, "fonts/$fontName")
        typeface = face1
    }
}
