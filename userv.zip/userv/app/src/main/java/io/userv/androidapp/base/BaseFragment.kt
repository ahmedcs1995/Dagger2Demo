package io.userv.androidapp.base

import android.view.View
import androidx.fragment.app.Fragment

open class BaseFragment : Fragment() {
    var title = ""
    var fragmentView: View? = null


    fun <T : View> findViewById(viewId: Int): T {
        return fragmentView!!.findViewById(viewId)
    }
}