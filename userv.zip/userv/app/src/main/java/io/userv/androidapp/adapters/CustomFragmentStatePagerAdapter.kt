package io.userv.androidapp.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import io.userv.androidapp.base.BaseFragment
import java.util.ArrayList

class CustomFragmentStatePagerAdapter(fm: FragmentManager, private var pages: ArrayList<BaseFragment>) :
    FragmentStatePagerAdapter(fm) {
    override fun getCount(): Int {
     return pages.size
    }


    override fun getItem(position: Int): Fragment {
        return pages[position]
    }

    override fun getPageTitle(position: Int): CharSequence {
        return if (pages[position] != null) pages[position].title else ""
    }
}