package io.userv.androidapp.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.userv.androidapp.activities.chat.ChatActivity
import io.userv.androidapp.adapters.RecentChatAdapter
import io.userv.androidapp.base.BaseFragment
import io.userv.androidapp.CallBacks.AdapterItemClickListener
import io.userv.androidapp.R
import java.util.ArrayList

class ChatFragment : BaseFragment(){

    private var listItems  = ArrayList<String>()

    init {
        title="Test Tab"
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =  inflater.inflate(R.layout.fragment_chat, container, false)
        fragmentView = view

        prepareListItems()
        setUpAdapter()


        return view
    }

    companion object {
        fun newInstance(): ChatFragment = ChatFragment()
    }
    private fun prepareListItems(){
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
        listItems.add("Test")
    }

    private fun setUpAdapter(){
        var mRecyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        var mAdapter  = RecentChatAdapter(listItems,object : AdapterItemClickListener<String> {
            override fun <V : View> act(item: String?, type: Int, view: V?) {
                //implement callbacks here
                startActivity(Intent(context, ChatActivity::class.java))
            }
        })
        mRecyclerView.adapter = mAdapter
        mRecyclerView.layoutManager = LinearLayoutManager(context)
    }
}