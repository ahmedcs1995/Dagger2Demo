package io.userv.androidapp.CustomViews

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.inputmethod.InputMethodManager
import android.widget.TextView

class AvenirBold : TextView {
    internal lateinit var context: Context
    internal lateinit var imm: InputMethodManager

    constructor(cntx: Context) : super(cntx) {
        context = cntx
        this.setCustomFont(cntx)
        imm = getContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    }

    fun requestFocus(cntx: Context) {
        super.requestFocus()
        try {
            imm = cntx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
        } catch (e: Exception) {
        }

    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        this.setCustomFont(context)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        this.setCustomFont(context)
    }

    fun setCustomFont(context: Context) {
        var fontName = "AvenirLTStd-Heavy.otf"
        if (typeface != null && typeface.style == Typeface.BOLD) {
            fontName = "AvenirLTStd-Heavy.otf"
        }
        val face1 = Typeface.createFromAsset(context.assets, "fonts/$fontName")
        typeface = face1
    }


    override fun setError(error: CharSequence) {
        super.setError(error, null)
    }
}



