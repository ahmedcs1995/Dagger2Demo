package io.userv.androidapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import io.userv.androidapp.Fragments.ChatFragment
import io.userv.androidapp.Fragments.HomeFragment
import io.userv.androidapp.R
import io.userv.androidapp.activities.Profile.UserProfile
import io.userv.androidapp.base.BaseActivity
import kotlinx.android.synthetic.main.toolbar_home.*

class MainActivity : BaseActivity() {

    private var navItem = 0

    // Lateinit var toolbar: ActionBar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // toolbar = supportActionBar!!
        val bottomNavigation: BottomNavigationView = findViewById(R.id.navigationView)
        setUpNavigationItemSelectListener(bottomNavigation)

        openDefaultFragment()

        view_profileBtn.setOnClickListener{
            startActivity(Intent(this, UserProfile::class.java))
        }

        view_addProfileBtn.setOnClickListener{
            showToast("Not Implemented Yet")
        }
    }

    private fun setUpNavigationItemSelectListener(bottomNavigation: BottomNavigationView) {
        bottomNavigation.setOnNavigationItemSelectedListener(BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home_page -> {
                    if(navItem != 0){
                        navItem = 0
                        val homeFragment = HomeFragment.newInstance()
                        openFragment(homeFragment)
                    }

                    return@OnNavigationItemSelectedListener true
                }
                R.id.add_service -> {
                    startActivity(Intent(this,ServicePost::class.java))

                    return@OnNavigationItemSelectedListener false
                }
                R.id.chat_page -> {
                    if(navItem != 2){
                        navItem = 2
                        val chatFragment = ChatFragment.newInstance()
                        openFragment(chatFragment)
                    }

                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        })
    }

    private fun openDefaultFragment() {
        val homeFragment = HomeFragment.newInstance()
        openFragment(homeFragment)
    }

    private fun openFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.container, fragment)
        transaction.commit()
    }
}
